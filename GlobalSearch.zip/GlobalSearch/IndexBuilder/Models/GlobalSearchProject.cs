﻿using Azure.Search.Documents.Indexes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IndexBuilder.Models
{
    public class GlobalSearchProject
    {
        [SimpleField(IsKey = true, IsFilterable = true, IsFacetable = true)]
        public string project_id { get; set; }
        [SearchableField(IsSortable = true, IsFilterable = true, IsFacetable = true)]
        public string erp_id { get; set; }
        [SearchableField(IsSortable = true, IsFilterable = true, IsFacetable = true)]
        public string project_manager { get; set; }
        [SearchableField(IsSortable = true, IsFilterable = true, IsFacetable = true)]
        public string customer_name { get; set; }
        [SearchableField(IsSortable = true, IsFilterable = true, IsFacetable = true)]
        public string customer_id { get; set; }
        [SearchableField]
        public List<GlobalSearchOffer> offer { get; set; } = new List<GlobalSearchOffer>();        
    }

    public class GlobalSearchOrder
    {
        [SearchableField(IsFilterable = true, IsFacetable = true)]
        public string order_id { get; set; }
        [SearchableField]
        public List<GlobalSearchService> service { get; set; } = new List<GlobalSearchService>();
    }

    public class GlobalSearchOffer
    {
        [SearchableField(IsFilterable = true, IsFacetable = true)]
        public string offer_id { get; set; }
        [SearchableField]
        public List<GlobalSearchOrder> order { get; set; } = new List<GlobalSearchOrder>();
    }

    public class GlobalSearchService
    {
        [SearchableField(IsFilterable = true, IsFacetable = true)]
        public string product_id { get; set; }
        [SearchableField(IsFilterable = true, IsFacetable = true)]
        public string service_id { get; set; }
        [SearchableField]
        public List<GlobalSearchMachine> machine { get; set; } = new List<GlobalSearchMachine>();
    }

    public class GlobalSearchMachine
    {
        [SearchableField(IsFilterable = true, IsFacetable = true)]
        public string machine_id { get; set; }
        [SearchableField(IsFilterable = true, IsFacetable = true)]
        public string machine_name { get; set; }
        [SearchableField(IsFilterable = true, IsFacetable = true)]
        public string machine_type{ get; set; }
    }
}
