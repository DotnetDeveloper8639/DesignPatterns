﻿using Azure;
using Azure.Search.Documents;
using Azure.Search.Documents.Indexes;
using Azure.Search.Documents.Indexes.Models;
using IndexBuilder.Models;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using Tenant.Service;
using System.Net.Http;
using System.Threading.Tasks;

namespace IndexBuilder
{
    internal class Program
    {
        private static IHost AppStartup()
        {
            //var builder = new ConfigurationBuilder();
            var host = Host.CreateDefaultBuilder() // Initialising the Host 
                                                   //.ConfigureServices((context, services) => { // Adding the DI container for configuration
                                                   //    services.RegisterTenantService(null);
                                                   //})
                        .Build(); // Build the Host

            return host;
        }
        static async Task Main(string[] args)
        {
            using var host = AppStartup();

            using var serviceScope = host.Services.CreateScope();
            var provider = serviceScope.ServiceProvider;

            //var tenantService = provider.GetRequiredService<ITenantService>();

            string serviceName = "dna-srch-westeurman-qa";//Environment.GetEnvironmentVariable("SERVICE_NAME"); // "dna-srch-westeurman-qa";
            string indexName = "blueprint-globalsearch";//Environment.GetEnvironmentVariable("INDEX_NAME"); //"blueprint-globalsearch";
            string apiKey = "d3KmxPeBdd0guITBdAI8GT9tAGrwE9C7migYU9sArGAzSeCRLDA1";//Environment.GetEnvironmentVariable("API_KEY"); //"d3KmxPeBdd0guITBdAI8GT9tAGrwE9C7migYU9sArGAzSeCRLDA1";
            string azureSearchDataSourceName = "blueprint-datasource";//Environment.GetEnvironmentVariable("AZURESEARCH_DATASOURCE_NAME"); //"blueprint-datasource";
            string tenantId = "6d525c42-c3cd-44f6-b3d7-aec5ec3b1202";//Environment.GetEnvironmentVariable("TENANT_ID"); //6d525c42-c3cd-44f6-b3d7-aec5ec3b1202
            //string connectionString = tenantService.GetTenantInfo(tenantId)?.Connectionstring ?? string.Empty;
            string connectionString = "Server=tcp:dna-sql-westeurman-dev01.database.windows.net,1433;Initial Catalog=DNA-Blueprint-Q-DB;Persist Security Info=False;User ID=blueprintschqdbln;Password=YEqxU5kA3P4m;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;";

            // Create a SearchIndexClient to send create/delete index commands
            Uri serviceEndpoint = new Uri($"https://{serviceName}.search.windows.net/");
            AzureKeyCredential credential = new AzureKeyCredential(apiKey);
            SearchIndexClient adminClient = new SearchIndexClient(serviceEndpoint, credential);
            SearchIndexerClient indexerClient = new SearchIndexerClient(serviceEndpoint, credential);

            // Create a SearchClient to load and query documents
            //SearchClient srchclient = new SearchClient(serviceEndpoint, indexName, credential);

            //UpdateSuggester();
            CreateIndex(indexName, adminClient);
            //CreateOrUpdateDatasource(connectionString, azureSearchDataSourceName, indexerClient);
            //CreateOrUpdateIndexer(indexerClient, azureSearchDataSourceName, indexName);

            Console.WriteLine("Indexer Refreshed successfully..!!");

            //using var client = new HttpClient();
            //var url = Environment.GetEnvironmentVariable("SEARCHENDPOINT");//"https://blueprint-q.dnaofsafety.net/api/offersvc/search";
            //var response = await client.GetAsync(url);

            //if (response.IsSuccessStatusCode)
            //{
            //    Console.WriteLine("Index Refreshed Successfully");
            //}
            //else
            //{
            //    throw new HttpRequestException(response.ReasonPhrase);
            //}
        }
        private static void CleanupSearchIndexClientResources(SearchIndexClient indexClient, SearchIndex index)
        {
            try
            {
                if (indexClient.GetIndex(index.Name) != null)
                {
                    indexClient.DeleteIndex(index.Name);
                }
            }
            catch (RequestFailedException e) when (e.Status == 404)
            {
                //if exception occurred and status is "Not Found", this is working as expected
                Console.WriteLine("Failed to find index and this is because it doesn't exist.");
            }
        }

        private static void CreateIndex(string indexName, SearchIndexClient adminClient)
        {
            FieldBuilder fieldBuilder = new FieldBuilder();
            var searchFields = fieldBuilder.Build(typeof(GlobalSearchProject));

            var definition = new SearchIndex(indexName, searchFields);
            CleanupSearchIndexClientResources(adminClient, definition);
            string suggesterName = "qa-suggester";

            var suggester = new SearchSuggester(suggesterName, new[] { "erp_id", "project_id", "project_manager", "customer_id", "customer_name", "offer/offer_id", "offer/order/order_id", "offer/order/service/product_id", "offer/order/service/service_id", "offer/order/service/machine/machine_type", "offer/order/service/machine/machine_name", "offer/order/service/machine/machine_id" });
            definition.Suggesters.Add(suggester);

            var cors_option = new CorsOptions(new List<string> { "*" });
            cors_option.MaxAgeInSeconds = 300;
            definition.CorsOptions = cors_option;

            adminClient.CreateOrUpdateIndex(definition);
        }

        private static void CreateOrUpdateDatasource(string connectionString
            ,string dataSourceName
            , SearchIndexerClient indexerClient)
        {

            string viewName = "ViewGlobalSearch";
            var dataSource =
                    new SearchIndexerDataSourceConnection(
                        dataSourceName,
                        SearchIndexerDataSourceType.AzureSql,
                        connectionString,
                        new SearchIndexerDataContainer(viewName));

            indexerClient.CreateOrUpdateDataSourceConnection(dataSource);
        }

        private static void CreateOrUpdateIndexer(SearchIndexerClient indexerClient,string dataSource,string indexName)
        {
            string indexerName = Environment.GetEnvironmentVariable("INDEXER_NAME"); //blueprint-azure-indexer

            FieldBuilder fieldBuilder = new FieldBuilder();
            var searchFields = fieldBuilder.Build(typeof(GlobalSearchProject));

            var definition = new SearchIndex(indexName, searchFields);

            var schedule = new IndexingSchedule(TimeSpan.FromMinutes(30))
            {
                StartTime = DateTimeOffset.Now
            };  
            var parameters = new IndexingParameters()
            {
                BatchSize = 100,
                MaxFailedItems = 0,
                MaxFailedItemsPerBatch = 0
            };
            var indexer = new SearchIndexer(indexerName,dataSource, indexName)
            {
                Description = "Data indexer",
                Schedule = schedule,
                Parameters = parameters,
                FieldMappings =
                  {
                      new FieldMapping("erp_id") {TargetFieldName = "erp_id"},
                      new FieldMapping("project_id") {TargetFieldName = "project_id"},
                      new FieldMapping("product_id") {TargetFieldName = "product_id"},
                      new FieldMapping("customer_name") {TargetFieldName = "customer_name"},
                      new FieldMapping("project_manager") {TargetFieldName = "project_manager"},
                      new FieldMapping("machine_name") {TargetFieldName = "machine_name"},
                      new FieldMapping("machine_type") {TargetFieldName = "machine_type"},
                      new FieldMapping("order_id") {TargetFieldName = "order_id"},
                      new FieldMapping("offer_id") {TargetFieldName = "offer_id"},
                      new FieldMapping("machine_id") {TargetFieldName = "machine_id"},
                      new FieldMapping("customer_id") {TargetFieldName = "customer_id"},
                      new FieldMapping("service_id") {TargetFieldName = "service_id"},
                  }
            };
            var suggester = new SearchSuggester("sg", new[] { "project_id", "customer_name", "product_id", "project_manager", "machine_name", "machine_type", "order_id", "offer_id", "machine_id", "customer_id", "service_id" });
            definition.Suggesters.Add(suggester);
            //CleanupSearchIndexerClientResources(indexerClient, indexer);
            indexerClient.CreateOrUpdateIndexerAsync(indexer);

            try
            {
                indexerClient.RunIndexerAsync(indexer.Name);
            }
            catch (Exception ex)
            {

            }
        }
        public static void UpdateSuggester()
        {
            string searchServiceEndpoint = "https://dna-srch-westeurman-qa.search.windows.net";
            string apiKey = "d3KmxPeBdd0guITBdAI8GT9tAGrwE9C7migYU9sArGAzSeCRLDA1";

            SearchIndexClient indexClient = new SearchIndexClient(new Uri(searchServiceEndpoint), new AzureKeyCredential(apiKey));
            string indexName = "blueprint-globalsearch";
            Response<SearchIndex> indexResponse = indexClient.GetIndex(indexName);
            SearchIndex existingIndex = indexResponse.Value;
            string suggesterName = "qa-suggester";

            // Create a new suggester definition or update the existing one
            var suggester = new SearchSuggester(suggesterName, new[] { "erp_id", "project_id", "project_manager", "customer_id", "customer_name", "offer/offer_id", "offer/order/order_id", "offer/order/service/product_id", "offer/order/service/service_id", "offer/order/service/machine/machine_type", "offer/order/service/machine/machine_name", "offer/order/service/machine/machine_id" });
            //existingIndex.Suggesters.Add(suggester);

            // Find the existing suggester in the index and replace it with the updated one
            bool suggesterIndex = existingIndex.Suggesters.Contains(suggester);
            if (suggesterIndex)
            {
                //existingIndex.Suggesters.Add = suggester;
            }
            else
            {
                // If the suggester doesn't exist, add it to the index
                existingIndex.Suggesters.Add(suggester);
            }

            // Update the index on the service
            indexClient.CreateOrUpdateIndex(existingIndex);

        }
    }
}
