﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Order.API.Helpers
{
    public class OrderDataRange
    {
        public const string WEEK = "week";
        public const string MONTH = "month";
        public const string DAY = "day";
    }
    public static class OrderStatus
    {
        public static string CREATED = "Created";
        public static string IN_PROGRESS = "In Progress";
        public static string COMPLETED = "Completed";
        public static string CANCELLED = "Cancelled";
        public static string BLOCKED = "Blocked";
    }
}
