﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Order.API.IntegrationEvents.NotificationEvents
{
    public class NotificationEvent
    {
        public string Message { get; set; }
    }
}
