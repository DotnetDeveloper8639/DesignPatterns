﻿using EventBus.Abstractions;
using System.Collections.Generic;

namespace Order.API.IntegrationEvents.Events
{
    public class ErpOrderResponseEvent
    {
        public RequestTechnicalHeader TechnicalHeader { get; set; }
        public ErpOrder Order { get; set; }
    }

    public class ErpService
    {
        public string ServiceID { get; set; }
        public string WBSID { get; set; }
        public string ServiceProductID { get; set; }
    }

    public class ErpOrder
    {
        public string ProjectID { get; set; }
        public string ERPProjectID { get; set; }
        public string OfferID { get; set; }
        public string ERPOrderID { get; set; }
        public string Status { get; set; }
        public List<ErpService> Services { get; set; }
    }
}
