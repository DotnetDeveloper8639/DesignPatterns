﻿using EventBus.Abstractions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Order.API.IntegrationEvents.Events;
using Order.API.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Order.API.Controllers
{
    [Authorize]
    [Route("/api/ordersvc")]
    [ApiController]
    public class OrderController : ControllerBase
    {
        public readonly IOrderService _repositoryService;
        private readonly IEventBus eventBus;
        public IDataProtector _protection;
        public readonly string offerSecurityString = "InpOrderUpR!@!$oTe*&*cti&onS%ch*em#aRsal!";
        public OrderController(IOrderService repositoryService
            , IDataProtectionProvider protection
            , IEventBus eventBus)
        {
            _repositoryService = repositoryService;
            this.eventBus = eventBus;
            //_protection = protection.CreateProtector(offerSecurityString);
        }

        /// <summary>
        /// To Get All orders
        /// </summary>
        /// <returns></returns>
        [Route("orders")]
        [Authorize(Roles = "Order.Read,Order.Write")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [Produces("application/json")]
        [HttpGet]
        public async Task<IActionResult> GetAllOrders()
        {
            var result = await _repositoryService.GetAllOrders();
            if (!result.Any())
            {
                return new JsonResult("No Records Found")
                {
                    StatusCode = StatusCodes.Status404NotFound
                };
            }
            return new JsonResult(result)
            {
                StatusCode = StatusCodes.Status200OK
            };
        }

        /// <summary>
        /// Get Order by OrderId
        /// </summary>
        /// <param name="orderId"></param>
        /// <returns></returns>
        [Route("{orderId}/orders")]
        [Authorize(Roles = "Order.Read,Order.Write")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [Produces("application/json")]
        [HttpGet]
        public async Task<IActionResult> GetOrderById(string orderId)
        {
            //var decryptedOrderId = _protection.Unprotect(orderId);
            var result = await _repositoryService.GetOrderById(orderId);

            if (result == null)
            {
                return new JsonResult("No Order Found")
                {
                    StatusCode = StatusCodes.Status404NotFound
                };
            }
            return new JsonResult(result)
            {
                StatusCode = StatusCodes.Status200OK
            };
        }

        /// <summary>
        /// Order effort metrics
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("effortsmetrics")]
        [Authorize(Roles = "Order.Read,Order.Write")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [Produces("application/json")]
        public IActionResult GetOfferMetricsdata()
        {
            var result = _repositoryService.GetOrderMetrics();
            if (result == null)
            {
                return new JsonResult("No Data Found")
                {
                    StatusCode = StatusCodes.Status404NotFound
                };
            }
            //return Ok(new JsonResult(result, StatusCodes.Status200OK));
            return new JsonResult(result)
            {
                StatusCode = StatusCodes.Status200OK
            };
        }

        [Route("erporderresponse")]
        [AllowAnonymous]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Produces("application/json")]
        [HttpPost]
        public async Task<IActionResult> ERPOrderProcess(ErpOrderResponseEvent erpOrderResponse)
        {
            eventBus.StoreState("salesorder_erp", erpOrderResponse);

            HttpContext.Items["CurrentTenantId"] = erpOrderResponse.TechnicalHeader.TenantID;
            _repositoryService.ProcessErpOrderResponse(erpOrderResponse);
            return Ok();
        }
        /// <summary>
        /// Project effort metrics
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("{dataRange}/dailymetrics")]
        [Authorize(Roles = "Order.Read,Order.Write")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [Produces("application/json")]
        public IActionResult GetOrderDailyMetrics(string dataRange)
        {
            try
            {
                var result = _repositoryService.GetOrderDailyEffortMetrics(dataRange);
                if (result == null)
                {
                    return new JsonResult("No Data Found") { StatusCode = StatusCodes.Status404NotFound };
                }
                return new JsonResult(result) { StatusCode = StatusCodes.Status200OK };
            }
            catch (Exception ex)
            {
                return null;
            }
        }
    }
}
