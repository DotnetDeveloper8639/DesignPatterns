using EventBus;
using EventBus.Abstractions;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Identity.Web;
using Microsoft.IdentityModel.Tokens;
using Order.API.DbContextClass;
using Order.API.Extensions;
using Order.API.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Tenant.Service;

namespace Order.API
{
    public class Startup
    {
        readonly string corsPolicy = "CORSPolicy";
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllers();
            services.AddTransient<OrderApiRatelimitMiddleware>();
            services.AddDaprClient(config =>
            config.UseJsonSerializationOptions(new System.Text.Json.JsonSerializerOptions()
            {
                PropertyNamingPolicy = null,
            }));

            services.AddTransient<IOrderService, OrderService>();
            services.AddSingleton<IEventBus, DaprEventBus>();

            services.AddDataProtection();

            services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme).AddJwtBearer(options =>
            {
                options.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidateLifetime = true,
                    ValidateIssuerSigningKey = true,
                    ValidIssuer = Environment.GetEnvironmentVariable("TOKEN_SERVER"),
                    ValidAudience = "blueprint-api",
                    IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(Environment.GetEnvironmentVariable("JWT_KEY")))
                };
            });

            // adds an authorization policy to make sure the token is for scope 'api1'
            services.AddAuthorization(options =>
            {
                options.AddPolicy("ApiScope", policy =>
                {
                    policy.RequireAuthenticatedUser();
                    policy.RequireClaim(ClaimTypes.Role);
                    policy.RequireClaim(ClaimConstants.TenantId);
                });
            });

            services.AddSwaggerGen(options =>
            {
                options.SwaggerDoc("v2", new Microsoft.OpenApi.Models.OpenApiInfo
                {
                    Title = "Order Service API",
                    Version = "v2",
                    Description = "Order service Schmersal",
                });
            });

            services.AddDbContext<Sch_Context>(ServiceLifetime.Scoped);

            services.AddHttpContextAccessor();
            services.RegisterTenantService(Configuration);

            services.AddCors(options =>
            {
                options.AddPolicy(name: corsPolicy,
                                  builder =>
                                  {
                                      builder.AllowAnyOrigin()
                        .AllowAnyMethod()
                        .AllowAnyHeader();
                                  });
            });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseCors(corsPolicy);

            app.UseRouting();

            app.UseSwagger(options =>
            {
                options.RouteTemplate = "order/swagger/{documentName}/swagger.json";
            });

            app.UseSwaggerUI(options =>
            {
                options.SwaggerEndpoint("/order/swagger/v2/swagger.json", "Order Service API");
                options.RoutePrefix = "order/swagger";
            });

            app.UseAuthentication();
            app.UseAuthorization();
            //Api Rate limit
            app.UseMiddleware<OrderApiRatelimitMiddleware>(100, TimeSpan.FromMinutes(1));
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
