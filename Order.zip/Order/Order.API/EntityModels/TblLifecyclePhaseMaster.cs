﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Order.API.EntityModels
{
    [Table("tblLifecyclePhaseMaster")]
    public class TblLifecyclePhaseMaster
    {
        [Key]
        [Column(TypeName = "nvarchar(50)")]
        public string id { get; set; }
        [Column(TypeName = "nvarchar(100)")]
        public string lifecycle_phase { get; set; }
    }
}
