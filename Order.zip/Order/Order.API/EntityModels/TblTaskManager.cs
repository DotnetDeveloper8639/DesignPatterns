﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Order.API.EntityModels
{
    [Table("tblTask")]
    public class TblTaskManager
    {
        [Key]
        [Column(TypeName = "nvarchar(50)")]
        public string id { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string task_id { get; set; }
        [Column(TypeName = "nvarchar(150)")]
        public string task_label { get; set; }
        [Column(TypeName = "nvarchar(150)")]
        public string task_title { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string priority { get; set; }
        [Column(TypeName = "nvarchar(255)")]
        public string description { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string assigned_to { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        [ForeignKey("TblUser")]
        public string user_id { get; set; }
        [Column(TypeName = "datetimeoffset(7)")]
        public DateTimeOffset due_date { get; set; }
        [Column(TypeName = "nvarchar(80)")]
        public string status { get; set; }
        [Column(TypeName = "datetimeoffset(7)")]
        public DateTimeOffset created_at { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string created_by { get; set; }
        [Column(TypeName = "datetimeoffset(7)")]
        public DateTimeOffset modified_at { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string modified_by { get; set; }

        public virtual TblUser TblUser { get; set; }
    }
}
