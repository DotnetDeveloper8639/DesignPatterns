﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Order.API.EntityModels
{
    [Table("tblMachineRoadmap")]
    public class TblMachineRoadmap
    {
        [Key]
        [Column(TypeName = "varchar(50)")]
        public string id { get; set; }
        [Column(TypeName = "varchar(50)")]
        public string service_machine_id { get; set; }
        [Column(TypeName = "varchar(50)")]
        public string roadmap_id { get; set; }
    }
}
