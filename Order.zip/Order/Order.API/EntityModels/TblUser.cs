﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Order.API.EntityModels
{
    [Table("tblUser")]
    public class TblUser
    {
        [Key]
        [Column(TypeName = "nvarchar(50)")]
        public string id { get; set; }
        [Column(TypeName = "nvarchar(80)")]
        public string first_name { get; set; }
        [Column(TypeName = "nvarchar(80)")]
        public string last_name { get; set; }
        [Column(TypeName = "nvarchar(160)")]
        public string display_name { get; set; }
        [Column(TypeName = "nvarchar(90)")]
        public string login_name { get; set; }
        [Column(TypeName = "nvarchar(150)")]
        public string email_address { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string role { get; set; }
    }
}
