﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Order.API.EntityModels
{
    [Table("tblOffer")]
    public class TblOffer
    {
        [Key]
        [Column(TypeName = "nvarchar(50)")]
        public string id { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string quote_type { get; set; }
        [Column(TypeName = "nvarchar(1000)")]
        public string notes { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        [ForeignKey("TblProject")]
        public string project_id { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        [ForeignKey("TblContact")]
        public string contact_id { get; set; }

        [Column(TypeName = "nvarchar(50)")]
        public string status { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        [ForeignKey("TblOfferKPI")]
        public string offer_kpi_id { get; set; }
        [Column(TypeName = "nvarchar(100)")]
        public string quote_template_type { get; set; }
        [Column(TypeName = "datetimeoffset(7)")]
        public DateTimeOffset created_at { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string created_by { get; set; }
        [Column(TypeName = "datetimeoffset(7)")]
        public DateTimeOffset modified_at { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string modified_by { get; set; }
        [Column("erp_wbs_id", TypeName = "nvarchar(100)")]
        public string WBSID { get; set; }
        public virtual TblProject TblProject { get; set; }
        public virtual TblContact TblContact { get; set; }
        public virtual TblOfferKPI TblOfferKPI { get; set; }
    }
}
