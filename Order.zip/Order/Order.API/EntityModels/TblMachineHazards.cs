﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Order.API.EntityModels
{
    [Table("tblMachineHazards")]
    public class TblMachineHazards
    {
        [Key]
        [Column(TypeName = "nvarchar(50)")]
        public string id { get; set; }
        [Column(TypeName = "nvarchar(100)")]
        public string name { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        [ForeignKey("HazardType")]
        public string hazard_type_id { get; set; }
        [Column(TypeName = "nvarchar(255)")]
        public string initial_hazard { get; set; }
        [Column(TypeName = "nvarchar(255)")]
        public string counter_measure { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        [ForeignKey("TblServiceMachine")]
        public string service_machine_id { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        [ForeignKey("TblStepMaster")]
        public string step_id { get; set; }
        [Column(TypeName = "varchar(50)")]
        [ForeignKey("TblUser")]
        public string user_id { get; set; }

        public virtual TblHazardType HazardType { get; set; }
        public virtual TblServiceMachine TblServiceMachine { get; set; }
        public virtual TblUser TblUser { get; set; }
        public virtual TblStepMaster TblStepMaster { get; set; }
    }
}
