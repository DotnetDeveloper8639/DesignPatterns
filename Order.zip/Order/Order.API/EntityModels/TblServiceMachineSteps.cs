﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Order.API.EntityModels
{
    [Table("tblServiceMachineSteps")]
    public class TblServiceMachineSteps
    {
        [Key]
        [Column(TypeName = "nvarchar(50)")]
        public string service_machine_steps_id { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string step_id { get; set; }
        [Column(TypeName = "bit")]
        public bool compliant { get; set; }
        [Column(TypeName = "bit")]
        public bool not_applicable { get; set; }
        [Column(TypeName = "bit")]
        public bool hazard { get; set; }
        [Column(TypeName = "varchar(50)")]
        public string servicemachine_id { get; set; }
        [Column(TypeName = "varchar(50)")]
        public string user_id { get; set; }
        [Column(TypeName = "bit")]
        public bool ispreferred { get; set; }
        [Column(TypeName = "datetimeoffset(7)")]
        public DateTimeOffset created_at { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string created_by { get; set; }
        [Column(TypeName = "datetimeoffset(7)")]
        public DateTimeOffset modified_at { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string modified_by { get; set; }
    }
}
