﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Order.API.EntityModels
{
    [Table("tblServiceMachine")]
    public class TblServiceMachine
    {
        [Key]
        [Column(TypeName = "nvarchar(50)")]
        public string id { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        [ForeignKey("TblService")]
        public string service_id { get; set; }
        [Column(TypeName = "nvarchar(80)")]
        [ForeignKey("TblMachine")]
        public string machine_id { get; set; }

        public virtual TblService TblService { get; set; }
        public virtual TblMachine TblMachine { get; set; }
    }
}
