﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Order.API.EntityModels
{
    [Table("tblMachineRoadmapAssociation")]
    public class TblMachineRoadmapAssociation
    {
        [Key]
        [Column(TypeName = "nvarchar(50)")]
        public string id { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        [ForeignKey("TblMachine")]
        public string machine_id { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        [ForeignKey("RoadmapMaster")]
        public string roadmap_id { get; set; }

        public virtual TblRoadmapMaster RoadmapMaster { get; set; }
        public virtual TblMachine TblMachine { get; set; }
    }
}
