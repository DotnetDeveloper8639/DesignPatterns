﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Order.API.EntityModels
{
    [Table("tblMachine")]
    public class TblMachine
    {
        [Key]
        [Column(TypeName = "nvarchar(80)")]
        public string id { get; set; }
        [Column(TypeName = "nvarchar(80)")]
        public string master_machine_id { get; set; }
        [Column(TypeName = "nvarchar(160)")]
        public string machine_name { get; set; }
        [Column(TypeName = "nvarchar(80)")]
        public string asset_id { get; set; }
        [Column(TypeName = "nvarchar(80)")]
        public string serial_number { get; set; }
        [Column(TypeName = "nvarchar(150)")]
        public string machine_description { get; set; }
        [Column(TypeName = "int")]
        public int estimated_hours { get; set; }
        [Column(TypeName = "nvarchar(80)")]
        public string machine_type { get; set; }
        [Column(TypeName = "nvarchar(100)")]
        public string machine_location { get; set; }
        [Column(TypeName = "nvarchar(100)")]
        public string industry_type { get; set; }
        [Column(TypeName = "datetimeoffset(7)")]
        public DateTimeOffset created_at { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string created_by { get; set; }
        [Column(TypeName = "datetimeoffset(7)")]
        public DateTimeOffset modified_at { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string modified_by { get; set; }

    }
}
