﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Order.API.EntityModels
{
    [Table("tblNotifications")]
    public class TblSchNotification
    {
        [Key]
        [Column(TypeName = "varchar(80)")]
        public string NotificationId { get; set; }
        [Column(TypeName = "nvarchar(80)")]
        public string Notification_Type { get; set; }
        [Column(TypeName = "nvarchar(80)")]
        public string Notification_Cat { get; set; }
        [Column(TypeName = "varchar(80)")]
        public string User_Id { get; set; }
        [Column(TypeName = "varchar(80)")]
        public string Tenant_Id { get; set; }
        [Column(TypeName = "nvarchar(80)")]
        public string Notification_Value { get; set; }
        [Column(TypeName = "nvarchar(80)")]
        public string Created_By { get; set; }
        [Column(TypeName = "DateTimeOffset")]
        public DateTimeOffset Created_Dt { get; set; }
        [Column(TypeName = "nvarchar(80)")]
        public string Modified_By { get; set; }
        [Column(TypeName = "DateTimeOffset")]
        public DateTimeOffset Modified_Dt { get; set; }
    }
}
