﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Order.API.EntityModels
{
    [Table("tblAuditEntry")]
    public class TblAuditEntry
    {
        [Key]
        [Column(TypeName = "nvarchar(50)")]
        public string id { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string project_id { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string erp_project_id { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string offer_id { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string service_id { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string order_id { get; set; }
        [Column(TypeName = "nvarchar(100)")]
        public string affected_table { get; set; }
        [Column(TypeName = "nvarchar(MAX)")]
        public string old_value { get; set; }
        [Column(TypeName = "nvarchar(MAX)")]
        public string new_value { get; set; }
        [Column(TypeName = "nvarchar(MAX)")]
        public string scope { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string action { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string user_id { get; set; }
        [Column(TypeName = "datetimeoffset(7)")]
        public DateTimeOffset created_at { get; set; }
    }
}
