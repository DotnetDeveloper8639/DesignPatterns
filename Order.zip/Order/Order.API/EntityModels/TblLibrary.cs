﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Order.API.EntityModels
{
    [Table("tblLibrary")]
    public class TblLibrary
    {
        [Key]
        [Column(TypeName = "varchar(50)")]
        public string id { get; set; }
        [Column(TypeName = "nvarchar(150)")]
        public string name { get; set; }
        [Column(TypeName = "nvarchar(100)")]
        public string type { get; set; }
        [Column(TypeName = "nvarchar(500)")]
        public string url { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string content_type { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string version { get; set; }
        [Column(TypeName = "nvarchar(500)")]
        public string preview_image_url { get; set; }
    }
}
