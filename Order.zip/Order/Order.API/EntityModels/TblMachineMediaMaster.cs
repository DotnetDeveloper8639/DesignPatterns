﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Order.API.EntityModels
{
    [Table("tblMachineMediaMaster")]
    public class TblMachineMediaMaster
    {
        [Key]
        [Column(TypeName = "nvarchar(50)")]
        public string id { get; set; }
        [Column(TypeName = "nvarchar(500)")]
        public string url { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string type { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string machine_limits { get; set; }
    }
}
