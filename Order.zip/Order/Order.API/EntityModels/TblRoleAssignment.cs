﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Order.API.EntityModels
{
    [Table("tblRoleAssignment")]
    public class TblRoleAssignment
    {
        [Key]
        [Column(TypeName = "nvarchar(50)")]
        public string id { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string user_or_group_id { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        [ForeignKey("TblRoles")]
        public string role_id { get; set; }

        public virtual TblRoles TblRoles { get; set; }
    }
}
