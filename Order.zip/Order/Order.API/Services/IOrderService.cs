﻿using Order.API.EntityModels;
using Order.API.IntegrationEvents.Events;
using Order.API.Models.ApiModels;
using Order.API.Models.OrderDTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Order.API.Services
{
    public interface IOrderService : IOrderRepositoryBase<TblOrder>
    {
        Task<List<OrderDTO>> GetAllOrders();
        Task<OrderDTO> GetOrderById(string orderId);
        //Task<List<OrderApiModel>> GetServiceStatus();
        Dictionary<string, int> GetOrderMetrics();

        Task ProcessErpOrderResponse(ErpOrderResponseEvent erpOrderResponse);
        Task<Dictionary<string, List<OrderEffortMetricsDTO>>> GetOrderDailyEffortMetrics(string range);
    }
}
