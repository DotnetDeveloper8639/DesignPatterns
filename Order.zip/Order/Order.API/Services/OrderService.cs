﻿using EventBus.Abstractions;
using EventBus.Events;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Identity.Web;
using Order.API.DbContextClass;
using Order.API.EntityModels;
using Order.API.Helpers;
using Order.API.IntegrationEvents.Events;
using Order.API.IntegrationEvents.NotificationEvents;
using Order.API.Models.ApiModels;
using Order.API.Models.OrderDTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace Order.API.Services
{
    public class OrderService : OrderRepositoryBase<TblOrder>, IOrderService
    {
        private readonly Sch_Context _context;
        private readonly IHttpContextAccessor httpContextAccessor;
        public IDataProtector _protection;
        public readonly string offerSecurityString = "InpOrderUpR!@!$oTe*&*cti&onS%ch*em#aRsal!";
        private readonly IEventBus eventBus;

        public OrderService(Sch_Context context
            , IDataProtectionProvider protection
            , IHttpContextAccessor httpContextAccessor
            , IEventBus _eventBus) : base(context)
        {
            _context = context;
            this.httpContextAccessor = httpContextAccessor;
            _protection = protection.CreateProtector(offerSecurityString);
            eventBus = _eventBus;
        }
        public async Task<List<OrderDTO>> GetAllOrders()
        {
            var result = new List<OrderDTO>();
            var userId = GetCurrentUserId();
            if (IsUserOrderManager())
                result = await (from order in _context.TblOrder
                                join offer in _context.TblOffers on order.offer_id equals offer.id
                                join project in _context.TblProjects on order.project_id equals project.id
                                join srv in _context.TblServices on order.service_id equals srv.id into srvGroup
                                from service in srvGroup.DefaultIfEmpty()
                                join customer in _context.TblCustomers on project.customer_id equals customer.id
                                join orderKpi in _context.TblOrderKPI on order.order_kpi_id equals orderKpi.id into orderKpiGroup
                                from ordKpi in orderKpiGroup.DefaultIfEmpty()
                                orderby order.created_at descending
                                select new OrderDTO
                                {
                                    Order_Id = order.id,
                                    Erp_Wbs_Id = offer.WBSID,
                                    Encryption_Order_Id = string.Empty, //_protection.Protect(order.id),
                                    Offer_Id = offer.id,
                                    Project_Id = project.id,
                                    Opportunity_Id = order.id,
                                    Service_Id = service.id,
                                    Start_Date = project.start_date.Value.ToString("dd/MM/yyyy"),
                                    End_Date = project.end_date.Value.ToString("dd/MM/yyyy"),
                                    Status = order.status,
                                    Purchase_Order_Id = "",
                                    Service_Type = service.service_type,
                                    Total_CalculatedHours = (from service in _context.TblServices.Where(s => s.id == order.service_id)
                                                     join sm in _context.TblServiceMachines on service.id equals sm.service_id
                                                     join hrs in _context.TblMachineHour on sm.id equals hrs.service_machine_id
                                                     select new
                                                     {
                                                         CalculatedHours = hrs.calculated_hours
                                                     }).Sum(s => s.CalculatedHours),
                                    Total_ActualHours = (from service in _context.TblServices.Where(s => s.id == order.service_id)
                                                     join sm in _context.TblServiceMachines on service.id equals sm.service_id
                                                     join actl in _context.TblActualHours on sm.id equals actl.service_machine_id
                                                     select new
                                                     {
                                                         ActualHours = actl.actualhours
                                                     }).Sum(s => s.ActualHours),
                                    TotalStepCount = (from service in _context.TblServices.Where(s => s.id == order.service_id)
                                                      join sm in _context.TblServiceMachines on service.id equals sm.service_id
                                                      join mr in _context.TblMachineRoadmap on sm.id equals mr.service_machine_id
                                                      join rm in _context.TblRoadmapMaster on mr.roadmap_id equals rm.roadmap_id
                                                      join section in _context.TblRoadmapSection on rm.roadmap_id equals section.roadmap_id
                                                      join subsection in _context.TblRoadmapSubSectionMster on section.id equals subsection.section_id
                                                      join step in _context.TblStepMaster on subsection.id equals step.roadmap_section_id
                                                      select new { }).Count(),
                                    TotalAnswredStepCount = (from service in _context.TblServices.Where(s => s.id == order.service_id)
                                                             join sm in _context.TblServiceMachines on service.id equals sm.service_id
                                                             join mr in _context.TblMachineRoadmap on sm.id equals mr.service_machine_id
                                                             join rm in _context.TblRoadmapMaster on mr.roadmap_id equals rm.roadmap_id
                                                             join section in _context.TblRoadmapSection on rm.roadmap_id equals section.roadmap_id
                                                             join subsection in _context.TblRoadmapSubSectionMster on section.id equals subsection.section_id
                                                             join step in _context.TblStepMaster on subsection.id equals step.roadmap_section_id
                                                             join smsteps in _context.TblServiceMachineSteps on new { a1 = step.step_id, a2 = sm.id, a3 = userId } equals new { a1 = smsteps.step_id, a2 = smsteps.servicemachine_id, a3 = smsteps.user_id }
                                                             select new { }).Count(),
                                    Progress = ordKpi == null ? 0 : ordKpi.roadmap_progress,
                                    Customer_Name = customer.customer_name,
                                    PO_Status = "",
                                    Erp_Order_Id = order.erp_order_id,
                                    Erp_Project_Id = order.erp_project_id,
                                    Erp_Service_Wbs_Id = service.erp_wbs_id
                                }).ToListAsync();
            else
                result = await (from order in _context.TblOrder
                                join offer in _context.TblOffers on order.offer_id equals offer.id
                                join project in _context.TblProjects on order.project_id equals project.id
                                join prjstaff in _context.TblProjectStaffs on new { userId = GetCurrentUserId(), projectId = project.id } equals new { userId = prjstaff.user_id, projectId = prjstaff.project_id }
                                join srv in _context.TblServices on order.service_id equals srv.id into srvGroup
                                from service in srvGroup.DefaultIfEmpty()
                                join customer in _context.TblCustomers on project.customer_id equals customer.id
                                join orderKpi in _context.TblOrderKPI on order.order_kpi_id equals orderKpi.id into orderKpiGroup
                                from ordKpi in orderKpiGroup.DefaultIfEmpty()
                                orderby order.created_at descending
                                select new OrderDTO
                                {
                                    Order_Id = order.id,
                                    Erp_Wbs_Id = order.erp_wbs_id,
                                    Encryption_Order_Id = String.Empty, //_protection.Protect(order.id),
                                    Offer_Id = offer.id,
                                    Project_Id = project.id,
                                    Opportunity_Id = order.id,
                                    Service_Id = service.id,
                                    Start_Date = project.start_date.Value.ToString("dd/MM/yyyy"),
                                    End_Date = project.end_date.Value.ToString("dd/MM/yyyy"),
                                    Status = order.status,
                                    Purchase_Order_Id = "",
                                    Service_Type = service.service_type,
                                    Total_CalculatedHours = (from service in _context.TblServices.Where(s => s.id == order.service_id)
                                                     join sm in _context.TblServiceMachines on service.id equals sm.service_id
                                                     join hrs in _context.TblMachineHour on sm.id equals hrs.service_machine_id
                                                     select new
                                                     {
                                                         CalculatedHours = hrs.calculated_hours
                                                     }).Sum(s => s.CalculatedHours),
                                    Total_ActualHours = (from service in _context.TblServices.Where(s => s.id == order.service_id)
                                                     join sm in _context.TblServiceMachines on service.id equals sm.service_id
                                                     join actl in _context.TblActualHours on sm.id equals actl.service_machine_id
                                                     select new
                                                     {
                                                         ActualHours = actl.actualhours
                                                     }).Sum(s => s.ActualHours),
                                    TotalStepCount = (from service in _context.TblServices.Where(s => s.id == order.service_id)
                                                      join sm in _context.TblServiceMachines on service.id equals sm.service_id
                                                      join mr in _context.TblMachineRoadmap on sm.id equals mr.service_machine_id
                                                      join rm in _context.TblRoadmapMaster on mr.roadmap_id equals rm.roadmap_id
                                                      join section in _context.TblRoadmapSection on rm.roadmap_id equals section.roadmap_id
                                                      join subsection in _context.TblRoadmapSubSectionMster on section.id equals subsection.section_id
                                                      join step in _context.TblStepMaster on subsection.id equals step.roadmap_section_id
                                                      select new { }).Count(),
                                    TotalAnswredStepCount = (from service in _context.TblServices.Where(s => s.id == order.service_id)
                                                             join sm in _context.TblServiceMachines on service.id equals sm.service_id
                                                             join mr in _context.TblMachineRoadmap on sm.id equals mr.service_machine_id
                                                             join rm in _context.TblRoadmapMaster on mr.roadmap_id equals rm.roadmap_id
                                                             join section in _context.TblRoadmapSection on rm.roadmap_id equals section.roadmap_id
                                                             join subsection in _context.TblRoadmapSubSectionMster on section.id equals subsection.section_id
                                                             join step in _context.TblStepMaster on subsection.id equals step.roadmap_section_id
                                                             join smsteps in _context.TblServiceMachineSteps on new { a1 = step.step_id, a2 = sm.id, a3 = userId } equals new { a1 = smsteps.step_id, a2 = smsteps.servicemachine_id, a3 = smsteps.user_id }
                                                             select new { }).Count(),
                                    Progress = ordKpi == null ? 0 : ordKpi.roadmap_progress,
                                    Customer_Name = customer.customer_name,
                                    PO_Status = "",
                                    Erp_Order_Id = order.erp_order_id,
                                    Erp_Project_Id = order.erp_project_id,
                                    Erp_Service_Wbs_Id = service.erp_wbs_id
                                }).ToListAsync();

            return result;
        }
        public async Task<OrderDTO> GetOrderById(string orderId)
        {
            var result = new OrderDTO();
            var userId = GetCurrentUserId();
            if (IsUserOrderManager())
                result = await (from order in _context.TblOrder
                                join project in _context.TblProjects on order.project_id equals project.id
                                join customer in _context.TblCustomers on project.customer_id equals customer.id
                                join ordkpi in _context.TblOrderKPI on order.order_kpi_id equals ordkpi.id into ordKpiGroup
                                from orderKpi in ordKpiGroup.DefaultIfEmpty()
                                join srv in _context.TblServices on order.service_id equals srv.id into srvGroup
                                from service in srvGroup.DefaultIfEmpty()
                                join servicekpi in _context.TblServiceKPI on service.service_kpi_id equals servicekpi.id into kpiGroup
                                from srvKpi in kpiGroup.DefaultIfEmpty()
                                where order.id == orderId
                                select new OrderDTO
                                {
                                    Order_Id = order.id,
                                    Erp_Order_Id = order.erp_order_id,
                                    Erp_Project_Id = project.erp_project_id,
                                    Erp_Wbs_Id = (from offer in _context.TblOffers
                                                  join orderTable in _context.TblOrder on offer.id equals orderTable.offer_id
                                                  where orderTable.id == order.id
                                                  select offer.WBSID).FirstOrDefault(),
                                    Encryption_Order_Id = _protection.Protect(order.id),
                                    Offer_Id = order.offer_id,
                                    Customer_Name = customer.customer_name,
                                    Phone_Number = customer.phone_number,
                                    Address_Line1 = string.Format("{0}: {1}", customer.street, customer.city, customer.country_code, customer.zipcode),
                                    Service_Id = service.id,
                                    Service_Type = service.service_type,
                                    Hours_Progress = orderKpi == null ? 0 : orderKpi.hours_progress,
                                    Calculated_Hours = orderKpi == null ? 0 : orderKpi.calculated_hours,
                                    Actual_progress = orderKpi == null ? 0 : orderKpi.hours_progress,
                                    Roadmap_Progress = orderKpi == null ? 0 : orderKpi.roadmap_progress,

                                    Services_Status = _context.TblServices.Where(s => s.id == order.service_id).Select(s => new ServiceDTO
                                    {
                                        Id = s.id,
                                        Service_Type = s.service_type,
                                        Project_Id = s.project_id,
                                        Offer_Id = s.offer_id,
                                        Contact_Id = s.contact_id,
                                        Service_Location = s.service_location,
                                        Status = order.status,
                                        Hours_Progress = srvKpi == null ? 0 : srvKpi.hours_progress,
                                        Calculated_Hours = srvKpi == null ? 0 : srvKpi.calculated_hours,
                                        Actual_progress = srvKpi == null ? 0 : srvKpi.hours_progress,
                                        Roadmap_Progress = srvKpi == null ? 0 : srvKpi.roadmap_progress,
                                        Total_CalculatedHours = (from service in _context.TblServices.Where(s => s.id == order.service_id)
                                                                 join sm in _context.TblServiceMachines on service.id equals sm.service_id
                                                                 join hrs in _context.TblMachineHour on sm.id equals hrs.service_machine_id
                                                                 select new
                                                                 {
                                                                     CalculatedHours = hrs.calculated_hours
                                                                 }).Sum(s => s.CalculatedHours),
                                        Total_ActualHours = (from service in _context.TblServices.Where(s => s.id == order.service_id)
                                                             join sm in _context.TblServiceMachines on service.id equals sm.service_id
                                                             join actl in _context.TblActualHours on sm.id equals actl.service_machine_id
                                                             select new
                                                             {
                                                                 ActualHours = actl.actualhours
                                                             }).Sum(s => s.ActualHours),
                                        TotalStepCount = (from service in _context.TblServices.Where(s => s.id == order.service_id)
                                                          join sm in _context.TblServiceMachines on service.id equals sm.service_id
                                                          join mr in _context.TblMachineRoadmap on sm.id equals mr.service_machine_id
                                                          join rm in _context.TblRoadmapMaster on mr.roadmap_id equals rm.roadmap_id
                                                          join section in _context.TblRoadmapSection on rm.roadmap_id equals section.roadmap_id
                                                          join subsection in _context.TblRoadmapSubSectionMster on section.id equals subsection.section_id
                                                          join step in _context.TblStepMaster on subsection.id equals step.roadmap_section_id
                                                          select new { }).Count(),
                                        TotalAnswredStepCount = (from service in _context.TblServices.Where(s => s.id == order.service_id)
                                                                 join sm in _context.TblServiceMachines on service.id equals sm.service_id
                                                                 join mr in _context.TblMachineRoadmap on sm.id equals mr.service_machine_id
                                                                 join rm in _context.TblRoadmapMaster on mr.roadmap_id equals rm.roadmap_id
                                                                 join section in _context.TblRoadmapSection on rm.roadmap_id equals section.roadmap_id
                                                                 join subsection in _context.TblRoadmapSubSectionMster on section.id equals subsection.section_id
                                                                 join step in _context.TblStepMaster on subsection.id equals step.roadmap_section_id
                                                                 join smsteps in _context.TblServiceMachineSteps on new { a1 = step.step_id, a2 = sm.id, a3 = userId } equals new { a1 = smsteps.step_id, a2 = smsteps.servicemachine_id, a3 = smsteps.user_id }
                                                                 select new { }).Count(),
                                    }).ToList(),
                                    Erp_Service_Wbs_Id = service.erp_wbs_id
                                }).FirstOrDefaultAsync();
            else
                result = await (from order in _context.TblOrder
                                join project in _context.TblProjects on order.project_id equals project.id
                                join prjstaff in _context.TblProjectStaffs on new { userId = GetCurrentUserId(), projectId = project.id } equals new { userId = prjstaff.user_id, projectId = prjstaff.project_id }
                                join customer in _context.TblCustomers on project.customer_id equals customer.id
                                join ordkpi in _context.TblOrderKPI on order.order_kpi_id equals ordkpi.id into ordKpiGroup
                                from orderKpi in ordKpiGroup.DefaultIfEmpty()
                                join srv in _context.TblServices on order.service_id equals srv.id into srvGroup
                                from service in srvGroup.DefaultIfEmpty()
                                join servicekpi in _context.TblServiceKPI on service.service_kpi_id equals servicekpi.id into kpiGroup
                                from srvKpi in kpiGroup.DefaultIfEmpty()
                                where order.id == orderId
                                select new OrderDTO
                                {
                                    Order_Id = order.id,
                                    Erp_Order_Id = order.erp_order_id,
                                    Erp_Project_Id = project.erp_project_id,
                                    Erp_Wbs_Id = order.erp_wbs_id,
                                    Encryption_Order_Id = _protection.Protect(order.id),
                                    Offer_Id = order.offer_id,
                                    Customer_Name = customer.customer_name,
                                    Phone_Number = customer.phone_number,
                                    Address_Line1 = string.Format("{0}: {1}", customer.street, customer.city, customer.country_code, customer.zipcode),
                                    Service_Id = service.id,
                                    Service_Type = service.service_type,
                                    Hours_Progress = orderKpi == null ? 0 : orderKpi.hours_progress,
                                    Calculated_Hours = orderKpi == null ? 0 : orderKpi.calculated_hours,
                                    Actual_progress = orderKpi == null ? 0 : orderKpi.hours_progress,
                                    Roadmap_Progress = orderKpi == null ? 0 : orderKpi.roadmap_progress,

                                    Services_Status = _context.TblServices.Where(s => s.id == order.service_id).Select(s => new ServiceDTO
                                    {
                                        Id = s.id,
                                        Service_Type = s.service_type,
                                        Project_Id = s.project_id,
                                        Offer_Id = s.offer_id,
                                        Contact_Id = s.contact_id,
                                        Service_Location = s.service_location,
                                        Status = order.status,
                                        Hours_Progress = srvKpi == null ? 0 : srvKpi.hours_progress,
                                        Calculated_Hours = srvKpi == null ? 0 : srvKpi.calculated_hours,
                                        Actual_progress = srvKpi == null ? 0 : srvKpi.hours_progress,
                                        Roadmap_Progress = srvKpi == null ? 0 : srvKpi.roadmap_progress,
                                        Total_CalculatedHours = (from service in _context.TblServices.Where(s => s.id == order.service_id)
                                                                 join sm in _context.TblServiceMachines on service.id equals sm.service_id
                                                                 join hrs in _context.TblMachineHour on sm.id equals hrs.service_machine_id
                                                                 select new
                                                                 {
                                                                     CalculatedHours = hrs.calculated_hours
                                                                 }).Sum(s => s.CalculatedHours),
                                        Total_ActualHours = (from service in _context.TblServices.Where(s => s.id == order.service_id)
                                                             join sm in _context.TblServiceMachines on service.id equals sm.service_id
                                                             join actl in _context.TblActualHours on sm.id equals actl.service_machine_id
                                                             select new
                                                             {
                                                                 ActualHours = actl.actualhours
                                                             }).Sum(s => s.ActualHours),
                                        TotalStepCount = (from service in _context.TblServices.Where(s => s.id == order.service_id)
                                                          join sm in _context.TblServiceMachines on service.id equals sm.service_id
                                                          join mr in _context.TblMachineRoadmap on sm.id equals mr.service_machine_id
                                                          join rm in _context.TblRoadmapMaster on mr.roadmap_id equals rm.roadmap_id
                                                          join section in _context.TblRoadmapSection on rm.roadmap_id equals section.roadmap_id
                                                          join subsection in _context.TblRoadmapSubSectionMster on section.id equals subsection.section_id
                                                          join step in _context.TblStepMaster on subsection.id equals step.roadmap_section_id
                                                          select new { }).Count(),
                                        TotalAnswredStepCount = (from service in _context.TblServices.Where(s => s.id == order.service_id)
                                                                 join sm in _context.TblServiceMachines on service.id equals sm.service_id
                                                                 join mr in _context.TblMachineRoadmap on sm.id equals mr.service_machine_id
                                                                 join rm in _context.TblRoadmapMaster on mr.roadmap_id equals rm.roadmap_id
                                                                 join section in _context.TblRoadmapSection on rm.roadmap_id equals section.roadmap_id
                                                                 join subsection in _context.TblRoadmapSubSectionMster on section.id equals subsection.section_id
                                                                 join step in _context.TblStepMaster on subsection.id equals step.roadmap_section_id
                                                                 join smsteps in _context.TblServiceMachineSteps on new { a1 = step.step_id, a2 = sm.id, a3 = userId } equals new { a1 = smsteps.step_id, a2 = smsteps.servicemachine_id, a3 = smsteps.user_id }
                                                                 select new { }).Count(),
                                    }).ToList(),
                                    Erp_Service_Wbs_Id = service.erp_wbs_id
                                }).FirstOrDefaultAsync();
            return result;
        }
        public Dictionary<string, int> GetOrderMetrics()
        {
            try
            {
                Dictionary<string, int> dataList = new();
                var result = _context.TblOrder.ToList();
                var totalOrders = result.Count != 0 ? result.Count : 0;
                var ordersInprogress = result.Count(p => p.status.ToLower() == OrderStatus.IN_PROGRESS.ToLower());
                var ordersCompleted = result.Count(p => p.status.ToLower() == OrderStatus.COMPLETED.ToLower());
                dataList.Add("TotalOrder", totalOrders);
                dataList.Add("OrdersInprogress", ordersInprogress);
                dataList.Add("OrdersCompleted", ordersCompleted);
                return dataList;
            }
            catch (Exception)
            {

                throw;
            }
        }
        /// <summary>
        /// Get Daily Metrics
        /// </summary>
        /// <param name="range"></param>
        /// <returns></returns>
        public async Task<Dictionary<string, List<OrderEffortMetricsDTO>>> GetOrderDailyEffortMetrics(string range)
        {
            try
            {
                var result = new Dictionary<string, List<OrderEffortMetricsDTO>>();
                result = range.ToLower() switch
                {
                    OrderDataRange.WEEK => GetWeekDataMetrics(),
                    OrderDataRange.MONTH => GetMonthMetrics(),
                    OrderDataRange.DAY => GetDayDataMetrics(),
                    _ => GetMonthMetrics(),
                };
                return result;
            }
            catch (Exception)
            {
                throw;
            }
        }
        /// <summary>
        /// Get Weekly Metrics
        /// </summary>
        /// <returns></returns>
        private Dictionary<string, List<OrderEffortMetricsDTO>> GetWeekDataMetrics()
        {
            try
            {
                Dictionary<string, List<OrderEffortMetricsDTO>> dataList = new();
                DateTime endDate = DateTime.Today;
                DateTime startDate = endDate.AddDays(-6);
                var totalOrders = Enumerable.Range(0, 7)
                    .Select(offset => startDate.AddDays(offset))
                          .Select(day => new OrderEffortMetricsDTO
                          {
                              DayOfWeek = day.DayOfWeek.ToString(),
                              Date = day.Date,
                              Data = _context.TblOrder
                                 .Where(e => e.created_at.Date.Date == day)
                                 .Count()
                          }).ToList();
                var ordersInprogress = Enumerable.Range(0, 7)
                    .Select(offset => startDate.AddDays(offset))
                          .Select(day => new OrderEffortMetricsDTO
                          {
                              DayOfWeek = day.DayOfWeek.ToString(),
                              Date = day.Date,
                              Data = _context.TblOrder
                                 .Where(e => e.status.ToLower() == OrderStatus.IN_PROGRESS.ToLower() && e.modified_at.Date.Date == day)
                                 .Count()
                          }).ToList();
                var ordersCompleted = Enumerable.Range(0, 7)
                    .Select(offset => startDate.AddDays(offset))
                          .Select(day => new OrderEffortMetricsDTO
                          {
                              DayOfWeek = day.DayOfWeek.ToString(),
                              Date = day.Date,
                              Data = _context.TblOrder
                                 .Where(e => e.status.ToLower() == OrderStatus.COMPLETED.ToLower() && e.modified_at.Date.Date == day)
                                 .Count()
                          }).ToList();
                dataList.Add("TotalOrder", totalOrders);
                dataList.Add("OrdersInprogress", ordersInprogress);
                dataList.Add("OrdersCompleted", ordersCompleted);
                return dataList;
            }
            catch (Exception)
            {

                throw;
            }
        }
        /// <summary>
        /// Get Monthly Metrics
        /// </summary>
        /// <returns></returns>
        private Dictionary<string, List<OrderEffortMetricsDTO>> GetMonthMetrics()
        {
            Dictionary<string, List<OrderEffortMetricsDTO>> dataList = new();
            DateTime endDate = DateTime.Today;
            DateTime startDate = endDate.AddDays(-29); // Subtract 29 to get the last 30 days
            var totalOrders = Enumerable.Range(0, 5)
                    .Select(week => startDate.AddDays(week * 7))
                    .Select((startOfWeek, index) => new OrderEffortMetricsDTO
                    {
                        WeekStartDate = startOfWeek,
                        WeekEndDate = startOfWeek.AddDays(6),
                        Data = _context.TblOrder
                                         .Where(e => e.created_at.Date >= startOfWeek && e.created_at.Date <= startOfWeek.AddDays(6))
                                         .Count(),
                        WeekCount = $"Week{index + 1}"
                    }).ToList();
            var ordersInprogress = Enumerable.Range(0, 5)
                .Select(week => startDate.AddDays(week * 7))
                .Select((startOfWeek, index) => new OrderEffortMetricsDTO
                {
                    WeekStartDate = startOfWeek,
                    WeekEndDate = startOfWeek.AddDays(6),
                    Data = _context.TblOrder
                                     .Where(e => e.status.ToLower() == OrderStatus.IN_PROGRESS.ToLower() && e.modified_at.Date >= startOfWeek && e.modified_at.Date <= startOfWeek.AddDays(6))
                                     .Count(),
                    WeekCount = $"Week{index + 1}"
                }).ToList();
            var ordersCompleted = Enumerable.Range(0, 5)
                .Select(week => startDate.AddDays(week * 7))
                .Select((startOfWeek, index) => new OrderEffortMetricsDTO
                {
                    WeekStartDate = startOfWeek,
                    WeekEndDate = startOfWeek.AddDays(6),
                    Data = _context.TblOrder
                                 .Where(e => e.status.ToLower() == OrderStatus.COMPLETED.ToLower() && e.modified_at.Date >= startOfWeek && e.modified_at.Date <= startOfWeek.AddDays(6))
                                 .Count(),
                    WeekCount = $"Week{index + 1}"
                }).ToList();
            dataList.Add("TotalOrder", totalOrders);
            dataList.Add("OrdersInprogress", ordersInprogress);
            dataList.Add("OrdersCompleted", ordersCompleted);
            return dataList;
        }
        /// <summary>
        /// Get Day Metrics
        /// </summary>
        /// <returns></returns>
        private Dictionary<string, List<OrderEffortMetricsDTO>> GetDayDataMetrics()
        {
            try
            {
                Dictionary<string, List<OrderEffortMetricsDTO>> dataList = new();
                DateTimeOffset currentDate = DateTimeOffset.Now;
                var last48hrsOrders = _context.TblOrder
                                         .Where(e => e.created_at.Date >= currentDate.AddHours(-48) && e.created_at.Date < currentDate)
                                         .Select(s => new
                                         {
                                             OrderId = s.id,
                                             CreatedDate = s.created_at
                                         }).ToList();
                var totalOrders = Enumerable.Range(0, 24)
                    .Select(hour =>  new OrderEffortMetricsDTO
                    {
                        Hours = hour,
                        HourStart = currentDate.AddHours(-hour).AddHours(-1),
                        HourEnd = currentDate.AddHours(-hour),
                        Data = last48hrsOrders.Where(t => t.CreatedDate >= currentDate.AddHours(-24) && t.CreatedDate < currentDate && t.CreatedDate.Hour == hour)
                        .ToList().Count
                    }).ToList();
                var last48hrsOrderInprogress = _context.TblOrder
                                     .Where(e => e.status.ToLower() == OrderStatus.IN_PROGRESS.ToLower() && e.modified_at.Date >= currentDate.AddHours(-48) && e.modified_at.Date < currentDate)
                                     .Select(s => new
                                     {
                                         OrderId = s.id,
                                         ModifiedDate = s.modified_at
                                     }).ToList();
                var ordersInprogress = Enumerable.Range(0, 24)
                    .Select(hour =>  new OrderEffortMetricsDTO
                    {
                        Hours = hour,
                        HourStart = currentDate.AddHours(-hour).AddHours(-1),
                        HourEnd = currentDate.AddHours(-hour),
                        Data = last48hrsOrderInprogress.Where(t => t.ModifiedDate >= currentDate.AddHours(-24) && t.ModifiedDate < currentDate && t.ModifiedDate.Hour == hour)
                        .ToList().Count
                    }).ToList();
                var last48hrsOrderCompleted = _context.TblOrder
                                     .Where(e => e.status.ToLower() == OrderStatus.COMPLETED.ToLower() && e.modified_at.Date >= currentDate.AddHours(-48) && e.modified_at.Date < currentDate)
                                     .Select(s => new
                                     {
                                         OrderId = s.id,
                                         ModifiedDate = s.modified_at
                                     }).ToList();

                var ordersCompleted = Enumerable.Range(0, 24)
                    .Select(hour =>  new OrderEffortMetricsDTO
                    {
                        Hours = hour,
                        HourStart = currentDate.AddHours(-hour).AddHours(-1),
                        HourEnd = currentDate.AddHours(-hour),
                        Data = last48hrsOrderCompleted.Where(t => t.ModifiedDate >= currentDate.AddHours(-24) && t.ModifiedDate < currentDate && t.ModifiedDate.Hour == hour)
                        .ToList().Count
                    }).ToList();
                dataList.Add("TotalOrder", totalOrders);
                dataList.Add("OrdersInprogress", ordersInprogress);
                dataList.Add("OrdersCompleted", ordersCompleted);
                return dataList;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task ProcessErpOrderResponse(ErpOrderResponseEvent erpOrderResponse)
        {
            try
            {
                string orderId = (from record in _context.TblOrder orderby record.created_at select record.id).LastOrDefault();
                var projectStaff = _context.TblProjectStaffs.Where(p => p.project_id == erpOrderResponse.Order.ProjectID).ToList();
                var email = GetStaffedUserEmails(projectStaff);
                var Id = string.IsNullOrEmpty(orderId) || orderId.Contains("-") ? 0 : Convert.ToInt32(orderId.Substring(3));
                string generatedOrderId = "";

                foreach (var service in erpOrderResponse.Order.Services)
                {
                    var orderFromDb = _context.TblOrder.FirstOrDefault(o => o.erp_order_id == erpOrderResponse.Order.ERPOrderID
                    && o.service_id == service.ServiceID);
                    var serviceDetails = _context.TblServices.Where(s => s.id == service.ServiceID).FirstOrDefault();

                    if (orderFromDb is null)
                    {
                        Id++;

                        generatedOrderId = $"ORD{Id:0000000000}";
                        _context.TblOrder.Add(new TblOrder()
                        {
                            id = generatedOrderId,
                            erp_order_id = erpOrderResponse.Order.ERPOrderID,
                            project_id = erpOrderResponse.Order.ProjectID,
                            erp_project_id = erpOrderResponse.Order.ERPProjectID,
                            service_id = service.ServiceID,
                            erp_wbs_id = service.WBSID,
                            offer_id = erpOrderResponse.Order.OfferID,
                            status = erpOrderResponse.Order.Status,
                            service_product_id = service.ServiceProductID,
                            created_at = DateTimeOffset.Now
                        });
                        #region Log AuditEntry
                        TblAuditEntry tblAuditEntry = new();
                        tblAuditEntry.id = Guid.NewGuid().ToString();
                        tblAuditEntry.project_id = erpOrderResponse.Order.ProjectID;
                        tblAuditEntry.erp_project_id = erpOrderResponse.Order.ERPProjectID;
                        tblAuditEntry.offer_id = erpOrderResponse.Order.OfferID;
                        tblAuditEntry.service_id = service.ServiceID;
                        tblAuditEntry.action = "Create";
                        tblAuditEntry.scope = "New Order " + erpOrderResponse.Order.ERPOrderID + " has been created for the service " +service?.WBSID+"";
                        tblAuditEntry.created_at = DateTimeOffset.UtcNow;
                        tblAuditEntry.user_id = erpOrderResponse?.TechnicalHeader?.EmailAddress??null;
                        tblAuditEntry.affected_table = "TblOrder";
                        _context.TblAuditEntry.Add(tblAuditEntry);
                        #endregion
                    }
                }

                _context.SaveChanges();

                #region Erp Order Notification
                if (erpOrderResponse.Order.ERPOrderID != null || erpOrderResponse.Order.ERPOrderID != "")
                {
                    var tenantId = httpContextAccessor.HttpContext?.User?.GetTenantId() ?? String.Empty;
                    
                    eventBus.PublishToQueue(new OrderNotificationEvent(email, "Create", "", tenantId, "The Order with " + erpOrderResponse?.Order.ERPOrderID + " is created", erpOrderResponse.Order.ERPOrderID, erpOrderResponse.Order.ERPOrderID,  "Order") { TopicName = "ordernotificationrequest" });
                }
                #endregion
            }
            catch (Exception ex)
            {

                throw;
            }
            
        }
        private static async Task LogAuditEntry(AuditLogEntryEvent auditLogEntryEvent)
        {
            try
            {
                using var context = new Sch_Context();
                TblAuditEntry tblAuditEntry = new();
                tblAuditEntry.id = Guid.NewGuid().ToString();
                tblAuditEntry.project_id = auditLogEntryEvent?.Project_Id;
                tblAuditEntry.action = auditLogEntryEvent?.Action;
                tblAuditEntry.scope = auditLogEntryEvent?.Scope;
                tblAuditEntry.created_at = DateTimeOffset.UtcNow;
                tblAuditEntry.user_id = auditLogEntryEvent?.User_Id;
                tblAuditEntry.old_value = auditLogEntryEvent?.Old_Value;
                tblAuditEntry.new_value = auditLogEntryEvent?.New_Value;
                tblAuditEntry.affected_table = auditLogEntryEvent?.Affected_Table;
                tblAuditEntry.offer_id = auditLogEntryEvent?.Offer_Id;
                tblAuditEntry.service_id = auditLogEntryEvent?.Service_Id;
                context.TblAuditEntry.Add(tblAuditEntry);
                await context.SaveChangesAsync();
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        private string GetCurrentUserId() => httpContextAccessor.HttpContext.User.Claims.FirstOrDefault(c => c.Type == "Id")?.Value ?? String.Empty;

        private bool IsUserOrderManager() => httpContextAccessor.HttpContext.User.Claims.Where(c => c.Type == ClaimTypes.Role).Any(c => c.Value == "Global Admin");
        private List<string> GetStaffedUserEmails(List<TblProjectStaff> projectStaffs)
        {
            var emails = new List<string>();
            try
            {
                foreach (var item in projectStaffs)
                {
                    var email = _context.TblUser.Where(u => u.id == item.user_id).FirstOrDefault()??null;
                    if(email != null)
                    {
                        emails.Add(email?.email_address);
                    } 
                }

                return emails;
            }
            catch (Exception ex)
            {
                return null;
            }
            
        }

    }
}
