﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Order.API.Migrations
{
    public partial class IntegrationColumnChange : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "erp_order_id",
                table: "tblOrder",
                type: "nvarchar(50)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "erp_project_id",
                table: "tblOrder",
                type: "nvarchar(50)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "erp_wbs_id",
                table: "tblOrder",
                type: "nvarchar(50)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "service_product_id",
                table: "tblOrder",
                type: "nvarchar(50)",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "tblBookmarks",
                columns: table => new
                {
                    id = table.Column<string>(type: "varchar(50)", nullable: false),
                    user_id = table.Column<string>(type: "varchar(50)", nullable: true),
                    library_id = table.Column<string>(type: "varchar(50)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblBookmarks", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tblCounterMeasures",
                columns: table => new
                {
                    id = table.Column<string>(type: "nvarchar(50)", nullable: false),
                    value = table.Column<string>(type: "nvarchar(255)", nullable: true),
                    created_at = table.Column<DateTimeOffset>(nullable: false),
                    created_by = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    modified_at = table.Column<DateTimeOffset>(type: "datetimeoffset(7)", nullable: false),
                    modified_by = table.Column<string>(type: "nvarchar(50)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblCounterMeasures", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tblGroups",
                columns: table => new
                {
                    id = table.Column<string>(type: "nvarchar(50)", nullable: false),
                    group_name = table.Column<string>(type: "nvarchar(160)", nullable: true),
                    group_email_address = table.Column<string>(type: "nvarchar(255)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblGroups", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tblHazardType",
                columns: table => new
                {
                    id = table.Column<string>(type: "nvarchar(50)", nullable: false),
                    type = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    created_at = table.Column<DateTimeOffset>(nullable: false),
                    created_by = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    modified_at = table.Column<DateTimeOffset>(type: "datetimeoffset(7)", nullable: false),
                    modified_by = table.Column<string>(type: "nvarchar(50)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblHazardType", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tblInitialHazardsMaster",
                columns: table => new
                {
                    id = table.Column<string>(type: "nvarchar(50)", nullable: false),
                    value = table.Column<string>(type: "nvarchar(255)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblInitialHazardsMaster", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tblLibrary",
                columns: table => new
                {
                    id = table.Column<string>(type: "varchar(50)", nullable: false),
                    name = table.Column<string>(type: "nvarchar(150)", nullable: true),
                    type = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    url = table.Column<string>(type: "nvarchar(500)", nullable: true),
                    content_type = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    version = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    preview_image_url = table.Column<string>(type: "nvarchar(500)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblLibrary", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tblLifecyclePhaseMaster",
                columns: table => new
                {
                    id = table.Column<string>(type: "nvarchar(50)", nullable: false),
                    lifecycle_phase = table.Column<string>(type: "nvarchar(100)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblLifecyclePhaseMaster", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tblMachineLimits",
                columns: table => new
                {
                    id = table.Column<string>(type: "nvarchar(50)", nullable: false),
                    machinemode = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    lifecycle_phase = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    limitation = table.Column<string>(type: "nvarchar(255)", nullable: true),
                    dimensions = table.Column<string>(type: "nvarchar(255)", nullable: true),
                    additional_limits = table.Column<string>(type: "nvarchar(255)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblMachineLimits", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tblMachineMediaMaster",
                columns: table => new
                {
                    id = table.Column<string>(type: "nvarchar(50)", nullable: false),
                    url = table.Column<string>(type: "nvarchar(500)", nullable: true),
                    type = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    machine_limits = table.Column<string>(type: "nvarchar(50)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblMachineMediaMaster", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tblMachineModeMaster",
                columns: table => new
                {
                    id = table.Column<string>(type: "nvarchar(50)", nullable: false),
                    machine_mode = table.Column<string>(type: "nvarchar(100)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblMachineModeMaster", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tblMachineRoadmap",
                columns: table => new
                {
                    id = table.Column<string>(type: "varchar(50)", nullable: false),
                    service_machine_id = table.Column<string>(type: "varchar(50)", nullable: true),
                    roadmap_id = table.Column<string>(type: "varchar(50)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblMachineRoadmap", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tblModes",
                columns: table => new
                {
                    id = table.Column<string>(type: "nvarchar(50)", nullable: false),
                    mode_name = table.Column<string>(type: "nvarchar(80)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblModes", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tblNotifications",
                columns: table => new
                {
                    NotificationId = table.Column<string>(type: "varchar(80)", nullable: false),
                    Notification_Type = table.Column<string>(type: "nvarchar(80)", nullable: true),
                    Notification_Cat = table.Column<string>(type: "nvarchar(80)", nullable: true),
                    User_Id = table.Column<string>(type: "varchar(80)", nullable: true),
                    Tenant_Id = table.Column<string>(type: "varchar(80)", nullable: true),
                    Notification_Value = table.Column<string>(type: "nvarchar(80)", nullable: true),
                    Created_By = table.Column<string>(type: "nvarchar(80)", nullable: true),
                    Created_Dt = table.Column<DateTimeOffset>(type: "DateTimeOffset", nullable: false),
                    Modified_By = table.Column<string>(type: "nvarchar(80)", nullable: true),
                    Modified_Dt = table.Column<DateTimeOffset>(type: "DateTimeOffset", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblNotifications", x => x.NotificationId);
                });

            migrationBuilder.CreateTable(
                name: "TblRoadmapMaster",
                columns: table => new
                {
                    roadmap_id = table.Column<string>(type: "nvarchar(50)", nullable: false),
                    roadmap_version = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    roadmap_name = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    description = table.Column<string>(type: "nvarchar(1000)", nullable: true),
                    version = table.Column<string>(type: "nvarchar(50)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TblRoadmapMaster", x => x.roadmap_id);
                });

            migrationBuilder.CreateTable(
                name: "tblRoleAndModuleAssociation",
                columns: table => new
                {
                    id = table.Column<string>(type: "nvarchar(50)", nullable: false),
                    role = table.Column<string>(type: "nvarchar(160)", nullable: true),
                    application_object = table.Column<string>(type: "nvarchar(160)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblRoleAndModuleAssociation", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tblRoles",
                columns: table => new
                {
                    id = table.Column<string>(type: "nvarchar(50)", nullable: false),
                    role_name = table.Column<string>(type: "nvarchar(160)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblRoles", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tblUsers",
                columns: table => new
                {
                    id = table.Column<string>(type: "nvarchar(50)", nullable: false),
                    first_name = table.Column<string>(type: "nvarchar(80)", nullable: true),
                    middle_initials = table.Column<string>(type: "nvarchar(80)", nullable: true),
                    last_name = table.Column<string>(type: "nvarchar(80)", nullable: true),
                    display_name = table.Column<string>(type: "nvarchar(160)", nullable: true),
                    email_address = table.Column<string>(type: "nvarchar(255)", nullable: true),
                    user_principal_name = table.Column<string>(type: "nvarchar(255)", nullable: true),
                    tenant_id = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    user_image = table.Column<string>(type: "nvarchar(1000)", nullable: true),
                    profile_data = table.Column<string>(type: "nvarchar(1000)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblUsers", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tblUserAndGroupAssociation",
                columns: table => new
                {
                    id = table.Column<string>(type: "nvarchar(50)", nullable: false),
                    owners = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    members = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    group_id = table.Column<string>(type: "nvarchar(50)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblUserAndGroupAssociation", x => x.id);
                    table.ForeignKey(
                        name: "FK_tblUserAndGroupAssociation_tblGroups_group_id",
                        column: x => x.group_id,
                        principalTable: "tblGroups",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "tblHazardSource",
                columns: table => new
                {
                    id = table.Column<string>(type: "nvarchar(50)", nullable: false),
                    hazard_type_id = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    source = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    created_at = table.Column<DateTimeOffset>(nullable: false),
                    created_by = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    modified_at = table.Column<DateTimeOffset>(type: "datetimeoffset(7)", nullable: false),
                    modified_by = table.Column<string>(type: "nvarchar(50)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblHazardSource", x => x.id);
                    table.ForeignKey(
                        name: "FK_tblHazardSource_tblHazardType_hazard_type_id",
                        column: x => x.hazard_type_id,
                        principalTable: "tblHazardType",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "tblMachineRoadmapAssociation",
                columns: table => new
                {
                    id = table.Column<string>(type: "nvarchar(50)", nullable: false),
                    machine_id = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    roadmap_id = table.Column<string>(type: "nvarchar(50)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblMachineRoadmapAssociation", x => x.id);
                    table.ForeignKey(
                        name: "FK_tblMachineRoadmapAssociation_tblMachine_machine_id",
                        column: x => x.machine_id,
                        principalTable: "tblMachine",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_tblMachineRoadmapAssociation_TblRoadmapMaster_roadmap_id",
                        column: x => x.roadmap_id,
                        principalTable: "TblRoadmapMaster",
                        principalColumn: "roadmap_id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "tblRoadmapSection",
                columns: table => new
                {
                    id = table.Column<string>(type: "nvarchar(50)", nullable: false),
                    roadmap_id = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    section = table.Column<string>(type: "nvarchar(500)", nullable: true),
                    subsection = table.Column<string>(type: "nvarchar(500)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblRoadmapSection", x => x.id);
                    table.ForeignKey(
                        name: "FK_tblRoadmapSection_TblRoadmapMaster_roadmap_id",
                        column: x => x.roadmap_id,
                        principalTable: "TblRoadmapMaster",
                        principalColumn: "roadmap_id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "tblRoleAssignment",
                columns: table => new
                {
                    id = table.Column<string>(type: "nvarchar(50)", nullable: false),
                    user_or_group_id = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    role_id = table.Column<string>(type: "nvarchar(50)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblRoleAssignment", x => x.id);
                    table.ForeignKey(
                        name: "FK_tblRoleAssignment_tblRoles_role_id",
                        column: x => x.role_id,
                        principalTable: "tblRoles",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "tblHazardConsequences",
                columns: table => new
                {
                    id = table.Column<string>(type: "nvarchar(50)", nullable: false),
                    hazard_type_id = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    hazard_source_id = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    consequence = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    created_at = table.Column<DateTimeOffset>(nullable: false),
                    created_by = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    modified_at = table.Column<DateTimeOffset>(type: "datetimeoffset(7)", nullable: false),
                    modified_by = table.Column<string>(type: "nvarchar(50)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblHazardConsequences", x => x.id);
                    table.ForeignKey(
                        name: "FK_tblHazardConsequences_tblHazardSource_hazard_source_id",
                        column: x => x.hazard_source_id,
                        principalTable: "tblHazardSource",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_tblHazardConsequences_tblHazardType_hazard_type_id",
                        column: x => x.hazard_type_id,
                        principalTable: "tblHazardType",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "tblStepMaster",
                columns: table => new
                {
                    step_id = table.Column<string>(type: "nvarchar(50)", nullable: false),
                    step_type = table.Column<string>(type: "nvarchar(80)", nullable: true),
                    step_body = table.Column<string>(type: "nvarchar(1000)", nullable: true),
                    roadmap_section_id = table.Column<string>(type: "nvarchar(50)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblStepMaster", x => x.step_id);
                    table.ForeignKey(
                        name: "FK_tblStepMaster_tblRoadmapSection_roadmap_section_id",
                        column: x => x.roadmap_section_id,
                        principalTable: "tblRoadmapSection",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "tblMachineHazards",
                columns: table => new
                {
                    id = table.Column<string>(type: "nvarchar(50)", nullable: false),
                    name = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    hazard_type_id = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    initial_hazard = table.Column<string>(type: "nvarchar(255)", nullable: true),
                    counter_measure = table.Column<string>(type: "nvarchar(255)", nullable: true),
                    service_machine_id = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    step_id = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    user_id = table.Column<string>(type: "varchar(50)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblMachineHazards", x => x.id);
                    table.ForeignKey(
                        name: "FK_tblMachineHazards_tblHazardType_hazard_type_id",
                        column: x => x.hazard_type_id,
                        principalTable: "tblHazardType",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_tblMachineHazards_tblServiceMachine_service_machine_id",
                        column: x => x.service_machine_id,
                        principalTable: "tblServiceMachine",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_tblMachineHazards_tblStepMaster_step_id",
                        column: x => x.step_id,
                        principalTable: "tblStepMaster",
                        principalColumn: "step_id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_tblMachineHazards_tblUser_user_id",
                        column: x => x.user_id,
                        principalTable: "tblUser",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "tblHazardMedia",
                columns: table => new
                {
                    id = table.Column<string>(type: "nvarchar(50)", nullable: false),
                    url = table.Column<string>(type: "nvarchar(255)", nullable: true),
                    type = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    machine_hazard_id = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    created_at = table.Column<DateTimeOffset>(nullable: false),
                    created_by = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    modified_at = table.Column<DateTimeOffset>(type: "datetimeoffset(7)", nullable: false),
                    modified_by = table.Column<string>(type: "nvarchar(50)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblHazardMedia", x => x.id);
                    table.ForeignKey(
                        name: "FK_tblHazardMedia_tblMachineHazards_machine_hazard_id",
                        column: x => x.machine_hazard_id,
                        principalTable: "tblMachineHazards",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "tblHRNCalculations",
                columns: table => new
                {
                    id = table.Column<string>(type: "nvarchar(50)", nullable: false),
                    PO = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    SD = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    FE = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    NP = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    rating = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    modes = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    machine_hazard_id = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    type = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    version = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    created_at = table.Column<DateTimeOffset>(nullable: false),
                    created_by = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    modified_at = table.Column<DateTimeOffset>(type: "datetimeoffset(7)", nullable: false),
                    modified_by = table.Column<string>(type: "nvarchar(50)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblHRNCalculations", x => x.id);
                    table.ForeignKey(
                        name: "FK_tblHRNCalculations_tblMachineHazards_machine_hazard_id",
                        column: x => x.machine_hazard_id,
                        principalTable: "tblMachineHazards",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "tblPerformanceLevelRating",
                columns: table => new
                {
                    id = table.Column<string>(type: "nvarchar(50)", nullable: false),
                    group_name = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    frequency_of_exposure = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    possibility_of_avoidance = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    PLR = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    category = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    sistema_report_associated = table.Column<bool>(type: "bit", nullable: false),
                    sistema_report_url = table.Column<string>(type: "nvarchar(255)", nullable: true),
                    machine_hazard_id = table.Column<string>(type: "nvarchar(50)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblPerformanceLevelRating", x => x.id);
                    table.ForeignKey(
                        name: "FK_tblPerformanceLevelRating_tblMachineHazards_machine_hazard_id",
                        column: x => x.machine_hazard_id,
                        principalTable: "tblMachineHazards",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_tblHazardConsequences_hazard_source_id",
                table: "tblHazardConsequences",
                column: "hazard_source_id");

            migrationBuilder.CreateIndex(
                name: "IX_tblHazardConsequences_hazard_type_id",
                table: "tblHazardConsequences",
                column: "hazard_type_id");

            migrationBuilder.CreateIndex(
                name: "IX_tblHazardMedia_machine_hazard_id",
                table: "tblHazardMedia",
                column: "machine_hazard_id");

            migrationBuilder.CreateIndex(
                name: "IX_tblHazardSource_hazard_type_id",
                table: "tblHazardSource",
                column: "hazard_type_id");

            migrationBuilder.CreateIndex(
                name: "IX_tblHRNCalculations_machine_hazard_id",
                table: "tblHRNCalculations",
                column: "machine_hazard_id");

            migrationBuilder.CreateIndex(
                name: "IX_tblMachineHazards_hazard_type_id",
                table: "tblMachineHazards",
                column: "hazard_type_id");

            migrationBuilder.CreateIndex(
                name: "IX_tblMachineHazards_service_machine_id",
                table: "tblMachineHazards",
                column: "service_machine_id");

            migrationBuilder.CreateIndex(
                name: "IX_tblMachineHazards_step_id",
                table: "tblMachineHazards",
                column: "step_id");

            migrationBuilder.CreateIndex(
                name: "IX_tblMachineHazards_user_id",
                table: "tblMachineHazards",
                column: "user_id");

            migrationBuilder.CreateIndex(
                name: "IX_tblMachineRoadmapAssociation_machine_id",
                table: "tblMachineRoadmapAssociation",
                column: "machine_id");

            migrationBuilder.CreateIndex(
                name: "IX_tblMachineRoadmapAssociation_roadmap_id",
                table: "tblMachineRoadmapAssociation",
                column: "roadmap_id");

            migrationBuilder.CreateIndex(
                name: "IX_tblPerformanceLevelRating_machine_hazard_id",
                table: "tblPerformanceLevelRating",
                column: "machine_hazard_id");

            migrationBuilder.CreateIndex(
                name: "IX_tblRoadmapSection_roadmap_id",
                table: "tblRoadmapSection",
                column: "roadmap_id");

            migrationBuilder.CreateIndex(
                name: "IX_tblRoleAssignment_role_id",
                table: "tblRoleAssignment",
                column: "role_id");

            migrationBuilder.CreateIndex(
                name: "IX_tblStepMaster_roadmap_section_id",
                table: "tblStepMaster",
                column: "roadmap_section_id");

            migrationBuilder.CreateIndex(
                name: "IX_tblUserAndGroupAssociation_group_id",
                table: "tblUserAndGroupAssociation",
                column: "group_id");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "tblBookmarks");

            migrationBuilder.DropTable(
                name: "tblCounterMeasures");

            migrationBuilder.DropTable(
                name: "tblHazardConsequences");

            migrationBuilder.DropTable(
                name: "tblHazardMedia");

            migrationBuilder.DropTable(
                name: "tblHRNCalculations");

            migrationBuilder.DropTable(
                name: "tblInitialHazardsMaster");

            migrationBuilder.DropTable(
                name: "tblLibrary");

            migrationBuilder.DropTable(
                name: "tblLifecyclePhaseMaster");

            migrationBuilder.DropTable(
                name: "tblMachineLimits");

            migrationBuilder.DropTable(
                name: "tblMachineMediaMaster");

            migrationBuilder.DropTable(
                name: "tblMachineModeMaster");

            migrationBuilder.DropTable(
                name: "tblMachineRoadmap");

            migrationBuilder.DropTable(
                name: "tblMachineRoadmapAssociation");

            migrationBuilder.DropTable(
                name: "tblModes");

            migrationBuilder.DropTable(
                name: "tblNotifications");

            migrationBuilder.DropTable(
                name: "tblPerformanceLevelRating");

            migrationBuilder.DropTable(
                name: "tblRoleAndModuleAssociation");

            migrationBuilder.DropTable(
                name: "tblRoleAssignment");

            migrationBuilder.DropTable(
                name: "tblUserAndGroupAssociation");

            migrationBuilder.DropTable(
                name: "tblUsers");

            migrationBuilder.DropTable(
                name: "tblHazardSource");

            migrationBuilder.DropTable(
                name: "tblMachineHazards");

            migrationBuilder.DropTable(
                name: "tblRoles");

            migrationBuilder.DropTable(
                name: "tblGroups");

            migrationBuilder.DropTable(
                name: "tblHazardType");

            migrationBuilder.DropTable(
                name: "tblStepMaster");

            migrationBuilder.DropTable(
                name: "tblRoadmapSection");

            migrationBuilder.DropTable(
                name: "TblRoadmapMaster");

            migrationBuilder.DropColumn(
                name: "erp_order_id",
                table: "tblOrder");

            migrationBuilder.DropColumn(
                name: "erp_project_id",
                table: "tblOrder");

            migrationBuilder.DropColumn(
                name: "erp_wbs_id",
                table: "tblOrder");

            migrationBuilder.DropColumn(
                name: "service_product_id",
                table: "tblOrder");
        }
    }
}
