﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Order.API.Migrations
{
    public partial class relationsadded : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "tblCompany",
                columns: table => new
                {
                    id = table.Column<string>(type: "nvarchar(50)", nullable: false),
                    company_name = table.Column<string>(type: "nvarchar(80)", nullable: true),
                    company_code = table.Column<string>(type: "nvarchar(80)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblCompany", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tblContact",
                columns: table => new
                {
                    contact_id = table.Column<string>(type: "nvarchar(50)", nullable: false),
                    first_name = table.Column<string>(type: "nvarchar(80)", nullable: true),
                    last_name = table.Column<string>(type: "nvarchar(80)", nullable: true),
                    display_name = table.Column<string>(type: "nvarchar(160)", nullable: true),
                    email_address = table.Column<string>(type: "nvarchar(150)", nullable: true),
                    title = table.Column<string>(type: "nvarchar(10)", nullable: true),
                    language = table.Column<string>(type: "nvarchar(10)", nullable: true),
                    phone_number = table.Column<string>(type: "nvarchar(80)", nullable: true),
                    department = table.Column<string>(type: "nvarchar(80)", nullable: true),
                    created_at = table.Column<DateTimeOffset>(type: "datetimeoffset(7)", nullable: false),
                    created_by = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    modified_at = table.Column<DateTimeOffset>(type: "datetimeoffset(7)", nullable: false),
                    modified_by = table.Column<string>(type: "nvarchar(50)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblContact", x => x.contact_id);
                });

            migrationBuilder.CreateTable(
                name: "tblControllingArea",
                columns: table => new
                {
                    id = table.Column<string>(type: "nvarchar(50)", nullable: false),
                    controlling_area = table.Column<string>(type: "nvarchar(80)", nullable: true),
                    controlling_area_code = table.Column<string>(type: "nvarchar(50)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblControllingArea", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tblErpContact",
                columns: table => new
                {
                    erp_contact_id = table.Column<string>(type: "nvarchar(50)", nullable: false),
                    first_name = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    customer_id = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    last_name = table.Column<string>(type: "nvarchar(150)", nullable: true),
                    display_name = table.Column<string>(type: "nvarchar(150)", nullable: true),
                    email_address = table.Column<string>(type: "nvarchar(150)", nullable: true),
                    title = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    language = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    phone_number = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    department = table.Column<string>(type: "nvarchar(50)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblErpContact", x => x.erp_contact_id);
                });

            migrationBuilder.CreateTable(
                name: "tblErpCustomer",
                columns: table => new
                {
                    erp_customer_id = table.Column<string>(type: "nvarchar(50)", nullable: false),
                    company_name = table.Column<string>(type: "nvarchar(80)", nullable: true),
                    company_code = table.Column<string>(type: "nvarchar(80)", nullable: true),
                    controlling_area = table.Column<string>(type: "nvarchar(80)", nullable: true),
                    controlling_area_code = table.Column<string>(type: "nvarchar(80)", nullable: true),
                    customer_id = table.Column<string>(type: "nvarchar(80)", nullable: true),
                    customer_name = table.Column<string>(type: "nvarchar(150)", nullable: true),
                    country_code = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    city = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    zipcode = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    street = table.Column<string>(type: "nvarchar(150)", nullable: true),
                    phone_number = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    tenant_id = table.Column<string>(type: "nvarchar(50)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblErpCustomer", x => x.erp_customer_id);
                });

            migrationBuilder.CreateTable(
                name: "tblMachine",
                columns: table => new
                {
                    id = table.Column<string>(type: "nvarchar(80)", nullable: false),
                    master_machine_id = table.Column<string>(type: "nvarchar(80)", nullable: true),
                    machine_name = table.Column<string>(type: "nvarchar(160)", nullable: true),
                    asset_id = table.Column<string>(type: "nvarchar(80)", nullable: true),
                    serial_number = table.Column<string>(type: "nvarchar(80)", nullable: true),
                    machine_description = table.Column<string>(type: "nvarchar(150)", nullable: true),
                    estimated_hours = table.Column<int>(type: "int", nullable: false),
                    machine_type = table.Column<string>(type: "nvarchar(80)", nullable: true),
                    machine_location = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    industry_type = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    created_at = table.Column<DateTimeOffset>(type: "datetimeoffset(7)", nullable: false),
                    created_by = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    modified_at = table.Column<DateTimeOffset>(type: "datetimeoffset(7)", nullable: false),
                    modified_by = table.Column<string>(type: "nvarchar(50)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblMachine", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tblMachinemaster",
                columns: table => new
                {
                    id = table.Column<string>(type: "nvarchar(80)", nullable: false),
                    machine_name = table.Column<string>(type: "nvarchar(160)", nullable: true),
                    machine_type = table.Column<string>(type: "nvarchar(80)", nullable: true),
                    manufacturer = table.Column<string>(type: "nvarchar(80)", nullable: true),
                    created_at = table.Column<DateTimeOffset>(type: "datetimeoffset(7)", nullable: false),
                    created_by = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    modified_at = table.Column<DateTimeOffset>(type: "datetimeoffset(7)", nullable: false),
                    modified_by = table.Column<string>(type: "nvarchar(50)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblMachinemaster", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tblOfferKPI",
                columns: table => new
                {
                    id = table.Column<string>(type: "nvarchar(50)", nullable: false),
                    calculated_hours = table.Column<int>(type: "int", nullable: false),
                    cost_progress = table.Column<decimal>(type: "money", nullable: false),
                    hours_progress = table.Column<int>(type: "int", nullable: false),
                    roadmap_progress = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblOfferKPI", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tblOrderKPI",
                columns: table => new
                {
                    id = table.Column<string>(type: "nvarchar(50)", nullable: false),
                    calculated_hours = table.Column<int>(type: "int", nullable: false),
                    cost_progress = table.Column<decimal>(type: "money", nullable: false),
                    hours_progress = table.Column<int>(type: "int", nullable: false),
                    roadmap_progress = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblOrderKPI", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tblProjectKPI",
                columns: table => new
                {
                    id = table.Column<string>(type: "nvarchar(50)", nullable: false),
                    calculated_hours = table.Column<int>(type: "int", nullable: false),
                    cost_progress = table.Column<decimal>(type: "money", nullable: false),
                    hours_progress = table.Column<int>(type: "int", nullable: false),
                    roadmap_progress = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblProjectKPI", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tblProjectStaff",
                columns: table => new
                {
                    id = table.Column<string>(type: "nvarchar(50)", nullable: false),
                    user_id = table.Column<string>(type: "nvarchar(80)", nullable: true),
                    created_at = table.Column<DateTimeOffset>(type: "datetimeoffset(7)", nullable: false),
                    created_by = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    modified_at = table.Column<DateTimeOffset>(type: "datetimeoffset(7)", nullable: false),
                    modified_by = table.Column<string>(type: "nvarchar(50)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblProjectStaff", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tblServiceKPI",
                columns: table => new
                {
                    id = table.Column<string>(type: "nvarchar(50)", nullable: false),
                    calculated_hours = table.Column<int>(type: "int", nullable: false),
                    cost_progress = table.Column<decimal>(type: "money", nullable: false),
                    hours_progress = table.Column<int>(type: "int", nullable: false),
                    roadmap_progress = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblServiceKPI", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tblTenantCatalog",
                columns: table => new
                {
                    id = table.Column<string>(type: "nvarchar(50)", nullable: false),
                    client_name = table.Column<string>(type: "nvarchar(80)", nullable: true),
                    region = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    country = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    language = table.Column<string>(type: "nvarchar(50)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblTenantCatalog", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tblUser",
                columns: table => new
                {
                    id = table.Column<string>(type: "nvarchar(50)", nullable: false),
                    first_name = table.Column<string>(type: "nvarchar(80)", nullable: true),
                    last_name = table.Column<string>(type: "nvarchar(80)", nullable: true),
                    display_name = table.Column<string>(type: "nvarchar(160)", nullable: true),
                    login_name = table.Column<string>(type: "nvarchar(90)", nullable: true),
                    email_address = table.Column<string>(type: "nvarchar(150)", nullable: true),
                    role = table.Column<string>(type: "nvarchar(50)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblUser", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tblCustomer",
                columns: table => new
                {
                    id = table.Column<string>(type: "nvarchar(50)", nullable: false),
                    customer_id = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    customer_name = table.Column<string>(type: "nvarchar(150)", nullable: true),
                    erp_customer_id = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    contact_id = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    country_code = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    city = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    zipcode = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    street = table.Column<string>(type: "nvarchar(150)", nullable: true),
                    phone_number = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    project_id = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    language = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    created_at = table.Column<DateTimeOffset>(type: "datetimeoffset(7)", nullable: false),
                    created_by = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    modified_at = table.Column<DateTimeOffset>(type: "datetimeoffset(7)", nullable: false),
                    modified_by = table.Column<string>(type: "nvarchar(50)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblCustomer", x => x.id);
                    table.ForeignKey(
                        name: "FK_tblCustomer_tblContact_contact_id",
                        column: x => x.contact_id,
                        principalTable: "tblContact",
                        principalColumn: "contact_id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "tblTask",
                columns: table => new
                {
                    id = table.Column<string>(type: "nvarchar(50)", nullable: false),
                    task_id = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    task_label = table.Column<string>(type: "nvarchar(150)", nullable: true),
                    task_title = table.Column<string>(type: "nvarchar(150)", nullable: true),
                    priority = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    description = table.Column<string>(type: "nvarchar(255)", nullable: true),
                    assigned_to = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    user_id = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    due_date = table.Column<DateTimeOffset>(type: "datetimeoffset(7)", nullable: false),
                    status = table.Column<string>(type: "nvarchar(80)", nullable: true),
                    created_at = table.Column<DateTimeOffset>(type: "datetimeoffset(7)", nullable: false),
                    created_by = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    modified_at = table.Column<DateTimeOffset>(type: "datetimeoffset(7)", nullable: false),
                    modified_by = table.Column<string>(type: "nvarchar(50)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblTask", x => x.id);
                    table.ForeignKey(
                        name: "FK_tblTask_tblUser_user_id",
                        column: x => x.user_id,
                        principalTable: "tblUser",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "tblProject",
                columns: table => new
                {
                    id = table.Column<string>(type: "nvarchar(50)", nullable: false),
                    erp_project_id = table.Column<string>(type: "nvarchar(80)", nullable: true),
                    project_name = table.Column<string>(type: "nvarchar(80)", nullable: true),
                    description = table.Column<string>(type: "nvarchar(160)", nullable: true),
                    start_date = table.Column<DateTime>(type: "datetime", nullable: true),
                    end_date = table.Column<DateTime>(type: "datetime", nullable: true),
                    status = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    controlling_id = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    tenant_id = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    company_id = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    customer_id = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    staff_id = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    order_id = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    notes = table.Column<string>(type: "nvarchar(1000)", nullable: true),
                    estimatedhours = table.Column<int>(type: "int", nullable: false),
                    project_kpi_id = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    created_at = table.Column<DateTimeOffset>(type: "datetimeoffset(7)", nullable: false),
                    created_by = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    modified_at = table.Column<DateTimeOffset>(type: "datetimeoffset(7)", nullable: false),
                    modified_by = table.Column<string>(type: "nvarchar(50)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblProject", x => x.id);
                    table.ForeignKey(
                        name: "FK_tblProject_tblCompany_company_id",
                        column: x => x.company_id,
                        principalTable: "tblCompany",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_tblProject_tblControllingArea_controlling_id",
                        column: x => x.controlling_id,
                        principalTable: "tblControllingArea",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_tblProject_tblCustomer_customer_id",
                        column: x => x.customer_id,
                        principalTable: "tblCustomer",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_tblProject_tblProjectKPI_project_kpi_id",
                        column: x => x.project_kpi_id,
                        principalTable: "tblProjectKPI",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_tblProject_tblProjectStaff_staff_id",
                        column: x => x.staff_id,
                        principalTable: "tblProjectStaff",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_tblProject_tblTenantCatalog_tenant_id",
                        column: x => x.tenant_id,
                        principalTable: "tblTenantCatalog",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "tblOffer",
                columns: table => new
                {
                    id = table.Column<string>(type: "nvarchar(50)", nullable: false),
                    quote_type = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    notes = table.Column<string>(type: "nvarchar(1000)", nullable: true),
                    project_id = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    contact_id = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    status = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    offer_kpi_id = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    quote_template_type = table.Column<string>(type: "nvarchar(100)", nullable: true),
                    created_at = table.Column<DateTimeOffset>(type: "datetimeoffset(7)", nullable: false),
                    created_by = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    modified_at = table.Column<DateTimeOffset>(type: "datetimeoffset(7)", nullable: false),
                    modified_by = table.Column<string>(type: "nvarchar(50)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblOffer", x => x.id);
                    table.ForeignKey(
                        name: "FK_tblOffer_tblContact_contact_id",
                        column: x => x.contact_id,
                        principalTable: "tblContact",
                        principalColumn: "contact_id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_tblOffer_tblOfferKPI_offer_kpi_id",
                        column: x => x.offer_kpi_id,
                        principalTable: "tblOfferKPI",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_tblOffer_tblProject_project_id",
                        column: x => x.project_id,
                        principalTable: "tblProject",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "tblQuotation",
                columns: table => new
                {
                    id = table.Column<string>(type: "nvarchar(80)", nullable: false),
                    offer_id = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    template_name = table.Column<string>(type: "nvarchar(150)", nullable: true),
                    template_url = table.Column<string>(type: "nvarchar(80)", nullable: true),
                    quotation_url = table.Column<string>(type: "nvarchar(80)", nullable: true),
                    version = table.Column<string>(type: "nvarchar(80)", nullable: true),
                    created_at = table.Column<DateTimeOffset>(type: "datetimeoffset(7)", nullable: false),
                    created_by = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    modified_at = table.Column<DateTimeOffset>(type: "datetimeoffset(7)", nullable: false),
                    modified_by = table.Column<string>(type: "nvarchar(50)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblQuotation", x => x.id);
                    table.ForeignKey(
                        name: "FK_tblQuotation_tblOffer_offer_id",
                        column: x => x.offer_id,
                        principalTable: "tblOffer",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "tblService",
                columns: table => new
                {
                    id = table.Column<string>(type: "nvarchar(50)", nullable: false),
                    erp_wbs_id = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    project_id = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    offer_id = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    contact_id = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    service_type = table.Column<string>(type: "nvarchar(80)", nullable: true),
                    service_location = table.Column<string>(type: "nvarchar(80)", nullable: true),
                    service_description = table.Column<string>(type: "nvarchar(1000)", nullable: true),
                    service_region = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    start_date = table.Column<DateTime>(type: "datetime", nullable: true),
                    end_date = table.Column<DateTime>(type: "datetime", nullable: true),
                    actual_hours = table.Column<int>(type: "int", nullable: false),
                    service_kpi_id = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    is_active = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    created_at = table.Column<DateTimeOffset>(type: "datetimeoffset(7)", nullable: false),
                    created_by = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    modified_at = table.Column<DateTimeOffset>(type: "datetimeoffset(7)", nullable: false),
                    modified_by = table.Column<string>(type: "nvarchar(50)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblService", x => x.id);
                    table.ForeignKey(
                        name: "FK_tblService_tblContact_contact_id",
                        column: x => x.contact_id,
                        principalTable: "tblContact",
                        principalColumn: "contact_id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_tblService_tblOffer_offer_id",
                        column: x => x.offer_id,
                        principalTable: "tblOffer",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_tblService_tblProject_project_id",
                        column: x => x.project_id,
                        principalTable: "tblProject",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_tblService_tblServiceKPI_service_kpi_id",
                        column: x => x.service_kpi_id,
                        principalTable: "tblServiceKPI",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "tblOrder",
                columns: table => new
                {
                    id = table.Column<string>(type: "nvarchar(50)", nullable: false),
                    service_id = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    status = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    order_kpi_id = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    offer_id = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    customer_id = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    project_id = table.Column<string>(type: "nvarchar(50)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblOrder", x => x.id);
                    table.ForeignKey(
                        name: "FK_tblOrder_tblCustomer_customer_id",
                        column: x => x.customer_id,
                        principalTable: "tblCustomer",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_tblOrder_tblOffer_offer_id",
                        column: x => x.offer_id,
                        principalTable: "tblOffer",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_tblOrder_tblOrderKPI_order_kpi_id",
                        column: x => x.order_kpi_id,
                        principalTable: "tblOrderKPI",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_tblOrder_tblProject_project_id",
                        column: x => x.project_id,
                        principalTable: "tblProject",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_tblOrder_tblService_service_id",
                        column: x => x.service_id,
                        principalTable: "tblService",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "tblServiceMachine",
                columns: table => new
                {
                    id = table.Column<string>(type: "nvarchar(50)", nullable: false),
                    service_id = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    machine_id = table.Column<string>(type: "nvarchar(80)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblServiceMachine", x => x.id);
                    table.ForeignKey(
                        name: "FK_tblServiceMachine_tblMachine_machine_id",
                        column: x => x.machine_id,
                        principalTable: "tblMachine",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_tblServiceMachine_tblService_service_id",
                        column: x => x.service_id,
                        principalTable: "tblService",
                        principalColumn: "id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_tblCustomer_contact_id",
                table: "tblCustomer",
                column: "contact_id");

            migrationBuilder.CreateIndex(
                name: "IX_tblOffer_contact_id",
                table: "tblOffer",
                column: "contact_id");

            migrationBuilder.CreateIndex(
                name: "IX_tblOffer_offer_kpi_id",
                table: "tblOffer",
                column: "offer_kpi_id");

            migrationBuilder.CreateIndex(
                name: "IX_tblOffer_project_id",
                table: "tblOffer",
                column: "project_id");

            migrationBuilder.CreateIndex(
                name: "IX_tblOrder_customer_id",
                table: "tblOrder",
                column: "customer_id");

            migrationBuilder.CreateIndex(
                name: "IX_tblOrder_offer_id",
                table: "tblOrder",
                column: "offer_id");

            migrationBuilder.CreateIndex(
                name: "IX_tblOrder_order_kpi_id",
                table: "tblOrder",
                column: "order_kpi_id");

            migrationBuilder.CreateIndex(
                name: "IX_tblOrder_project_id",
                table: "tblOrder",
                column: "project_id");

            migrationBuilder.CreateIndex(
                name: "IX_tblOrder_service_id",
                table: "tblOrder",
                column: "service_id");

            migrationBuilder.CreateIndex(
                name: "IX_tblProject_company_id",
                table: "tblProject",
                column: "company_id");

            migrationBuilder.CreateIndex(
                name: "IX_tblProject_controlling_id",
                table: "tblProject",
                column: "controlling_id");

            migrationBuilder.CreateIndex(
                name: "IX_tblProject_customer_id",
                table: "tblProject",
                column: "customer_id");

            migrationBuilder.CreateIndex(
                name: "IX_tblProject_order_id",
                table: "tblProject",
                column: "order_id");

            migrationBuilder.CreateIndex(
                name: "IX_tblProject_project_kpi_id",
                table: "tblProject",
                column: "project_kpi_id");

            migrationBuilder.CreateIndex(
                name: "IX_tblProject_staff_id",
                table: "tblProject",
                column: "staff_id");

            migrationBuilder.CreateIndex(
                name: "IX_tblProject_tenant_id",
                table: "tblProject",
                column: "tenant_id");

            migrationBuilder.CreateIndex(
                name: "IX_tblQuotation_offer_id",
                table: "tblQuotation",
                column: "offer_id");

            migrationBuilder.CreateIndex(
                name: "IX_tblService_contact_id",
                table: "tblService",
                column: "contact_id");

            migrationBuilder.CreateIndex(
                name: "IX_tblService_offer_id",
                table: "tblService",
                column: "offer_id");

            migrationBuilder.CreateIndex(
                name: "IX_tblService_project_id",
                table: "tblService",
                column: "project_id");

            migrationBuilder.CreateIndex(
                name: "IX_tblService_service_kpi_id",
                table: "tblService",
                column: "service_kpi_id");

            migrationBuilder.CreateIndex(
                name: "IX_tblServiceMachine_machine_id",
                table: "tblServiceMachine",
                column: "machine_id");

            migrationBuilder.CreateIndex(
                name: "IX_tblServiceMachine_service_id",
                table: "tblServiceMachine",
                column: "service_id");

            migrationBuilder.CreateIndex(
                name: "IX_tblTask_user_id",
                table: "tblTask",
                column: "user_id");

            migrationBuilder.AddForeignKey(
                name: "FK_tblProject_tblOrder_order_id",
                table: "tblProject",
                column: "order_id",
                principalTable: "tblOrder",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_tblCustomer_tblContact_contact_id",
                table: "tblCustomer");

            migrationBuilder.DropForeignKey(
                name: "FK_tblOffer_tblContact_contact_id",
                table: "tblOffer");

            migrationBuilder.DropForeignKey(
                name: "FK_tblService_tblContact_contact_id",
                table: "tblService");

            migrationBuilder.DropForeignKey(
                name: "FK_tblOffer_tblOfferKPI_offer_kpi_id",
                table: "tblOffer");

            migrationBuilder.DropForeignKey(
                name: "FK_tblOffer_tblProject_project_id",
                table: "tblOffer");

            migrationBuilder.DropForeignKey(
                name: "FK_tblOrder_tblProject_project_id",
                table: "tblOrder");

            migrationBuilder.DropForeignKey(
                name: "FK_tblService_tblProject_project_id",
                table: "tblService");

            migrationBuilder.DropTable(
                name: "tblErpContact");

            migrationBuilder.DropTable(
                name: "tblErpCustomer");

            migrationBuilder.DropTable(
                name: "tblMachinemaster");

            migrationBuilder.DropTable(
                name: "tblQuotation");

            migrationBuilder.DropTable(
                name: "tblServiceMachine");

            migrationBuilder.DropTable(
                name: "tblTask");

            migrationBuilder.DropTable(
                name: "tblMachine");

            migrationBuilder.DropTable(
                name: "tblUser");

            migrationBuilder.DropTable(
                name: "tblContact");

            migrationBuilder.DropTable(
                name: "tblOfferKPI");

            migrationBuilder.DropTable(
                name: "tblProject");

            migrationBuilder.DropTable(
                name: "tblCompany");

            migrationBuilder.DropTable(
                name: "tblControllingArea");

            migrationBuilder.DropTable(
                name: "tblOrder");

            migrationBuilder.DropTable(
                name: "tblProjectKPI");

            migrationBuilder.DropTable(
                name: "tblProjectStaff");

            migrationBuilder.DropTable(
                name: "tblTenantCatalog");

            migrationBuilder.DropTable(
                name: "tblCustomer");

            migrationBuilder.DropTable(
                name: "tblOrderKPI");

            migrationBuilder.DropTable(
                name: "tblService");

            migrationBuilder.DropTable(
                name: "tblOffer");

            migrationBuilder.DropTable(
                name: "tblServiceKPI");
        }
    }
}
