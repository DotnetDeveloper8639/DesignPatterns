﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Order.API.Models.ApiModels
{
    public class CustomerDTO
    {
        public string Customer_Id { get; set; }
        public string Customer_Name { get; set; }
        public string Erp_Customer_Id { get; set; }
        public string Country_Code { get; set; }
        public string Company_Code { get; set; }
        public string Controlling_Area_Code { get; set; }
        public string City { get; set; }
        public string Zipcode { get; set; }
        public string Street { get; set; }
        public string Phone_Number { get; set; }
        public string Company_Name { get; set; }
        public string Controlling_Area { get; set; }
        public string Language { get; set; }
        public List<ContactDTO> Contacts { get; set; }
    }

    public class ErpCustomerApiModel
    {
        public string Customer_Id { get; set; }
        public string Customer_Name { get; set; }
        public string Erp_Customer_Id { get; set; }
        public string Country_Code { get; set; }
        public string Company_Code { get; set; }
        public string Controlling_Area_Code { get; set; }
        public string City { get; set; }
        public string Zipcode { get; set; }
        public string Street { get; set; }
        public string Phone_Number { get; set; }
        public string Company_Name { get; set; }
        public string Controlling_Area { get; set; }
        public string Language { get; set; }
    }

    //public class Customer: BaseMessage
    //{
    //    public string Cus_Id { get; set; }
    //    public string Customer_Id { get; set; }
    //    public string Customer_Name { get; set; }
    //    public string Erp_Customer_Id { get; set; }
    //    public string Project_Id { get; set; }
    //    public string Country_Code { get; set; }
    //    public string Company_Code { get; set; }
    //    public string Contact_Id { get; set; }
    //    public string Controlling_Area_Code { get; set; }
    //    public string City { get; set; }
    //    public int? Zipcode { get; set; }
    //    public string Street { get; set; }
    //    public string Phone_Number { get; set; }
    //    public string Company_Name { get; set; }
    //    public string Controlling_Area { get; set; }
    //    public string Language { get; set; }
    //    public DateTimeOffset Created_At{ get; set; }
    //    public string Created_By { get; set; }
    //    public DateTimeOffset Modified_At { get; set; }
    //    public string Modified_By { get; set; }
    //}
}
