﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Order.API.Models.ApiModels
{
    public class ServiceDetailDTO
    {
        public ProjectDTO Project { get; set; }
        public ServiceDTO Service { get; set; }
        public OrderDTO Order { get; set; }
    }
}
