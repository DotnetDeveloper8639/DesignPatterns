﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Order.API.Models.ApiModels
{
    public class ServiceDTO
    {
        public string Id { get; set; }
        public string Erp_Wbs_Id { get; set; }
        public string Project_Id { get; set; }
        public string Offer_Id { get; set; }
        public string Contact_Id { get; set; }
        public string Service_Type { get; set; }
        public string Service_Location { get; set; }
        public DateTime? Start_Date { get; set; }
        public DateTime? End_Date { get; set; }
        public int Actual_Hours { get; set; }
        public string Is_Active { get; set; }
        public DateTimeOffset Created_At { get; set; }
        public string Created_By { get; set; }
        public DateTimeOffset Modified_At { get; set; }
        public string Modified_By { get; set; }
        public int Hours_Progress { get; set; }
        public int Calculated_Hours { get; set; }
        public int Actual_progress { get; set; }
        public int Roadmap_Progress { get; set; }
        public int TotalStepCount { get; set; }
        public int TotalAnswredStepCount { get; set; }
        public decimal Total_CalculatedHours { get; set; }
        public decimal Total_ActualHours { get; set; }
        public string Status { get; set; }
    }
}
