﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Order.API.Models.ApiModels
{
    public class TaskManagerDTO
    {
        public string Task_Id { get; set; }
        public string Task_Title { get; set; }
        public string Task_Label { get; set; }
        public string Priority { get; set; }
        public string Description { get; set; }
        public string Assigned_To { get; set; }
        public string Due_Date { get; set; }
        public string Status { get; set; }
        public string Created_Date { get; set; }
    }
}
