﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Order.API.Models.ApiModels
{
   public class OrderDTO
    {
        public string Order_Id { get; set; }
        public string Encryption_Order_Id { get; set; }
        public string Service_Id { get; set; }
        public string Status { get; set; }
        public string Project_Id { get; set; }
        public string Offer_Id { get; set; }
        public string Opportunity_Id { get; set; }
        public string Purchase_Order_Id { get; set; }
        public string Customer_Name { get; set; }
        public string PO_Status { get; set; }
        public decimal Total_CalculatedHours { get; set; }
        public decimal Total_ActualHours { get; set; }
        public int Progress { get; set; }
        public int TotalStepCount { get; set; }
        public int TotalAnswredStepCount { get; set; }
        public string Start_Date { get; set; }
        public string End_Date { get; set; }
        public OrderKpiDTO Order_Kpi { get; set; }
        public string Company_Name { get; set; }
        public string Phone_Number { get; set; }
        public string Address_Line1 { get; set; }
        public string Service_Type { get; set; }
        public int Hours_Progress { get; set; }
        public int Calculated_Hours { get; set; }
        public int Actual_progress { get; set; }
        public int Roadmap_Progress { get; set; }
        public string Erp_Wbs_Id { get; set; }
        public string Erp_Order_Id { get; set; }
        public string Erp_Project_Id { get; set; }
        public string Erp_Service_Wbs_Id { get; set; }
        public List<ServiceDTO> Services_Status { get; set; }
    }
}
