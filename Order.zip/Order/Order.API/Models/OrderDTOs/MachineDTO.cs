﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Order.API.Models.ApiModels
{
    public class MachineDTO
    {
        public string Machine_Id { get; set; }
        public string Machine_Name { get; set; }
        public string Asset_Id { get; set; }
        public string Serial_Number { get; set; }
        public string Machine_Description { get; set; }
        public int Estimated_Hours { get; set; }
        public MasterMachines MasterMachine { get; set; }
        public ProjectStaffApiModel AssignedStaff { get; set; }
        public DateTimeOffset Created_At { get; set; }
        public string Created_By { get; set; }
        public DateTimeOffset Modified_At { get; set; }
        public string Modified_By { get; set; }
    }

    public class MasterMachines
    {
        public string Machine_Master_Id { get; set; }
        public string Machine_Name { get; set; }
        public string Machine_Type { get; set; }
        public string Manufacturer { get; set; }
        public DateTimeOffset Created_At { get; set; }
        public string Created_By { get; set; }
        public DateTimeOffset Modified_At { get; set; }
        public string Modified_By { get; set; }
    }
}
