﻿using EventBus.Abstractions;
using EventBus.Events;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Identity.Web;
using Project.API.DbContextClass;
using Project.API.EntityModels;
using Project.API.Helper;
using Project.API.IntegrationEvents.Events;
using Project.API.IntegrationEvents.NotificationEvents;
using Project.API.Models.ProjectDTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Security.Claims;
using System.Threading.Tasks;

namespace Project.API.Services
{
    public class ProjectServices : ProjectBaseRepository<TblProject>, IProjectServices
    {
        private readonly Sch_Context _context;
        private readonly IHttpContextAccessor httpContextAccessor;
        private readonly IEventBus eventBus;
        //Security string to encript the Id
        public readonly string projectSecurityString = "InpupR!@!$oTe*&*cti&onS%ch*em#aRsal!";

        public ProjectServices(Sch_Context context
            , IHttpContextAccessor httpContextAccessor
            , IEventBus _eventBus) : base(context)
        {
            _context = context;
            this.httpContextAccessor = httpContextAccessor;
            eventBus = _eventBus;
        }

        /// <summary>
        /// Service for create new project
        /// </summary>
        /// <param name="project"></param>
        /// <returns></returns>
        public async Task<ProjectRequestEvent> CreateProject(CreateProjectDTO project)
        {
            Guid guid = Guid.NewGuid();
            Guid project_Guid = Guid.NewGuid();
            Guid customer_Guid = Guid.NewGuid();

            try
            {
                var tenantid = string.Empty;
                var areaId = _context.TblControllingAreas
                    .FirstOrDefault(a => a.controlling_area_code == project.Controlling_Area_Code)?.id ?? String.Empty;

                var userId = httpContextAccessor.HttpContext?.User?.Claims.FirstOrDefault(c => c.Type == "Id")?.Value ?? String.Empty;

                TblProject prj = new TblProject();
                prj.id = ProjectId();
                prj.project_name = project.Project_Name;
                prj.tenant_id = tenantid;
                prj.description = project.Description;
                prj.start_date = project.Start_Date;
                prj.end_date = project.End_Date;
                prj.status = project.Status;
                prj.customer_id = project.CustomerDetails.Customer_Id;
                prj.company_id = project.Company_Code;
                prj.controlling_id = areaId;
                prj.staff_id = String.Empty; //GetStaffId();
                prj.estimatedhours = 0;
                prj.project_kpi_id = _context.TblProjectKPI.FirstOrDefault()?.id ?? String.Empty;
                prj.contact_id = project.CustomerDetails.Contacts.FirstOrDefault(con => con.IsSeleted)?.Contact_Id ?? String.Empty;
                prj.created_at = DateTimeOffset.Now;
                prj.created_by = userId;
                prj.modified_at = DateTimeOffset.Now;
                prj.modified_by = "";
                _context.TblProjects.Add(prj);

                var projectStaff = new TblProjectStaff()
                {
                    id = Guid.NewGuid().ToString(),
                    project_id = prj.id,
                    user_id = userId,
                    created_by = userId,
                    created_at = DateTimeOffset.Now
                };

                _context.TblProjectStaffs.Add(projectStaff);

                var ifCustomerExists = _context.TblCustomers.Where(c => c.id == project.CustomerDetails.Customer_Id).FirstOrDefault();
                TblCustomer customer = new();
                TblIndustrySegments industrySegment = new();
                if (ifCustomerExists == null)
                {
                    customer.id = project.CustomerDetails.Customer_Id;
                    customer.customer_id = project.CustomerDetails.Customer_Id;
                    customer.erp_customer_id = project.CustomerDetails.Erp_Customer_Id;
                    customer.customer_name = project.CustomerDetails.Customer_Name;
                    customer.country_code = project.CustomerDetails.Country_Code;
                    customer.zipcode = project.CustomerDetails.Zipcode;
                    customer.city = project.CustomerDetails.City;
                    customer.street = project.CustomerDetails.Street;
                    customer.contact_id = string.Empty; //project.CustomerDetails.Contacts[0].Contact_Id;
                    customer.phone_number = project.CustomerDetails.Phone_Number;
                    customer.language = project.CustomerDetails.Language;
                    customer.company_code = project.Company_Code;
                    customer.created_at = DateTimeOffset.Now;
                    customer.created_by = userId;
                    customer.modified_at = DateTimeOffset.Now;
                    customer.modified_by = "";
                    _context.TblCustomers.Add(customer);

                    industrySegment.id = Guid.NewGuid().ToString();
                    industrySegment.segments = project?.CustomerDetails?.IndustryCode;
                    industrySegment.created_at = DateTimeOffset.Now;
                    industrySegment.created_by = userId;
                    industrySegment.modified_at = DateTimeOffset.Now;
                    industrySegment.modified_by = userId;
                    _context.TblIndustrySegments.Add(industrySegment);
                }
                else
                {
                    ifCustomerExists.customer_name = project.CustomerDetails.Customer_Name;
                    ifCustomerExists.country_code = project.CustomerDetails.Country_Code;
                    ifCustomerExists.zipcode = project.CustomerDetails.Zipcode;
                    ifCustomerExists.city = project.CustomerDetails.City;
                    ifCustomerExists.street = project.CustomerDetails.Street;
                    ifCustomerExists.contact_id = string.Empty;
                    ifCustomerExists.phone_number = project.CustomerDetails.Phone_Number;
                    ifCustomerExists.language = project.CustomerDetails.Language;
                    ifCustomerExists.company_code = project.Company_Code;
                    ifCustomerExists.modified_at = DateTimeOffset.Now;

                    _context.SaveChanges();
                }

                List<TblContact> contacts = new List<TblContact>();
                foreach (var item in project.CustomerDetails.Contacts)
                {
                    var contactDuplicate = _context.TblContacts.Where(con => con.contact_id == item.Contact_Id).FirstOrDefault();
                    if (contactDuplicate == null)
                    {
                        //&& !contacts.Any(c => c.contact_id == item.Contact_Id)
                        TblContact contact = new TblContact();
                        contact.contact_id = item.Contact_Id;
                        contact.customer_id = project.CustomerDetails.Customer_Id;
                        contact.department = item.Department;
                        contact.display_name = item.Display_Name;
                        contact.email_address = item.Email_Address;
                        contact.first_name = item.First_Name;
                        contact.last_name = item.Last_Name;
                        contact.phone_number = item.Phone_Number;
                        contact.language = item.Language;
                        contact.title = item.Title;
                        contact.created_at = DateTimeOffset.Now;
                        contact.created_by = userId;
                        contact.modified_at = DateTimeOffset.Now;
                        contact.modified_by = "";

                        contacts.Add(contact);
                        _context.TblContacts.Add(contact);
                        _context.SaveChanges();
                    }
                    else
                    {
                        contactDuplicate.department = item.Department;
                        contactDuplicate.display_name = item.Display_Name;
                        contactDuplicate.email_address = item.Email_Address;
                        contactDuplicate.first_name = item.First_Name;
                        contactDuplicate.last_name = item.Last_Name;
                        contactDuplicate.phone_number = item.Phone_Number;
                        contactDuplicate.language = item.Language;
                        contactDuplicate.title = item.Title;

                        _context.SaveChanges();
                    }

                }
                _context.SaveChanges();

                var projectRequest = new ProjectRequest(prj.id
                    , prj.erp_project_id
                    , prj.project_name
                    , prj.status
                    , prj.start_date
                    , prj.end_date
                    , project.Controlling_Area_Code
                    , customer_Guid.ToString()
                    , project.Customer_Id
                    , "ADD");

                var techincalHeader = new RequestTechnicalHeader()
                {
                    TenantID = httpContextAccessor.HttpContext?.User?.GetTenantId() ?? String.Empty,
                    CompanyCode = project.Company_Code,
                    EmailAddress = httpContextAccessor
                    .HttpContext?
                    .User?
                    .Claims
                    .FirstOrDefault(c => c.Type == ClaimTypes.Email)?
                    .Value ?? String.Empty,
                    RequestID = Guid.NewGuid().ToString(),
                    Timestamp = DateTime.UtcNow
                };
                var projectRequestEvent = new ProjectRequestEvent(projectRequest, techincalHeader);

                return projectRequestEvent;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        /// <summary>
        /// Service for delete project
        /// </summary>
        /// <param name="projectId"></param>
        /// <returns></returns>
        public async Task<bool> DeleteProject(string projectId)
        {
            try
            {
                var deleteProject = await _context.Database.ExecuteSqlRawAsync("usp_Deleteproject {0}", projectId);
                if (deleteProject == -1)
                {
                    return true;
                }
            }
            catch (Exception e)
            {
                Console.Write(e);
                return false;
            }
            return false;
        }

        /// <summary>
        /// Repository Service to get All projects
        /// </summary>
        /// <returns></returns>
        public async Task<List<ProjectDashboardDTO>> GetAllProjects()
        {
            try
            {
                var result = new List<ProjectDashboardDTO>();
                var userId = GetCurrentUserId();
                if (IsUserProjectManager())
                    result = await (from p in _context.TblProjects
                                    join cus in _context.TblCustomers on p.customer_id equals cus.id
                                    join u in _context.TblUsers on p.created_by equals u.id
                                    join cnt in _context.TblContacts on p.contact_id equals cnt.contact_id
                                    join comp in _context.TblCompanies on p.company_id equals comp.company_code
                                    let stpCount = (from service in _context.TblServices.Where(s => s.project_id == p.id)
                                                    join sm in _context.TblServiceMachines on service.id equals sm.service_id
                                                    join mr in _context.TblMachineRoadmap on sm.id equals mr.service_machine_id
                                                    join rm in _context.TblRoadmapMaster on mr.roadmap_id equals rm.roadmap_id
                                                    join section in _context.TblRoadmapSection on rm.roadmap_id equals section.roadmap_id
                                                    join subsection in _context.TblRoadmapSubSectionMster on section.id equals subsection.section_id
                                                    join step in _context.TblStepMaster on subsection.id equals step.roadmap_section_id
                                                    select new { }).Count()
                                    let answerStp = (from service in _context.TblServices.Where(s => s.project_id == p.id)
                                                     join sm in _context.TblServiceMachines on service.id equals sm.service_id
                                                     join mr in _context.TblMachineRoadmap on sm.id equals mr.service_machine_id
                                                     join rm in _context.TblRoadmapMaster on mr.roadmap_id equals rm.roadmap_id
                                                     join section in _context.TblRoadmapSection on rm.roadmap_id equals section.roadmap_id
                                                     join subsection in _context.TblRoadmapSubSectionMster on section.id equals subsection.section_id
                                                     join step in _context.TblStepMaster on subsection.id equals step.roadmap_section_id
                                                     join stepAssoci in _context.TblStepMachineAssociation on new { a1 = step.step_id, a2 = sm.id } equals new { a1 = stepAssoci.step_id, a2 = stepAssoci.servicemachine_id }
                                                     join smsteps in _context.TblServiceMachineSteps on new { a1 = step.step_id, a2 = sm.id } equals new { a1 = smsteps.step_id, a2 = smsteps.servicemachine_id }
                                                     select new { }).Count()
                                    let serviceStpCount = (from service in _context.TblServices.Where(s => s.project_id == p.id)
                                                           join mr in _context.TblServiceRoadmapAssociationTable on service.id equals mr.service_id
                                                           join rm in _context.TblRoadmapMaster on mr.roadmap_id equals rm.roadmap_id
                                                           join section in _context.TblRoadmapSection on rm.roadmap_id equals section.roadmap_id
                                                           join subsection in _context.TblRoadmapSubSectionMster on section.id equals subsection.section_id
                                                           join step in _context.TblStepMaster on subsection.id equals step.roadmap_section_id
                                                           select new { }).Count()
                                    let ansServiceStp = (from service in _context.TblServices.Where(s => s.project_id == p.id)
                                                         join mr in _context.TblServiceRoadmapAssociationTable on service.id equals mr.service_id
                                                         join rm in _context.TblRoadmapMaster on mr.roadmap_id equals rm.roadmap_id
                                                         join section in _context.TblRoadmapSection on rm.roadmap_id equals section.roadmap_id
                                                         join subsection in _context.TblRoadmapSubSectionMster on section.id equals subsection.section_id
                                                         join step in _context.TblStepMaster on subsection.id equals step.roadmap_section_id
                                                         join stepAssoci in _context.TblStepMachineAssociation on new { a1 = step.step_id, a2 = service.id } equals new { a1 = stepAssoci.step_id, a2 = stepAssoci.servicemachine_id }
                                                         join smsteps in _context.TblServiceMachineSteps on new { a1 = step.step_id, a2 = service.id } equals new { a1 = smsteps.step_id, a2 = smsteps.servicemachine_id }
                                                         select new { }).Count()
                                    let totalCalHrs = (from service in _context.TblServices.Where(s => s.project_id == p.id)
                                                       join sm in _context.TblServiceMachines on service.id equals sm.service_id
                                                       join hrs in _context.TblMachineHour on sm.id equals hrs.service_machine_id
                                                       select new
                                                       {
                                                           CalculatedHours = hrs.calculated_hours
                                                       }).Sum(s => s.CalculatedHours)
                                    let actlHours = (from service in _context.TblServices.Where(s => s.project_id == p.id)
                                                     join sm in _context.TblServiceMachines on service.id equals sm.service_id
                                                     join actl in _context.TblActualHours on sm.id equals actl.service_machine_id
                                                     select new
                                                     {
                                                         ActualHours = actl.actualhours
                                                     }).Sum(s => s.ActualHours)

                                    orderby p.created_at descending

                                    select new ProjectDashboardDTO
                                    {
                                        Project_Id = p.id,
                                        Erp_Project_Id = p.erp_project_id,
                                        Project_Name = p.project_name,
                                        Status = p.status,
                                        Region = String.Empty, //tnc.region,
                                        Customer_Name = cus.customer_name,
                                        Erp_Customer_Id = cus.erp_customer_id,
                                        Customer_Id = cus.customer_id,
                                        Contact_Name = cnt.first_name + " " + cnt.last_name,
                                        Company_Code = p.company_id,
                                        Customer_Address = cus.street + ", " + cus.city + ", " + cus.country_code + ", " + cus.zipcode,
                                        Project_Manager = u.display_name,
                                        Progress = 0,
                                        TotalActualHours = actlHours,
                                        TotlalCalculatedHours = totalCalHrs,
                                        AnsweredServiceStepCount = serviceStpCount,
                                        TotalServiceStepCount = ansServiceStp,
                                        TotalStepCount = stpCount,
                                        TotalAnswredStepCount = answerStp,
                                        End_Date = p.end_date != null ? p.end_date.Value.ToString("dd/MM/yyyy") : null,
                                    }).ToListAsync();
                else
                    result = await (from p in _context.TblProjects
                                    join cus in _context.TblCustomers on p.customer_id equals cus.id
                                    join pst in _context.TblProjectStaffs on p.id equals pst.project_id
                                    join u in _context.TblUsers on p.created_by equals u.id
                                    join cnt in _context.TblContacts on p.contact_id equals cnt.contact_id
                                    join comp in _context.TblCompanies on p.company_id equals comp.company_code
                                    let stpCount = (from service in _context.TblServices.Where(s => s.project_id == p.id)
                                                    join sm in _context.TblServiceMachines on service.id equals sm.service_id
                                                    join mr in _context.TblMachineRoadmap on sm.id equals mr.service_machine_id
                                                    join rm in _context.TblRoadmapMaster on mr.roadmap_id equals rm.roadmap_id
                                                    join section in _context.TblRoadmapSection on rm.roadmap_id equals section.roadmap_id
                                                    join subsection in _context.TblRoadmapSubSectionMster on section.id equals subsection.section_id
                                                    join step in _context.TblStepMaster on subsection.id equals step.roadmap_section_id
                                                    select new { }).Count()
                                    let answerStp = (from service in _context.TblServices.Where(s => s.project_id == p.id)
                                                     join sm in _context.TblServiceMachines on service.id equals sm.service_id
                                                     join mr in _context.TblMachineRoadmap on sm.id equals mr.service_machine_id
                                                     join rm in _context.TblRoadmapMaster on mr.roadmap_id equals rm.roadmap_id
                                                     join section in _context.TblRoadmapSection on rm.roadmap_id equals section.roadmap_id
                                                     join subsection in _context.TblRoadmapSubSectionMster on section.id equals subsection.section_id
                                                     join step in _context.TblStepMaster on subsection.id equals step.roadmap_section_id
                                                     join stepAssoci in _context.TblStepMachineAssociation on new { a1 = step.step_id, a2 = sm.id } equals new { a1 = stepAssoci.step_id, a2 = stepAssoci.servicemachine_id }
                                                     join smsteps in _context.TblServiceMachineSteps on new { a1 = step.step_id, a2 = sm.id, a3 = userId } equals new { a1 = smsteps.step_id, a2 = smsteps.servicemachine_id, a3 = smsteps.user_id }
                                                     select new { }).Count()
                                    let serviceStpCount = (from service in _context.TblServices.Where(s => s.project_id == p.id)
                                                           join mr in _context.TblServiceRoadmapAssociationTable on service.id equals mr.service_id
                                                           join rm in _context.TblRoadmapMaster on mr.roadmap_id equals rm.roadmap_id
                                                           join section in _context.TblRoadmapSection on rm.roadmap_id equals section.roadmap_id
                                                           join subsection in _context.TblRoadmapSubSectionMster on section.id equals subsection.section_id
                                                           join step in _context.TblStepMaster on subsection.id equals step.roadmap_section_id
                                                           select new { }).Count()
                                    let ansServiceStp = (from service in _context.TblServices.Where(s => s.project_id == p.id)
                                                         join mr in _context.TblServiceRoadmapAssociationTable on service.id equals mr.service_id
                                                         join rm in _context.TblRoadmapMaster on mr.roadmap_id equals rm.roadmap_id
                                                         join section in _context.TblRoadmapSection on rm.roadmap_id equals section.roadmap_id
                                                         join subsection in _context.TblRoadmapSubSectionMster on section.id equals subsection.section_id
                                                         join step in _context.TblStepMaster on subsection.id equals step.roadmap_section_id
                                                         join stepAssoci in _context.TblStepMachineAssociation on new { a1 = step.step_id, a2 = service.id } equals new { a1 = stepAssoci.step_id, a2 = stepAssoci.servicemachine_id }
                                                         join smsteps in _context.TblServiceMachineSteps on new { a1 = step.step_id, a2 = service.id, a3 = userId } equals new { a1 = smsteps.step_id, a2 = smsteps.servicemachine_id, a3 = smsteps.user_id }
                                                         select new { }).Count()
                                    let totalCalHrs = (from service in _context.TblServices.Where(s => s.project_id == p.id)
                                                       join sm in _context.TblServiceMachines on service.id equals sm.service_id
                                                       join hrs in _context.TblMachineHour on sm.id equals hrs.service_machine_id
                                                       select new
                                                       {
                                                           CalculatedHours = hrs.calculated_hours
                                                       }).Sum(s => s.CalculatedHours)
                                    let actlHours = (from service in _context.TblServices.Where(s => s.project_id == p.id)
                                                     join sm in _context.TblServiceMachines on service.id equals sm.service_id
                                                     join actl in _context.TblActualHours on sm.id equals actl.service_machine_id
                                                     select new
                                                     {
                                                         ActualHours = actl.actualhours
                                                     }).Sum(s => s.ActualHours)
                                    where pst.user_id == GetCurrentUserId()
                                    orderby p.created_at descending

                                    select new ProjectDashboardDTO
                                    {
                                        Project_Id = p.id,
                                        Erp_Project_Id = p.erp_project_id,
                                        Project_Name = p.project_name,
                                        Status = p.status,
                                        Region = String.Empty, //tnc.region,
                                        Customer_Name = cus.customer_name,
                                        Erp_Customer_Id = cus.erp_customer_id,
                                        Customer_Id = cus.customer_id,
                                        Contact_Name = cnt.first_name + " " + cnt.last_name,
                                        Company_Code = p.company_id,
                                        Customer_Address = cus.street + ", " + cus.city + ", " + cus.country_code + ", " + cus.zipcode,
                                        Project_Manager = u.display_name,
                                        Progress = 0,
                                        TotalActualHours = actlHours,
                                        TotlalCalculatedHours = totalCalHrs,
                                        AnsweredServiceStepCount = serviceStpCount,
                                        TotalServiceStepCount = ansServiceStp,
                                        TotalStepCount = stpCount,
                                        TotalAnswredStepCount = answerStp,
                                        End_Date = p.end_date != null ? p.end_date.Value.ToString("dd/MM/yyyy") : null,
                                    }).ToListAsync();
                return result;
            }
            catch (Exception ex)
            {

                throw ex;
            }
            
        }

        /// <summary>
        /// Find project by Id
        /// </summary>
        /// <param name="projectId"></param>
        /// <returns></returns>
        public async Task<ProjectDTO> GetprojectById(string projectId)
        {
            var result = new ProjectDTO();
            var userId = GetCurrentUserId();
            if (IsUserProjectManager())
                
                result = await ((from p in _context.TblProjects
                                 join cus in _context.TblCustomers on p.customer_id equals cus.id
                                 join con in _context.TblControllingAreas on p.controlling_id equals con.id into gj
                                 from ca in gj.DefaultIfEmpty()
                                 join u in _context.TblUsers on p.created_by equals u.id
                                 join contact in _context.TblContacts on p.contact_id equals contact.contact_id
                                 join cust in _context.TblCustomers on p.customer_id equals cust.customer_id
                                 join comp in _context.TblCompanies on p.company_id equals comp.company_code
                                 where p.id == projectId
                                 select new ProjectDTO
                                 {
                                     Project_Id = p.id,
                                     Erp_Project_Id = p.erp_project_id,
                                     Project_Name = p.project_name,
                                     Description = p.description,
                                     Start_Date = p.start_date != null ? p.start_date.Value.ToString("dd/MM/yyyy") : null,
                                     End_Date = p.end_date != null ? p.end_date.Value.ToString("dd/MM/yyyy") : null,
                                     Status = p.status,
                                     Parent_Company = ca.controlling_area,
                                     Controlling_Area_Code = ca.controlling_area_code,
                                     Region = String.Empty,//tnc.region,
                                     Customer_Name = cus.customer_name,
                                     Erp_Customer_Id = cus.erp_customer_id,
                                     IndustrySegment = _context.TblIndustrySegments.Where(i =>i.customer_id == cus.customer_id).FirstOrDefault().segments??null,
                                     Comapny_Name = comp.company_name,
                                     Company_Code = comp.company_code,
                                     Machine_Number = "",
                                     Account_Name = "",
                                     Notes = p.notes,
                                     Manager_Name = "-",
                                     Time = 30,
                                     Revenue = 70,
                                     Cost = 50,
                                     Project_Phase = "Project Management",
                                     User_Name = u.display_name,
                                     CustomerDetails = new CustomerDTO
                                     {
                                         Customer_Id = cust.customer_id,
                                         Customer_Name = cust.customer_name,
                                         City = cust.city,
                                         Zipcode = cust.zipcode,
                                         Street = cust.street,
                                         Phone_Number = cust.phone_number,
                                         Contacts = new List<ContactDTO>{new ContactDTO
                                         {
                                             Contact_Id = contact.contact_id,
                                             First_Name = contact.first_name,
                                             Last_Name = contact.last_name,
                                             Display_Name = contact.display_name,
                                             Email_Address = contact.email_address,
                                             Title = contact.title,
                                             Language = contact.language,
                                             Phone_Number = contact.phone_number,
                                             Department = contact.department
                                         }}
                                     },
                                     project_Kpi_Details = _context.TblProjectKPI.Where(kpi => kpi.id == p.project_kpi_id).Select(kpi => new ProjectKpiDTO
                                     {
                                         Project_Kpi_Id = kpi.id,
                                         Calculated_Hours = kpi.calculated_hours,
                                         Cost_Proress = kpi.cost_progress,
                                         Hours_Progress = kpi.hours_progress,
                                         Roadmap_Progress = kpi.roadmap_progress
                                     }).FirstOrDefault(),
                                     TotalActualHours = (from prj in _context.TblProjects
                                                         join service in _context.TblServices on prj.id equals service.project_id into serviceHours
                                                         from actualhrs in serviceHours.DefaultIfEmpty()
                                                         join sm in _context.TblServiceMachines on actualhrs.id equals sm.service_id
                                                         join actl in _context.TblActualHours on sm.id equals actl.service_machine_id
                                                         where prj.id == p.id
                                                         select new
                                                         {
                                                             ActualHours = actl.actualhours
                                                         }).Sum(s => s.ActualHours),
                                     TotlalCalculatedHours = (from prj in _context.TblProjects
                                                              join service in _context.TblServices on prj.id equals service.project_id into serviceHours
                                                              from s in serviceHours.DefaultIfEmpty()
                                                              join hrs in _context.TblServiceHour on s.id equals hrs.service_id
                                                              where prj.id == p.id
                                                              select new
                                                              {
                                                                  CalculatedHours = hrs.calculated_hours
                                                              }).Sum(s => s.CalculatedHours),
                                     TotalStepCount = (from prj in _context.TblProjects
                                                       join service in _context.TblServices on prj.id equals service.project_id into serviceHours
                                                       from s in serviceHours.DefaultIfEmpty()
                                                       join sm in _context.TblServiceMachines on s.id equals sm.service_id
                                                       join mr in _context.TblMachineRoadmap on sm.id equals mr.service_machine_id
                                                       join rm in _context.TblRoadmapMaster on mr.roadmap_id equals rm.roadmap_id
                                                       join section in _context.TblRoadmapSection on rm.roadmap_id equals section.roadmap_id
                                                       join subsection in _context.TblRoadmapSubSectionMster on section.id equals subsection.section_id
                                                       join step in _context.TblStepMaster on subsection.id equals step.roadmap_section_id
                                                       where prj.id == p.id
                                                       select new { }).Count(),
                                     TotalAnswredStepCount = (from prj in _context.TblProjects
                                                              join service in _context.TblServices on prj.id equals service.project_id into serviceHours
                                                              from s in serviceHours.DefaultIfEmpty()
                                                              join sm in _context.TblServiceMachines on s.id equals sm.service_id
                                                              join mr in _context.TblMachineRoadmap on sm.id equals mr.service_machine_id
                                                              join rm in _context.TblRoadmapMaster on mr.roadmap_id equals rm.roadmap_id
                                                              join section in _context.TblRoadmapSection on rm.roadmap_id equals section.roadmap_id
                                                              join subsection in _context.TblRoadmapSubSectionMster on section.id equals subsection.section_id
                                                              join step in _context.TblStepMaster on subsection.id equals step.roadmap_section_id
                                                              join smsteps in _context.TblServiceMachineSteps on new { a1 = step.step_id, a2 = sm.id} equals new { a1 = smsteps.step_id, a2 = smsteps.servicemachine_id }
                                                              where prj.id == p.id
                                                              select new { }).Count(),
                                     ActualCost = (from prj in _context.TblProjects
                                                   join service in _context.TblServices on prj.id equals service.project_id into serviceHours
                                                   from s in serviceHours.DefaultIfEmpty()
                                                   join cost in _context.TblServiceActualCost on s.id equals cost.service_id
                                                   where prj.id == p.id
                                                   select new
                                                   {
                                                       Actual_Cost = cost.current_value
                                                   }).Sum(s1 =>s1.Actual_Cost),
                                     ProjectBudget = (from prj in _context.TblProjects
                                                      join service in _context.TblServices on prj.id equals service.project_id into serviceHours
                                                      from s in serviceHours.DefaultIfEmpty()
                                                      join cost in _context.TblServicePlannedCost on s.id equals cost.service_id
                                                      where prj.id == p.id
                                                      select new
                                                      {
                                                          planned_Cost = cost.current_value
                                                      }).Sum(s1 => s1.planned_Cost)
                                 }).FirstOrDefaultAsync());
            else
                result = await ((from p in _context.TblProjects
                                 join cus in _context.TblCustomers on p.customer_id equals cus.id
                                 join con in _context.TblControllingAreas on p.controlling_id equals con.id into gj
                                 from ca in gj.DefaultIfEmpty()
                                 join u in _context.TblUsers on p.created_by equals u.id
                                 join contact in _context.TblContacts on p.contact_id equals contact.contact_id
                                 join cust in _context.TblCustomers on p.customer_id equals cust.customer_id
                                 join comp in _context.TblCompanies on p.company_id equals comp.company_code
                                 join prjstaff in _context.TblProjectStaffs on new { userId = GetCurrentUserId(), projectId = p.id } equals new { userId = prjstaff.user_id, projectId = prjstaff.project_id }
                                 where p.id == projectId
                                 select new ProjectDTO
                                 {
                                     Project_Id = p.id,
                                     Erp_Project_Id = p.erp_project_id,
                                     Project_Name = p.project_name,
                                     Description = p.description,
                                     Start_Date = p.start_date != null ? p.start_date.Value.ToString("dd/MM/yyyy") : null,
                                     End_Date = p.end_date != null ? p.end_date.Value.ToString("dd/MM/yyyy") : null,
                                     Status = p.status,
                                     Parent_Company = ca.controlling_area,
                                     Controlling_Area_Code = ca.controlling_area_code,
                                     Region = String.Empty,//tnc.region,
                                     Customer_Name = cus.customer_name,
                                     Erp_Customer_Id = cus.erp_customer_id,
                                     IndustrySegment = _context.TblIndustrySegments.Where(i => i.customer_id == cus.customer_id).FirstOrDefault().segments ?? null,
                                     Comapny_Name = comp.company_name,
                                     Company_Code = comp.company_code,
                                     Machine_Number = "",
                                     Account_Name = "",
                                     Notes = p.notes,
                                     Manager_Name = "-",
                                     Time = 30,
                                     Revenue = 70,
                                     Cost = 50,
                                     Project_Phase = "Project Management",
                                     User_Name = u.display_name,
                                     CustomerDetails = new CustomerDTO
                                     {
                                         Customer_Id = cust.customer_id,
                                         Customer_Name = cust.customer_name,
                                         City = cust.city,
                                         Zipcode = cust.zipcode,
                                         Street = cust.street,
                                         Phone_Number = cust.phone_number,
                                         Contacts = new List<ContactDTO> { new ContactDTO
                                         {
                                             Contact_Id = contact.contact_id,
                                             First_Name = contact.first_name,
                                             Last_Name = contact.last_name,
                                             Display_Name = contact.display_name,
                                             Email_Address = contact.email_address,
                                             Title = contact.title,
                                             Language = contact.language,
                                             Phone_Number = contact.phone_number,
                                             Department = contact.department
                                         } }
                                     },
                                     project_Kpi_Details = _context.TblProjectKPI.Where(kpi => kpi.id == p.project_kpi_id).Select(kpi => new ProjectKpiDTO
                                     {
                                         Project_Kpi_Id = kpi.id,
                                         Calculated_Hours = kpi.calculated_hours,
                                         Cost_Proress = kpi.cost_progress,
                                         Hours_Progress = kpi.hours_progress,
                                         Roadmap_Progress = kpi.roadmap_progress
                                     }).FirstOrDefault(),
                                     TotalActualHours = (from prj in _context.TblProjects
                                                         join service in _context.TblServices on prj.id equals service.project_id into serviceHours
                                                         from actualhrs in serviceHours.DefaultIfEmpty()
                                                         join sm in _context.TblServiceMachines on actualhrs.id equals sm.service_id
                                                         join actl in _context.TblActualHours on sm.id equals actl.service_machine_id
                                                         where prj.id == p.id
                                                         select new
                                                         {
                                                             ActualHours = actl.actualhours
                                                         }).Sum(s => s.ActualHours),
                                     TotlalCalculatedHours = (from prj in _context.TblProjects
                                                              join service in _context.TblServices on prj.id equals service.project_id into serviceHours
                                                              from s in serviceHours.DefaultIfEmpty()
                                                              join hrs in _context.TblServiceHour on s.id equals hrs.service_id
                                                              where prj.id == p.id
                                                              select new
                                                              {
                                                                  CalculatedHours = hrs.calculated_hours
                                                              }).Sum(s => s.CalculatedHours),
                                     TotalStepCount = (from prj in _context.TblProjects
                                                       join service in _context.TblServices on prj.id equals service.project_id into serviceHours
                                                       from s in serviceHours.DefaultIfEmpty()
                                                       join sm in _context.TblServiceMachines on s.id equals sm.service_id
                                                       join mr in _context.TblMachineRoadmap on sm.id equals mr.service_machine_id
                                                       join rm in _context.TblRoadmapMaster on mr.roadmap_id equals rm.roadmap_id
                                                       join section in _context.TblRoadmapSection on rm.roadmap_id equals section.roadmap_id
                                                       join subsection in _context.TblRoadmapSubSectionMster on section.id equals subsection.section_id
                                                       join step in _context.TblStepMaster on subsection.id equals step.roadmap_section_id
                                                       where prj.id == p.id
                                                       select new { }).Count(),
                                     TotalAnswredStepCount = (from prj in _context.TblProjects
                                                              join service in _context.TblServices on prj.id equals service.project_id into serviceHours
                                                              from s in serviceHours.DefaultIfEmpty()
                                                              join sm in _context.TblServiceMachines on s.id equals sm.service_id
                                                              join mr in _context.TblMachineRoadmap on sm.id equals mr.service_machine_id
                                                              join rm in _context.TblRoadmapMaster on mr.roadmap_id equals rm.roadmap_id
                                                              join section in _context.TblRoadmapSection on rm.roadmap_id equals section.roadmap_id
                                                              join subsection in _context.TblRoadmapSubSectionMster on section.id equals subsection.section_id
                                                              join step in _context.TblStepMaster on subsection.id equals step.roadmap_section_id
                                                              join smsteps in _context.TblServiceMachineSteps on new { a1 = step.step_id, a2 = sm.id, a3 = userId } equals new { a1 = smsteps.step_id, a2 = smsteps.servicemachine_id, a3 = smsteps.user_id }
                                                              where prj.id == p.id
                                                              select new { }).Count(),
                                     ActualCost = (from prj in _context.TblProjects
                                                   join service in _context.TblServices on prj.id equals service.project_id into serviceHours
                                                   from s in serviceHours.DefaultIfEmpty()
                                                   join cost in _context.TblServiceActualCost on s.id equals cost.service_id
                                                   where prj.id == p.id
                                                   select new
                                                   {
                                                       Actual_Cost = cost.current_value
                                                   }).Sum(s1 => s1.Actual_Cost),
                                     ProjectBudget = (from prj in _context.TblProjects
                                                      join service in _context.TblServices on prj.id equals service.project_id into serviceHours
                                                      from s in serviceHours.DefaultIfEmpty()
                                                      join cost in _context.TblServicePlannedCost on s.id equals cost.service_id
                                                      where prj.id == p.id
                                                      select new
                                                      {
                                                          planned_Cost = cost.current_value
                                                      }).Sum(s1 => s1.planned_Cost)
                                 }).FirstOrDefaultAsync());

            if (!string.IsNullOrEmpty(result.Project_Id))
            {
                var assignedStaff = new List<ProjectStaffDTO>();

                var userStaffs = (from u in _context.TblUsers
                                  join ps in _context.TblProjectStaffs on u.id equals ps.user_id
                                  where ps.project_id == projectId
                                  select new ProjectStaffDTO
                                  {
                                      Display_Name = u.display_name,
                                      Email_Address = u.email_address,
                                      First_Name = u.first_name,
                                      Last_Name = u.last_name,
                                      Login_Name = u.email_address,
                                      UserSharePointId = ps.User_SharePoint_Id,
                                      StaffType = "User"
                                  }).ToList();

                var groupStaffs = (from g in _context.TblGroups
                                   join ps in _context.TblProjectStaffs on g.id equals ps.group_id
                                   where ps.project_id == projectId
                                   select new ProjectStaffDTO
                                   {
                                       Display_Name = g.group_name,
                                       Email_Address = g.group_email_address,
                                       First_Name = string.Empty,
                                       Last_Name = string.Empty,
                                       Login_Name = string.Empty,
                                       UserSharePointId = ps.User_SharePoint_Id,
                                       StaffType = "Group"
                                   }).ToList();

                result.AssignedStaff = new List<ProjectStaffDTO>();

                result.AssignedStaff.AddRange(userStaffs);
                result.AssignedStaff.AddRange(groupStaffs);
            }
            return result;
        }

        /// <summary>
        /// Service to update project
        /// </summary>
        /// <param name="project"></param>
        /// <returns></returns>
        public async Task<bool> UpdateProject(UpdateProjectDto project)
        {
            var isSuccess = false;
            try
            {
                var updatePrj = _context.TblProjects.Where(p => p.id == project.Project_Id).FirstOrDefault();

                var userId = GetCurrentUserId();

                if (updatePrj != null)
                {
                    #region Log AuditEntry
                    //    bool projectName = project.Project_Name != null && project?.Project_Name.Trim() != updatePrj?.project_name.Trim();
                    //    bool projectDescription = project.Project_Description != null && project?.Project_Description != updatePrj?.description;
                    //    bool projectStartDate = project.Start_Date != null && project?.Start_Date.ToString() != updatePrj.start_date.ToString();
                    //    bool projectEndDate = project.End_Date != null && project?.End_Date.ToString() != updatePrj?.end_date.ToString();
                    bool projectContact = project.Contacts.FirstOrDefault(con => con.IsSeleted)?.Contact_Id != null && project.Contacts.FirstOrDefault(con => con.IsSeleted)?.Contact_Id != updatePrj?.contact_id;
                    
                    if (projectContact)
                    {
                        //AuditLogEntryEvent auditLogEntryEvent = new()
                        //{
                        //    Project_Id = updatePrj.id,
                        //    Action = "Update",
                        //    Scope = "Project updated with new contact" + " " + project.Contacts.FirstOrDefault(con => con.IsSeleted)?.Contact_Id,
                        //    Old_Value = updatePrj.contact_id,
                        //    New_Value = project.Contacts.FirstOrDefault(con => con.IsSeleted)?.Contact_Id,
                        //    User_Id = GetCurrentUserId(),
                        //    Affected_Table = "TblProject"
                        //};
                        //LogAuditEntry(auditLogEntryEvent);
                        TblAuditEntry tblAuditEntry = new();
                        tblAuditEntry.id = Guid.NewGuid().ToString();
                        tblAuditEntry.project_id = updatePrj?.id;
                        tblAuditEntry.erp_project_id = updatePrj?.erp_project_id;
                        tblAuditEntry.action = "Update";
                        tblAuditEntry.scope = "Project updated with new contact" + " " + project?.Contacts.FirstOrDefault(con => con.IsSeleted)?.Contact_Id;
                        tblAuditEntry.created_at = DateTime.UtcNow;
                        tblAuditEntry.user_id = _context.TblUsers.FirstOrDefault(p => p.id == GetCurrentUserId())?.email_address ?? null;
                        tblAuditEntry.old_value = updatePrj?.contact_id;
                        tblAuditEntry.new_value = project?.Contacts.FirstOrDefault(con => con.IsSeleted)?.Contact_Id;
                        tblAuditEntry.affected_table = "TblProject";
                        _context.TblAuditEntry.Add(tblAuditEntry);
                    }
                    #endregion
                    updatePrj.project_name = project.Project_Name != null ? project.Project_Name : updatePrj.project_name;
                    updatePrj.description = project.Project_Description != null ? project.Project_Description : updatePrj.description;
                    updatePrj.start_date = project.Start_Date != null ? project.Start_Date : updatePrj.start_date;
                    updatePrj.end_date = project.End_Date != null ? project.End_Date : updatePrj.end_date;
                    updatePrj.contact_id = project.Contacts.FirstOrDefault(con => con.IsSeleted)?.Contact_Id ?? String.Empty;

                    
                    _context.SaveChanges();


                    isSuccess = true;
                }
                return isSuccess;
            }
            catch (Exception ex)
            {
                return isSuccess;
            }
        }

        /// <summary>
        /// Project metrics and Service metrics
        /// </summary>
        /// <returns></returns>
        public Dictionary<string, int> GetProjectEffortMetrics()
        {
            try
            {
                Dictionary<string, int> dataList = new();
                var result = _context.TblProjects.ToList();
                var service = _context.TblServices.ToList();
                var TotalProjects = result.Count != 0 ? result.Count : 0;
                var totalServices = (from prj in _context.TblProjects
                                     join offer in _context.TblOffers on prj.id equals offer.project_id
                                     join ser in _context.TblServices on offer.id equals ser.offer_id
                                     select new { }).Count();
                var servicesInProgress = (from prj in _context.TblProjects
                                          join offer in _context.TblOffers on prj.id equals offer.project_id
                                          join ser in _context.TblServices on offer.id equals ser.offer_id
                                          where ser.status.ToLower() == MachineStatus.IN_PROGRESS.ToLower()
                                          select new { }).Count();
                var servicesCompleted = (from prj in _context.TblProjects
                                         join offer in _context.TblOffers on prj.id equals offer.project_id
                                         join ser in _context.TblServices on offer.id equals ser.offer_id
                                         where ser.status.ToLower() == MachineStatus.COMPLETED.ToLower()
                                         select new { }).Count();
                dataList.Add("TotalProjects", TotalProjects);
                dataList.Add("ServicesInProgress", servicesInProgress);
                dataList.Add("ServicesCompleted", servicesCompleted);
                dataList.Add("TotalServices", totalServices);
                return dataList;
            }
            catch (Exception)
            {

                throw;
            }
        }
      

        /// <summary>
        /// Get project related services
        /// </summary>
        /// <param name="projectId"></param>
        /// <param name="orderId"></param>
        /// <param name="serviceType"></param>
        /// <returns></returns>
        public async Task<ServiceDetailDTO> GetServiceDetails(string projectId, string orderId, string serviceType)
        {
            var serviceDetails = new ServiceDetailDTO();
            if (IsUserProjectManager())

                serviceDetails = await (from service in _context.TblServices
                                        join order in _context.TblOrder on service.id equals order.service_id
                                        join p in _context.TblProjects on service.project_id equals p.id
                                        join company in _context.TblCompanies on p.company_id equals company.company_code
                                        join conArea in _context.TblControllingAreas on p.controlling_id equals conArea.id into controllingGrp
                                        from con in controllingGrp.DefaultIfEmpty()

                                        where order.project_id == projectId && order.erp_order_id == orderId && order.service_id == serviceType
                                        select new ServiceDetailDTO
                                        {
                                            Project = new ProjectDTO
                                            {
                                                Project_Id = p.id,
                                                Erp_Project_Id = p.erp_project_id,
                                                Project_Name = p.project_name,
                                                Description = p.description,
                                                Start_Date = p.start_date != null ? p.start_date.Value.ToString("dd/MM/yyyy") : null,
                                                End_Date = p.end_date != null ? p.end_date.Value.ToString("dd/MM/yyyy") : null,
                                                Status = p.status,
                                                Parent_Company = con.controlling_area,
                                                Controlling_Area_Code = con.controlling_area_code,
                                                Comapny_Name = company.company_name,
                                                Company_Code = company.company_code,
                                                Machine_Number = "",
                                                Account_Name = "",
                                                Notes = p.notes,
                                                EstimateHours = p.estimatedhours,
                                                Manager_Name = "-",
                                                Time = 30,
                                                Revenue = 70,
                                                Cost = 50,
                                                Project_Phase = "",
                                                CustomerDetails = _context.TblCustomers.Where(c => c.id == p.customer_id).Select(usr => new CustomerDTO
                                                {
                                                    Customer_Id = usr.customer_id,
                                                    Customer_Name = usr.customer_name,
                                                    City = usr.city,
                                                    Zipcode = usr.zipcode,
                                                    Street = usr.street,
                                                    Phone_Number = usr.phone_number,
                                                    Contacts = _context.TblContacts.Where(con => con.contact_id == p.contact_id).Select(contact => new ContactDTO
                                                    {
                                                        Contact_Id = contact.contact_id,
                                                        First_Name = contact.first_name,
                                                        Last_Name = contact.last_name,
                                                        Display_Name = contact.display_name,
                                                        Email_Address = contact.email_address,
                                                        Title = contact.title,
                                                        Language = contact.language,
                                                        Phone_Number = contact.phone_number,
                                                        Department = contact.department
                                                    }).ToList()
                                                }).FirstOrDefault(),
                                            },
                                            Service = new ServiceDTO
                                            {
                                                Id = service.id,
                                                Offer_Id = service.offer_id,
                                                Service_Type = service.service_type,
                                                Service_Location = service.service_location,
                                                Start_Date = service.start_date != null ? service.start_date.Value.ToString("dd/MM/yyyy") : null,
                                                End_Date = service.end_date != null ? service.end_date.Value.ToString("dd/MM/yyyy") : null,
                                                Actual_Hours = service.actual_hours,
                                                Is_Active = service.is_active,
                                                Service_Description = service.service_description != null ? service.service_description : null,
                                                Service_Region = service.service_region,
                                                Erp_Wbs_Id = (from offer in _context.TblOffers
                                                              join ser in _context.TblServices on offer.id equals ser.offer_id
                                                              where ser.id == service.id
                                                              select offer.WBSID).FirstOrDefault()

                                            },
                                            Order = new OrderDTO
                                            {
                                                Id = order.id,
                                                Service_Id = order.service_id,
                                                Status = order.status,
                                                Order_Kpi = _context.TblOrderKPI.Where(k => k.id == order.order_kpi_id).Select(k => new OrderKpiDTO
                                                {
                                                    Id = k.id,
                                                    Calculated_Hours = k.calculated_hours,
                                                    Hours_Progress = k.hours_progress,
                                                    Roadmap_Progress = k.roadmap_progress,
                                                    Cost_Proress = k.cost_progress
                                                }).FirstOrDefault()
                                            },
                                        }).FirstOrDefaultAsync();
            else
                serviceDetails = await (from service in _context.TblServices
                                        join order in _context.TblOrder on service.id equals order.service_id
                                        join p in _context.TblProjects on service.project_id equals p.id
                                        join prjstaff in _context.TblProjectStaffs on new { userId = GetCurrentUserId(), projectId = p.id } equals new { userId = prjstaff.user_id, projectId = prjstaff.project_id }
                                        join company in _context.TblCompanies on p.company_id equals company.company_code
                                        join conArea in _context.TblControllingAreas on p.controlling_id equals conArea.id into controllingGrp
                                        from con in controllingGrp.DefaultIfEmpty()
                                        where order.project_id == projectId && order.erp_order_id == orderId && order.service_id == serviceType
                                        select new ServiceDetailDTO
                                        {
                                            Project = new ProjectDTO
                                            {
                                                Project_Id = p.id,
                                                Erp_Project_Id = p.erp_project_id,
                                                Project_Name = p.project_name,
                                                Description = p.description,
                                                Start_Date = p.start_date != null ? p.start_date.Value.ToString("dd/MM/yyyy") : null,
                                                End_Date = p.end_date != null ? p.end_date.Value.ToString("dd/MM/yyyy") : null,
                                                Status = p.status,
                                                Parent_Company = con.controlling_area,
                                                Controlling_Area_Code = con.controlling_area_code,
                                                Comapny_Name = company.company_name,
                                                Company_Code = company.company_code,
                                                Machine_Number = "",
                                                Account_Name = "",
                                                Notes = p.notes,
                                                EstimateHours = p.estimatedhours,
                                                Manager_Name = "-",
                                                Time = 30,
                                                Revenue = 70,
                                                Cost = 50,
                                                Project_Phase = "Project Management",
                                                CustomerDetails = _context.TblCustomers.Where(c => c.id == p.customer_id).Select(usr => new CustomerDTO
                                                {
                                                    Customer_Id = usr.customer_id,
                                                    Customer_Name = usr.customer_name,
                                                    City = usr.city,
                                                    Zipcode = usr.zipcode,
                                                    Street = usr.street,
                                                    Phone_Number = usr.phone_number,
                                                    Contacts = _context.TblContacts.Where(con => con.contact_id == p.contact_id).Select(contact => new ContactDTO
                                                    {
                                                        Contact_Id = contact.contact_id,
                                                        First_Name = contact.first_name,
                                                        Last_Name = contact.last_name,
                                                        Display_Name = contact.display_name,
                                                        Email_Address = contact.email_address,
                                                        Title = contact.title,
                                                        Language = contact.language,
                                                        Phone_Number = contact.phone_number,
                                                        Department = contact.department
                                                    }).ToList()
                                                }).FirstOrDefault(),
                                            },
                                            Service = new ServiceDTO
                                            {
                                                Id = service.id,
                                                Offer_Id = service.offer_id,
                                                Service_Type = service.service_type,
                                                Service_Location = service.service_location,
                                                Start_Date = service.start_date != null ? service.start_date.Value.ToString("dd/MM/yyyy") : null,
                                                End_Date = service.end_date != null ? service.end_date.Value.ToString("dd/MM/yyyy") : null,
                                                Actual_Hours = service.actual_hours,
                                                Is_Active = service.is_active,
                                                Service_Description = service.service_description != null ? service.service_description : null,
                                                Service_Region = service.service_region,
                                                Erp_Wbs_Id = (from offer in _context.TblOffers
                                                              join ser in _context.TblServices on offer.id equals ser.offer_id
                                                              where ser.id == service.id
                                                              select offer.WBSID).FirstOrDefault()


                                            },
                                            Order = new OrderDTO
                                            {
                                                Id = order.id,
                                                Service_Id = order.service_id,
                                                Status = order.status,
                                                Order_Kpi = _context.TblOrderKPI.Where(k => k.id == order.order_kpi_id).Select(k => new OrderKpiDTO
                                                {
                                                    Id = k.id,
                                                    Calculated_Hours = k.calculated_hours,
                                                    Hours_Progress = k.hours_progress,
                                                    Roadmap_Progress = k.roadmap_progress,
                                                    Cost_Proress = k.cost_progress
                                                }).FirstOrDefault()
                                            },
                                        }).FirstOrDefaultAsync();
            return serviceDetails;
        }

        /// <summary>
        /// Get project related machines
        /// </summary>
        /// <param name="projectId"></param>
        /// <param name="orderId"></param>
        /// <param name="serviceType"></param>
        /// <returns></returns>
        public List<MachineDTO> GetProjectMachines(string projectId, string orderId, string serviceType)
        {
            try
            {
                var machines = new List<MachineDTO>();
                if (IsUserProjectManager())
                    machines = (from order in _context.TblOrder
                                join service in _context.TblServices on order.service_id equals service.id into joined
                                from s in joined.DefaultIfEmpty()
                                join sm in _context.TblServiceMachines on s.id equals sm.service_id
                                join machine in _context.TblMachines on sm.machine_id equals machine.id
                                join machineAssoc in _context.TblMachineCustomerAssociation on machine.id equals machineAssoc.machine_id
                                let rmList = _context.TblMachineRoadmap.Where(s => s.service_machine_id == sm.id).ToList()
                                let machineTotalSteps = (from sermachine in _context.TblServiceMachines
                                                         join mr in _context.TblMachineRoadmap on sermachine.id equals mr.service_machine_id into mr1
                                                         from mr2 in mr1.DefaultIfEmpty()
                                                         join rms in _context.TblRoadmapMaster on mr2.roadmap_id equals rms.roadmap_id
                                                         join section in _context.TblRoadmapSection on rms.roadmap_id equals section.roadmap_id
                                                         join subsection in _context.TblRoadmapSubSectionMster on section.id equals subsection.section_id
                                                         join step in _context.TblStepMaster on subsection.id equals step.roadmap_section_id
                                                         join stepAssoci in _context.TblStepMachineAssociation on new { a1 = step.step_id, a2 = sm.id } equals new { a1 = stepAssoci.step_id, a2 = stepAssoci.servicemachine_id }
                                                         where sermachine.id == sm.id
                                                         select new { }).Count()
                                let machineAnsweredSteps = (from sermachine in _context.TblServiceMachines.Where(s => s.id == sm.id)
                                                            join mr in _context.TblMachineRoadmap on sermachine.id equals mr.service_machine_id into mr1
                                                            from mr2 in mr1.DefaultIfEmpty()
                                                            join rms in _context.TblRoadmapMaster on mr2.roadmap_id equals rms.roadmap_id
                                                            join section in _context.TblRoadmapSection on rms.roadmap_id equals section.roadmap_id
                                                            join subsection in _context.TblRoadmapSubSectionMster on section.id equals subsection.section_id
                                                            join step in _context.TblStepMaster on subsection.id equals step.roadmap_section_id
                                                            join stepAssoci in _context.TblStepMachineAssociation on new { a1 = step.step_id, a2 = sm.id } equals new { a1 = stepAssoci.step_id, a2 = stepAssoci.servicemachine_id }
                                                            join smsteps in _context.TblServiceMachineSteps on new { a1 = step.step_id, a2 = sermachine.id } equals new { a1 = smsteps.step_id, a2 = smsteps.servicemachine_id }
                                                            where sermachine.id == sm.id
                                                            select new { }).Count()
                                where order.project_id == projectId && order.erp_order_id == orderId && order.service_id == serviceType && machine.is_delete == false
                                select new MachineDTO
                                {
                                    Machine_Id = machine.id,
                                    Global_Id = machine.global_id,
                                    Customer_Id = machineAssoc.customer_id,
                                    Machine_Name = machine.machine_name,
                                    Asset_Id = machine.asset_id,
                                    Serial_Number = machine.serial_number,
                                    Machine_Type = machine.machine_type,
                                    Is_RA_External = s.is_ra_external,
                                    IsActive = sm.isactive,
                                    Machine_Description = machine.machine_description,
                                    Is_RA_Status = rmList.Where(s => s.roadmap_status.ToLower() != MachineStatus.COMPLETED.ToLower()).ToList().Count == 0 && machineTotalSteps != 0 && machineTotalSteps == machineAnsweredSteps ? MachineStatus.COMPLETED :
                                     machineAnsweredSteps != 0 ? MachineStatus.IN_PROGRESS :
                                    rmList.Count != 0 && rmList.Where(s => s.roadmap_status.ToLower() != MachineStatus.COMPLETED.ToLower()).ToList().Count != 0 ? MachineStatus.NOT_STARTED :
                                    rmList.Count == 0 ? MachineStatus.NOT_CONFIGURED : MachineStatus.NOT_STARTED,
                                    RA_Count = rmList.Count,
                                    Image_Size = (from steps in _context.TblServiceMachineSteps.Where(s => s.servicemachine_id == sm.id)
                                                  join hazard in _context.TblMachineHazards on steps.service_machine_steps_id equals hazard.service_machine_steps_id
                                                  join media in _context.TblHazardMedia on hazard.id equals media.machine_hazard_id
                                                  select new { size = media.image_size }).Sum(s => s.size),
                                    ServiceMachine_Id = new ServiceMachineDTO
                                    {
                                        ServiceMachineId = sm.id,
                                        IsConflict = sm.isconflict,
                                        IsRequested = sm.isrequested
                                    },
                                    FourEyeQualityDTO = _context.TblMachineFourEyesQualityAssociation.Where(fe => fe.servicemachine_id == sm.id).Select(fe => new FourEyesQualityDTO
                                    {
                                        IsFourEyeQuality = fe.isComplete,
                                        IsFourEyePerform = fe.user_id == GetCurrentUserId()
                                    }).FirstOrDefault(),
                                    Estimated_Hours = machine.estimated_hours,
                                    CalculatedHours = _context.TblMachineHour.Where(c => c.service_machine_id == sm.id).FirstOrDefault() != null ? _context.TblMachineHour.Where(c => c.service_machine_id == sm.id).FirstOrDefault().calculated_hours : 0m,
                                    AggregatedHours = _context.TblMachineKPI.Where(m => m.service_machine_id == sm.id).FirstOrDefault() != null ? _context.TblMachineKPI.Where(m => m.service_machine_id == sm.id).FirstOrDefault().actualaggregatedhours : 0m,
                                }).ToList();

                else
                    machines = (from order in _context.TblOrder
                                join service in _context.TblServices on order.service_id equals service.id into joined
                                from s in joined.DefaultIfEmpty()
                                join sm in _context.TblServiceMachines on s.id equals sm.service_id
                                join machine in _context.TblMachines on sm.machine_id equals machine.id
                                join machineAssoc in _context.TblMachineCustomerAssociation on machine.id equals machineAssoc.machine_id
                                join project in _context.TblProjects on order.project_id equals project.id
                                join prjstaff in _context.TblProjectStaffs on new { userId = GetCurrentUserId(), projectId = project.id } equals new { userId = prjstaff.user_id, projectId = prjstaff.project_id }
                                join limit in _context.TblMachineLimitsMaster on sm.id equals limit.servicemachine_id into machinelimits
                                from limits in machinelimits.DefaultIfEmpty()
                                let rmList = _context.TblMachineRoadmap.Where(s => s.service_machine_id == sm.id).ToList()
                                let machineTotalSteps = (from sermachine in _context.TblServiceMachines
                                                         join mr in _context.TblMachineRoadmap on sermachine.id equals mr.service_machine_id into mr1
                                                         from mr2 in mr1.DefaultIfEmpty()
                                                         join rms in _context.TblRoadmapMaster on mr2.roadmap_id equals rms.roadmap_id
                                                         join section in _context.TblRoadmapSection on rms.roadmap_id equals section.roadmap_id
                                                         join subsection in _context.TblRoadmapSubSectionMster on section.id equals subsection.section_id
                                                         join step in _context.TblStepMaster on subsection.id equals step.roadmap_section_id
                                                         join stepAssoci in _context.TblStepMachineAssociation on new { a1 = step.step_id, a2 = sm.id } equals new { a1 = stepAssoci.step_id, a2 = stepAssoci.servicemachine_id }
                                                         where sermachine.id == sm.id
                                                         select new { }).Count()
                                let machineAnsweredSteps = (from sermachine in _context.TblServiceMachines.Where(s => s.id == sm.id)
                                                            join mr in _context.TblMachineRoadmap on sermachine.id equals mr.service_machine_id into mr1
                                                            from mr2 in mr1.DefaultIfEmpty()
                                                            join rms in _context.TblRoadmapMaster on mr2.roadmap_id equals rms.roadmap_id
                                                            join section in _context.TblRoadmapSection on rms.roadmap_id equals section.roadmap_id
                                                            join subsection in _context.TblRoadmapSubSectionMster on section.id equals subsection.section_id
                                                            join step in _context.TblStepMaster on subsection.id equals step.roadmap_section_id
                                                            join stepAssoci in _context.TblStepMachineAssociation on new { a1 = step.step_id, a2 = sm.id } equals new { a1 = stepAssoci.step_id, a2 = stepAssoci.servicemachine_id }
                                                            join smsteps in _context.TblServiceMachineSteps on new { a1 = step.step_id, a2 = sermachine.id, a3 = GetCurrentUserId() } equals new { a1 = smsteps.step_id, a2 = smsteps.servicemachine_id, a3 = smsteps.user_id }
                                                            where sermachine.id == sm.id
                                                            select new { }).Count()
                                where order.project_id == projectId && order.erp_order_id == orderId && order.service_id == serviceType && machine.is_delete == false
                                select new MachineDTO
                                {
                                    Machine_Id = machine.id,
                                    Global_Id = machine.global_id,
                                    Customer_Id = machineAssoc.customer_id,
                                    Machine_Name = machine.machine_name,
                                    Asset_Id = machine.asset_id,
                                    Serial_Number = machine.serial_number,
                                    Machine_Type = machine.machine_type,
                                    Is_RA_External = s.is_ra_external,
                                    IsActive = sm.isactive,
                                    Machine_Description = machine.machine_description,
                                    Is_RA_Status = rmList.Where(s => s.roadmap_status.ToLower() != MachineStatus.COMPLETED.ToLower()).ToList().Count == 0 && machineTotalSteps != 0 && machineTotalSteps == machineAnsweredSteps ? MachineStatus.COMPLETED :
                                     machineAnsweredSteps != 0 ? MachineStatus.IN_PROGRESS :
                                    rmList.Count != 0 && rmList.Where(s => s.roadmap_status.ToLower() != MachineStatus.COMPLETED.ToLower()).ToList().Count != 0 ? MachineStatus.NOT_STARTED :
                                    rmList.Count == 0 ? MachineStatus.NOT_CONFIGURED : MachineStatus.NOT_STARTED,
                                    RA_Count = _context.TblMachineRoadmap.Where(s => s.service_machine_id == sm.id).ToList().Count,
                                    Image_Size = (from steps in _context.TblServiceMachineSteps.Where(s => s.servicemachine_id == sm.id)
                                                  join hazard in _context.TblMachineHazards on steps.service_machine_steps_id equals hazard.service_machine_steps_id
                                                  join media in _context.TblHazardMedia on hazard.id equals media.machine_hazard_id
                                                  select new { size = media.image_size }).Sum(s => s.size),
                                    ServiceMachine_Id = new ServiceMachineDTO
                                    {
                                        ServiceMachineId = sm.id,
                                        IsConflict = sm.isconflict,
                                        IsRequested = sm.isrequested
                                    },
                                    FourEyeQualityDTO = _context.TblMachineFourEyesQualityAssociation.Where(fe => fe.servicemachine_id == sm.id).Select(fe => new FourEyesQualityDTO
                                    {
                                        IsFourEyeQuality = fe.isComplete
                                    }).FirstOrDefault(),
                                    Estimated_Hours = machine.estimated_hours,
                                    MasterMachine = _context.TblMasterMachines.Where(m => m.id == machine.master_machine_id).Select(m => new MasterMachinesDTO
                                    {
                                        Machine_Master_Id = m.id,
                                        Machine_Name = m.machine_name,
                                        Machine_Type = m.machine_type,
                                        Manufacturer = m.manufacturer
                                    }).FirstOrDefault(),
                                    CalculatedHours = _context.TblMachineHour.Where(c => c.service_machine_id == sm.id).FirstOrDefault() != null ? _context.TblMachineHour.Where(c => c.service_machine_id == sm.id).FirstOrDefault().calculated_hours : 0m,
                                    AggregatedHours = _context.TblMachineKPI.Where(m => m.service_machine_id == sm.id).FirstOrDefault() != null ? _context.TblMachineKPI.Where(m => m.service_machine_id == sm.id).FirstOrDefault().actualaggregatedhours : 0m,
                                }).ToList();
                return machines;
            }
            catch (Exception)
            {

                throw;
            }
        }
        /// <summary>
        /// Add machines to project
        /// </summary>
        /// <param name="machines"></param>
        /// <returns></returns>
        public async Task<bool> AddProjectMachine(CreateMachineDTO machines)
        {
            bool isSuccess = false;

            try
            {
                TblServiceMachine serviceMachine = new TblServiceMachine();
                TblMachine tblMachine = new TblMachine();
                var orderDetails = _context.TblOrder.Where(o => o.id == machines.Order_Id).FirstOrDefault();

                var userId = GetCurrentUserId();

                foreach (var machine in machines.Machines)
                {
                    if (machine.Machine_Id != null && machine.Machine_Id != string.Empty)
                    {
                        var duplicateCheck = _context.TblServiceMachines.Where(s => s.service_id == orderDetails.service_id && s.machine_id == machine.Machine_Id).FirstOrDefault();
                        if (orderDetails != null && duplicateCheck == null)
                        {
                            serviceMachine.id = Guid.NewGuid().ToString();
                            serviceMachine.service_id = orderDetails.service_id;
                            serviceMachine.machine_id = machine.Machine_Id;
                            _context.TblServiceMachines.Add(serviceMachine);
                            _context.SaveChanges();
                        }
                        isSuccess = true;
                    }
                    else
                    {
                        if (orderDetails != null)
                        {
                            tblMachine.id = Guid.NewGuid().ToString();
                            tblMachine.machine_name = machine.Machine_Name;
                            tblMachine.machine_type = machine.Machine_Type;
                            tblMachine.asset_id = machine.Asset_Id;
                            tblMachine.serial_number = machine.Serial_Number;
                            tblMachine.industry_type = machine.Industry;
                            tblMachine.machine_description = machine.Machine_Description;
                            tblMachine.machine_location = machine.MasterMachine_Id;
                            tblMachine.estimated_hours = machine.Estimated_Hours;
                            tblMachine.created_at = DateTimeOffset.Now;
                            tblMachine.created_by = userId;
                            tblMachine.modified_at = DateTimeOffset.Now;
                            tblMachine.modified_by = "";



                            _context.TblMachines.Add(tblMachine);




                            serviceMachine.id = Guid.NewGuid().ToString();
                            serviceMachine.service_id = orderDetails.service_id;
                            serviceMachine.machine_id = tblMachine.id;

                            _context.TblServiceMachines.Add(serviceMachine);
                            await _context.SaveChangesAsync();
                        }



                        isSuccess = true;
                    }
                }
                return isSuccess;
            }
            catch (Exception ex)
            {
                return isSuccess;
            }
        }

        /// <summary>
        /// Get project related order and service details
        /// </summary>
        /// <param name="projectId"></param>
        /// <returns></returns>
        public List<OrderDTO> GetProjectOrderdetails(string projectId)
        {
            var result = new List<OrderDTO>();
            if (IsUserProjectManager())
                result = (from order in _context.TblOrder.Where(p =>p.project_id == projectId) 
                          group order by order.erp_order_id into uniqOrder
                          select new OrderDTO
                          {
                              Erp_Order_Id = uniqOrder.Key
                          }).Distinct().ToList();
            else
                result = (from project in _context.TblProjects
                          join prjstaff in _context.TblProjectStaffs on new { userId = GetCurrentUserId(), projectId = project.id } equals new { userId = prjstaff.user_id, projectId = prjstaff.project_id }
                          join order in _context.TblOrder.Where(p => p.project_id == projectId) on project.id equals order.project_id
                          group order by order.erp_order_id into uniqOrder
                          select new OrderDTO
                          {
                              Erp_Order_Id = uniqOrder.Key
                          }).Distinct().ToList();
            return result;
        }

        /// <summary>
        /// Get Project Id
        /// </summary>
        /// <returns></returns>
        public string ProjectId()
        {
            Task.Delay(250);
            var lastRecord = _context.TblProjects.OrderBy(p => p.created_at)?.LastOrDefault() ?? null;
            var Id = lastRecord != null ? Convert.ToInt32(lastRecord.id[3..]) : 0;
            string prjId;
            if (lastRecord != null)
            {
                Id++;
                prjId = "PRJ" + Id.ToString("D8");
            }
            else
            {
                prjId = "PRJ" + "00000001";
            }
            return prjId;
        }

        /// <summary>
        /// Get NotificationId
        /// </summary>
        /// <returns></returns>
        private async Task<TblSchNotification> GetNotification()
        {
            var result = await _context.TblNotiications.ToListAsync();
            var filteredData = result.Last();
            return filteredData;
        }

        /// <summary>
        /// Generate NotificationId
        /// </summary>
        /// <param name="notificationId"></param>
        /// <returns></returns>
        private static string GenerateId(string notificationId)
        {
            int id = Convert.ToInt32(notificationId);   //This increase the value to 1 every time you enter.
            id += 1;
            return id.ToString();
        }

        /// <summary>
        /// Get Notification Types
        /// </summary>
        /// <param name="enumType"></param>
        /// <param name="enumVal"></param>
        /// <returns></returns>
        public string GetEnumMemberAttrValue(Type enumType, object enumVal)
        {
            var memInfo = enumType.GetMember(enumVal.ToString());
            var attr = memInfo[0].GetCustomAttributes(false).OfType<EnumMemberAttribute>().FirstOrDefault();
            if (attr != null)
            {
                return attr.Value;
            }

            return null;
        }

        /// <summary>
        /// Update Project by ERP Responses
        /// </summary>
        /// <param name="projectResponse"></param>
        /// <returns></returns>
        public async Task<string> UpdateErpProject(ProjectResponseEvent projectResponse)
        {
            string isSuccess = "Failed to Update";
            try
            {
                var project = _context.TblProjects.FirstOrDefault(p => p.id == projectResponse.Project.ProjectID);
                var email = _context.TblUsers.Where(e => e.id == project.created_by).FirstOrDefault()??null;
                if (projectResponse.Project.Action.ToLower() == "added")
                {
                    #region Audit Log Entry
                    TblAuditEntry tblAuditEntry = new();
                    tblAuditEntry.id = Guid.NewGuid().ToString();
                    tblAuditEntry.project_id = project?.id;
                    tblAuditEntry.erp_project_id = projectResponse.Project.ERPProjectID;
                    tblAuditEntry.action = "Create";
                    tblAuditEntry.scope = "New project created with ProjectId" + " " + projectResponse.Project.ERPProjectID;
                    tblAuditEntry.created_at = DateTimeOffset.UtcNow;
                    tblAuditEntry.user_id = project.created_by != null? _context.TblUsers.FirstOrDefault(p => p.id == project.created_by).email_address??null: null;
                    tblAuditEntry.affected_table = "TblProject";
                    _context.TblAuditEntry.Add(tblAuditEntry);
                    #endregion
                    project.erp_project_id = projectResponse.Project.ERPProjectID;
                    project.status = projectResponse.Project.ProjectStatus;

                    _context.TblProjects.Update(project);

                   _context.SaveChangesAsync();

                    isSuccess = "Successfully Updated";

                    if (projectResponse.Project.ERPProjectID != null && email != null)
                    {
                        var tenantId = projectResponse.TechnicalHeader.TenantID ?? String.Empty;
                        eventBus.PublishToQueue(new ProjectNotificationEvent(new List<string> { email.email_address }, "Create", "", tenantId, "The Project with " + project.project_name + " has successfully been created in ERP, with the ERP Project ID " + project.erp_project_id + " ", projectResponse.Project.ERPProjectID, project.id, "Project Create") { TopicName = "projectnotificationrequest" });
                    }
                }
                else
                {
                    project.status = projectResponse.Project.ProjectStatus;
                    _context.TblProjects.Update(project);
                    #region Audit Log Entry
                    TblAuditEntry tblAuditEntry = new();
                    tblAuditEntry.id = Guid.NewGuid().ToString();
                    tblAuditEntry.project_id = project?.id;
                    tblAuditEntry.project_id = projectResponse.Project.ERPProjectID;
                    tblAuditEntry.action = "Update";
                    tblAuditEntry.scope = "Project updates with status" + " " + projectResponse.Project.ProjectStatus;
                    tblAuditEntry.created_at = DateTimeOffset.UtcNow;
                    tblAuditEntry.user_id = GetCurrentUserId();
                    tblAuditEntry.affected_table = "TblProject";
                    _context.TblAuditEntry.Add(tblAuditEntry);
                    #endregion
                    await _context.SaveChangesAsync();
                    isSuccess = "Successfully Updated";

                    if (projectResponse.Project.ERPProjectID != null && email != null)
                    {
                        var tenantId = httpContextAccessor.HttpContext?.User?.GetTenantId() ?? String.Empty;
                        eventBus.PublishToQueue(new ProjectNotificationEvent(new List<string> { email.email_address }, "Create", "", tenantId, "The Project with " + project.project_name + " status has been updated successfully with the status " + projectResponse.Project.ProjectStatus + " ", projectResponse.Project.ERPProjectID, project.id, "Project Create") { TopicName = "projectnotificationrequest" });
                    }
                }
            }
            catch (Exception ex)
            {
                isSuccess = ex.Message;
            }

            return isSuccess;
        }

        /// <summary>
        /// Add machines to Project
        /// </summary>
        /// <param name="machines"></param>
        /// <returns></returns>
        public async Task<bool> AddProjectMachine(CreateServiceMachineDTO machines)
        {
            bool isSuccess = false;

            try
            {
                TblServiceMachine serviceMachine = new TblServiceMachine();
                TblMachine tblMachine = new TblMachine();

                var orderDetails = _context.TblOrder.Where(o => o.id == machines.Order_Id).FirstOrDefault();

                var userId = GetCurrentUserId();

                foreach (var machine in machines.Machines)
                {
                    if (machine.Machine_Id != null)
                    {
                        var duplicateCheck = _context.TblServiceMachines.Where(s => s.service_id == orderDetails.service_id && s.machine_id == machine.Machine_Id).FirstOrDefault();
                        if (orderDetails != null && duplicateCheck == null)
                        {
                            serviceMachine.id = Guid.NewGuid().ToString();
                            serviceMachine.service_id = orderDetails.service_id;
                            serviceMachine.machine_id = machine.Machine_Id;

                            _context.TblServiceMachines.Add(serviceMachine);
                            _context.SaveChanges();
                        }
                        isSuccess = true;
                    }
                    else
                    {
                        if (orderDetails != null)
                        {
                            tblMachine.id = Guid.NewGuid().ToString();
                            tblMachine.machine_name = machine.Machine_Name;
                            tblMachine.machine_type = machine.Machine_Type;
                            tblMachine.asset_id = machine.Asset_Id;
                            tblMachine.serial_number = machine.Serial_Number;
                            tblMachine.industry_type = machine.Industry;
                            tblMachine.machine_description = machine.Machine_Description;
                            tblMachine.machine_location = machine.MasterMachine_Id;
                            tblMachine.created_at = DateTimeOffset.Now;
                            tblMachine.created_by = userId;
                            tblMachine.modified_at = DateTimeOffset.Now;
                            tblMachine.modified_by = "";

                            _context.TblMachines.Add(tblMachine);


                            serviceMachine.id = Guid.NewGuid().ToString();
                            serviceMachine.service_id = orderDetails.service_id;
                            serviceMachine.machine_id = tblMachine.id;

                            _context.TblServiceMachines.Add(serviceMachine);
                            await _context.SaveChangesAsync();
                        }

                        isSuccess = true;
                    }
                }
                return isSuccess;
            }
            catch (Exception ex)
            {
                return isSuccess;
            }
        }

        /// <summary>
        /// Get Company Details
        /// </summary>
        /// <returns></returns>
        public List<CompanyDTO> GetCompanyDetails()
        {
            try
            {
                var result = (from company in _context.TblCompanies
                              select new CompanyDTO
                              {
                                  id = company.id,
                                  company_code = company.company_code,
                                  company_name = company.company_name
                              }).ToList();
                return result;
            }
            catch (Exception ex)
            {
                return null;
            }

        }

        /// <summary>
        /// To get the List of Services based on OrderId
        /// </summary>
        /// <param name="orderId"></param>
        /// <returns>List Of Services</returns>
        public async Task<List<ServiceDTO>> GetServicesByOrderId(string orderId)
        {
            var result = new List<ServiceDTO>();
            try
            {
                if (IsUserProjectManager())
                    result = await (from order in _context.TblOrder.Where(o => o.erp_order_id == orderId)
                                    join service in _context.TblServices on order.service_id equals service.id into services
                                    from allServices in services.DefaultIfEmpty()
                                    select new ServiceDTO
                                    {
                                        Id = allServices.id,
                                        Service_Type = allServices.service_type,
                                        Offer_Id = _context.TblOffers.FirstOrDefault(of => of.id == allServices.offer_id).WBSID
                                    }).ToListAsync();
                else
                    result = await (from order in _context.TblOrder.Where(o => o.erp_order_id == orderId)
                                    join service in _context.TblServices on order.service_id equals service.id into services
                                    from allServices in services.DefaultIfEmpty()
                                    join project in _context.TblProjects on order.project_id equals project.id
                                    join prjstaff in _context.TblProjectStaffs on new { userId = GetCurrentUserId(), projectId = project.id } equals new { userId = prjstaff.user_id, projectId = prjstaff.project_id }
                                    select new ServiceDTO
                                    {
                                        Id = allServices.id,
                                        Service_Type = allServices.service_type,
                                        Offer_Id = _context.TblOffers.FirstOrDefault(of => of.id == allServices.offer_id).WBSID
                                    }).ToListAsync();
                return result;
            }
            catch (Exception)
            {
                return null;
            }
        }
        /// <summary>
        /// Assign staff to project
        /// </summary>
        /// <param name="projectStaffDto"></param>
        /// <returns></returns>
        public async Task<bool> AddStaffToProject(ProjectStaffUpsertDto projectStaffDto)
        {
            bool isEntityUpdated = false;
            try
            {
                var newEntities = new List<TblProjectStaff>();

                var newUsers = projectStaffDto.user_ids;

                var existingUsers = _context.TblProjectStaffs
                    .Where(ps => ps.project_id == projectStaffDto.project_id)
                    .Select(ps => ps.user_id).ToList();
                foreach (var item in projectStaffDto.user_ids)
                {
                    if (!existingUsers.Contains(item.user_id))
                    {
                        TblProjectStaff staff = new();
                        staff.id = Guid.NewGuid().ToString();
                        staff.project_id = projectStaffDto.project_id;
                        staff.user_id = item.user_id;
                        staff.User_SharePoint_Id = item.UserSharePointId;
                        staff.created_by = httpContextAccessor.HttpContext.User.Claims.FirstOrDefault(c => c.Type == "Id")?.Value ?? String.Empty;
                        staff.created_at = DateTimeOffset.Now;
                        _context.TblProjectStaffs.Add(staff);
                        newEntities.Add(staff);
                        _context.SaveChanges();
                    }
                }
                var tenantId = httpContextAccessor.HttpContext?.User?.GetTenantId() ?? String.Empty;
                var email = GetStaffedUserEmails(projectStaffDto.user_ids);
                var projectDetails = _context.TblProjects.Where(p => p.id == projectStaffDto.project_id).FirstOrDefault();
                eventBus.PublishToQueue(new ProjectNotificationEvent(email, "Create", "", tenantId, "You've been now granted access to the Project "+ projectDetails .erp_project_id + " ", projectDetails.erp_project_id, projectDetails.id, "Project Staff") { TopicName = "projectnotificationrequest" });

                isEntityUpdated = true;
            }
            catch (Exception ex)
            {
            }
            return isEntityUpdated;
        }
        /// <summary>
        /// Delete staff from project
        /// </summary>
        /// <param name="projectStaffDto"></param>
        /// <returns></returns>
        public async Task<string> DeleteStaffFromProject(ProjectStaffDeleteDto projectStaffDto)
        {
            string status = "Staff Unassigned failed";
            try
            {
                //Get user Details
                var userDetails = _context.TblUsers.Where(u => u.email_address == projectStaffDto.user_id).FirstOrDefault();

                var projectStaff = _context.TblProjectStaffs
                    .Where(p => p.project_id == projectStaffDto.project_id && p.user_id == userDetails.id)
                    .FirstOrDefault();

                if (projectStaff is not null)
                {
                    //verify who created the project
                    var projectOwner = _context.TblProjects
                    .Where(p => p.id == projectStaffDto.project_id && p.created_by == userDetails.id)
                    .FirstOrDefault() != null;

                    if (projectOwner)
                    {
                        status = "Owner of the project cannot be modified";
                        return status;
                    }
                    else
                    {
                        _context.TblProjectStaffs.Remove(projectStaff);
                        _context.SaveChanges();
                        status = "Staff Unassigned";
                    }
                }
                return status;

            }
            catch (Exception ex)
            {
                return status;
            }
        }
        /// <summary>
        /// update machine state
        /// </summary>
        /// <param name="serviceMachineId"></param>
        /// <param name="isActive"></param>
        /// <returns></returns>
        public async Task<bool> UpdateMahineState(MachineStatusDTO machineStatus)
        {
            bool isSuccess = false;
            try
            {
                var machine = _context.TblServiceMachines.Where(m => m.id == machineStatus.ServiceMachine_Id).FirstOrDefault();

                if(machine != null)
                {
                    machine.isactive = machineStatus.IsActive;
                    machine.modified_by = GetCurrentUserId();
                    _context.SaveChanges();
                    isSuccess = true;
                }
                return isSuccess;
            }catch(Exception ex)
            {
                return isSuccess;
            }
        }
        /// <summary>
        /// Get Project Cost Data
        /// </summary>
        /// <param name="projectId"></param>
        /// <param name="serviceId"></param>
        /// <param name="orderId"></param>
        /// <returns>ProjectCostData</returns>
        public async Task<ProjectCostData> GetProjectCostData(string projectId, string serviceId, string orderId)
        {
            try
            {
                var resultData = (from order in _context.TblOrder
                                  where order.erp_order_id == orderId && order.project_id == projectId && order.service_id == serviceId
                                  select new ProjectCostData
                                  {
                                      TotalActualHours = (from service in _context.TblServices
                                                          join sm in _context.TblServiceMachines on service.id equals sm.service_id
                                                          join actl in _context.TblActualHours on sm.id equals actl.service_machine_id
                                                          where service.id == order.service_id
                                                          select new
                                                          {
                                                              ActualHours = actl.actualhours
                                                          }).Sum(s => s.ActualHours),
                                      TotlalCalculatedHours = (from service in _context.TblServices
                                                               join hrs in _context.TblServiceHour on service.id equals hrs.service_id
                                                               where service.id == order.service_id
                                                               select new
                                                               {
                                                                   CalculatedHours = hrs.calculated_hours
                                                               }).Sum(s => s.CalculatedHours),
                                      ActualCost = (from service in _context.TblServices
                                                    join cost in _context.TblServiceActualCost on service.id equals cost.service_id
                                                    where service.id == order.service_id
                                                    select new
                                                    {
                                                        Actual_Cost = cost.current_value
                                                    }).Sum(s1 => s1.Actual_Cost),
                                      ProjectBudget = (from service in _context.TblServices
                                                       join cost in _context.TblServicePlannedCost on service.id equals cost.service_id
                                                       where service.id == order.service_id
                                                       select new
                                                       {
                                                           planned_Cost = cost.current_value
                                                       }).Sum(s1 => s1.planned_Cost)
                                  }).FirstOrDefault();
                var stepCount = (from service in _context.TblServices
                                 join sm in _context.TblServiceMachines on service.id equals sm.service_id
                                 join mr in _context.TblMachineRoadmap on sm.id equals mr.service_machine_id
                                 join rm in _context.TblRoadmapMaster on mr.roadmap_id equals rm.roadmap_id
                                 join section in _context.TblRoadmapSection on rm.roadmap_id equals section.roadmap_id
                                 join subsection in _context.TblRoadmapSubSectionMster on section.id equals subsection.section_id
                                 join step in _context.TblStepMaster on subsection.id equals step.roadmap_section_id
                                 join sa in _context.TblStepMachineAssociation on new { a1 = step.step_id, a2 = sm.id } equals new { a1 = sa.step_id, a2 = sa.servicemachine_id }
                                 where service.id == serviceId
                                 select new { }).Count();
                var answeredStep = (from service in _context.TblServices
                                    join sm in _context.TblServiceMachines on service.id equals sm.service_id
                                    join mr in _context.TblMachineRoadmap on sm.id equals mr.service_machine_id
                                    join rm in _context.TblRoadmapMaster on mr.roadmap_id equals rm.roadmap_id
                                    join section in _context.TblRoadmapSection on rm.roadmap_id equals section.roadmap_id
                                    join subsection in _context.TblRoadmapSubSectionMster on section.id equals subsection.section_id
                                    join step in _context.TblStepMaster on subsection.id equals step.roadmap_section_id
                                    join sa in _context.TblStepMachineAssociation on new { a1 = step.step_id, a2 = sm.id } equals new { a1 = sa.step_id, a2 = sa.servicemachine_id }
                                    join smsteps in _context.TblServiceMachineSteps on new { a1 = sa.step_id, a2 = sm.id } equals new { a1 = smsteps.step_id, a2 = smsteps.servicemachine_id }
                                    where service.id == serviceId
                                    select new { }).Count();
                resultData.TotalStepCount = stepCount;
                resultData.TotalAnswredStepCount = answeredStep;
                return resultData;

            }
            catch (Exception)
            {

                throw;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="projectId"></param>
        /// <returns></returns>
        public async Task<List<ServiceDTO>> GetAllProjectRelatedServices(string projectId)
        {
            try
            {
                var services = new List<ServiceDTO>();
                if (IsUserProjectManager())
                {
                    services = await (from service in _context.TblServices
                                          join order in _context.TblOrder on service.id equals order.service_id
                                          where order.project_id == projectId
                                          select new ServiceDTO
                                          {
                                              Id = service.erp_wbs_id,
                                              Order_Id = order.erp_order_id,
                                              Service_Type = service.service_type
                                          }).ToListAsync();
                }
                else
                {
                    services = await (from service in _context.TblServices
                                          join order in _context.TblOrder on service.id equals order.service_id
                                          join project in _context.TblProjects on order.project_id equals project.id
                                          join prjstaff in _context.TblProjectStaffs on new { userId = GetCurrentUserId(), projectId = project.id } equals new { userId = prjstaff.user_id, projectId = prjstaff.project_id }
                                          where order.project_id == projectId
                                          select new ServiceDTO
                                          {
                                              Id = service.erp_wbs_id,
                                              Order_Id = order.erp_order_id,
                                              Service_Type = service.service_type
                                          }).ToListAsync();
                }
                   
                return services;
            }
            catch (Exception)
            {

                throw;
            }
        }
        private string GetCurrentUserId() => httpContextAccessor.HttpContext.User.Claims.FirstOrDefault(c => c.Type == "Id")?.Value ?? String.Empty;

        private bool IsUserProjectManager() => httpContextAccessor.HttpContext.User.Claims.Where(c => c.Type == ClaimTypes.Role).Any(c => c.Value == "Global Admin");
        /// <summary>
        /// 
        /// </summary>
        /// <param name="projectStaffs"></param>
        /// <returns></returns>
        private List<string> GetStaffedUserEmails(List<UserDetails> projectStaffs)
        {
            var emails = new List<string>();
            if(projectStaffs != null)
            {
                foreach (var item in projectStaffs)
                {
                    var email = _context.TblUsers.FirstOrDefault(u => u.id == item.user_id).email_address;
                    emails.Add(email);
                }
            }
            return emails;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="auditLogEntryEvent"></param>
        /// <returns></returns>
        private void LogAuditEntry(AuditLogEntryEvent auditLogEntryEvent)
        {
            try
            {
                using var context = new Sch_Context();
                TblAuditEntry tblAuditEntry = new();
                tblAuditEntry.id = Guid.NewGuid().ToString();
                tblAuditEntry.project_id = auditLogEntryEvent?.Project_Id;
                tblAuditEntry.action = auditLogEntryEvent?.Action;
                tblAuditEntry.scope = auditLogEntryEvent?.Scope;
                tblAuditEntry.created_at = DateTime.UtcNow;
                tblAuditEntry.user_id = auditLogEntryEvent?.User_Id;
                tblAuditEntry.old_value = auditLogEntryEvent?.Old_Value;
                tblAuditEntry.new_value = auditLogEntryEvent?.New_Value;
                tblAuditEntry.affected_table = auditLogEntryEvent?.Affected_Table;
                tblAuditEntry.offer_id = auditLogEntryEvent?.Offer_Id;
                tblAuditEntry.service_id = auditLogEntryEvent?.Service_Id;
                context.TblAuditEntry.Add(tblAuditEntry);
                context.SaveChanges();
            }
            catch (Exception ex)
            {

                throw;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="search"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns>List<TblAuditEntry></returns>
        public async Task<List<TblAuditEntry>> GetAuditLogs(AuditLogDTO auditLogDTO)
        {
            try
            {
                DateTime currentDate = DateTime.UtcNow;
                DateTimeOffset startTimeOffset = new DateTimeOffset(auditLogDTO.StartDate, TimeSpan.Zero);
                DateTimeOffset endTimeOffset = new DateTimeOffset(auditLogDTO.EndDate, TimeSpan.Zero);
                var auditLogs = new List<TblAuditEntry>();
                if (auditLogDTO.Search is not null)
                {
                    auditLogs = (from logs in _context.TblAuditEntry.Where(c => c.erp_project_id.ToLower().Contains(auditLogDTO.Search.ToLower())
                  || c.project_id.ToLower().Contains(auditLogDTO.Search.ToLower()) || c.scope.ToLower().Contains(auditLogDTO.Search.ToLower())
                  || c.user_id.ToLower().Contains(auditLogDTO.Search.ToLower()) || c.old_value.ToLower().Contains(auditLogDTO.Search.ToLower())
                  || c.new_value.ToLower().Contains(auditLogDTO.Search.ToLower()) || c.action.ToLower().Contains(auditLogDTO.Search.ToLower())
                  || c.created_at.ToString().Contains(auditLogDTO.Search))
                                 where logs.project_id == auditLogDTO.ProjectId && (logs.created_at.Date >= startTimeOffset.Date && logs.created_at.Month >= startTimeOffset.Month && logs.created_at.Year >= startTimeOffset.Year) && (logs.created_at.Date <= endTimeOffset.Date && logs.created_at.Month <= endTimeOffset.Month && logs.created_at.Year <= endTimeOffset.Year)
                                 select  new TblAuditEntry
                                 {
                                     id = logs.id,
                                     project_id = logs.project_id,
                                     erp_project_id = logs.erp_project_id,
                                     offer_id = logs.offer_id,
                                     service_id = logs.service_id,
                                     old_value = logs.old_value,
                                     new_value = logs.new_value,
                                     action = logs.action,
                                     created_at = logs.created_at,
                                     order_id = logs.order_id,
                                     affected_table = logs.affected_table,
                                     scope = logs.scope,
                                     user_id = logs.user_id
                                 }).Skip(auditLogDTO.IncreasedCount).Take(auditLogDTO.Count).OrderByDescending(s => s.created_at).ToList();
                }
                else
                {
                    auditLogs = await _context.TblAuditEntry
                  .Where(c => c.project_id == auditLogDTO.ProjectId && (c.created_at.Date >= startTimeOffset.Date && c.created_at.Month >= startTimeOffset.Month && c.created_at.Year >= startTimeOffset.Year) && (c.created_at.Date <= endTimeOffset.Date && c.created_at.Month <= endTimeOffset.Month && c.created_at.Year <= endTimeOffset.Year))
                  .Select(s => new TblAuditEntry
                  {
                      id = s.id,
                      project_id = s.project_id,
                      erp_project_id = s.erp_project_id,
                      offer_id = s.offer_id,
                      service_id = s.service_id,
                      old_value = s.old_value,
                      new_value = s.new_value,
                      action = s.action,
                      created_at = s.created_at,
                      order_id = s.order_id,
                      affected_table = s.affected_table,
                      scope = s.scope,
                      user_id = s.user_id
                  }).Skip(auditLogDTO.IncreasedCount).Take(auditLogDTO.Count).OrderByDescending(s => s.created_at).ToListAsync();
                }
                return auditLogs;
            }
            catch (Exception ex)
            {

                throw;
            }
        }
        /// <summary>
        /// Get Daily Metrics
        /// </summary>
        /// <param name="range"></param>
        /// <returns></returns>
        public async Task<Dictionary<string, List<ProjectEffortMetricsDTO>>> GetDailyEffortMetrics(string range)
        {
            try
            {
                var result = new Dictionary<string, List<ProjectEffortMetricsDTO>>();
                result = range.ToLower() switch
                {
                    ProjectDataRange.WEEK => GetWeekDataMetrics(),
                    ProjectDataRange.MONTH => GetMonthMetrics(),
                    ProjectDataRange.DAY => GetDayDataMetrics(),
                    _ => GetMonthMetrics(),
                };
                return result;
            }
            catch (Exception)
            {
                throw;
            }
        }
        /// <summary>
        /// Get Weekly Metrics
        /// </summary>
        /// <returns></returns>
        private Dictionary<string, List<ProjectEffortMetricsDTO>> GetWeekDataMetrics()
        {
            try
            {
                Dictionary<string, List<ProjectEffortMetricsDTO>> dataList = new();
                DateTime endDate = DateTime.Today;
                DateTime startDate = endDate.AddDays(-6);
                var projects = Enumerable.Range(0, 7)
                    .Select(offset => startDate.AddDays(offset))
                          .Select(day => new ProjectEffortMetricsDTO
                          {
                              DayOfWeek = day.DayOfWeek.ToString(),
                              Date = day.Date,
                              Data = _context.TblProjects
                                 .Where(e => e.created_at.Date.Date == day)
                                 .Count()
                          }).ToList();
                var totalServices = Enumerable.Range(0, 7)
                        .Select(offset => startDate.AddDays(offset))
                    .Select(day => new ProjectEffortMetricsDTO
                    {
                        DayOfWeek = day.DayOfWeek.ToString(),
                        Date = day.Date,
                        Data = (from prj in _context.TblProjects
                                join offer in _context.TblOffers on prj.id equals offer.project_id
                                join ser in _context.TblServices on offer.id equals ser.offer_id
                                where ser.created_at.Date.Date == day
                                select new { }).Count()
                    }).ToList();
                var servicesInProgress = Enumerable.Range(0, 7)
                        .Select(offset => startDate.AddDays(offset))
                    .Select(day => new ProjectEffortMetricsDTO
                    {
                        DayOfWeek = day.DayOfWeek.ToString(),
                        Date = day.Date,
                        Data = (from prj in _context.TblProjects
                                join offer in _context.TblOffers on prj.id equals offer.project_id
                                join ser in _context.TblServices on offer.id equals ser.offer_id
                                where ser.status.ToLower() == MachineStatus.IN_PROGRESS.ToLower() && ser.modified_at.Date.Date == day
                                select new { }).Count()
                    }).ToList();
                var servicesCompleted = Enumerable.Range(0, 7)
                        .Select(offset => startDate.AddDays(offset))
                    .Select(day => new ProjectEffortMetricsDTO
                    {
                        DayOfWeek = day.DayOfWeek.ToString(),
                        Date = day.Date,
                        Data = (from prj in _context.TblProjects
                                join offer in _context.TblOffers on prj.id equals offer.project_id
                                join ser in _context.TblServices on offer.id equals ser.offer_id
                                where ser.status.ToLower() == MachineStatus.COMPLETED.ToLower() && ser.modified_at.Date.Date == day
                                select new { }).Count()
                    }).ToList();
                dataList.Add("TotalProjects", projects);
                dataList.Add("ServicesInProgress", servicesInProgress);
                dataList.Add("ServicesCompleted", servicesCompleted);
                dataList.Add("TotalServices", totalServices);
                return dataList;
            }
            catch (Exception)
            {

                throw;
            }
        }
        /// <summary>
        /// Get Monthly Metrics
        /// </summary>
        /// <returns></returns>
        private Dictionary<string, List<ProjectEffortMetricsDTO>> GetMonthMetrics()
        {
            Dictionary<string, List<ProjectEffortMetricsDTO>> dataList = new();
            DateTime endDate = DateTime.Today;
            DateTime startDate = endDate.AddDays(-29); // Subtract 29 to get the last 30 days
            var projects = Enumerable.Range(0, 5)
            .Select(week => startDate.AddDays(week * 7))
            .Select((startOfWeek, index) => new ProjectEffortMetricsDTO
            {
                WeekStartDate = startOfWeek,
                WeekEndDate = startOfWeek.AddDays(6),
                Data = _context.TblProjects
                    .Where(e => e.created_at.Date >= startOfWeek && e.created_at.Date <= startOfWeek.AddDays(6))
                    .Count(),
                WeekCount = $"Week{index + 1}"
            }).ToList();
            var totalServices = Enumerable.Range(0, 5)
            .Select(week => startDate.AddDays(week * 7))
            .Select((startOfWeek, index) => new ProjectEffortMetricsDTO
            {
                WeekStartDate = startOfWeek,
                WeekEndDate = startOfWeek.AddDays(6),
                Data = (from prj in _context.TblProjects
                        join offer in _context.TblOffers on prj.id equals offer.project_id
                        join ser in _context.TblServices on offer.id equals ser.offer_id
                        where ser.created_at.Date >= startOfWeek && ser.created_at.Date <= startOfWeek.AddDays(6)
                        select new { }).Count(),
                WeekCount = $"Week{index + 1}"
            }).ToList();
            var servicesInProgress = Enumerable.Range(0, 5)
            .Select(week => startDate.AddDays(week * 7))
            .Select((startOfWeek, index) => new ProjectEffortMetricsDTO
            {
                WeekStartDate = startOfWeek,
                WeekEndDate = startOfWeek.AddDays(6),
                Data = (from prj in _context.TblProjects
                        join offer in _context.TblOffers on prj.id equals offer.project_id
                        join ser in _context.TblServices on offer.id equals ser.offer_id
                        where ser.status.ToLower() == MachineStatus.IN_PROGRESS.ToLower() && ser.modified_at.Date >= startOfWeek && ser.modified_at.Date <= startOfWeek.AddDays(6)
                        select new { }).Count(),
                WeekCount = $"Week{index + 1}"
            }).ToList();
            var servicesCompleted = Enumerable.Range(0, 5)
            .Select(week => startDate.AddDays(week * 7))
            .Select((startOfWeek, index) => new ProjectEffortMetricsDTO
            {
                WeekStartDate = startOfWeek,
                WeekEndDate = startOfWeek.AddDays(6),
                Data = (from prj in _context.TblProjects
                        join offer in _context.TblOffers on prj.id equals offer.project_id
                        join ser in _context.TblServices on offer.id equals ser.offer_id
                        where ser.status.ToLower() == MachineStatus.COMPLETED.ToLower() && ser.modified_at.Date >= startOfWeek && ser.modified_at.Date <= startOfWeek.AddDays(6)
                        select new { }).Count(),
                WeekCount = $"Week{index + 1}"
            }).ToList();
            dataList.Add("TotalProjects", projects);
            dataList.Add("ServicesInProgress", servicesInProgress);
            dataList.Add("ServicesCompleted", servicesCompleted);
            dataList.Add("TotalServices", totalServices);
            return dataList;
        }
        /// <summary>
        /// Get Yearly Metrics
        /// </summary>
        /// <returns></returns>
        private Dictionary<string, List<ProjectEffortMetricsDTO>> GetYearDataMetrics()
        {
            try
            {
                Dictionary<string, List<ProjectEffortMetricsDTO>> dataList = new();
                DateTime date = DateTime.Now;
                DateTime currentDate = DateTime.Today;

                // Calculate the start date of the current year
                DateTime startOfLastYear = currentDate.AddDays(-364);

                // Determine the number of quarters in the year
                int numberOfQuarters = 4;

                var projects = Enumerable.Range(0, numberOfQuarters)
                .Select(quarter => startOfLastYear.AddMonths(quarter * 3))
                .Select(startOfMonth => new ProjectEffortMetricsDTO
                {
                    QuarterStartDate = startOfMonth,
                    QuarterEndDate = startOfMonth.AddMonths(2).AddDays(DateTime.DaysInMonth(startOfMonth.Year, startOfMonth.Month + 2)),
                    Data = _context.TblProjects
                        .Where(e => e.created_at.Date.Minute >= startOfMonth.Minute && e.created_at.Date <= startOfMonth.AddMonths(2).AddDays(DateTime.DaysInMonth(startOfMonth.Year, startOfMonth.Month + 2)))
                        .Count()
                }).ToList();
                var totalServices = Enumerable.Range(0, numberOfQuarters)
                    .Select(quarter => startOfLastYear.AddMonths(quarter * 3))
                    .Select(startOfMonth => new ProjectEffortMetricsDTO
                    {
                        QuarterStartDate = startOfMonth,
                        QuarterEndDate = startOfMonth.AddMonths(2).AddDays(DateTime.DaysInMonth(startOfMonth.Year, startOfMonth.Month + 2)),
                        Data = (from prj in _context.TblProjects
                                join offer in _context.TblOffers on prj.id equals offer.project_id
                                join ser in _context.TblServices on offer.id equals ser.offer_id
                                where ser.created_at.Date >= startOfMonth && ser.created_at.Date <= startOfMonth.AddMonths(2).AddDays(DateTime.DaysInMonth(startOfMonth.Year, startOfMonth.Month + 2))
                                select new { }).Count()
                    }).ToList();
                var servicesInProgress = Enumerable.Range(0, numberOfQuarters)
                    .Select(quarter => startOfLastYear.AddMonths(quarter * 3))
                    .Select(startOfMonth => new ProjectEffortMetricsDTO
                    {
                        QuarterStartDate = startOfMonth,
                        QuarterEndDate = startOfMonth.AddMonths(2).AddDays(DateTime.DaysInMonth(startOfMonth.Year, startOfMonth.Month + 2)),
                        Data = (from prj in _context.TblProjects
                                join offer in _context.TblOffers on prj.id equals offer.project_id
                                join ser in _context.TblServices on offer.id equals ser.offer_id
                                where ser.status.ToLower() == MachineStatus.IN_PROGRESS.ToLower() && ser.modified_at.Date >= startOfMonth && ser.modified_at.Date <= startOfMonth.AddMonths(2).AddDays(DateTime.DaysInMonth(startOfMonth.Year, startOfMonth.Month + 2))
                                select new { }).Count()
                    }).ToList();
                var servicesCompleted = Enumerable.Range(0, numberOfQuarters)
                    .Select(quarter => startOfLastYear.AddMonths(quarter * 3))
                    .Select(startOfMonth => new ProjectEffortMetricsDTO
                    {
                        QuarterStartDate = startOfMonth,
                        QuarterEndDate = startOfMonth.AddMonths(2).AddDays(DateTime.DaysInMonth(startOfMonth.Year, startOfMonth.Month + 2)),
                        Data = (from prj in _context.TblProjects
                                join offer in _context.TblOffers on prj.id equals offer.project_id
                                join ser in _context.TblServices on offer.id equals ser.offer_id
                                where ser.status.ToLower() == MachineStatus.COMPLETED.ToLower() && ser.modified_at.Date >= startOfMonth && ser.modified_at.Date <= startOfMonth.AddMonths(2).AddDays(DateTime.DaysInMonth(startOfMonth.Year, startOfMonth.Month + 2))
                                select new { }).Count()
                    }).ToList();
                dataList.Add("TotalProjects", projects);
                dataList.Add("ServicesInProgress", servicesInProgress);
                dataList.Add("ServicesCompleted", servicesCompleted);
                dataList.Add("TotalServices", totalServices);
                return dataList;
            }
            catch (Exception)
            {

                throw;
            }
        }
        /// <summary>
        /// Get Day Metrics
        /// </summary>
        /// <returns></returns>
        private Dictionary<string, List<ProjectEffortMetricsDTO>> GetDayDataMetrics()
        {
            try
            {
                Dictionary<string, List<ProjectEffortMetricsDTO>> dataList = new();
                DateTimeOffset currentDate = DateTimeOffset.Now;
                var last48HrsData = _context.TblProjects.Where(p => p.created_at >= currentDate.AddHours(-48) && p.created_at < currentDate)
                    .Select(s => new
                    {
                        ProjectId = s.id,
                        CreatedDate = s.created_at
                    }).ToList();
                var projects = Enumerable.Range(0, 24)
                    .Select(hour => new ProjectEffortMetricsDTO
                    {
                        Hours = hour,
                        HourStart = currentDate.AddHours(-hour).AddHours(-1),
                        HourEnd = currentDate.AddHours(-hour),
                        Data = last48HrsData
                        .Where(t => t.CreatedDate >= currentDate.AddHours(-24) && t.CreatedDate < currentDate && t.CreatedDate.Hour == hour)
                        .ToList().Count
                    }).ToList();
                var services = (from prj in _context.TblProjects
                                join offer in _context.TblOffers on prj.id equals offer.project_id
                                join ser in _context.TblServices on offer.id equals ser.offer_id
                                where ser.created_at.Date >= currentDate.AddHours(-48) && ser.created_at.Date < currentDate
                                select new
                                {
                                    ServiceId = ser.id,
                                    CreatedDate = ser.created_at
                                }).ToList();
                var totalServices = Enumerable.Range(0, 24)
                    .Select(hourStart => new ProjectEffortMetricsDTO
                    {
                        Hours = hourStart,
                        HourStart = currentDate.AddHours(-hourStart),
                        HourEnd = currentDate.AddHours(-hourStart).AddHours(1),
                        Data = services.Where(t => t.CreatedDate >= currentDate.AddHours(-24) && t.CreatedDate < currentDate && t.CreatedDate.Hour == hourStart).Count()
                    }).ToList();
                var last48ServiceInprogress = (from prj in _context.TblProjects
                                               join offer in _context.TblOffers on prj.id equals offer.project_id
                                               join ser in _context.TblServices on offer.id equals ser.offer_id
                                               where ser.status.ToLower() == MachineStatus.IN_PROGRESS.ToLower() && ser.created_at >= currentDate.AddHours(-48) && ser.created_at < currentDate
                                               select new
                                               {
                                                   ServiceId = ser.id,
                                                   ModifiedDate = ser.modified_at
                                               }).ToList();
                var servicesInProgress = Enumerable.Range(0, 24)
                    .Select(hourStart => new ProjectEffortMetricsDTO
                    {
                        Hours = hourStart,
                        HourStart = currentDate.AddHours(-hourStart),
                        HourEnd = currentDate.AddHours(-hourStart).AddHours(1),
                        Data = last48ServiceInprogress.Where(t => t.ModifiedDate >= currentDate.AddHours(-24) && t.ModifiedDate < currentDate && t.ModifiedDate.Hour == hourStart).Count()
                    }).ToList();
                var last48hrsServicesCompleted = (from prj in _context.TblProjects
                                                  join offer in _context.TblOffers on prj.id equals offer.project_id
                                                  join ser in _context.TblServices on offer.id equals ser.offer_id
                                                  where ser.status.ToLower() == MachineStatus.COMPLETED.ToLower() && ser.created_at >= currentDate.AddHours(-48) && ser.created_at < currentDate
                                                  select new
                                                  {
                                                      ServiceId = ser.id,
                                                      ModifiedDate = ser.modified_at
                                                  }).ToList();
                var servicesCompleted = Enumerable.Range(0, 24)
                    .Select(hourStart => new ProjectEffortMetricsDTO
                    {
                        Hours = hourStart,
                        HourStart = currentDate.AddHours(-hourStart),
                        HourEnd = currentDate.AddHours(-hourStart).AddHours(1),
                        Data = last48hrsServicesCompleted.Where(t => t.ModifiedDate >= currentDate.AddHours(-24) && t.ModifiedDate < currentDate && t.ModifiedDate.Hour == hourStart).Count()
                    }).ToList();
                dataList.Add("TotalProjects", projects);
                dataList.Add("ServicesInProgress", servicesInProgress);
                dataList.Add("ServicesCompleted", servicesCompleted);
                dataList.Add("TotalServices", totalServices);
                return dataList;
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
