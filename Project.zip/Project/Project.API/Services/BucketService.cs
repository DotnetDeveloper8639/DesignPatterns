﻿using Microsoft.EntityFrameworkCore;
using Project.API.DbContextClass;
using Project.API.EntityModels;
using Project.API.Services;
using Project.API.Models.ProjectDTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project.API.Services
{

    public class BucketService : ProjectBaseRepository<TblBucket>, IBucketService
    {
        private readonly Sch_Context _context;
        public BucketService(Sch_Context context) : base(context)
        {
            _context = context;
        }
        /// <summary>
        /// Get all buckets list
        /// </summary>
        public async Task<List<BucketDetailsDTO>> GetAllBucketsByProjectId(string project_id, string order_id, string service_type)
        {
            try
            {
                var result = await (from b in _context.TblBucket
                                    join o in _context.TblOrder on b.order_id equals o.id
                                    join s in _context.TblServices on o.service_id equals s.id
                                    where b.project_id == project_id && b.order_id == order_id && s.service_type == service_type
                                    select new BucketDetailsDTO
                                    {
                                        Bucket_Id = b.id,
                                        Bucket_Name = b.bucket_name,
                                        //machines = _context.TblServiceMachines.Where(a => a.bucket_id == b.id).Join(_context.TblMachines, sm => sm.machine_id, m => m.id, (sm, m) => new MachineDTO
                                        //{
                                        //    Machine_Id = m.id,
                                        //    Machine_Name = m.machine_name,
                                        //    Asset_Id = m.asset_id,
                                        //    Serial_Number = m.serial_number
                                        //}).ToList(),
                                    }).ToListAsync();
                return result;
            }
            catch (Exception ex)
            {
                return null;
            }

        }
        /// <summary>
        /// Get all buckets list
        /// </summary>
        public async Task<List<BucketDTO>> GetAllBucketsById(string project_id)
        {

            var result = await (from b in _context.TblBucket
                                where b.project_id == project_id
                                select new BucketDTO
                                {
                                    Bucket_Id = b.id,
                                    Bucket_Name = b.bucket_name,
                                    Machine_Id = _context.TblBucket.Where(x => x.project_id == project_id && x.bucket_name == b.bucket_name).Select(y => y.machine_id).ToList().ToArray(),

                                }).ToListAsync();
            return result;
        }
        /// <summary>
        /// Create one or more Buckets
        /// </summary>
        /// <param name="bucket"></param>
        /// <returns></returns>
        public async Task<bool> CreateBucket(CreateBucketDTO bucket)
        {
            var isSuccess = false;
            TblBucket bkt = new TblBucket();
            try
            {

                if (bucket.Bucket_Id != null && bucket.Bucket_Id != "")
                {
                    for (var i = 0; i < bucket.Machine_Id.Count; i++)
                    {

                        var machine = _context.TblServiceMachines.Where(a => a.machine_id == bucket.Machine_Id[i]).FirstOrDefault();
                        if (machine != null)
                        {
                            //machine.bucket_id = bucket.Bucket_Id;
                            _context.SaveChanges();

                        }

                    }
                }
                else
                {


                    bkt.id = Guid.NewGuid().ToString();
                    bkt.bucket_name = bucket.Bucket_Name == "string" ? "" : bucket.Bucket_Name;
                    bkt.project_id = bucket.Project_Id == "string" ? "" : bucket.Project_Id;
                    bkt.order_id = bucket.Order_Id == "string" ? "" : bucket.Order_Id;
                    bkt.service_id = bucket.Service_Id == "string" ? "" : bucket.Service_Id;
                    bkt.user_id = bucket.User_Id == "string" ? "" : bucket.User_Id;

                    if (bucket.Machine_Id.Count > 0)
                    {
                        for (var i = 0; i < bucket.Machine_Id.Count; i++)
                        {
                            var machine = _context.TblServiceMachines.Where(a => a.machine_id == bucket.Machine_Id[i]).FirstOrDefault();
                            if (machine != null)
                            {
                                //machine.bucket_id = bkt.id;
                                _context.SaveChanges();

                            }

                        }
                    }
                    _context.TblBucket.Add(bkt);
                }



                await _context.SaveChangesAsync();
                isSuccess = true;
                return isSuccess;
            }
            catch (Exception ex)
            {
                return isSuccess;
            }

        }
        /// <summary>
        /// Update bucket
        /// </summary>
        /// <param name="bucket"></param>
        /// <returns></returns>
        public async Task<bool> UpdateBucket(List<BucketDTO> bucket)
        {
            var isSuccess = false;
            try
            {
                foreach (var item in bucket)
                {
                    var bkt = _context.TblBucket.Where(a => a.id == item.Bucket_Id).FirstOrDefault();
                    if (bkt != null)
                    {

                        bkt.bucket_name = item.Bucket_Name;
                        //bkt.machine_id = item.Machine_Id;
                        await _context.SaveChangesAsync();
                        isSuccess = true;
                    }
                }
                return isSuccess;
            }
            catch (Exception ex)
            {
                return false;
            }

        }
        /// <summary>
        /// Delete Bucket
        /// </summary>
        /// <param name="bucketId"></param>
        /// <returns></returns>
        public async Task<bool> DeleteBucket(string[] bucketId)
        {

            foreach (var item in bucketId)
            {

                var bucketList = _context.TblBucket.Where(a => a.id == item).FirstOrDefault();
                _context.TblBucket.Remove(bucketList);
                await _context.SaveChangesAsync();
                foreach (var i in bucketId)
                {
                    //var bucket = _context.TblServiceMachines.Where(a => a.bucket_id == i).FirstOrDefault();
                    //bucket.bucket_id = null;
                    //_context.SaveChanges();
                }
            }

            return true;

        }
    }
}
