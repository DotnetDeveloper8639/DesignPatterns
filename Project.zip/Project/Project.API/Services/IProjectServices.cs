﻿using Project.API.Models.ProjectDTOs;
using Project.API.EntityModels;
using System.Collections.Generic;
using System.Threading.Tasks;
using Project.API.IntegrationEvents.Events;
using System;

namespace Project.API.Services
{
    public interface IProjectServices
    {
        Task<List<ProjectDashboardDTO>> GetAllProjects();
        Task<ProjectRequestEvent> CreateProject(CreateProjectDTO project);
        Task<bool> UpdateProject(UpdateProjectDto project);
        Task<bool> DeleteProject(string projectId);
        Task<ProjectDTO> GetprojectById(string projectId);
        Dictionary<string, int> GetProjectEffortMetrics();
        Task<ServiceDetailDTO> GetServiceDetails(string projectId, string orderId, string serviceType);
        List<MachineDTO> GetProjectMachines(string projectId, string orderId, string serviceType);
        Task<bool> AddProjectMachine(CreateMachineDTO machines);
        List<OrderDTO> GetProjectOrderdetails(string projectId);
        Task<string> UpdateErpProject(ProjectResponseEvent projectResponse);
        List<CompanyDTO> GetCompanyDetails();
        Task<List<ServiceDTO>> GetServicesByOrderId(string orderId);
        Task<bool> AddStaffToProject(ProjectStaffUpsertDto projectStaffDto);
        Task<bool> UpdateMahineState(MachineStatusDTO machine);
        Task<string> DeleteStaffFromProject(ProjectStaffDeleteDto projectStaffDto);
        Task<ProjectCostData> GetProjectCostData(string projectId, string serviceId, string orderId);
        Task<List<TblAuditEntry>> GetAuditLogs(AuditLogDTO auditLogDTO);
        Task<List<ServiceDTO>> GetAllProjectRelatedServices(string projectId);
        Task<Dictionary<string, List<ProjectEffortMetricsDTO>>> GetDailyEffortMetrics(string range);
    }
}
