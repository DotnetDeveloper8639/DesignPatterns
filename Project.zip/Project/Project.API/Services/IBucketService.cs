﻿using Project.API.EntityModels;
using Project.API.Models.ProjectDTOs;
using Project.API.Services;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Project.API.Services
{
    public interface IBucketService : IProjectBaseRepository<TblBucket>
    {
        Task<List<BucketDetailsDTO>> GetAllBucketsByProjectId(string project_id, string order_id, string service_type);
        Task<List<BucketDTO>> GetAllBucketsById(string project_id);
        Task<bool> CreateBucket(CreateBucketDTO bucket);       
        Task<bool> UpdateBucket(List<BucketDTO> bucketName);
        //Task<bool> DeleteBucket(TblBucket bucket);
        Task<bool> DeleteBucket(string[] bucketId);
    }
}
