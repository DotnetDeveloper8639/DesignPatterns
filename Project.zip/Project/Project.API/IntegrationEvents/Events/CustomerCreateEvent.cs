﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Project.API.IntegrtaionEvents.Events
{
    public class CustomerCreateEvent
    {
        public string Cus_Id { get; set; }
        public string Customer_Id { get; set; }
        public string Customer_Name { get; set; }
        public string Erp_Customer_Id { get; set; }
        public string Project_Id { get; set; }
        public string Country_Code { get; set; }
        public string Contact_Id { get; set; }
        public string City { get; set; }
        public string Zipcode { get; set; }
        public string Street { get; set; }
        public string Phone_Number { get; set; }
        public string Language { get; set; }
        public DateTimeOffset Created_At { get; set; }
        public string Created_By { get; set; }
        public DateTimeOffset Modified_At { get; set; }
        public string Modified_By { get; set; }

        public CustomerCreateEvent(string cus_Id, string customer_Id, string customer_Name, string erp_Cutomer_Id, string project_Id, string country_Code, 
                                     string city, string zipcode, string street, string phone_Number, string contact_Id,
                                    string language, DateTimeOffset created_At, string created_By, DateTimeOffset modified_At, string modified_By)
        {
            Cus_Id = cus_Id;
            Customer_Id = customer_Id;
            Customer_Name = customer_Name;
            Erp_Customer_Id = erp_Cutomer_Id;
            Project_Id = project_Id;
            Country_Code = country_Code;
            City = city;
            Zipcode = zipcode;
            Street = street;
            Phone_Number = phone_Number;
            Contact_Id = contact_Id;
            Language = language;
            Created_At = created_At;
            Created_By = created_By;
            Modified_At = modified_At;
            Modified_By = modified_By;
        }
    }
}
