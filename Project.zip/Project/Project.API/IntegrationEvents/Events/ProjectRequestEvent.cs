﻿using EventBus.Abstractions;
using EventBus.Events;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Project.API.IntegrationEvents.Events
{
    public class ProjectRequestEvent: IntegrationEvent
    {

        [JsonPropertyName("TechnicalHeader")]
        public RequestTechnicalHeader TechnicalHeader { get; set; }

        [JsonPropertyName("Project")]
        public ProjectRequest ProjectRequest { get; set; }

        public ProjectRequestEvent(ProjectRequest projectRequest, RequestTechnicalHeader technicalHeader)
        {
            ProjectRequest = projectRequest;
            TechnicalHeader = technicalHeader;
        }
    }

    public class ProjectRequest
    {
        [JsonPropertyName("ProjectID")]
        public string ProjectID { get; set; }
        [JsonPropertyName("ERPProjectID")]
        public string ERPProjectID { get; set; }
        [JsonPropertyName("ProjectName")]
        public string ProjectName { get; set; }
        [JsonPropertyName("ProjectStatus")]
        public string ProjectStatus { get; set; }
        [JsonPropertyName("StartDate")]
        public DateTime? StartDate { get; set; }
        [JsonPropertyName("EndDate")]
        public DateTime? EndDate { get; set; }
        [JsonPropertyName("ControllingArea")]
        public string ControllingArea { get; set; }
        
        [JsonPropertyName("CustomerID")]
        public string CustomerId { get; set; }
        [JsonPropertyName("ERPCustomerID")]
        public string ERPCustomerId { get; set; }
        [JsonPropertyName("Action")]
        public string Action { get; set; }

        public ProjectRequest(string projectId, string erpProjectId, string projectName, string projectStatus, DateTime? startDate, DateTime? endDate, string controllingArea, string customerId,string erpCustomerId, string action)
        {
            ProjectID = projectId;
            ERPProjectID = erpProjectId;
            ProjectName = projectName;
            ProjectStatus = projectStatus;
            StartDate = startDate;
            EndDate = endDate;
            ControllingArea = controllingArea;
            CustomerId = customerId;
            ERPCustomerId = erpCustomerId;
            Action = action;
        }
    }
    //public class TechnicalHeader : RequestTechnicalHeader
    //{
    //    public TechnicalHeader(string tenantID, string companyCode, string emailAddress, string requestID, DateTime? timestamp)
    //    {
    //        TenantID = tenantID;
    //        CompanyCode = companyCode;
    //        EmailAddress = emailAddress;
    //        RequestID = requestID;
    //        Timestamp = timestamp;
    //    }
    //}
}
