﻿using EventBus.Abstractions;
using EventBus.Events;
using Project.API.IntegrtaionEvents.Events;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Project.API.IntegrationEvents.Events
{
    public class ProjectResponseEvent//: IntegrationEvent
    {
        public RequestTechnicalHeader TechnicalHeader { get; set; }
        public ErpProjectProject Project { get; set; }
        public ErpProjectResponseCustomer Customer { get; set; }
    }
    public class ErpProjectProject
    {
        public string ProjectID { get; set; }
        public string ERPProjectID { get; set; }
        public string ProjectName { get; set; }
        public string ProjectStatus { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string ControllingArea { get; set; }
        public string Action { get; set; }
    }

    public class ErpProjectResponseContact
    {
        public string ContactID { get; set; }
        public string Firstname { get; set; }
        public string Lastname { get; set; }
        public string EmailAddress { get; set; }
        public string Title { get; set; }
        public string Language { get; set; }
        public string PhoneNumber { get; set; }
        public string Department { get; set; }
    }

    public class ErpProjectResponseCustomer
    {
        public string CustomerID { get; set; }
        public string CustomerName { get; set; }
        public string CountryCode { get; set; }
        public string City { get; set; }
        public string ZipCode { get; set; }
        public string Street { get; set; }
        public string PhoneNumber { get; set; }
        public List<ErpProjectResponseContact> Contact { get; set; }
    }
}
