﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Project.API.IntegrtaionEvents.Events
{
    public class ContactCreateEvent
    {
        public string Contact_Id { get; set; }
        public string Erp_Contact_Id { get; set; }
        public string First_Name { get; set; }
        public string Last_Name { get; set; }
        public string Display_Name { get; set; }
        public string Email_Address { get; set; }
        public string Title { get; set; }
        public string Language { get; set; }
        public string Phone_Number { get; set; }
        public string Department { get; set; }
        public DateTimeOffset Created_At { get; set; }
        public string Created_By { get; set; }
        public DateTimeOffset Modified_At { get; set; }
        public string Modified_By { get; set; }

        public ContactCreateEvent(string contact_Id, string erp_Contact_Id, string first_Name, string display_Name, string email_Address, string title,
                                   string language, string phone_Number, string department, DateTimeOffset created_At, string created_By, DateTimeOffset modified_At,
                                   string modified_By)
        {
            Contact_Id = contact_Id;
            Erp_Contact_Id = erp_Contact_Id;
            First_Name = first_Name;
            Display_Name = display_Name;
            Email_Address = email_Address;
            Title = title;
            Language = language;
            Phone_Number = phone_Number;
            Department = department;
            Created_At = created_At;
            Created_By = created_By;
            Modified_At = modified_At;
            Modified_By = modified_By;
        }
    }
}
