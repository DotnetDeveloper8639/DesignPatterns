﻿using EventBus.Events;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Project.API.IntegrationEvents.NotificationEvents
{
    public class ProjectNotificationEvent : IntegrationEvent
    {
        public List<string> UserId { get; set; }
        public string NotificationType { get; set; }
        public string CreatedByUserId { get; set; }
        public string Message { get; set; }
        public string Tid { get; set; }
        public string Erp_Id { get; set; }
        public string Blueprint_Id { get; set; }
        public string NotificationEvent { get; set; }
        public ProjectNotificationEvent(
        List<string> userId
            , string notificationType
            , string createdByUserId
            , string tid
            , string message
            , string erp_Id
            , string blueprint_Id
            , string notificationEvent)
        {
            this.Message = message;
            this.CreatedByUserId = createdByUserId;
            this.NotificationType = notificationType;
            this.UserId = userId;
            this.Tid = tid;
            this.Erp_Id = erp_Id;
            this.Blueprint_Id = blueprint_Id;
            this.NotificationEvent = notificationEvent;
        }
    }
}
