﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Project.API.EntityModels
{
    [Table("tblMachineFourEyesQualityAssociation")]
    public class TblMachineFourEyesQualityAssociation
    {
        [Key]
        [Column(TypeName = "varchar(50)")]
        public string id { get; set; }
        [Column(TypeName = "varchar(50)")]
        [ForeignKey("TblServiceMachine")]
        public string servicemachine_id { get; set; }
        [Column(TypeName = "varchar(50)")]
        [ForeignKey("TblUser")]
        public string user_id { get; set; }
        [Column(TypeName = "bit")]
        public bool isComplete { get; set; }



        public virtual TblUser TblUser { get; set; }
        public virtual TblServiceMachine TblServiceMachine { get; set; }
    }
}
