﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Project.API.EntityModels
{
    [Table("tblMachineCustomerAssociation")]
    public class TblMachineCustomerAssociation
    {
        [Key]
        [Column(TypeName = "nvarchar(50)")]
        public string id { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string customer_id { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string machine_id { get; set; }
        [Column(TypeName = "nvarchar(MAX)")]
        public string segments { get; set; }
        [Column(TypeName = "varchar(MAX)")]
        public string sub_segments { get; set; }
    }
}
