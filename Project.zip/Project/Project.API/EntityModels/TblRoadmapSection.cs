﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Project.API.EntityModels
{
    [Table("tblRoadmapSection")]
    public class TblRoadmapSection
    {
        [Key]
        [Column(TypeName = "nvarchar(50)")]
        public string id { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        [ForeignKey("RoadmapMaster")]
        public string roadmap_id { get; set; }
        [Column(TypeName = "nvarchar(500)")]
        public string section { get; set; }
        [Column(TypeName = "nvarchar(500)")]
        public string subsection { get; set; }
        [Column(TypeName = "datetimeoffset(7)")]
        public DateTimeOffset created_at { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string created_by { get; set; }
        [Column(TypeName = "datetimeoffset(7)")]
        public DateTimeOffset modified_at { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string modified_by { get; set; }

        public virtual TblRoadmapMaster RoadmapMaster { get; set; }
    }
}
