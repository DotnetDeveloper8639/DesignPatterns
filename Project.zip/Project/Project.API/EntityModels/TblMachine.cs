﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Project.API.EntityModels
{
    [Table("tblMachine")]
    public class TblMachine
    {
        [Key]
        [Column(TypeName = "nvarchar(80)")]
        public string id { get; set; }
        [Column(TypeName = "nvarchar(80)")]
        public string global_id { get; set; }
        [Column(TypeName = "nvarchar(80)")]
        public string master_machine_id { get; set; }
        [Column(TypeName = "nvarchar(160)")]
        public string machine_name { get; set; }
        [Column(TypeName = "nvarchar(80)")]
        public string asset_id { get; set; }
        [Column(TypeName = "nvarchar(80)")]
        public string serial_number { get; set; }
        [Column(TypeName = "nvarchar(150)")]
        public string machine_description { get; set; }
        [Column(TypeName = "decimal(18,4)")]
        public decimal estimated_hours { get; set; }
        [Column(TypeName = "nvarchar(80)")]
        public string machine_type { get; set; }
        [Column(TypeName = "nvarchar(100)")]
        public string machine_location { get; set; }
        [Column(TypeName = "nvarchar(500)")]
        public string manufacturer { get; set; }
        [Column(TypeName = "nvarchar(100)")]
        public string industry_type { get; set; }

        [Column("erp_wbs_id", TypeName = "nvarchar(100)")]
        public string WBSID { get; set; }
        [Column(TypeName = "bit")]
        public bool is_delete { get; set; }

        [Column(TypeName = "datetimeoffset(7)")]
        public DateTimeOffset created_at { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string created_by { get; set; }
        [Column(TypeName = "datetimeoffset(7)")]
        public DateTimeOffset modified_at { get; set; }
        [Column(TypeName = "datetimeoffset(7)")]
        public DateTimeOffset? deleted_at { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string deleted_by { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string modified_by { get; set; }

        [Column(TypeName = "nvarchar(100)")]
        public string machine_status { get; set; }
        [Column(TypeName = "nvarchar(100)")]
        public string machine_model { get; set; }

    }
}
