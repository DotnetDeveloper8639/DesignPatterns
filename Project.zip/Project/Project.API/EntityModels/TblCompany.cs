﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Project.API.EntityModels
{
    [Table("tblCompany")]
    public class TblCompany
    {
        [Key]
        [Column(TypeName = "nvarchar(50)")]
        public string id { get; set; }
        [Column(TypeName = "nvarchar(80)")]
        public string company_name { get; set; }
        [Column(TypeName = "nvarchar(80)")]
        public string company_code { get; set; }
        [Column(TypeName = "nvarchar(100)")]
        public string region { get; set; }
    }
}
