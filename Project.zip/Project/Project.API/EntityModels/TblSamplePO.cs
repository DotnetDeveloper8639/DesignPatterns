﻿
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Project.API.EntityModels
{
    [Table("tblSamplePO")]
    public class TblSamplePO
    {
        [Key]
        [Column(TypeName = "nvarchar(50)")]
        public string id { get; set; }
        [Column(TypeName = "nvarchar(255)")]
        public string name { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string value { get; set; }
    }
}
