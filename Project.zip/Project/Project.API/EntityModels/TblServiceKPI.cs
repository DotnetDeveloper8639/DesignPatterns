﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Project.API.EntityModels
{
    [Table("tblServiceKPI")]
    public class TblServiceKPI
    {
        [Key]
        [Column(TypeName = "nvarchar(50)")]
        public string id { get; set; }
        [Column(TypeName = "int")]
        public int calculated_hours { get; set; }
        [Column(TypeName = "money")]
        public decimal cost_progress { get; set; }
        [Column(TypeName = "int")]
        public int hours_progress { get; set; }
        [Column(TypeName = "int")]
        public int roadmap_progress { get; set; }
    }
}
