﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Project.API.EntityModels
{
    [Table("tblHazardConsequences")]
    public class HazardConsequences
    {
        [Key]
        [Column(TypeName = "nvarchar(50)")]
        public string id { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        [ForeignKey("HazardType")]
        public string hazard_type_id { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        [ForeignKey("HazardSource")]
        public string hazard_source_id { get; set; }
        [Column(TypeName = "nvarchar(100)")]
        public string consequence { get; set; }
        public DateTimeOffset created_at { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string created_by { get; set; }
        [Column(TypeName = "datetimeoffset(7)")]
        public DateTimeOffset modified_at { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string modified_by { get; set; }

        public virtual TblHazardType HazardType { get; set; }
        public virtual TblHazardSource HazardSource { get; set; }
    }
}
