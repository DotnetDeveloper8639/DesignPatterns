﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Project.API.EntityModels
{
    [Table("tblServiceMachine")]
    public class TblServiceMachine
    {
        [Key]
        [Column(TypeName = "varchar(50)")]
        public string id { get; set; }
        [Column(TypeName = "varchar(50)")]
        [ForeignKey("TblService")]
        public string service_id { get; set; }
        [Column(TypeName = "varchar(80)")]
        [ForeignKey("TblMachine")]
        public string machine_id { get; set; }
        [Column(TypeName = "bit")]
        public bool sistema_report_associated { get; set; }
        [Column(TypeName = "nvarchar(255)")]
        public string sistema_report_url { get; set; }
        [Column(TypeName = "bit")]
        public bool isrequested { get; set; }
        [Column(TypeName = "bit")]
        public bool isconflict { get; set; }
        [Column(TypeName = "bit")]
        public bool isactive { get; set; }
        [Column(TypeName = "datetimeoffset(7)")]
        public DateTimeOffset created_at { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string created_by { get; set; }
        [Column(TypeName = "datetimeoffset(7)")]
        public DateTimeOffset modified_at { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string modified_by { get; set; }

        public virtual TblService TblService { get; set; }
        public virtual TblMachine TblMachine { get; set; }
    }
}
