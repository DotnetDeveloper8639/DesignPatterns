﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Project.API.EntityModels
{
    [Table("tblMachineLimits")]
    public class TblMachineLimits
    {
        [Key]
        [Column(TypeName = "nvarchar(50)")]
        public string id { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string machinemode { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string lifecycle_phase { get; set; }
        [Column(TypeName = "nvarchar(255)")]
        public string limitation { get; set; }
        [Column(TypeName = "nvarchar(255)")]
        public string dimensions { get; set; }
        [Column(TypeName = "nvarchar(255)")]
        public string additional_limits { get; set; }
    }
}
