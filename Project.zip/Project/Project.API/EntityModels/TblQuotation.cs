﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Project.API.EntityModels
{
    [Table("tblQuotation")]
    public class TblQuotation
    {
        [Key]
        [Column(TypeName = "nvarchar(80)")]
        public string id { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        [ForeignKey("TblOffer")]
        public string offer_id { get; set; }
        [Column(TypeName = "nvarchar(150)")]
        public string template_name { get; set; }
        [Column(TypeName = "nvarchar(80)")]
        public string template_url { get; set; }
        [Column(TypeName = "nvarchar(80)")]
        public string quotation_url { get; set; }
        [Column(TypeName = "nvarchar(80)")]
        public decimal? version { get; set; }
        [Column(TypeName = "datetimeoffset(7)")]
        public DateTimeOffset created_at { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string created_by { get; set; }
        [Column(TypeName = "datetimeoffset(7)")]
        public DateTimeOffset modified_at { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string modified_by { get; set; }

        public virtual TblOffer TblOffer { get; set; }

    }
}
