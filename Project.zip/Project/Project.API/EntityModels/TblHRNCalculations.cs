﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Project.API.EntityModels
{
    [Table("tblHRNCalculations")]
    public class TblHRNCalculations
    {
        [Key]
        [Column(TypeName = "nvarchar(50)")]
        public string id { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string PO { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string SD { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string FE { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string NP { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string rating { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string modes { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        [ForeignKey("MachineHazards")]
        public string machine_hazard_id { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string type { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string version { get; set; }
        public DateTimeOffset created_at { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string created_by { get; set; }
        [Column(TypeName = "datetimeoffset(7)")]
        public DateTimeOffset modified_at { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string modified_by { get; set; }

        public virtual TblMachineHazards MachineHazards { get; set; }
    }
}
