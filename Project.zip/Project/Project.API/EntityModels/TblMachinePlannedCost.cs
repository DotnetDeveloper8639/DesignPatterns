﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Project.API.EntityModels
{
    [Table("tblMachinePlannedCost")]
    public class TblMachinePlannedCost
    {
        [Key]
        [Column(TypeName = "nvarchar(50)")]
        public string id { get; set; }

        [Column(TypeName = "nvarchar(50)")]
        [ForeignKey("TblServiceMachine")]
        public string service_machine_id { get; set; }

        [Column(TypeName = "nvarchar(50)")]
        public string cost_type { get; set; }
        [Column(TypeName = "nvarchar(10)")]
        public string currency { get; set; }

        [Column(TypeName = "money")]
        public decimal current_value { get; set; }
    }
}
