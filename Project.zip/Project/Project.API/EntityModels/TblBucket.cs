﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Project.API.EntityModels
{
    [Table("tblBucket")]
    public class TblBucket
    {
        [Key]
        [Column(TypeName = "varchar(50)")]
        public string id { get; set; }

        [Column(TypeName = "varchar(250)")]
        public string bucket_name { get; set; }

        [Column(TypeName = "varchar(50)")]
        public string project_id { get; set; }

        [Column(TypeName = "varchar(50)")]
        public string order_id { get; set; }

        [Column(TypeName = "varchar(50)")]
        public string service_id { get; set; }

        [Column(TypeName = "varchar(50)")]
        public string machine_id { get; set; }

        [Column(TypeName = "varchar(50)")]
        public string user_id { get; set; }
    }
}
