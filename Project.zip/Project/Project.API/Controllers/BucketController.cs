﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Project.API.Models.ProjectDTOs;
using Project.API.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProjectAPI.Controllers
{
    [Route("api/BucketService")]
    [ApiController]
    public class BucketController : ControllerBase
    {
        public readonly IBucketService _repositoryService;
        public BucketController(IBucketService repositoryService)
        {
            _repositoryService = repositoryService;
        }
        [Route("buckets")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [Produces("application/json")]
        [HttpGet]
        public async Task<IActionResult> GetAllBucketsByProjectId(string project_id, string order_id, string service_type)
        {
            var result = await _repositoryService.GetAllBucketsByProjectId(project_id, order_id, service_type);
            if (!result.Any())
            {
                return new JsonResult("No Records Found")
                {
                    StatusCode = StatusCodes.Status404NotFound
                };
            }
            return new JsonResult(result)
            {
                StatusCode = StatusCodes.Status200OK
            };
        }
        //[Route("get")]
        //[ProducesResponseType(StatusCodes.Status200OK)]
        //[ProducesResponseType(StatusCodes.Status404NotFound)]
        //[Produces("application/json")]
        //[HttpGet]
        //public async Task<IActionResult> GetAllBucketsById(string project_id)
        //{
        //    var result = await _repositoryService.GetAllBucketsById(project_id);
        //    if (!result.Any())
        //    {
        //        return new JsonResult("No Records Found")
        //        {
        //            StatusCode = StatusCodes.Status404NotFound
        //        };
        //    }
        //    return new JsonResult(result)
        //    {
        //        StatusCode = StatusCodes.Status200OK
        //    };
        //}
        [Route("bucket")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Produces("application/json")]
        [HttpPost]
        public async Task<IActionResult> CreateBucket([FromBody] CreateBucketDTO bucket)
        {
            var result = await _repositoryService.CreateBucket(bucket);
            if (result == false)
            {
                return new JsonResult("bucket not been created")
                {
                    StatusCode = StatusCodes.Status500InternalServerError
                };
            }
            return new JsonResult("Bucket has been created")
            {
                StatusCode = StatusCodes.Status201Created
            };
        }
        [Route("buckets")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Produces("application/json")]
        [HttpPut]
        public async Task<bool> Update(List<BucketDTO> bucketName)
        {
            var result = await _repositoryService.UpdateBucket(bucketName);
            return result;
        }
        [Route("buckets")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Produces("application/json")]
        [HttpDelete]
        public async Task<bool> DeleteBucket(string[] bucketId)
        {
            var result = await _repositoryService.DeleteBucket(bucketId);
            return result;
        }
    }
}
