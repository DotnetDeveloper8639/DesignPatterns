﻿using EventBus.Abstractions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Project.API.IntegrationEvents.Events;
using Project.API.Models.ProjectDTOs;
using Project.API.Services;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace Project.API.Controllers
{
    [Authorize]
    [Route("/api/projectsvc")]
    [ApiController]
    public class ProjectController : ControllerBase
    {
        public readonly IProjectServices _repositoryService;
        private const string DAPR_PUBSUB_NAME = "pubsub";
        private readonly IHttpContextAccessor httpContextAccessor;
        private readonly IEventBus eventBus;
        public ProjectController(
            IProjectServices repositoryService
            , IHttpContextAccessor httpContextAccessor
            , IEventBus _eventBus)
        {
            _repositoryService = repositoryService;
            this.httpContextAccessor = httpContextAccessor;
            eventBus = _eventBus;
        }

        /// <summary>
        /// Get All available project records
        /// </summary>       
        [Route("projects")]
        [Authorize(Roles = "Project.Read,Project.Write")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status504GatewayTimeout)]
        [Produces("application/json")]
        [HttpGet]
        [ResponseCache(Duration = 10)]
        public async Task<IActionResult> GetAllProjects()
        {
            try
            {
                var result = await _repositoryService.GetAllProjects();
                if (!result.Any())
                {
                    return new JsonResult("No Records Found")
                    {
                        StatusCode = StatusCodes.Status404NotFound
                    };
                }
                return Ok(result);
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        /// <summary>
        /// Create New project 
        /// </summary>
        /// <param name="project"></param>
        /// <returns></returns>
        [Route("project")]
        [Authorize(Roles = "Project.Write")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Produces("application/json")]
        [HttpPost]
        public async Task<IActionResult> CeateProject([FromBody] CreateProjectDTO project)
        {
            try
            {
                var result = await _repositoryService.CreateProject(project);
                if(result != null)
                {
                    //var tenantId = httpContextAccessor.HttpContext?.User?.GetTenantId() ?? String.Empty;
                    //eventBus.PublishToQueue(new ProjectNotificationEvent(new List<string> { result.TechnicalHeader.EmailAddress }, "Create", "", tenantId, "Project Created"+"- "+ project.Project_Name) { TopicName = "projectnotificationrequest" });
                    result.TopicName = "projectrequest";
                    await eventBus.PublishToQueue(result, true);
                }
                //eventBus.StoreState(result);
                

                return Ok(result);
            }
            catch (Exception ex)
            {
                Console.Write(ex);
                return null;
            }

        }



        /// <summary>
        /// Create New project 
        /// </summary>
        /// <param name="project"></param>
        /// <returns></returns>
        ///
        [Route("erpprojectresponse")]
        [AllowAnonymous]
        //[Authorize(Roles = "Project.Update,Project.Manage")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Produces("application/json")]
        [HttpPost]
        public async Task<IActionResult> ERPProjectResponse(ProjectResponseEvent project)
        {
            eventBus.StoreState("project_erp", project);

            HttpContext.Items["CurrentTenantId"] = project.TechnicalHeader.TenantID;
            try
            {
                var result = _repositoryService.UpdateErpProject(project);
                return Ok();
            }
            catch (Exception ex)
            {
                Console.Write(ex);
                return null;
            }

        }

        [Route("addmachine")]
        [Authorize(Roles = "Service.Write,Project.Write")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Produces("application/json")]
        [HttpPost]
        public async Task<IActionResult> AddProjectmachine(CreateMachineDTO machine)
        {
            var result = await _repositoryService.AddProjectMachine(machine);
            if (result == false)
            {
                return new JsonResult("Machine Failed to Add")
                {
                    StatusCode = StatusCodes.Status500InternalServerError
                };
            }
            return new JsonResult("Machine has been Added")
            {
                StatusCode = StatusCodes.Status200OK
            };
        }


        /// <summary>
        /// Find project by Id
        /// </summary>
        /// <param name="projectId"></param>
        /// <returns></returns>
        [Route("project/{projectId}")]
        [Authorize(Roles = "Project.Read,Project.Write")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [Produces("application/json")]
        [HttpGet]
        public async Task<IActionResult> GetProjectById(string projectId)
        {
            try
            {
                var result = await _repositoryService.GetprojectById(projectId);
                if (result == null)
                {
                    return new JsonResult("No Project Found") { StatusCode = StatusCodes.Status404NotFound };
                }
                return new JsonResult(result) { StatusCode = StatusCodes.Status200OK };
            }
            catch (Exception ex) {
                Console.Write(ex);
                return null;
            }
        }
        /// <summary>
        /// Project effort metrics
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("projectmetrics")]
        [Authorize(Roles = "Project.Write, Project.Read")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [Produces("application/json")]
        public IActionResult GetProjectMetrics()
        {
            try
            {
                var result = _repositoryService.GetProjectEffortMetrics();
                if (result == null)
                {
                    return new JsonResult("No Data Found") { StatusCode = StatusCodes.Status404NotFound };
                }
                return new JsonResult(result) { StatusCode = StatusCodes.Status200OK };
            }
            catch (Exception ex) {
                Console.Write(ex);
                return null;
            }
        }

        /// <summary>
        /// Get service fo orderId, ServiceType and ProjectId
        /// </summary>
        /// <param name="orderId"></param>
        /// <param name="serviceType"></param>
        /// <param name="projectId"></param>
        /// <returns></returns>
        [HttpGet]
        [Authorize(Roles = "Project.Read,Service.Read")]
        [Route("service/{orderId}/{serviceType}/{projectId}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [Produces("application/json")]
        public async Task<IActionResult> GetServiceOrderDetails(string orderId, string serviceType, string projectId)
        {
            try
            {
                var result = await _repositoryService.GetServiceDetails(projectId, orderId, serviceType);
                if (result == null)
                {
                    return new JsonResult("No Services Found") { StatusCode = StatusCodes.Status404NotFound };
                }
                return new JsonResult(result) { StatusCode = StatusCodes.Status200OK };
            }
            catch (Exception ex) {
                Console.Write(ex);
                return StatusCode(500,"Internal Server Error");
            }
        }

        /// <summary>
        /// Get Machines of OrderId, ServiceType and ProjectId
        /// </summary>
        /// <param name="orderId"></param>
        /// <param name="serviceType"></param>
        /// <param name="projectId"></param>
        /// <returns></returns>
        [HttpGet]
        [Authorize(Roles = "Project.Read,Service.Read")]
        [Route("machines/{orderId}/{serviceType}/{projectId}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [Produces("application/json")]
        public IActionResult GetMachines(string orderId, string serviceType, string projectId)
        {
            try
            {
                var result = _repositoryService.GetProjectMachines(projectId, orderId, serviceType);
                if (result == null)
                {
                    return new JsonResult("No Machines Found")
                    {
                        StatusCode = StatusCodes.Status404NotFound
                    };
                }
                return new JsonResult(result)
                {
                    StatusCode = StatusCodes.Status200OK
                };
            }
            catch (Exception ex)
            {
                Console.Write(ex);
                return null;
            }

        }

        /// <summary>
        /// Get Orders of ProjectId
        /// </summary>
        /// <param name="projectId"></param>
        /// <returns></returns>
        [HttpGet]
        [Authorize(Roles = "Project.Read,Service.Read")]
        [Route("{projectId}/projectorders")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [Produces("application/json")]
        public IActionResult GetProjectRelatedOrders(string projectId)
        {
            try
            {
                var result = _repositoryService.GetProjectOrderdetails(projectId);
                if (result == null)
                {
                    return new JsonResult("No Orders Found")
                    {
                        StatusCode = StatusCodes.Status404NotFound
                    };
                }
                return new JsonResult(result)
                {
                    StatusCode = StatusCodes.Status200OK
                };
            }
            catch (Exception ex)
            {
                Console.Write(ex);
                return null;
            }

        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("companydetails")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [Produces("application/json")]
        public IActionResult GetCompanyDetails()
        {
            var result = _repositoryService.GetCompanyDetails();
            if (result == null)
            {
                return new JsonResult("No Orders Found")
                {
                    StatusCode = StatusCodes.Status404NotFound
                };
            }
            return new JsonResult(result)
            {
                StatusCode = StatusCodes.Status200OK
            };
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="project"></param>
        /// <returns></returns>
        [Route("update")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Produces("application/json")]
        [Authorize(Roles = "Project.Edit")]
        [HttpPut]
        public IActionResult UpdateProject([FromBody] UpdateProjectDto project)
        {
            var result = _repositoryService.UpdateProject(project);
            if (result.Result == false)
            {
                return new JsonResult("Project not been updated")
                {
                    StatusCode = StatusCodes.Status500InternalServerError
                };
            }
            return new JsonResult("Project has been updated")
            {
                StatusCode = StatusCodes.Status200OK
            };
        }

        [HttpGet]
        [Route("{orderId}/servicesbyorder")]
        [Authorize(Roles = "Project.Read,Service.Read")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Produces("application/json")]
        public IActionResult GetServicesByOrderId(string orderId)
        {
            var result = _repositoryService.GetServicesByOrderId(orderId);

            return new JsonResult(result.Result)
            {
                StatusCode = StatusCodes.Status200OK
            };
        }

        [Route("addstafftoproject")]
        [Authorize(Roles = "Project.Write,Project.Edit")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Produces("application/json")]
        [HttpPost]
        public async Task<IActionResult> AddProjectStaff(ProjectStaffUpsertDto projectStaffUpsertDto)
        {
            var result = await _repositoryService.AddStaffToProject(projectStaffUpsertDto);
            if (!result)
            {
                return new JsonResult("Failed to Add Staff to project")
                {
                    StatusCode = StatusCodes.Status500InternalServerError
                };
            }
            return new JsonResult("Staff has been added to project")
            {
                StatusCode = StatusCodes.Status200OK
            };
        }

        [Route("deletestafffromproject")]
        [Authorize(Roles = "Project.Write,Project.Delete,Project.Edit")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Produces("application/json")]
        [HttpPost]
        public async Task<IActionResult> DeleteProjectStaff([FromBody]ProjectStaffDeleteDto projectStaffUpsertDto)
        {
            var result = await _repositoryService.DeleteStaffFromProject(projectStaffUpsertDto);
            return Ok(result);
        }
        [Route("machinestatus")]
        [Authorize(Roles = "Project.Write,Project.Edit")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [Produces("application/json")]
        [HttpPut]
        public async Task<IActionResult> UpdateMahineState(MachineStatusDTO machine)
        {
            var result = await _repositoryService.UpdateMahineState(machine);
            if (result == false)
            {
                return new JsonResult("Failed to update machine status")
                {
                    StatusCode = StatusCodes.Status500InternalServerError
                };
            }
            return new JsonResult("Machine status updated successfully")
            {
                StatusCode = StatusCodes.Status200OK
            };
        }
        [Route("{projectId}/{serviceId}/{orderId}/projectcost")]
        [Authorize(Roles = "Project.Write,Project.Edit")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [Produces("application/json")]
        [HttpGet]
        public async Task<IActionResult> GetProjectCostData(string projectId, string serviceId, string orderId)
        {
            var result = await _repositoryService.GetProjectCostData(projectId, serviceId, orderId);
            if (result == null)
            {
                return new JsonResult("No Records Found")
                {
                    StatusCode = StatusCodes.Status404NotFound
                };
            }
            return Ok(result);
        }
        [Route("auditlogs")]
        [Authorize(Roles = "Project.Write,Project.Edit")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [Produces("application/json")]
        [HttpPost]
        public async Task<IActionResult> GetAuditLogs(AuditLogDTO auditLogDTO)
        {
            var result = await _repositoryService.GetAuditLogs(auditLogDTO);
            if (result == null)
            {
                return new JsonResult("No Records Found")
                {
                    StatusCode = StatusCodes.Status404NotFound
                };
            }
            return Ok(result);
        }
        [Route("{projectId}/projectservices")]
        [Authorize(Roles = "Project.Write,Project.Edit")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [Produces("application/json")]
        [HttpPost]
        public async Task<IActionResult> GetAllProjectRelatedServices(string projectId)
        {
            var result = await _repositoryService.GetAllProjectRelatedServices(projectId);
            if (result == null)
            {
                return new JsonResult("No Records Found")
                {
                    StatusCode = StatusCodes.Status404NotFound
                };
            }
            return Ok(result);
        }
        /// <summary>
        /// Project effort metrics
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("{dataRange}/dailymetrics")]
        [Authorize(Roles = "Project.Write, Project.Read")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [Produces("application/json")]
        public IActionResult GetProjectDailyMetrics(string dataRange)
        {
            try
            {
                var result = _repositoryService.GetDailyEffortMetrics(dataRange);
                if (result == null)
                {
                    return new JsonResult("No Data Found") { StatusCode = StatusCodes.Status404NotFound };
                }
                return new JsonResult(result) { StatusCode = StatusCodes.Status200OK };
            }
            catch (Exception ex)
            {
                return null;
            }
        }
    }
}
