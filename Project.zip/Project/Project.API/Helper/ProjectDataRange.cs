﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Project.API.Helper
{
    public static class ProjectDataRange
    {
        public const string WEEK = "week";
        public const string MONTH = "month";
        public const string DAY = "day";
    }
}
