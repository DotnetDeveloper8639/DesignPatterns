﻿using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Project.API.EntityModels;
using Tenant.Service;
using Microsoft.Identity.Web;
using System;

namespace Project.API.DbContextClass
{
    public class Sch_Context : DbContext
    {
        private readonly IConfiguration _configuration;
        private readonly IHttpContextAccessor httpContextAccessor;
        private readonly ITenantService tenantService;

        public Sch_Context()
        {
        }

        public Sch_Context(DbContextOptions<Sch_Context> options
            , IConfiguration configuration
            , IHttpContextAccessor httpContextAccessor
            , ITenantService tenantService)
                     : base(options)
        {
            _configuration = configuration;
            this.httpContextAccessor = httpContextAccessor;
            this.tenantService = tenantService;
        }


        public virtual DbSet<TblCompany> TblCompanies { get; set; }
        public virtual DbSet<TblContact> TblContacts { get; set; }
        public virtual DbSet<TblControllingArea> TblControllingAreas { get; set; }
        public virtual DbSet<TblCustomer> TblCustomers { get; set; }
        public virtual DbSet<TblErpContact> TblErpContacts { get; set; }
        public virtual DbSet<TblErpCustomer> TblErpCustomers { get; set; }
        public virtual DbSet<TblMachine> TblMachines { get; set; }
        public virtual DbSet<TblMasterMachine> TblMasterMachines { get; set; }
        public virtual DbSet<TblOffer> TblOffers { get; set; }
        public virtual DbSet<TblProject> TblProjects { get; set; }
        public virtual DbSet<TblProjectStaff> TblProjectStaffs { get; set; }
        public virtual DbSet<TblQuotation> TblQuotations { get; set; }
        public virtual DbSet<TblService> TblServices { get; set; }
        public virtual DbSet<TblServiceMachine> TblServiceMachines { get; set; }
        public virtual DbSet<TblTenantCatalog> TblTenantCatalogs { get; set; }
        public virtual DbSet<TblUser> TblUsers { get; set; }
        public virtual DbSet<TblTaskManager> TblTasks { get; set; }
        public virtual DbSet<TblOrder> TblOrder { get; set; }
        public virtual DbSet<TblOrderKPI> TblOrderKPI { get; set; }
        public virtual DbSet<TblServiceKPI> TblServiceKPI { get; set; }
        public virtual DbSet<TblOfferKPI> TblOfferKPI { get; set; }
        public virtual DbSet<TblProjectKPI> TblProjectKPI { get; set; }
        public virtual DbSet<TblSchNotification> TblNotiications { get; set; }
        public virtual DbSet<TblBucket> TblBucket { get; set; }
        public virtual DbSet<TblMachineKPI> TblMachineKPI { get; set; }
        public virtual DbSet<TblMachineFourEyesQualityAssociation> TblMachineFourEyesQualityAssociation { get; set; }
        public virtual DbSet<TblGroup> TblGroups { get; set; }
        public virtual DbSet<TblMachineHour> TblMachineHour { get; set; }
        public virtual DbSet<TblMachineRoadmap> TblMachineRoadmap { get; set; }
        public virtual DbSet<TblActualHours> TblActualHours { get; set; }
        public virtual DbSet<TblRoadmapMaster> TblRoadmapMaster { get; set; }
        public virtual DbSet<TblRoadmapSection> TblRoadmapSection { get; set; }
        public virtual DbSet<TblRoadmapSubSectionMster> TblRoadmapSubSectionMster { get; set; }
        public virtual DbSet<TblStepMaster> TblStepMaster { get; set; }
        public virtual DbSet<TblServiceMachineSteps> TblServiceMachineSteps { get; set; }
        public virtual DbSet<TblMachinePlannedCost> TblMachinePlannedCost { get; set; }
        public virtual DbSet<TblServiceActualCost> TblServiceActualCost { get; set; }
        public virtual DbSet<TblServicePlannedCost> TblServicePlannedCost { get; set; }
        public virtual DbSet<TblServiceHour> TblServiceHour { get; set; }
        public virtual DbSet<TblStepMachineAssociation> TblStepMachineAssociation { get; set; }
        public virtual DbSet<TblMachineLimitsMaster> TblMachineLimitsMaster { get; set; }
        public virtual DbSet<TblMachineMediaMaster> TblMachineMediaMaster { get; set; }
        public virtual DbSet<TblMachineHazards> TblMachineHazards { get; set; }
        public virtual DbSet<TblHazardMedia> TblHazardMedia { get; set; }
        public virtual DbSet<TblServiceRoadmapAssociationTable> TblServiceRoadmapAssociationTable { get; set; }
        public virtual DbSet<TblAuditEntry> TblAuditEntry { get; set; }
        public virtual DbSet<TblIndustrySegments> TblIndustrySegments { get; set; }
        public virtual DbSet<TblMachineCustomerAssociation> TblMachineCustomerAssociation { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                string tid = string.Empty;
                var currentTenantId = httpContextAccessor.HttpContext.Items["CurrentTenantId"];
                if (currentTenantId != null)
                    tid = Convert.ToString(currentTenantId);
                else
                    tid = httpContextAccessor.HttpContext.User.GetTenantId();

                //var tenantInfo = "Server=tcp:dna-sql-westeurman-dev01.database.windows.net,1433;Initial Catalog=DNA-Blueprint-Q-DB;Persist Security Info=False;User ID=blueprintschqdbln;Password=YEqxU5kA3P4m;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;";
                //optionsBuilder.UseSqlServer(tenantInfo);

                var tenantInfo = tenantService.GetTenantInfo(tid);

                optionsBuilder.UseSqlServer(tenantInfo.Connectionstring);


                base.OnConfiguring(optionsBuilder);
            }
        }
    }
}
