﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Project.API.Models.ProjectDTOs
{
    public class BucketServiceMachineAssociationDTO
    {
        public string Id { get; set; }        
        public string Bucket_Id { get; set; }        
        public string Service_machine_Id { get; set; }

    }
}
