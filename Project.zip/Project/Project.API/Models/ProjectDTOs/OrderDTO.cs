﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Project.API.Models.ProjectDTOs
{
   public class OrderDTO
    {
        public string Id { get; set; }
        public string Erp_Order_Id { get; set; }
        public string Service_Id { get; set; }
        public string Status { get; set; }
        public OrderKpiDTO Order_Kpi { get; set; }
    }
}
