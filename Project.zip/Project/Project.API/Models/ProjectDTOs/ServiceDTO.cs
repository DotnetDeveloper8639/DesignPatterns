﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Project.API.Models.ProjectDTOs
{
    public class ServiceDTO
    {
        public string Id { get; set; }
        public string Erp_Wbs_Id { get; set; }
        public string Project_Id { get; set; }
        public string Offer_Id { get; set; }
        public string Order_Id { get; set; }
        public string Contact_Id { get; set; }
        public string Service_Type { get; set; }
        public string Service_Location { get; set; }
        public string Start_Date { get; set; }
        public string End_Date { get; set; }
        public int Actual_Hours { get; set; }
        public string Is_Active { get; set; }
        public string Service_Description { get; set; }
        public string Service_Region { get; set; }
        public DateTimeOffset Created_At { get; set; }
        public string Created_By { get; set; }
        public DateTimeOffset Modified_At { get; set; }
        public string Modified_By { get; set; }
    }
}
