﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Project.API.Models.ProjectDTOs
{
    public class MachineDTO
    {
        public string Machine_Id { get; set; }
        public string Global_Id { get; set; }
        public string Customer_Id { get; set; }
        public string Machine_Name { get; set; }
        public string Asset_Id { get; set; }
        public string Serial_Number { get; set; }
        public string Machine_Type { get; set; }
        public string Industry { get; set; }
        public string Is_RA_Status { get; set; }
        public int RA_Count { get; set; }
        public int? Image_Size { get; set; }
        public string Is_RA_External { get; set; }
        public bool IsActive { get; set; }
        public string MasterMachine_Id { get; set; }
        public ServiceMachineDTO ServiceMachine_Id { get; set; }
        public FourEyesQualityDTO FourEyeQualityDTO { get; set; }
        public string Machine_Description { get; set; }
        public decimal Estimated_Hours { get; set; }
        public MasterMachinesDTO MasterMachine { get; set; }
        public ProjectStaffDTO AssignedStaff { get; set; }
        public BucketDTO BucketName { get; set; }
        public decimal CalculatedHours { get; set; }
        public decimal AggregatedHours { get; set; }
        public DateTimeOffset Created_At { get; set; }
        public string Created_By { get; set; }
        public DateTimeOffset Modified_At { get; set; }
        public string Modified_By { get; set; }
    }

    public class LogActualHours
    {
        public int CalculatedHours { get; set; }
        public int AggregatedHours { get; set; }
    }
    public class MasterMachinesDTO
    {
        public string Machine_Master_Id { get; set; }
        public string Machine_Name { get; set; }
        public string Machine_Type { get; set; }
        public string Manufacturer { get; set; }
        public DateTimeOffset Created_At { get; set; }
        public string Created_By { get; set; }
        public DateTimeOffset Modified_At { get; set; }
        public string Modified_By { get; set; }
    }

    public class ServiceMachineDTO
    {
        public string ServiceMachineId { get; set; }
        public bool IsRequested { get; set; }
        public bool IsConflict { get; set; }
    }

    public class FourEyesQualityDTO
    {
        public bool IsFourEyeQuality { get; set; }
        public bool IsFourEyePerform { get; set; }
    }
    public class ProjectMachineDTO
    {
        public int? Image_Size { set; get; }
        public List<MachineDTO> Machines { get; set; }
    }
}
