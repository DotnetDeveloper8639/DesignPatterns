﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Project.API.Models.ProjectDTOs
{
    public class ServiceDetailDTO
    {
        public ProjectDTO Project { get; set; }
        public ServiceDTO Service { get; set; }
        public OrderDTO Order { get; set; }
    }
}
