﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Project.API.Models.ProjectDTOs
{
    public class MachineKpiDTO
    {
        public string Id { get; set; }
        public string ServiceMachine_Id { get; set; }
        public string PlannedCost { get; set; }
        public string ActualCost { get; set; }
        public string PlannedSales { get; set; }
        public string ActualSales { get; set; }
        public string CalculatedHours { get; set; }
        public string ActualAggregatedHours { get; set; }
    }
}
