﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Project.API.Models.ProjectDTOs
{
    public class ProjectDTO
    {
        public string Project_Id { get; set; }
        public string Encrypted_Project_Id { get; set; }
        public string Erp_Project_Id { get; set; }
        public string Project_Name { get; set; }
        public string Description { get; set; }
        public string Start_Date { get; set; }
        public string End_Date { get; set; }
        public string Status { get; set; }
        public string Parent_Company { get; set; }
        public string Controlling_Area_Code { get; set; }
        public string Region { get; set; }
        public string Customer_Id { get; set; }
        public string Comapny_Name { get; set; }
        public string Company_Code { get; set; }
        public string Customer_Name { get; set; }
        public string Erp_Customer_Id { get; set; }
        public string User_Name { get; set; }
        public string Machine_Number { get; set; }
        public string Account_Name { get; set; }
        public string Manager_Name { get; set; }
        public int Time { get; set; }
        public int Cost { get; set; }
        public int Revenue { get; set; }
        public string Project_Phase { get; set; }
        public string Notes { get; set; }
        public int EstimateHours { get; set; }
        public string OrderId { get; set; }
        public ProjectKpiDTO project_Kpi_Details { get; set; }
        public DateTimeOffset created_at { get; set; }
        public string created_by { get; set; }
        public DateTimeOffset modified_at { get; set; }
        public string modified_by { get; set; }
        public List<ProjectStaffDTO> AssignedStaff { get; set; }
        public CustomerDTO CustomerDetails { get; set; }
        public int TotalStepCount { get; set; }
        public int TotalAnswredStepCount { get; set; }
        public decimal Hours_Progress { get; set; }
        public decimal TotlalCalculatedHours { get; set; }
        public decimal TotalActualHours { get; set; }
        public decimal ProjectBudget { get; set; }
        public decimal ActualCost { get; set; }
        public string IndustrySegment { get; set; }
    }

    public class ProjectStaffDTO
    {
        public string First_Name { get; set; }
        public string Last_Name { get; set; }
        public string Display_Name { get; set; }
        public string Login_Name { get; set; }
        public string Email_Address { get; set; }
        public string User_Role { get; set; }
        public string StaffType { get; set; }
        public string UserSharePointId { get; set; }
    }

    public class ProjectDashboardDTO
    {
        public string Project_Id { get; set; }
        public string Encrypted_Project_Id { get; set; }
        public string Project_Name { get; set; }
        public string Customer_Name { get; set; }
        public string Erp_Customer_Id { get; set; }
        public string Customer_Id { get; set; }
        public string Contact_Name { get; set; }
        public string Company_Code { get; set; }
        public string Customer_Address { get; set; }
        public string Region { get; set; }
        public string Project_Manager { get; set; }
        public int Progress { get; set; }
        public int TotalStepCount { get; set; }
        public int TotalAnswredStepCount { get; set; }
        public decimal Hours_Progress { get; set; }
        public decimal TotlalCalculatedHours { get; set; }
        public decimal TotalActualHours{ get; set; }
        public decimal ProjectBudget { get; set; }
        public decimal ActualCost { get; set; }
        public string End_Date{ get; set; }
        public string Status { get; set; }
        public string Erp_Project_Id { get; set; }
        public int TotalServiceStepCount { get; set; }
        public int AnsweredServiceStepCount { get; set; }
    }

    public class CreateProjectDTO
    {
        [Required(ErrorMessage ="Please provide Project Name")]
        public string Project_Name { get; set; }
        [Required(ErrorMessage = "Please provide Description")]
        public string Description { get; set; }
        [Required(ErrorMessage = "Please provide Start Date")]
        public DateTime? Start_Date { get; set; }
        [Required(ErrorMessage = "Please provide End Date")]
        public DateTime? End_Date { get; set; }
        public string Status { get; set; }
        public string Controlling_Area_Code { get; set; }
        public string Customer_Id { get; set; }
        public string Company_Code { get; set; }
        public string Customer_Name { get; set; }
        public CustomerDTO CustomerDetails { get; set; }
    }

    public class OrderServiceDetailsDTO
    {
        public List<OrderDTO> Order_Details { get; set; }
        public List<ServiceDTO> Service_Details { get; set; }
    }

    public class CreateServiceMachineDTO
    {
        public string Project_Id { get; set; }
        public string Order_Id { get; set; }
        public string Service_Id { get; set; }
        public List<MachineDTO> Machines { get; set; }
    }
}
