﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Project.API.Models.ProjectDTOs
{
    public class CalculatedHourDTO
    {
        public decimal CalculatedHours { get; set; }
    }
    public class HoursProgressDTO
    {
        public decimal ActualHours { get; set; }
    }
    public class ProgressDTO
    {
        public int TotalSteps { get; set; }
        public int AnsweredSteps { get; set; }
    }
}
