﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Project.API.Models.ProjectDTOs
{
    public class OrderKpiDTO
    {
        public string Id { get; set; }
        public int Calculated_Hours { get; set; }
        public decimal Cost_Proress { get; set; }
        public int Hours_Progress { get; set; }
        public int Roadmap_Progress { get; set; }
    }
}
