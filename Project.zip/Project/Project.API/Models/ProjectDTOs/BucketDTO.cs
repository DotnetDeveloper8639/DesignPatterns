﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Project.API.Models.ProjectDTOs
{
    public class BucketDTO
    {
        public string Bucket_Id { get; set; }
        public string Bucket_Name { get; set; }
        //public string Project_Id { get; set; }
        //public string Order_Id { get; set; }
        //public string Service_Id { get; set; }
        //public string User_Id { get; set; }
        public string[] Machine_Id { get; set; }

    }
    public class CreateBucketDTO
    {
        public string Bucket_Id { get; set; }
        public string Bucket_Name { get; set; }
        public string Project_Id { get; set; }
        public string Order_Id { get; set; }
        public string Service_Id { get; set; }
        public string User_Id { get; set; }
        public List<string> Machine_Id { get; set; }
    }
    public class BucketDetailsDTO
    {
        public string Bucket_Id { get; set; }
        public string Bucket_Name { get; set; }
        public List<MachineDTO> machines { get; set; }       
    }
}
