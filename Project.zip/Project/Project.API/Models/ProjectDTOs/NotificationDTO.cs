﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Project.API.Models.ProjectDTOs
{
    public class NotificationDTO
    {
        public string NotificationId { get; set; }
        public string Notification_Type { get; set; }
        public string Notification_Cat { get; set; }
        public string User_Id { get; set; }
        public string Tenant_Id { get; set; }
        public string Created_By { get; set; }
        public DateTimeOffset Created_Dt { get; set; }
        public string Modified_By { get; set; }
        public DateTimeOffset Modified_Dt { get; set; }
    }

    public class NotificationMessage 
    {
       public string Message { get; set; }
    }
}
