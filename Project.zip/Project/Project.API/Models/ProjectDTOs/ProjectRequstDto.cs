﻿using EventBus.Abstractions;
using Project.API.IntegrationEvents.Events;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Project.API.Models.ProjectDTOs
{
    public class ProjectRequstDto
    {
        public RequestTechnicalHeader TechnicalHeader { get; set; }
        public ProjectRequestEvent ProjectRequestEvent { get; set; }

        public ProjectRequstDto(ProjectRequestEvent projectRequestEvent, RequestTechnicalHeader technicalHeader)
        {
            ProjectRequestEvent = projectRequestEvent;
            TechnicalHeader = technicalHeader;
        }
    }
}
