﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Project.API.Models.ProjectDTOs
{
    public class ProjectCostData
    {
        public string Project_Id { get; set; }
        public int TotalStepCount { get; set; }
        public int TotalAnswredStepCount { get; set; }
        public decimal Hours_Progress { get; set; }
        public decimal TotlalCalculatedHours { get; set; }
        public decimal TotalActualHours { get; set; }
        public decimal ProjectBudget { get; set; }
        public decimal ActualCost { get; set; }
    }
}
