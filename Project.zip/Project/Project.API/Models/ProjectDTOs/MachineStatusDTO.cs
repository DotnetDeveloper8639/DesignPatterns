﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Project.API.Models.ProjectDTOs
{
    public class MachineStatusDTO
    {
        public string ServiceMachine_Id { get; set; }
        public bool IsActive { get; set; }
    }
}
