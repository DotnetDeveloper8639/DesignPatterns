﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Project.API.Models.ProjectDTOs
{
    public class ProjectStaffUpsertDto
    {
        [Required(ErrorMessage = "Please provide Project Id")]
        [StringLength(80, ErrorMessage = "Project Id can't exceed the length of 80 characters")]
        public string project_id { get; set; }
        public List<UserDetails> user_ids { get; set; }
    }
    public class ProjectStaffDeleteDto
    {
        [Required(ErrorMessage = "Please provide Project Id")]
        [StringLength(80, ErrorMessage = "Project Id can't exceed the length of 80 characters")]
        public string project_id { get; set; }
        [Required(ErrorMessage = "Please provide User Id")]
        [StringLength(80, ErrorMessage = "User Id can't exceed the length of 80 characters")]
        public string user_id { get; set; }
    }
    public class UserDetails
    {
        [Required(ErrorMessage = "Please provide User Id")]
        [StringLength(80, ErrorMessage = "User Id can't exceed the length of 80 characters")]
        public string user_id { get; set; }
        public string UserSharePointId { get; set; }
    }
}
