﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Project.API.Models.ProjectDTOs
{
    public class AuditLogDTO
    {
        public string ProjectId { get; set; }
        public string Search { get; set; }
        public int Count { get; set; }
        public int IncreasedCount { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
    }
}
