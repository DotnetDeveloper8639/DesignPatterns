﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Project.API.Models.ProjectDTOs
{
    public class CompanyDTO
    {
        public string id { get; set; }
        public string company_name { get; set; }
        public string company_code { get; set; }
    }
}
