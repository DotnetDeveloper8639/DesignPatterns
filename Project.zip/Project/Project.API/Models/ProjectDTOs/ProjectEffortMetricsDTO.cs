﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Project.API.Models.ProjectDTOs
{
    public record ProjectEffortMetricsDTO
    {
        public int Data { get; set; }
        public string WeekCount { get; set; }
        public DateTime QuarterStartDate { get; set; }
        public DateTime QuarterEndDate { get; set; }
        public DateTime WeekStartDate { get; set; }
        public DateTime WeekEndDate { get; set; }
        public string DayOfWeek { get; set; }
        public DateTime Date { get; set; }
        public DateTimeOffset HourStart { get; set; }
        public DateTimeOffset HourEnd { get; set; }
        public int Hours { get; set; }
    }
}
