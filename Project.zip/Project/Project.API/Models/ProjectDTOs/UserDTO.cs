﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Project.API.Models.ProjectDTOs
{
    public class UserDTO
    {
        public string Id { get; set; }
        public string First_Name { get; set; }
        public string Last_Name { get; set; }
        public string Display_Name { get; set; }
        public string Login_Name { get; set; }
        public string Email_Address { get; set; }
    }
}
