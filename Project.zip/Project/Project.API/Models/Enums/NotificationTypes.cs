﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Threading.Tasks;

namespace Project.API.Enums
{
    public enum NotificationTypes
    {
        [EnumMember(Value = "Request Project Access")]
        RequestProjectAccess,
        [EnumMember(Value = "Project Access Granted")]
        ProjectAccessGranted,
        [EnumMember(Value = "Project Access Revoked")]
        ProjectAccessRevoked,
        [EnumMember(Value = "Project Created")]
        ProjectCreated,
        [EnumMember(Value = "Project Deleted")]
        ProjectDeleted,
        [EnumMember(Value = "Staffed to a Project")]
        StaffedtoaProject,
        [EnumMember(Value = "Staffed to a Group")]
        StaffedtoaGroup,
        [EnumMember(Value = "Assigned to a Role")]
        AssignedtoaRole,
        [EnumMember(Value = "Machine Added")]
        MachineAdded
    }
}
