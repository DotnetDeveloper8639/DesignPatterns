using EventBus;
using EventBus.Abstractions;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Identity.Web;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json.Serialization;
using Project.API.DbContextClass;
using Project.API.Extensions;
using Project.API.Services;
using System;
using System.Security.Claims;
using System.Text;
using System.Web.Http;
using Tenant.Service;

namespace Project.API
{
    public class Startup
    {
        readonly string corsPolicy = "CORSPolicy";
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            //services.Configure<EventBusConfiguration>(Configuration.GetSection("ServiceBusConnection"));
            services.AddControllers();
            services.AddResponseCaching();
            services.AddScoped<IEventBus, DaprEventBus>();
            services.AddTransient<ProjectApiRatelimitMiddleware>();
            services.AddDaprClient(config => 
            config.UseJsonSerializationOptions(new System.Text.Json.JsonSerializerOptions() 
            {
                PropertyNamingPolicy = null,
            }));
            services.AddIntegrationServices();
            services.AddTransient<IProjectServices, ProjectServices>();
            services.AddTransient<IBucketService, BucketService>();
            //services.AddSingleton<IMessageBus, AzureServiceBusMessageBus>();
            services.AddDataProtection();

            services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme).AddJwtBearer(options =>
            {
                options.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidateLifetime = true,
                    ValidateIssuerSigningKey = true,
                    ValidIssuer = Environment.GetEnvironmentVariable("TOKEN_SERVER"),
                    ValidAudience = "blueprint-api",
                    IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(Environment.GetEnvironmentVariable("JWT_KEY")))
                };
            });

            // adds an authorization policy to make sure the token is for scope 'api1'
            services.AddAuthorization(options =>
            {
                options.AddPolicy("ApiScope", policy =>
                {
                    policy.RequireAuthenticatedUser();
                    policy.RequireClaim(ClaimTypes.Role);
                    policy.RequireClaim(ClaimConstants.TenantId);
                });
            });

            services.AddSwaggerGen(options =>
            {
                options.SwaggerDoc("v2", new Microsoft.OpenApi.Models.OpenApiInfo
                {
                    Title = "Project Service API",
                });
            });

            //services.AddDbContext<Sch_Context>(options =>
            //options.UseSqlServer(Configuration.GetConnectionString("AzureConnection")));
            services.AddDbContext<Sch_Context>(ServiceLifetime.Scoped);

            services.AddHttpContextAccessor();
            services.RegisterTenantService(Configuration);

            services.AddCors(options =>
            {
                options.AddPolicy(name: corsPolicy,
                                  builder =>
                                  {
                                      builder.AllowAnyOrigin()
                        .AllowAnyMethod()
                        .AllowAnyHeader();
                                  });
            });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            app.UseResponseCaching();
            app.UseCors(corsPolicy);
            app.UseRouting();

            app.UseSwagger(options =>
            {
                options.RouteTemplate = "project/swagger/{documentName}/swagger.json";
            });

            app.UseSwaggerUI(options =>
            {
                options.SwaggerEndpoint("/project/swagger/v2/swagger.json", "Project Service API");
                options.RoutePrefix = "project/swagger";
            });

            app.UseAuthentication();
            app.UseAuthorization();
            app.UseMiddleware<ProjectApiRatelimitMiddleware>(100, TimeSpan.FromMinutes(1));
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });

        }
    }
}
