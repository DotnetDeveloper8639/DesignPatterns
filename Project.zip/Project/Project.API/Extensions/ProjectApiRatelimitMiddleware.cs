﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Caching.Memory;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Project.API.Extensions
{
    public class ProjectApiRatelimitMiddleware
    {
        private readonly RequestDelegate _next;
        private readonly IMemoryCache _cache;
        private readonly int _limit;
        private readonly TimeSpan _period;

        public ProjectApiRatelimitMiddleware()
        {

        }
        public ProjectApiRatelimitMiddleware(RequestDelegate next, IMemoryCache cache, int limit, TimeSpan period)
        {
            _next = next;
            _cache = cache;
            _limit = limit;
            _period = period;
        }

        public async Task Invoke(HttpContext httpContext)
        {
            var ipAddress = httpContext?.Connection?.RemoteIpAddress?.ToString();
            var cacheKey = $"{ipAddress}:{DateTime.UtcNow:yyyyMMddHHmm}";
            var requestCount = _cache.GetOrCreate(cacheKey, entry =>
            {
                entry.AbsoluteExpirationRelativeToNow = _period;
                return 0;
            });
            if (requestCount >= _limit)
            {
                //Too many Requests
                httpContext.Response.StatusCode = 429;
                await httpContext.Response.WriteAsync("Rate limit exceeded");
                return;
            }

            _cache.Set(cacheKey, requestCount + 1, _period);
            await _next(httpContext);
        }


    }
}
