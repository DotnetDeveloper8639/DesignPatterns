﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Project.API.Extensions
{
    public static class DateTimeConvertion
    {
        public static string UtcTimeConvert(DateTime? dateTime)
        {
            var date = dateTime.Value.ToUniversalTime();
            return date.ToString();
        }
    }
}
