﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Project.API.Extensions
{
    internal static class IntegrationsServices
    {
        public static IServiceCollection AddIntegrationServices(this IServiceCollection services)
        {
            //var eventBusConfiguration = services.BuildServiceProvider().GetRequiredService<IOptions<EventBusConfiguration>>().Value;
            //services.AddSingleton<EventBusConfiguration>(eventBusConfiguration);
            //services.AddSingleton<IEventBusSubscriptionsManager, InMemoryEventBusSubscriptionsManager>();

            //services.AddSingleton(implementationFactory =>
            //{
            //    //Connection string value in app settings has to be properly added (for either queue or topic with subscriptions):
            //    var serviceBusClient = new ServiceBusClient(eventBusConfiguration.SendConnectionString);
            //    return serviceBusClient;
            //});

            //services.AddSingleton(implementationFactory =>
            //{
            //    var serviceBusClient = implementationFactory.GetRequiredService<ServiceBusClient>();

            //    // Creates sender for specific topic:
            //    var serviceBusSender = serviceBusClient.CreateSender(eventBusConfiguration.TopicName);

            //    var serviceBusSenderContact = serviceBusClient.CreateSender(eventBusConfiguration.ContactTopic);


            //    return serviceBusSender;
            //});

            //services.AddSingleton(implementationFactory =>
            //{
            //    //Connection string value in app settings has to be properly added:
            //    var serviceBusAdministrationClient = new ServiceBusAdministrationClient(eventBusConfiguration
            //                                                                            .SendConnectionString);
            //    return serviceBusAdministrationClient;
            //});

            //services.AddSingleton(implementationFactory =>
            //{
            //    var serviceBusClient = implementationFactory.GetRequiredService<ServiceBusClient>();

            //    //Creates receiver for specific topic:
            //    var serviceBusReceiver = serviceBusClient.CreateProcessor(eventBusConfiguration.TopicName,
            //                                                             eventBusConfiguration.Subscription,
            //                                                             new ServiceBusProcessorOptions
            //                                                             {
            //                                                                 AutoCompleteMessages = false
            //                                                             });
            //    return serviceBusReceiver;
            //});

            //services.AddSingleton<IEventBus, AzureServiceBusEvent>();

            //return services;
            return null;
        }
    }
}
