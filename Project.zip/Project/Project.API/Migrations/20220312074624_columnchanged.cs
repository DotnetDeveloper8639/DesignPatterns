﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Project.API.Migrations
{
    public partial class columnchanged : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "bucket_id",
                table: "tblServiceMachine",
                type: "varchar(50)",
                nullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "description",
                table: "tblProject",
                type: "nvarchar(1000)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(160)",
                oldNullable: true);

            migrationBuilder.CreateTable(
                name: "tblBucket",
                columns: table => new
                {
                    id = table.Column<string>(type: "varchar(50)", nullable: false),
                    bucket_name = table.Column<string>(type: "varchar(250)", nullable: true),
                    project_id = table.Column<string>(type: "varchar(50)", nullable: true),
                    order_id = table.Column<string>(type: "varchar(50)", nullable: true),
                    service_id = table.Column<string>(type: "varchar(50)", nullable: true),
                    machine_id = table.Column<string>(type: "varchar(50)", nullable: true),
                    user_id = table.Column<string>(type: "varchar(50)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblBucket", x => x.id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "tblBucket");

            migrationBuilder.DropColumn(
                name: "bucket_id",
                table: "tblServiceMachine");

            migrationBuilder.AlterColumn<string>(
                name: "description",
                table: "tblProject",
                type: "nvarchar(160)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(1000)",
                oldNullable: true);
        }
    }
}
