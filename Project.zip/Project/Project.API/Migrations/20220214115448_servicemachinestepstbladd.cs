﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Project.API.Migrations
{
    public partial class servicemachinestepstbladd : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
