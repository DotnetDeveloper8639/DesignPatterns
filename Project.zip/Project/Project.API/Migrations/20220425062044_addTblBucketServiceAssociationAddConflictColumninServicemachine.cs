﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Project.API.Migrations
{
    public partial class addTblBucketServiceAssociationAddConflictColumninServicemachine : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

            migrationBuilder.AddColumn<bool>(
                name: "isconflict",
                table: "tblServiceMachine",
                type: "bit",
                nullable: false,
                defaultValue: false);

           

            migrationBuilder.CreateTable(
                name: "tblBucketServiceMachineAssociation",
                columns: table => new
                {
                    id = table.Column<string>(type: "varchar(50)", nullable: false),
                    bucket_id = table.Column<string>(type: "varchar(50)", nullable: true),
                    service_machine_id = table.Column<string>(type: "varchar(50)", nullable: true),
                    created_at = table.Column<DateTimeOffset>(type: "datetimeoffset(7)", nullable: false),
                    created_by = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    modified_at = table.Column<DateTimeOffset>(type: "datetimeoffset(7)", nullable: false),
                    modified_by = table.Column<string>(type: "nvarchar(50)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblBucketServiceMachineAssociation", x => x.id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "tblBucketServiceMachineAssociation");

            migrationBuilder.DropColumn(
                name: "isconflict",
                table: "tblServiceMachine");

            migrationBuilder.DropColumn(
                name: "created_at",
                table: "tblBucket");

            migrationBuilder.DropColumn(
                name: "created_by",
                table: "tblBucket");

            migrationBuilder.DropColumn(
                name: "modified_at",
                table: "tblBucket");

            migrationBuilder.DropColumn(
                name: "modified_by",
                table: "tblBucket");

            migrationBuilder.AlterColumn<string>(
                name: "sistema_report_url",
                table: "tblServiceMachine",
                type: "nvarchar(255)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(50)",
                oldNullable: true);
        }
    }
}
