﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Project.API.Migrations
{
    public partial class bucketidremoved : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

            migrationBuilder.AddForeignKey(
                name: "FK_tblServiceMachine_tblMachine_machine_id",
                table: "tblServiceMachine",
                column: "machine_id",
                principalTable: "tblMachine",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_tblServiceMachine_tblService_service_id",
                table: "tblServiceMachine",
                column: "service_id",
                principalTable: "tblService",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_tblServiceMachine_tblMachine_machine_id",
                table: "tblServiceMachine");

            migrationBuilder.DropForeignKey(
                name: "FK_tblServiceMachine_tblService_service_id",
                table: "tblServiceMachine");

            migrationBuilder.DropPrimaryKey(
                name: "PK_tblServiceMachine",
                table: "tblServiceMachine");

            migrationBuilder.DropIndex(
                name: "IX_tblServiceMachine_machine_id",
                table: "tblServiceMachine");

            migrationBuilder.DropIndex(
                name: "IX_tblServiceMachine_service_id",
                table: "tblServiceMachine");

            migrationBuilder.DropColumn(
                name: "id",
                table: "tblServiceMachine");

            migrationBuilder.DropColumn(
                name: "created_at",
                table: "tblServiceMachine");

            migrationBuilder.DropColumn(
                name: "created_by",
                table: "tblServiceMachine");

            migrationBuilder.DropColumn(
                name: "modified_at",
                table: "tblServiceMachine");

            migrationBuilder.DropColumn(
                name: "modified_by",
                table: "tblServiceMachine");

            migrationBuilder.DropColumn(
                name: "sistema_report_associated",
                table: "tblServiceMachine");

            migrationBuilder.DropColumn(
                name: "sistema_report_url",
                table: "tblServiceMachine");

            migrationBuilder.RenameTable(
                name: "tblServiceMachine",
                newName: "TblServiceMachine");

            migrationBuilder.AlterColumn<string>(
                name: "service_id",
                table: "TblServiceMachine",
                type: "nvarchar(50)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "varchar(50)",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "machine_id",
                table: "TblServiceMachine",
                type: "nvarchar(80)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "varchar(80)",
                oldNullable: true);

            migrationBuilder.CreateTable(
                name: "tblServiceMachine",
                columns: table => new
                {
                    id = table.Column<string>(type: "varchar(50)", nullable: false),
                    bucket_id = table.Column<string>(type: "varchar(50)", nullable: true),
                    created_at = table.Column<DateTimeOffset>(type: "datetimeoffset(7)", nullable: false),
                    created_by = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    machine_id = table.Column<string>(type: "varchar(80)", nullable: true),
                    modified_at = table.Column<DateTimeOffset>(type: "datetimeoffset(7)", nullable: false),
                    modified_by = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    service_id = table.Column<string>(type: "varchar(50)", nullable: true),
                    sistema_report_associated = table.Column<bool>(type: "bit", nullable: false),
                    sistema_report_url = table.Column<string>(type: "nvarchar(255)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblServiceMachine", x => x.id);
                });

            migrationBuilder.CreateIndex(
                name: "IX_tblServiceMachine_machine_id",
                table: "tblServiceMachine",
                column: "machine_id");

            migrationBuilder.CreateIndex(
                name: "IX_tblServiceMachine_service_id",
                table: "tblServiceMachine",
                column: "service_id");

            migrationBuilder.AddForeignKey(
                name: "FK_TblServiceMachine_tblMachine_machine_id",
                table: "TblServiceMachine",
                column: "machine_id",
                principalTable: "tblMachine",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_TblServiceMachine_tblService_service_id",
                table: "TblServiceMachine",
                column: "service_id",
                principalTable: "tblService",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
