﻿using AutoMapper;
using Bucket.API.EntityModels;
using Bucket.API.Models;
using System.Collections.Generic;

namespace Bucket.API
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<BucketDto, TblBucket>()
                .ForMember(dest => dest.bucket_name, source => source.MapFrom(prop => prop.Bucket_Name))
                .ForMember(dest => dest.id, source => source.MapFrom(prop => prop.Bucket_Id))
                .ForMember(dest => dest.order_id, source => source.MapFrom(prop => prop.Order_Id))
                .ForMember(dest => dest.project_id, source => source.MapFrom(prop => prop.Project_Id))
                .ForMember(dest => dest.service_id, source => source.MapFrom(prop => prop.Service_Id))
                .ReverseMap();

            CreateMap<MachineDTO, TblMachine>()
                .ForMember(dest => dest.asset_id, source => source.MapFrom(prop => prop.asset_Id))
                .ForMember(dest => dest.id, source => source.MapFrom(prop => prop.machine_Id))
                .ForMember(dest => dest.machine_description, source => source.MapFrom(prop => prop.machine_Description))
                .ForMember(dest => dest.machine_name, source => source.MapFrom(prop => prop.machine_Name))
                .ForMember(dest => dest.serial_number, source => source.MapFrom(prop => prop.serial_Number))
                .ReverseMap();

        }
    }
}
