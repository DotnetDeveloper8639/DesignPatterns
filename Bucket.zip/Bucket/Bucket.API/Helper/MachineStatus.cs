﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Bucket.API.Helper
{
    public static class MachineStatus
    {
        public const string NOT_CONFIGURED = "Roadmap NC";
        public const string NOT_STARTED = "Not Started";
        public const string IN_PROGRESS = "In Progress";
        public const string COMPLETED = "Completed";
    }
}
