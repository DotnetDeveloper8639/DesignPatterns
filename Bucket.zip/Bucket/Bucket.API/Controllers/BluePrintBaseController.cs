﻿using Bucket.API.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Threading.Tasks;

namespace Bucket.API.Controllers
{
    [Authorize(Policy = "ApiScope")]
    [ApiController]
    public abstract class BluePrintBaseController : ControllerBase
    {
        public async Task<IActionResult> FormatOutput<T>(Task<ApiResponse<T>> result)
        {
            var output = await result;
            return new ContentResult()
            {
                StatusCode = output.StatusCode,
                Content = JsonConvert.SerializeObject(output),
                ContentType = "application/json"
            };
        }
    }
}
