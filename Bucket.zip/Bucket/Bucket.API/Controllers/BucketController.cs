﻿using Bucket.API.Models;
using Bucket.API.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Bucket.API.Controllers
{
    [Route("/api/bucketsvc")]
    //[ApiController]
    public class BucketController : BluePrintBaseController
    {
        private readonly IBucketService bucketService;

        public BucketController(IBucketService bucketService)
        {
            this.bucketService = bucketService;
        }

        [HttpGet]
        [Authorize(Roles = "Project.Edit,Project.Write, Project.Read")]
        [Route("Bucket/{id}")]
        public async Task<IActionResult> GetBucketById(string id)
        {
            return await FormatOutput(bucketService.GetAllBucketByService(id));
        }

        [HttpGet]
        [Authorize(Roles = "Project.Edit,Project.Write, Project.Read")]
        [Route("{serviceId}/Buckets")]
        public async Task<IActionResult> GetBucketByServiceId(string serviceId)
        {
            return await FormatOutput(bucketService.GetAllBucketByService(serviceId));
        }

        [Route("Buckets")]
        [Authorize(Roles = "Project.Edit,Project.Write, Project.Read")]
        [HttpGet]
        public async Task<IActionResult> GetAllBuckets()
        {
            return await FormatOutput(bucketService.GetAllBucketsAsync());
        }

        
        [Route("Bucket")]
        [Authorize(Roles = "Project.Edit,Project.Write, Project.Read")]
        [HttpPost]
        public async Task<IActionResult> CreateBucket([FromBody] BucketDto bucket)
        {
            return await FormatOutput(bucketService.CreateBucketAsync(bucket));
        }

        [Route("Bucket")]
        [Authorize(Roles = "Project.Edit,Project.Write, Project.Read")]
        [HttpPut]
        public async Task<IActionResult> UpdateBucket([FromBody] BucketDto bucket)
        {
            return await FormatOutput(bucketService.UpdateBucketAsync(bucket));
        }

        [Route("Bucket/{id}")]
        [Authorize(Roles = "Project.Edit,Project.Write, Project.Read")]
        [HttpDelete]
        public async Task<IActionResult> DeleteBucket(string id)
        {
            return await FormatOutput(bucketService.DeleteBucketAsync(id));
        }

        [Route("Buckets/Update")]
        [Authorize(Roles = "Project.Edit,Project.Write, Project.Read")]
        [HttpPost]
        public async Task<IActionResult> UpdateBuckets([FromBody] List<BucketDto> buckets)
        {
            return await FormatOutput(bucketService.UpdateBucketsAsync(buckets));
        }

        [Route("Buckets/Delete")]
        [Authorize(Roles = "Project.Edit,Project.Write, Project.Read")]
        [HttpPost]
        public async Task<IActionResult> DeleteBuckets(List<string> ids)
        {
            return await FormatOutput(bucketService.DeleteBucketsAsync(ids));
        }
    }
}
