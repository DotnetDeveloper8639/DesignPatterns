﻿namespace Bucket.API.Controllers
{
    using Bucket.API.Models;
    using Bucket.API.Services;
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Mvc;
    using System.Threading.Tasks;

    [Route("/api/bucketmachinesvc")]
    public class BucketMachineAssociationController : BluePrintBaseController
    {
        private readonly IBucketMachineAssociationService bucketMachineAssociationService;

        public BucketMachineAssociationController(IBucketMachineAssociationService bucketMachineAssociationService)
        {
            this.bucketMachineAssociationService = bucketMachineAssociationService;
        }

        [HttpGet]
        //[Authorize(Roles = "Bucket.Get,Bucket.Manage")]
        [Route("{id}/Machines")]
        public async Task<IActionResult> GetMachinesByBucketId(string id)
        {
            return await FormatOutput(bucketMachineAssociationService.GetMachinesByBucketId(id));
        }

        [Route("Machine/Add")]
        [HttpPost]
        public async Task<IActionResult> AddMachinesToBucket([FromBody] BucketServiceMachineAssociationDto serviceMachineAssociationDto)
        {
            return await FormatOutput(bucketMachineAssociationService.AddMachinesToBucketAsync(serviceMachineAssociationDto));
        }

        [Route("{id}/Machine")]
        [HttpDelete]
        public async Task<IActionResult> RemoveMachinesFromBucket(string id)
        {
            return await FormatOutput(bucketMachineAssociationService.RemoveMachinesFromBucketAsync(id));
        }
        [Route("{bucketId}/{machineId}/Machine")]
        [HttpDelete]
        public async Task<IActionResult> RemoveMachineFromBucket(string bucketId, string machineId)
        {
            return await FormatOutput(bucketMachineAssociationService.RemoveMachineFromBucketAsync(bucketId, machineId));
        }
    }
}
