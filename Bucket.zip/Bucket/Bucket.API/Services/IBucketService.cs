﻿using Bucket.API.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Bucket.API.Services
{
    public interface IBucketService
    {
        Task<ApiResponse<bool>> CreateBucketAsync(BucketDto bucketDto);
        Task<ApiResponse<bool>> DeleteBucketAsync(string bucketId);
        Task<ApiResponse<bool>> UpdateBucketAsync(BucketDto bucketDto);
        Task<ApiResponse<List<BucketDto>>> GetAllBucketsAsync();
        Task<ApiResponse<List<BucketDto>>> GetAllBucketByService(string serviceId);
        Task<ApiResponse<Dictionary<string, bool>>> DeleteBucketsAsync(List<string> bucketIds);
        Task<ApiResponse<Dictionary<string, string>>> UpdateBucketsAsync(List<BucketDto> bucketDto);
    }
}
