﻿using AutoMapper;
using Bucket.API.DbContextClass;
using Bucket.API.EntityModels;
using Bucket.API.Helper;
using Bucket.API.Models;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace Bucket.API.Services
{
    public class BucketMachineAssociationService : IBucketMachineAssociationService
    {
        private readonly BucketDbContext _dbContext;
        private readonly IMapper _mapper;
        private readonly IHttpContextAccessor httpContextAccessor;

        //private readonly IRole
        public BucketMachineAssociationService(BucketDbContext dbContext
            , IMapper mapper
            , IHttpContextAccessor httpContextAccessor)
        {
            this._dbContext = dbContext;
            this._mapper = mapper;
            this.httpContextAccessor = httpContextAccessor;
        }

        public async Task<ApiResponse<bool>> AddMachinesToBucketAsync(BucketServiceMachineAssociationDto bucketServiceMachineAssociationDto)
        {
            bool isEntityAdded = false;
            var apiResponse = new ApiResponse<bool>();
            try
            {

                var entityList = new List<TblBucketServiceMachineAssociation>();

                
                var existingEntity = _dbContext.TblBucketServiceMachineAssociations
                    .Where(bma => bma.bucket_id == bucketServiceMachineAssociationDto.BucketId).Select(bma => bma.service_machine_id)
                    .ToList();

                var machinesToAdd = bucketServiceMachineAssociationDto.MachineIds.Except(existingEntity).ToList();
                machinesToAdd?.ForEach(machine =>
                {
                    var serviceMachine = _dbContext.TblServiceMachines.Where(m => m.machine_id == machine).FirstOrDefault()?.id ?? String.Empty;
                    entityList.Add(new TblBucketServiceMachineAssociation()
                    {
                        id = Guid.NewGuid().ToString(),
                        bucket_id = bucketServiceMachineAssociationDto.BucketId,
                        service_machine_id = serviceMachine,
                        created_at = DateTime.UtcNow,
                        created_by = httpContextAccessor.HttpContext.User.Claims.FirstOrDefault(c => c.Type == "Id")?.Value ?? String.Empty,
                        modified_at = DateTime.UtcNow
                    });
                });

                await _dbContext.TblBucketServiceMachineAssociations.AddRangeAsync(entityList);

                _dbContext.SaveChanges();
                isEntityAdded = true;

                apiResponse.StatusCode = (int)HttpStatusCode.OK;
                apiResponse.StatusReason = "Machines(s) added to bucket successfully.";
            }
            catch (Exception ex)
            {
                apiResponse.StatusCode = (int)HttpStatusCode.InternalServerError;
                apiResponse.StatusReason = ex.Message;
            }

            apiResponse.Data = isEntityAdded;

            return apiResponse;
        }

        public async Task<ApiResponse<BucketServiceMachineDetailsDto>> GetMachinesByBucketId(string bucketId)
        {
            var bucketMachine = new BucketServiceMachineDetailsDto();
            var apiResponse = new ApiResponse<BucketServiceMachineDetailsDto>();
            var bucketFromDb = _dbContext.TblBuckets.FirstOrDefault(b => b.id == bucketId);

            if (bucketFromDb is not null)
            {
                var machineIdsFromDb = (from machine in _dbContext.TblMachines
                                        join sm in _dbContext.TblServiceMachines on machine.id equals sm.machine_id
                                        join bma in _dbContext.TblBucketServiceMachineAssociations on sm.id equals bma.service_machine_id
                                        join bucket in _dbContext.TblBuckets on bma.bucket_id equals bucket.id
                                        let rmList = _dbContext.TblMachineRoadmap.Where(s => s.service_machine_id == sm.id).ToList()
                                        let machineTotalSteps = (from sermachine in _dbContext.TblServiceMachines
                                                                 join mr in _dbContext.TblMachineRoadmap on sermachine.id equals mr.service_machine_id into mr1
                                                                 from mr2 in mr1.DefaultIfEmpty()
                                                                 join rms in _dbContext.TblRoadmapMaster on mr2.roadmap_id equals rms.roadmap_id
                                                                 join section in _dbContext.TblRoadmapSection on rms.roadmap_id equals section.roadmap_id
                                                                 join subsection in _dbContext.TblRoadmapSubSectionMster on section.id equals subsection.section_id
                                                                 join step in _dbContext.TblStepMaster on subsection.id equals step.roadmap_section_id
                                                                 join stepAssoci in _dbContext.TblStepMachineAssociation on new { a1 = step.step_id, a2 = sm.id } equals new { a1 = stepAssoci.step_id, a2 = stepAssoci.servicemachine_id }
                                                                 where sermachine.id == sm.id
                                                                 select new { }).Count()
                                        let machineAnsweredSteps = (from sermachine in _dbContext.TblServiceMachines.Where(s => s.id == sm.id)
                                                                    join mr in _dbContext.TblMachineRoadmap on sermachine.id equals mr.service_machine_id into mr1
                                                                    from mr2 in mr1.DefaultIfEmpty()
                                                                    join rms in _dbContext.TblRoadmapMaster on mr2.roadmap_id equals rms.roadmap_id
                                                                    join section in _dbContext.TblRoadmapSection on rms.roadmap_id equals section.roadmap_id
                                                                    join subsection in _dbContext.TblRoadmapSubSectionMster on section.id equals subsection.section_id
                                                                    join step in _dbContext.TblStepMaster on subsection.id equals step.roadmap_section_id
                                                                    join stepAssoci in _dbContext.TblStepMachineAssociation on new { a1 = step.step_id, a2 = sm.id } equals new { a1 = stepAssoci.step_id, a2 = stepAssoci.servicemachine_id }
                                                                    join smsteps in _dbContext.TblServiceMachineSteps on new { a1 = step.step_id, a2 = sermachine.id, a3 = "82890382-9041-4988-bed7-9e66c6b97b13" } equals new { a1 = smsteps.step_id, a2 = smsteps.servicemachine_id, a3 = smsteps.user_id }
                                                                    where sermachine.id == sm.id
                                                                    select new { }).Count()
                                        where bma.bucket_id == bucketId
                                        select new MachineDTO
                                        {
                                            asset_Id = machine.asset_id,
                                            machine_Description = machine.machine_description,
                                            machine_Name = machine.machine_name,
                                            serial_Number = machine.serial_number,
                                            machine_Id = machine.id,
                                            isActive = sm.isactive,
                                            is_RA_External = _dbContext.TblService.Where(s =>s.id == sm.service_id).FirstOrDefault().is_ra_external??null,
                                            is_RA_Status = rmList.Where(s => s.roadmap_status.ToLower() != MachineStatus.COMPLETED.ToLower()).ToList().Count == 0 && machineTotalSteps != 0 && machineTotalSteps == machineAnsweredSteps ? MachineStatus.COMPLETED :
                                                           machineAnsweredSteps != 0 ? MachineStatus.IN_PROGRESS :
                                                           rmList.Count != 0 && rmList.Where(s => s.roadmap_status.ToLower() != MachineStatus.COMPLETED.ToLower()).ToList().Count != 0 ? MachineStatus.NOT_STARTED :
                                                           rmList.Count == 0 ? MachineStatus.NOT_CONFIGURED : MachineStatus.NOT_STARTED,
                                            serviceMachine_Id = new ServiceMachineDTO
                                            {
                                                serviceMachineId = sm.id,
                                                isConflict = sm.isconflict,
                                                isRequested = sm.isrequested
                                            },
                                            fourEyeQualityDTO = _dbContext.TblMachineFourEyesQualityAssociation.Where(fe => fe.servicemachine_id == sm.id).Select(fe => new FourEyesQualityDTO
                                            {
                                                isFourEyeQuality = fe.isComplete,
                                                IsFourEyePerform = fe.user_id == GetCurrentUserId()
                                            }).FirstOrDefault(),
                                            calculatedHours = _dbContext.TblMachineHour.Where(c => c.service_machine_id == sm.id).FirstOrDefault() != null ? _dbContext.TblMachineHour.Where(c => c.service_machine_id == sm.id).FirstOrDefault().calculated_hours : 0m,
                                            aggregatedHours = _dbContext.TblMachineKPI.Where(m => m.service_machine_id == sm.id).FirstOrDefault() != null ? _dbContext.TblMachineKPI.Where(m => m.service_machine_id == sm.id).FirstOrDefault().actualaggregatedhours : 0m,
                                        }).ToList();

                bucketMachine.Machines = machineIdsFromDb;
                bucketMachine.Bucket_Id = bucketId;
                bucketMachine.Bucket_Name = bucketFromDb.bucket_name;

                apiResponse.StatusCode = (int)HttpStatusCode.OK;
                apiResponse.StatusReason = "";
            }
            else
            {
                apiResponse.StatusCode = (int)HttpStatusCode.NotFound;
                apiResponse.StatusReason = "Bucket does not exists.";
            }

            apiResponse.Data = bucketMachine;
            return apiResponse;
        }

        public async Task<ApiResponse<bool>> RemoveMachineFromBucketAsync(string bucketId, string machineId)
        {
            bool isEntityRemoved = false;
            var apiResponse = new ApiResponse<bool>();
            try
            {
                var entityToDelete = _dbContext.TblBucketServiceMachineAssociations
                    .FirstOrDefault(bma => bma.bucket_id == bucketId && bma.service_machine_id == machineId);
                if (entityToDelete != null)
                {
                    _dbContext.TblBucketServiceMachineAssociations.Remove(entityToDelete);
                    _dbContext.SaveChanges();

                    isEntityRemoved = true;

                    apiResponse.StatusCode = (int)HttpStatusCode.OK;
                    apiResponse.StatusReason = "Machine deleted from bucket successfully.";
                }
                else
                {
                    apiResponse.StatusCode = (int)HttpStatusCode.NotFound;
                    apiResponse.StatusReason = "Machine does not exists is the given bucket.";
                }
            }
            catch (Exception ex)
            {
                apiResponse.StatusCode = (int)HttpStatusCode.InternalServerError;
                apiResponse.StatusReason = ex.Message;
            }

            apiResponse.Data = isEntityRemoved;
            return apiResponse;
        }

        public async Task<ApiResponse<bool>> RemoveMachinesFromBucketAsync(string bucketId)
        {
            bool isEntityRemoved = false;
            var apiResponse = new ApiResponse<bool>();
            try
            {
                var entityToDelete = _dbContext.TblBucketServiceMachineAssociations
                    .Where(bma => bma.bucket_id == bucketId).ToList();
                if (entityToDelete != null)
                {
                    _dbContext.TblBucketServiceMachineAssociations.RemoveRange(entityToDelete);
                    _dbContext.SaveChanges();

                    isEntityRemoved = true;

                    apiResponse.StatusCode = (int)HttpStatusCode.OK;
                    apiResponse.StatusReason = "All Machine(s) deleted from bucket successfully.";
                }
                else
                {
                    apiResponse.StatusCode = (int)HttpStatusCode.NotFound;
                    apiResponse.StatusReason = "All Machine(s) does not exists is the given bucket.";
                }
            }
            catch (Exception ex)
            {
                apiResponse.StatusCode = (int)HttpStatusCode.InternalServerError;
                apiResponse.StatusReason = ex.Message;
            }

            apiResponse.Data = isEntityRemoved;
            return apiResponse;
        }
        private string GetCurrentUserId() => httpContextAccessor.HttpContext.User.Claims.FirstOrDefault(c => c.Type == "Id")?.Value ?? String.Empty;
    }
}
