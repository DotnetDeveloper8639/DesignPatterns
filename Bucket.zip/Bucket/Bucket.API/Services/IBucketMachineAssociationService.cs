﻿using Bucket.API.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Bucket.API.Services
{
    public interface IBucketMachineAssociationService
    {
        Task<ApiResponse<bool>> AddMachinesToBucketAsync(BucketServiceMachineAssociationDto bucketServiceMachineAssociationDto);
        Task<ApiResponse<bool>> RemoveMachinesFromBucketAsync(string bucketId);
        Task<ApiResponse<bool>> RemoveMachineFromBucketAsync(string bucketId,string machineId);
        Task<ApiResponse<BucketServiceMachineDetailsDto>> GetMachinesByBucketId(string bucketId);
    }
}
