﻿using AutoMapper;
using Bucket.API.DbContextClass;
using Bucket.API.EntityModels;
using Bucket.API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace Bucket.API.Services
{
    public class BucketService : IBucketService
    {
        private readonly BucketDbContext _dbContext;
        private readonly IMapper _mapper;
        private readonly IBucketMachineAssociationService bucketMachineAssociationService;

        //private readonly IRole
        public BucketService(BucketDbContext dbContext
            , IMapper mapper
            , IBucketMachineAssociationService bucketMachineAssociationService)
        {
            this._dbContext = dbContext;
            this._mapper = mapper;
            this.bucketMachineAssociationService = bucketMachineAssociationService;
        }
        public async Task<ApiResponse<bool>> CreateBucketAsync(BucketDto bucketDto)
        {
            bool isEntityAdded = false;
            var apiResponse = new ApiResponse<bool>();
            try
            {
                var isExists = _dbContext.TblBuckets.Where(b => b.bucket_name == bucketDto.Bucket_Name && b.service_id == bucketDto.Service_Id).FirstOrDefault() != null;
                if (!isExists)
                {
                    var newEntity = _mapper.Map<TblBucket>(bucketDto);
                    newEntity.id = Guid.NewGuid().ToString();

                    _dbContext.TblBuckets.Add(newEntity);

                    _dbContext.SaveChanges();

                    isEntityAdded = true;

                    if (bucketDto.Machine_Id.Count > 0)
                        isEntityAdded = (await bucketMachineAssociationService.AddMachinesToBucketAsync(new BucketServiceMachineAssociationDto()
                        {
                            BucketId = newEntity.id,
                            MachineIds = bucketDto.Machine_Id
                        }))?.Data ?? false;

                    apiResponse.StatusCode = (int)HttpStatusCode.OK;
                    apiResponse.StatusReason = "Bucket created successfully.";
                }
                else
                {
                    apiResponse.StatusCode = (int)HttpStatusCode.BadRequest;
                    apiResponse.StatusReason = "Bucket name already exists.";
                }
            }
            catch (Exception ex)
            {
                apiResponse.StatusCode = (int)HttpStatusCode.InternalServerError;
                apiResponse.StatusReason = ex.Message;
            }

            apiResponse.Data = isEntityAdded;

            return apiResponse;
        }

        public async Task<ApiResponse<bool>> DeleteBucketAsync(string bucketId)
        {
            bool isEntityRemoved = false;
            var apiResponse = new ApiResponse<bool>();
            try
            {
                var entityToDelete = _dbContext.TblBuckets.FirstOrDefault(b => b.id == bucketId);
                if (entityToDelete != null)
                {
                    isEntityRemoved = (await bucketMachineAssociationService.RemoveMachinesFromBucketAsync(bucketId))?.Data ?? false;
                    if (isEntityRemoved)
                    {
                        _dbContext.TblBuckets.Remove(entityToDelete);
                        _dbContext.SaveChanges();

                        isEntityRemoved = true;

                        apiResponse.StatusCode = (int)HttpStatusCode.OK;
                        apiResponse.StatusReason = "Bucket deleted successfully.";
                    }
                }
                else
                {
                    apiResponse.StatusCode = (int)HttpStatusCode.NotFound;
                    apiResponse.StatusReason = "Bucket does not exists.";
                }
            }
            catch (Exception ex)
            {
                apiResponse.StatusCode = (int)HttpStatusCode.InternalServerError;
                apiResponse.StatusReason = ex.Message;
            }

            apiResponse.Data = isEntityRemoved;
            return apiResponse;
        }

        //public async Task<List<BucketDto>> GetAllBucketByProject(string projectId)
        //{
        //    var bucketFromDb = _dbContext.TblBuckets.Where(b => b.project_id == projectId).ToList();

        //    return _mapper.Map<List<BucketDto>>(bucketFromDb);
        //}

        public async Task<ApiResponse<List<BucketDto>>> GetAllBucketByService(string serviceId)
        {
            var response = new ApiResponse<List<BucketDto>>();

            try
            {
                var bucketFromDb = _dbContext.TblBuckets.Where(b => b.service_id == serviceId).ToList();

                var buckets = _mapper.Map<List<BucketDto>>(bucketFromDb);

                buckets.ForEach(bucket => bucket.Machine_Id = new List<string>());

                response.Data = buckets;

                response.StatusCode = (int)HttpStatusCode.OK;
                response.StatusReason = "";
            }
            catch (Exception ex)
            {
                response.StatusCode = (int)HttpStatusCode.InternalServerError;
                response.StatusReason = ex.Message;
            }

            return response;
        }

        public async Task<ApiResponse<List<BucketDto>>> GetAllBucketsAsync()
        {
            var response = new ApiResponse<List<BucketDto>>();

            try
            {
                var bucketFromDb = _dbContext.TblBuckets.ToList();

                var buckets = _mapper.Map<List<BucketDto>>(bucketFromDb);

                buckets.ForEach(bucket => bucket.Machine_Id = new List<string>());

                response.Data = buckets;
                response.StatusCode = (int)HttpStatusCode.OK;
                response.StatusReason = "";
            }
            catch (Exception ex)
            {
                response.StatusCode = (int)HttpStatusCode.InternalServerError;
                response.StatusReason = ex.Message;
            }

            return response;
        }

        public async Task<ApiResponse<bool>> UpdateBucketAsync(BucketDto bucketDto)
        {
            var isEntityUpdated = false;

            var apiResponse = new ApiResponse<bool>();

            try
            {
                var tblEntity = _dbContext.TblBuckets.FirstOrDefault(b => b.id == bucketDto.Bucket_Id);
                if (tblEntity != null)
                {
                    var isExists = _dbContext.TblBuckets.Where(b => b.bucket_name == bucketDto.Bucket_Name && b.service_id == bucketDto.Service_Id).FirstOrDefault() != null;
                    if (isExists)
                    {
                        apiResponse.StatusCode = (int)HttpStatusCode.OK;
                        apiResponse.StatusReason = "Bucket Name Already Exists.";
                    }
                    else
                    {
                        tblEntity.bucket_name = bucketDto.Bucket_Name;
                        _dbContext.TblBuckets.Update(tblEntity);
                        _dbContext.SaveChanges(true);

                        isEntityUpdated = true;

                        apiResponse.StatusCode = (int)HttpStatusCode.OK;
                        apiResponse.StatusReason = "Bucket Updated successfully.";
                    }
                    
                }
                else
                {
                    apiResponse.StatusCode = (int)HttpStatusCode.NotFound;
                    apiResponse.StatusReason = "Bucket does not exists.";
                }
            }
            catch (Exception ex)
            {
                apiResponse.StatusCode = (int)HttpStatusCode.InternalServerError;
                apiResponse.StatusReason = ex.Message;
            }

            apiResponse.Data = isEntityUpdated;
            return apiResponse;
        }

        public async Task<ApiResponse<Dictionary<string, string>>> UpdateBucketsAsync(List<BucketDto> bucketDto)
        {
            var apiResponse = new ApiResponse<Dictionary<string, string>>();
            var bucketToUpdate = new Dictionary<string, string>();
            try
            {
                foreach (var bucket in bucketDto)
                {
                    var entity = _dbContext.TblBuckets.FirstOrDefault(b => b.id == bucket.Bucket_Id);
                    if (entity is not null)
                    {
                        var isExists = _dbContext.TblBuckets.Where(b => b.bucket_name == bucket.Bucket_Name && b.service_id == bucket.Service_Id).FirstOrDefault() != null;
                        if (isExists)
                        {
                            bucketToUpdate.Add(bucket.Bucket_Id, "Bucket Name Already Exists.");
                            apiResponse.StatusReason = "Bucket Name Already Exists.";
                        }
                        else
                        {
                            entity.bucket_name = bucket.Bucket_Name;
                            try
                            {
                                _dbContext.TblBuckets.Update(entity);
                                _dbContext.SaveChanges(true);

                                bucketToUpdate.Add(bucket.Bucket_Id, "Buckets Updated successfully.");
                            }
                            catch (Exception)
                            {
                                bucketToUpdate.Add(bucket.Bucket_Id, "Buckets Updated Failed.");
                            }
                        }
                        //entity.bucket_name = bucket.Bucket_Name;
                        //try
                        //{
                        //    _dbContext.TblBuckets.Update(entity);
                        //   _dbContext.SaveChangesAsync(true);
                        //}
                        //catch (Exception)
                        //{
                        //    bucketToUpdate.Add(bucket.Bucket_Id, false);
                        //}


                        //bucketToUpdate.Add(bucket.Bucket_Id, true);
                    }
                    else
                    {
                        bucketToUpdate.Add(bucket.Bucket_Id, "Bucket does not exists.");
                    }
                }
                apiResponse.StatusCode = (int)HttpStatusCode.OK;
                apiResponse.StatusReason = "Buckets Updated successfully.";
            }
            catch (Exception ex)
            {
                apiResponse.StatusCode = (int)HttpStatusCode.InternalServerError;
                apiResponse.StatusReason = ex.Message;
            }

            apiResponse.Data = bucketToUpdate;
            return apiResponse;
        }

        public async Task<ApiResponse<Dictionary<string, bool>>> DeleteBucketsAsync(List<string> bucketIds)
        {
            bool isEntityRemoved = false;
            var apiResponse = new ApiResponse<Dictionary<string, bool>>();
            var bucketToDelete = new Dictionary<string, bool>();
            try
            {
                foreach (var bucket in bucketIds)
                {
                    var entityToDelete = _dbContext.TblBuckets.FirstOrDefault(b => b.id == bucket);
                    if (entityToDelete != null)
                    {
                        isEntityRemoved = (await bucketMachineAssociationService.RemoveMachinesFromBucketAsync(bucket))?.Data ?? false;
                        if (isEntityRemoved)
                        {
                            try
                            {
                                _dbContext.TblBuckets.Remove(entityToDelete);
                                _dbContext.SaveChanges();
                                bucketToDelete.Add(bucket, true);
                            }
                            catch (Exception)
                            {
                                bucketToDelete.Add(bucket, false);
                            }
                        }
                        else
                            bucketToDelete.Add(bucket, false);
                    }
                    else
                    {
                        bucketToDelete.Add(bucket, false);
                    }
                }

                apiResponse.StatusCode = (int)HttpStatusCode.OK;
                apiResponse.StatusReason = "Bucket deleted successfully.";
            }
            catch (Exception ex)
            {
                apiResponse.StatusCode = (int)HttpStatusCode.InternalServerError;
                apiResponse.StatusReason = ex.Message;
            }

            apiResponse.Data = bucketToDelete;
            return apiResponse;
        }
    }
}
