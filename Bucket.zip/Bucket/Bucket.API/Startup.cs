using Bucket.API.DbContextClass;
using Bucket.API.Services;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Identity.Web;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Tenant.Service;
using Tenant.Service.DbContextClass;

namespace Bucket.API
{
    public class Startup
    {
        readonly string corsPolicy = "CORSPolicy";

        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllers();

            services.AddDbContext<BucketDbContext>(ServiceLifetime.Scoped);

            //services.AddDbContext<BucketDbContext>(options =>
            //options.UseSqlServer(Configuration.GetConnectionString("sqlConnection"),
            //sql => sql.MigrationsAssembly(migrationsAssembly)), ServiceLifetime.Singleton);

            services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme).AddJwtBearer(options =>
            {
                options.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidateLifetime = true,
                    ValidateIssuerSigningKey = true,
                    ValidIssuer = Environment.GetEnvironmentVariable("TOKEN_SERVER"),
                    ValidAudience = "blueprint-api",
                    IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(Environment.GetEnvironmentVariable("JWT_KEY")))
                };
            });

            // adds an authorization policy to make sure the token is for scope 'api1'
            services.AddAuthorization(options =>
            {
                options.AddPolicy("ApiScope", policy =>
                {
                    policy.RequireAuthenticatedUser();
                    policy.RequireClaim(ClaimTypes.Role);
                    policy.RequireClaim(ClaimConstants.TenantId);
                });
            });

            services.AddSwaggerGen(options =>
            {
                options.SwaggerDoc("v1", new Microsoft.OpenApi.Models.OpenApiInfo
                {
                    Title = "Bucket Service API",
                });
            });

            services.AddHttpContextAccessor();

            services.AddScoped<IBucketService, BucketService>();
            services.AddScoped<IBucketMachineAssociationService, BucketMachineAssociationService>();

            services.AddAutoMapper(typeof(Startup));
            services.RegisterTenantService(Configuration);

            services.AddCors(options =>
            {
                options.AddPolicy(name: corsPolicy,
                                  builder =>
                                  {
                                      builder.AllowAnyOrigin()
                        .AllowAnyMethod()
                        .AllowAnyHeader();
                                  });
            });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseCors(corsPolicy);
            app.UseHttpsRedirection();

            app.UseRouting();

            //app.UseSwaggerUI(options => options.SwaggerEndpoint("/swagger/v1/swagger.json", "Bucket Service API"));
            app.UseSwagger(options => 
            {
                options.RouteTemplate = "bucket/swagger/{documentName}/swagger.json";
            });

            app.UseSwaggerUI(options =>
            {
                options.SwaggerEndpoint("/bucket/swagger/v1/swagger.json", "Bucket Service API");
                options.RoutePrefix = "bucket/swagger";
            });
            //app.UseSwaggerUI(c =>
            //{
            //    string swaggerJsonBasePath = string.IsNullOrWhiteSpace(c.RoutePrefix) ? "." : "..";
            //    c.SwaggerEndpoint($"{swaggerJsonBasePath}/swagger/v1/swagger.json", "Bucket Service API");
            //});

            app.UseAuthentication();
            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
