﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Bucket.API.EntityModels
{
    [Table("tblService")]
    public class TblService
    {
        [Key]
        [Column(TypeName = "nvarchar(50)")]
        public string id { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string erp_wbs_id { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string project_id { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string offer_id { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string contact_id { get; set; }
        [Column(TypeName = "nvarchar(80)")]
        public string service_type { get; set; }
        [Column(TypeName = "nvarchar(80)")]
        public string service_location { get; set; }
        [Column(TypeName = "nvarchar(1000)")]
        public string service_description { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string service_region { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? start_date { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? end_date { get; set; }
        [Column(TypeName = "int")]
        public int actual_hours { get; set; }
        [Column(TypeName = "nvarchar(100)")]
        public string total_estimated_hours { get; set; }
        [Column(TypeName = "varchar(10)")]
        public string is_ra_external { get; set; }
        [Column(TypeName = "nvarchar(1000)")]
        public string external_ra_notes { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string service_kpi_id { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string is_active { get; set; }

        [Column(TypeName = "datetimeoffset(7)")]
        public DateTimeOffset created_at { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string created_by { get; set; }
        [Column(TypeName = "datetimeoffset(7)")]
        public DateTimeOffset modified_at { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string modified_by { get; set; }

    }
}
