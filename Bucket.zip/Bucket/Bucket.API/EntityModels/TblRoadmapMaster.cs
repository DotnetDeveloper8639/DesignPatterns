﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Bucket.API.EntityModels
{
    [Table("TblRoadmapMaster")]
    public class TblRoadmapMaster
    {
        [Key]
        [Column(TypeName = "nvarchar(50)")]
        public string roadmap_id { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string roadmap_version { get; set; }
        [Column(TypeName = "nvarchar(100)")]
        public string roadmap_name { get; set; }
        [Column(TypeName = "nvarchar(1000)")]
        public string description { get; set; }
        [Column(TypeName = "bit")]
        public bool iscustom { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string user_id { get; set; }
        [Column(TypeName = "datetimeoffset(7)")]
        public DateTimeOffset created_at { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string created_by { get; set; }
        [Column(TypeName = "datetimeoffset(7)")]
        public DateTimeOffset modified_at { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string modified_by { get; set; }
    }
}
