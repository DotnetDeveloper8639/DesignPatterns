﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Bucket.API.EntityModels
{
    [Table("tblMachineRoadmap")]
    public class TblMachineRoadmap
    {
        [Key]
        [Column(TypeName = "varchar(50)")]
        public string id { get; set; }
        [Column(TypeName = "varchar(50)")]
        public string service_machine_id { get; set; }
        [Column(TypeName = "varchar(50)")]
        public string roadmap_id { get; set; }
        [Column(TypeName = "varchar(50)")]
        public string roadmap_status { get; set; }
        [Column(TypeName = "int")]
        public int roadmap_progress { get; set; }
        [Column(TypeName = "bit")]
        public bool isconflict { get; set; }
        [Column(TypeName = "datetimeoffset(7)")]
        public DateTimeOffset created_at { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string created_by { get; set; }
        [Column(TypeName = "datetimeoffset(7)")]
        public DateTimeOffset modified_at { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string modified_by { get; set; }
    }
}
