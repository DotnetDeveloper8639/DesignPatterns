﻿namespace Bucket.API.DbContextClass
{
    using Bucket.API.EntityModels;
    using Microsoft.AspNetCore.Http;
    using Microsoft.EntityFrameworkCore;
    using Microsoft.Extensions.Configuration;
    using Tenant.Service;
    using Microsoft.Identity.Web;

    public class BucketDbContext : DbContext
    {
        private readonly IConfiguration _configuration;
        private readonly IHttpContextAccessor httpContextAccessor;
        private readonly ITenantService tenantService;

        public BucketDbContext()
        {
        }

        public BucketDbContext(DbContextOptions<BucketDbContext> options
            , IConfiguration configuration
            , IHttpContextAccessor httpContextAccessor
            , ITenantService tenantService)
                     : base(options)
        {
            _configuration = configuration;
            this.httpContextAccessor = httpContextAccessor;
            this.tenantService = tenantService;
        }

        public virtual DbSet<TblBucket> TblBuckets { get; set; }
        public virtual DbSet<TblBucketServiceMachineAssociation> TblBucketServiceMachineAssociations { get; set; }
        public virtual DbSet<TblMachine> TblMachines { get; set; }
        public virtual DbSet<TblServiceMachine> TblServiceMachines { get; set; }
        public virtual DbSet<TblMachineFourEyesQualityAssociation> TblMachineFourEyesQualityAssociation { get; set; }
        public virtual DbSet<TblService> TblService { get; set; }
        public virtual DbSet<TblMachineRoadmap> TblMachineRoadmap { get; set; }
        public virtual DbSet<TblMachineKPI> TblMachineKPI { get; set; }
        public virtual DbSet<TblMachineHour> TblMachineHour { get; set; }
        public virtual DbSet<TblRoadmapMaster> TblRoadmapMaster { get; set; }
        public virtual DbSet<TblRoadmapSection> TblRoadmapSection { get; set; }
        public virtual DbSet<TblRoadmapSubSectionMster> TblRoadmapSubSectionMster { get; set; }
        public virtual DbSet<TblStepMaster> TblStepMaster { get; set; }
        public virtual DbSet<TblServiceMachineSteps> TblServiceMachineSteps { get; set; }
        public virtual DbSet<TblStepMachineAssociation> TblStepMachineAssociation { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            var tid = httpContextAccessor.HttpContext.User.GetTenantId();

            var tenantInfo = tenantService.GetTenantInfo(tid);

            optionsBuilder.UseSqlServer(tenantInfo.Connectionstring);

            base.OnConfiguring(optionsBuilder);
        }
    }
}