﻿using System.Collections.Generic;

namespace Bucket.API.Models
{
    public class BucketServiceMachineAssociationDto
    {
        public string Id { get; set; }
        public string BucketId { get; set; }
        public List<string> MachineIds { get; set; } = new List<string>();
    }
}
