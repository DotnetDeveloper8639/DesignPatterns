﻿using System.Collections.Generic;

namespace Bucket.API.Models
{
    public class BucketDto
    {
        public string Bucket_Id { get; set; }
        public string Bucket_Name { get; set; }
        public string Project_Id { get; set; }
        public string Order_Id { get; set; }
        public string Service_Id { get; set; }
        public string User_Id { get; set; }
        public List<string> Machine_Id { get; set; }
    }
}
