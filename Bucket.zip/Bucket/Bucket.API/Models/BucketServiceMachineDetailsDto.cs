﻿using System;
using System.Collections.Generic;

namespace Bucket.API.Models
{
    public class BucketServiceMachineDetailsDto
    {
        public string Bucket_Id { get; set; }
        public string Bucket_Name { get; set; }
        public List<MachineDTO> Machines { get; set; }
    }

    public class MachineDTO
    {
        public string machine_Id { get; set; }
        public string machine_Name { get; set; }
        public string asset_Id { get; set; }
        public string serial_Number { get; set; }
        public string machine_Type { get; set; }
        public string industry { get; set; }
        public string is_RA_Status { get; set; }
        public string is_RA_External { get; set; }
        public bool isActive { get; set; }
        public string masterMachine_Id { get; set; }
        public ServiceMachineDTO serviceMachine_Id { get; set; }
        public FourEyesQualityDTO fourEyeQualityDTO { get; set; }
        public string machine_Description { get; set; }
        public decimal estimated_Hours { get; set; }
        public decimal calculatedHours { get; set; }
        public decimal aggregatedHours { get; set; }
        public DateTimeOffset created_At { get; set; }
        public string created_By { get; set; }
        public DateTimeOffset modified_At { get; set; }
        public string modified_By { get; set; }
    }
    public class ServiceMachineDTO
    {
        public string serviceMachineId { get; set; }
        public bool isRequested { get; set; }
        public bool isConflict { get; set; }
    }
    public class FourEyesQualityDTO
    {
        public bool isFourEyeQuality { get; set; }
        public bool IsFourEyePerform { get; set; }
    }
}
