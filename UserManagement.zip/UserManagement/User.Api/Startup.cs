using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Identity.Web;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Security.Claims;
using System.Text;
using Tenant.Service;
using User.API.DbContextClass;
using User.API.Extensions;
using User.API.Services;
//using Microsoft.Identity.Web;

namespace User.Api
{
    public class Startup
    {
        private const string AppName = "UserManagement API";
        readonly string corsPolicy = "CORSPolicy";
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            //services.AddControllers();
            var migrationsAssembly = typeof(Startup).GetTypeInfo().Assembly.GetName().Name;
            services.AddControllers();

            //services.AddDbContext<UserManagementDbContext>(options =>
            //options.UseSqlServer(Configuration.GetConnectionString("sqlConnection"),
            //sql => sql.MigrationsAssembly(migrationsAssembly)), ServiceLifetime.Singleton);

            services.AddDbContext<UserManagementDbContext>(ServiceLifetime.Scoped);

            // accepts any access token issued by identity server
            //services.AddAuthentication("Bearer")
            //    .AddJwtBearer("Bearer", options =>
            //    {
            //        options.Authority = identityUrlExternal;
            //        options.Audience = "user-api";
            //        options.RequireHttpsMetadata = false;
            //        //options.TokenValidationParameters = new TokenValidationParameters
            //        //{
            //        //    ValidateAudience = false
            //        //};
            //        //options.Events = new JwtBearerEvents()
            //        //{
            //        //    OnTokenValidated = async context =>
            //        //    {
            //        //        //var userUniqueId = context.Principal.Claims.FirstOrDefault(claim => claim.Type == ClaimTypes.NameIdentifier || claim.Type == "name")?.Value;
            //        //        //if (!string.IsNullOrEmpty(userUniqueId))
            //        //        //{
            //        //        //    var newIdentity = new AppIdentity(context.Principal.Identity);
            //        //        //    var serviceProvider = services.BuildServiceProvider();
            //        //        //    IGenericRepository<ApplicationUser> userService = serviceProvider.GetService<IGenericRepository<ApplicationUser>>();
            //        //        //    var localStoreUser = (await userService.Find(u => u.Email == userUniqueId))?.FirstOrDefault();
            //        //        //    if (localStoreUser != null)
            //        //        //    {
            //        //        //        newIdentity.Id = localStoreUser.Id;
            //        //        //        newIdentity.Email = localStoreUser.Email;
            //        //        //        newIdentity.DisplayName = $"{localStoreUser.FirstName} {localStoreUser.LastName}";
            //        //        //        context.Principal = new ClaimsPrincipal(newIdentity);
            //        //        //    }
            //        //        //}
            //        //        //return Task.CompletedTask;
            //        //    }
            //        //};
            //    });

            services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme).AddJwtBearer(options =>
            {
                options.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidateLifetime = true,
                    ValidateIssuerSigningKey = true,
                    ValidIssuer = Environment.GetEnvironmentVariable("TOKEN_SERVER"),
                    ValidAudience = "blueprint-api",
                    IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(Environment.GetEnvironmentVariable("JWT_KEY")))
                };
            });

            //services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
            //    .AddMicrosoftIdentityWebApi(Configuration)
            //     .EnableTokenAcquisitionToCallDownstreamApi()
            //            .AddMicrosoftGraph(Configuration.GetSection("DownstreamAPI"))
            //            .AddInMemoryTokenCaches();

            // adds an authorization policy to make sure the token is for scope 'api1'
            services.AddAuthorization(options =>
            {
                options.AddPolicy("ApiScope", policy =>
                {
                    policy.RequireAuthenticatedUser();
                    policy.RequireClaim(ClaimTypes.Role);
                    policy.RequireClaim(ClaimConstants.TenantId);
                    //policy.RequireClaim("scope", "user.api");
                });
            });
            //services.AddAuthorization();

            //services.grap

            //services.AddSwaggerGen(c =>
            //{
            //    c.SwaggerDoc("v1", new OpenApiInfo { Title = $"Trianz - {AppName}", Version = "v1" });

            //    c.AddSecurityDefinition("oauth2", new OpenApiSecurityScheme
            //    {
            //        Type = SecuritySchemeType.OAuth2,
            //        Flows = new OpenApiOAuthFlows()
            //        {
            //            Implicit = new OpenApiOAuthFlow()
            //            {
            //                AuthorizationUrl = new Uri($"{identityUrlExternal}/connect/authorize"),
            //                TokenUrl = new Uri($"{identityUrlExternal}/connect/token"),
            //                Scopes = new Dictionary<string, string>()
            //                {
            //                    { "user.api", AppName },
            //                    { "profile","Get User Info" }
            //                }
            //            }
            //        }
            //    });


            //    c.OperationFilter<AuthorizeCheckOperationFilter>();
            //});
            services.AddSwaggerGen(options =>
            {
                options.SwaggerDoc("v1", new Microsoft.OpenApi.Models.OpenApiInfo
                {
                    Title = "User Service API",
                });
            });
            services.AddAutoMapper(typeof(Startup));

            services.AddScoped<IUserService, UserService>();
            services.AddScoped<IUserGroupAssociationService, UserGroupAssociationService>();
            services.AddScoped<IUserRoleAssignmentService, UserRoleAssignmentService>();
            services.AddScoped<IGroupService, GroupService>();
            services.AddScoped<IGroupRoleAssignmentService, GroupRoleAssignmentService>();
            services.AddScoped<IPermissionAssociationService, PermissionAssociationService>();
            services.AddScoped<IRoleService, RoleService>();

            services.AddHttpContextAccessor();

            services.AddCors(options =>
            {
                options.AddPolicy(name: corsPolicy,
                                  builder =>
                                  {
                                      builder.AllowAnyOrigin()
                        .AllowAnyMethod()
                        .AllowAnyHeader();
                                  });
            });


            services.RegisterTenantService(Configuration);
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseSwagger(options =>
            {
                options.RouteTemplate = "user/swagger/{documentName}/swagger.json";
            });

            app.UseSwaggerUI(options =>
            {
                options.SwaggerEndpoint("/user/swagger/v1/swagger.json", "User Service API");
                options.RoutePrefix = "user/swagger";
            });

            app.UseCors(corsPolicy);
            app.UseHttpsRedirection();

            app.UseRouting();

            app.UseAuthentication();
            app.UseAuthorization();

            

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
