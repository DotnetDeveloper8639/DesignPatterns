﻿

namespace User.Api.Models
{
    public class UserProfileDTO
    {
        public string id { get; set; }
        public string first_name { get; set; }
        public string last_name { get; set; }
        public string display_name { get; set; }
        public string login_name { get; set; }
        public string email_address { get; set; }
        public ProfileData profiledata { get; set; }
    }
    public class ProfileData
    {
        public BookMarks BookMarks { get; set; }
    }
    public class BookMarks
    {
        public RoadmapBookmarks[] RoadmapBookmarks { get; set; }
        public MachineBookmarks[] MachineBookmarks { get; set; }
        public InitiaHazardBookmarks[] InitiaHazardBookmarks { get; set; }
        public CounterlMeasureBookmarks[] CounterlMeasureBookmarks { get; set; }
    }
    public class RoadmapBookmarks
    {
        public string roadmap_id { get; set; }
    }
    public class MachineBookmarks
    {
        public string machine_id { get; set; }
    }
    public class InitiaHazardBookmarks
    {
        public string hazard_id { get; set; }
    }
    public class CounterlMeasureBookmarks
    {
        public string countermeasure_id { get; set; }
    }
}
