﻿using System.Collections.Generic;

namespace User.API.Models
{
    public class UserDTO
    {
        public string Id { get; set; }
        public string First_Name { get; set; }
        public string Last_Name { get; set; }
        public string Display_Name { get; set; }
        public string Login_Name { get; set; }
        public string Email_Address { get; set; }
        public List<string> User_Roles { get; set; }
    }
}
