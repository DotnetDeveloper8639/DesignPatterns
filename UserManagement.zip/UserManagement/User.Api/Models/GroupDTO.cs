﻿namespace User.API.Models
{
    public class GroupDTO
    {
        public string id { get; set; }
        public string group_name { get; set; }
        public string group_email_address { get; set; }
    }

    public class GroupDTOWithUser : GroupDTO
    {
        public int UserCount { get; set; }
    }
}
