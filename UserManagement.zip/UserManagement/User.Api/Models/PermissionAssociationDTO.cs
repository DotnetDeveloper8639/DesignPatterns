﻿using System.Collections.Generic;

namespace User.API.Models
{
    public class PermissionAssociationDTO
    {
        public RoleDTO role { get; set; }
        public List<PermissionDTO> Permissions { get; set; } = new List<PermissionDTO>();

    }
    public class PermissionDTO
    {
        public int id { get; set; }
        public string  name { get; set; }
    }
}
