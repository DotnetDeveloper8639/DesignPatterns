﻿using System.Collections.Generic;

namespace User.API.Models
{
    public class UserGroupAssociationDTO
    {
        //private string _id;
        //public string group_id { get { return _id; } set { _id = value; this._group = new GroupDTO() { id = value }; } }

        private GroupDTO _group;
        public GroupDTO Group 
        { 
            get 
            {
                return this._group;
            } 
            set 
            { 
                this._group = value;
            } 
        }
        public List<UserDTO> Users { get; set; } = new List<UserDTO>();
    }
}
