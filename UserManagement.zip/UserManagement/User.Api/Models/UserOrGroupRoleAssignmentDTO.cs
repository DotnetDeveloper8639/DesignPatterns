﻿using System.Collections.Generic;

namespace User.API.Models
{
    public class UserOrGroupRoleAssignmentDTO
    {
        public string UserOrGroupId { get; set; }
        public string UserName { get; set; }
        public List<RoleDTO> Roles { get; set; } = new List<RoleDTO>();
    }

    public class RoleDTO
    {
        public string id { get; set; }
        public string role_name { get; set; }
        public bool IsDefault { get; set; }
        public bool IsGlobalAdminRole { get; set; }
    }

    public class RoleUserAssociationDTO
    {
        public string RoleId { get; set; }
        public List<UserDTO> Users { get; set; } = new List<UserDTO>();
    }
}
