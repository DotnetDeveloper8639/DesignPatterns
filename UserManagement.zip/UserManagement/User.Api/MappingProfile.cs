﻿using AutoMapper;
using System;
using User.API.EntityModel;
using User.API.Models;

namespace User.API
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<UserDTO,TblUser>().ReverseMap();
            CreateMap<RoleDTO,TblRole>().ReverseMap();
            CreateMap<GroupDTO,TblGroup>()
                //.ForMember(dest => dest.id, source => source.MapFrom(prop => string.IsNullOrEmpty(prop.id) ? Guid.NewGuid().ToString() : prop.id ))
                //.ForSourceMember(source => source.id,dest => dest.)
                .ReverseMap();
            CreateMap<PermissionDTO, TblPermission>()
                .ForMember(dest => dest.display_name, source => source.MapFrom(prop => prop.name))
                .ReverseMap();
            //CreateMap<Microsoft.Graph.User,UserDTO>()
            //     .ForMember(source => source., dest => dest.MapFrom(prop => prop.nam))
        }
    }
}
