﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using User.API.DbContextClass;
using User.API.EntityModel;
using User.API.Models;

namespace User.API.Services
{
    internal class PermissionAssociationService : IPermissionAssociationService
    {
        private readonly UserManagementDbContext _dbContext;
        private readonly IMapper _mapper;
        private readonly IRoleService _roleService;
        public PermissionAssociationService(UserManagementDbContext dbContext
            , IMapper mapper
            , IRoleService roleService)
        {
            this._dbContext = dbContext;
            this._mapper = mapper;
            this._roleService = roleService;
        }

        public async Task<ApiResponse<List<PermissionDTO>>> GetAllPermission()
        {
            var apiResponse = new ApiResponse<List<PermissionDTO>>();
            var data = new List<PermissionDTO>();
            try
            {
                data = _mapper.Map<List<PermissionDTO>>(_dbContext.TblPermissions.Where(p => p.is_active).ToList().OrderBy(p => p.number));
            }
            catch (Exception ex)
            {
                apiResponse.StatusCode = (int)HttpStatusCode.InternalServerError;
                apiResponse.StatusReason = ex.Message;
            }

            apiResponse.Data = data;

            return apiResponse;
        }

        public async Task<ApiResponse<List<PermissionAssociationDTO>>> GetAllPermissionAssociations()
        {
            var allRolePermissions = new List<PermissionAssociationDTO>();
            var apiResponse = new ApiResponse<List<PermissionAssociationDTO>>();
            try
            {
                var roles = (await _roleService.GetAllRolesAsync()).Data;

                foreach (var role in roles)
                {
                    var rolePermission = new PermissionAssociationDTO();
                    rolePermission.role = role;

                    if (role.IsGlobalAdminRole || role.IsDefault)
                        rolePermission.Permissions = _mapper.Map<List<PermissionDTO>>(_dbContext.TblPermissions.ToList());
                    else
                        rolePermission.Permissions = _mapper.Map<List<PermissionDTO>>(
                        from perms in _dbContext.TblPermissions
                        join permAssociation in _dbContext.TblPermissionAssociations on perms.id equals permAssociation.permission_id
                        where permAssociation.role_id == role.id && perms.is_active
                        select perms).ToList();

                    allRolePermissions.Add(rolePermission);
                }

                apiResponse.StatusCode = (int)HttpStatusCode.OK;
                apiResponse.StatusReason = "Data fetched successfully.";
            }
            catch (Exception ex)
            {
                apiResponse.StatusCode = (int)HttpStatusCode.InternalServerError;
                apiResponse.StatusReason = ex.Message;
            }

            apiResponse.Data = allRolePermissions;
            return apiResponse;
        }

        public async Task<ApiResponse<bool>> UpdateRolePermission(List<PermissionAssociationDTO> rolePermission)
        {
            bool isEntityUpdated = false;
            var apiResponse = new ApiResponse<bool>();
            try
            {
                foreach (var rolePerm in rolePermission)
                {
                    var permissionFromClient = rolePerm.Permissions.Select(perm => perm.id);

                    //var permissionIdsFromClient = _dbContext.TblPermissions.ToList()
                    //    .Where(dbPerm => permissionFromClient.Contains(dbPerm.name))
                    //    .Select(dbPerm => dbPerm.id);

                    //var newPermissions = _dbContext.TblPermissions.ToList()
                    //    .Where(dbPerm => permissionFromClient.Contains(dbPerm.name))
                    //    .Select(dbPerm => dbPerm.id);

                    // existing = [1,2,3,4,5] , client = [1,2,3,5,6]

                    var existingPermisisons = _dbContext.TblPermissionAssociations
                        .Where(perm => perm.role_id == rolePerm.role.id)
                        .Select(perm => perm.permission_id).ToList();

                    var permissionsToAdd = permissionFromClient.Except(existingPermisisons).ToList();
                    var permissionToRemove = existingPermisisons.Except(permissionFromClient).ToList();

                    if (permissionsToAdd.Count > 0)
                    {
                        var newEntities = new List<TblPermissionAssociation>();
                        permissionsToAdd.ForEach(perm => newEntities.Add(new TblPermissionAssociation()
                        {
                            role_id = rolePerm.role.id,
                            permission_id = perm
                        }
                            ));

                        _dbContext.TblPermissionAssociations.AddRange(newEntities);
                        _dbContext.SaveChanges();
                    }

                    if (permissionToRemove.Count > 0)
                    {
                        _dbContext.TblPermissionAssociations.RemoveRange(_dbContext.TblPermissionAssociations
                            .Where(perm => perm.role_id == rolePerm.role.id).ToList()
                            .Where(perm => permissionToRemove.Contains(perm.permission_id)));
                        _dbContext.SaveChanges(true);
                    }
                }


                isEntityUpdated = true;
                apiResponse.StatusCode = (int)HttpStatusCode.OK;
                apiResponse.StatusReason = "Role Permissions updated successfully.";

            }
            catch (Exception ex)
            {
                apiResponse.StatusCode = (int)HttpStatusCode.InternalServerError;
                apiResponse.StatusReason = ex.Message;
            }

            apiResponse.Data = isEntityUpdated;
            return apiResponse;
        }
    }
}
