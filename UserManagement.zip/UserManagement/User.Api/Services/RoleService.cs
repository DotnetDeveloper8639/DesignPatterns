﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using User.API.DbContextClass;
using User.API.EntityModel;
using User.API.Models;

namespace User.API.Services
{
    internal class RoleService : IRoleService
    {
        private readonly UserManagementDbContext _dbContext;
        private readonly IMapper _mapper;
        //private readonly IRole
        public RoleService(UserManagementDbContext dbContext
            , IMapper mapper)
        {
            this._dbContext = dbContext;
            this._mapper = mapper;
        }
        public async Task<ApiResponse<bool>> AddNewRoleAsync(RoleDTO role)
        {
            bool isEntityAdded = false;
            var apiResponse = new ApiResponse<bool>();
            try
            {
                var isExists = _dbContext.TblRoles.Where(r => r.role_name == role.role_name).FirstOrDefault() != null;
                if (!isExists)
                {
                    var newEntity = _mapper.Map<TblRole>(role);
                    newEntity.id = Guid.NewGuid().ToString();

                    _dbContext.TblRoles.Add(newEntity);

                    _dbContext.SaveChanges();

                    isEntityAdded = true;

                    apiResponse.StatusCode = (int)HttpStatusCode.OK;
                    apiResponse.StatusReason = "Role created successfully.";
                }
                else
                {
                    apiResponse.StatusCode = (int)HttpStatusCode.BadRequest;
                    apiResponse.StatusReason = "Role name already exists.";
                }
            }
            catch (Exception ex)
            {
                apiResponse.StatusCode = (int)HttpStatusCode.InternalServerError;
                apiResponse.StatusReason = ex.Message;
            }

            apiResponse.Data = isEntityAdded;

            return apiResponse;
        }

        public async Task<ApiResponse<List<RoleDTO>>> GetAllRolesAsync()
        { 
            var apiResponse = new ApiResponse<List<RoleDTO>>();
            var data = new List<RoleDTO>();
            try
            {
                data = _mapper.Map<List<RoleDTO>>(_dbContext.TblRoles.ToList());
            }
            catch (Exception ex)
            {
                apiResponse.StatusCode = (int)HttpStatusCode.InternalServerError;
                apiResponse.StatusReason = ex.Message;
            }

            apiResponse.Data = data;

            return apiResponse;
        }

        public async Task<ApiResponse<RoleDTO>> GetRoleByIdAsync(string id)
        {
            var roleDTO = new RoleDTO();
            var apiResponse = new ApiResponse<RoleDTO>();
            try
            {
                var tblEntity = _dbContext.TblRoles.FirstOrDefault(role => role.id == id);

                if (tblEntity != null)
                {
                    roleDTO = _mapper.Map<RoleDTO>(tblEntity);

                    apiResponse.StatusCode = (int)HttpStatusCode.OK;
                    apiResponse.StatusReason = $"Fetching role data for the id {id} completed successfully.";
                }
                else
                {
                    apiResponse.StatusCode = (int)HttpStatusCode.NotFound;
                    apiResponse.StatusReason = "Role does not exists.";
                }
            }
            catch (Exception ex)
            {
                apiResponse.StatusCode = (int)HttpStatusCode.InternalServerError;
                apiResponse.StatusReason = ex.Message;
            }

            apiResponse.Data = roleDTO;
            return apiResponse;
        }

        public async Task<ApiResponse<bool>> RemoveRoleAsync(string id)
        {
            bool isEntityRemoved = false;
            var apiResponse = new ApiResponse<bool>();
            try
            {
                var entityToDelete = _dbContext.TblRoles.FirstOrDefault(r => r.id == id);
                if (entityToDelete != null)
                {
                    _dbContext.TblUserRoleAssignments
                        .RemoveRange(_dbContext.TblUserRoleAssignments.Where(ra => ra.role_id == entityToDelete.id));

                    _dbContext.TblPermissionAssociations
                        .RemoveRange(_dbContext.TblPermissionAssociations.Where(pa => pa.role_id == entityToDelete.id));

                    _dbContext.SaveChanges();

                    _dbContext.TblRoles.Remove(entityToDelete);

                    _dbContext.SaveChanges();

                    isEntityRemoved = true;

                    apiResponse.StatusCode = (int)HttpStatusCode.OK;
                    apiResponse.StatusReason = "Role deleted successfully.";
                }
                else
                {
                    apiResponse.StatusCode = (int)HttpStatusCode.NotFound;
                    apiResponse.StatusReason = "Role does not exists.";
                }
            }
            catch (Exception ex)
            {
                apiResponse.StatusCode = (int)HttpStatusCode.InternalServerError;
                apiResponse.StatusReason = ex.Message;
            }

            apiResponse.Data = isEntityRemoved;
            return apiResponse;
        }

        public async Task<ApiResponse<bool>> UpdateRoleAsync(RoleDTO roleDTO)
        {
            var isEntityUpdated = false;

            var apiResponse = new ApiResponse<bool>();

            try
            {
                var tblEntity = _dbContext.TblRoles.FirstOrDefault(g => g.id == roleDTO.id);
                if (tblEntity != null)
                {
                    tblEntity.role_name = roleDTO.role_name;
                   
                    _dbContext.TblRoles.Update(tblEntity);
                    _dbContext.SaveChanges(true);

                    isEntityUpdated = true;

                    apiResponse.StatusCode = (int)HttpStatusCode.OK;
                    apiResponse.StatusReason = "Role deleted successfully.";
                }
                else
                {
                    apiResponse.StatusCode = (int)HttpStatusCode.NotFound;
                    apiResponse.StatusReason = "Role does not exists.";
                }
            }
            catch (Exception ex)
            {
                apiResponse.StatusCode = (int)HttpStatusCode.InternalServerError;
                apiResponse.StatusReason = ex.Message;
            }

            apiResponse.Data = isEntityUpdated;
            return apiResponse;
        }
    }
}
