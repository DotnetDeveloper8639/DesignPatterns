﻿using System.Collections.Generic;
using System.Threading.Tasks;
using User.API.Models;

namespace User.API.Services
{
    public interface IUserRoleAssignmentService
    {
        Task<ApiResponse<bool>> AddUserRoleAssignmentAsync(UserOrGroupRoleAssignmentDTO userRoleAssignmentDTO);
        Task<ApiResponse<bool>> DeleteUserRoleAssignmentsAsync(UserOrGroupRoleAssignmentDTO userRoleAssignmentDTO);
        Task<ApiResponse<bool>> DeleteUsersFromRole(RoleUserAssociationDTO userRoleAssignmentDTO);
        Task<ApiResponse<bool>> UpdateUserRoleAssignmentsAsync(UserOrGroupRoleAssignmentDTO userRoleAssignmentDTO);
        Task<ApiResponse<UserOrGroupRoleAssignmentDTO>> GetUserRoleAssignmentAsync(string userId);
        Task<ApiResponse<RoleUserAssociationDTO>> GetUsersByRoleAsync(string roleId);
        Task<ApiResponse<bool>> AddRoleToUsers(RoleUserAssociationDTO roleUserAssociationDTO);

        Task<ApiResponse<List<UserOrGroupRoleAssignmentDTO>>> GetUsersWithRole();
    }
}
