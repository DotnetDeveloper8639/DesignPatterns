﻿using System.Collections.Generic;
using System.Threading.Tasks;
using User.API.Models;

namespace User.API.Services
{
    public interface IPermissionAssociationService
    {
        //Task<bool> AddPermissionToRole(List<PermissionAssociationDTO> rolePermission);
        Task<ApiResponse<bool>> UpdateRolePermission(List<PermissionAssociationDTO> rolePermission);
        Task<ApiResponse<List<PermissionAssociationDTO>>> GetAllPermissionAssociations();
        Task<ApiResponse<List<PermissionDTO>>> GetAllPermission();
    }
}
