﻿using System.Collections.Generic;
using System.Threading.Tasks;
using User.API.Models;

namespace User.API.Services
{
    public interface IRoleService
    {
        Task<ApiResponse<bool>> AddNewRoleAsync(RoleDTO role);
        Task<ApiResponse<bool>> RemoveRoleAsync(string id);
        Task<ApiResponse<bool>> UpdateRoleAsync(RoleDTO roleDTO);
        Task<ApiResponse<List<RoleDTO>>> GetAllRolesAsync();
        Task<ApiResponse<RoleDTO>> GetRoleByIdAsync(string id);
    }
}
