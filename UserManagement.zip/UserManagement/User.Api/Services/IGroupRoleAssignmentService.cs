﻿using System.Threading.Tasks;
using User.API.Models;

namespace User.API.Services
{
    public interface IGroupRoleAssignmentService
    {
        Task<ApiResponse<bool>> AddGroupRoleAssignmentAsync(UserOrGroupRoleAssignmentDTO userRoleAssignmentDTO);
        Task<ApiResponse<bool>> DeleteGroupRoleAssignmentsAsync(UserOrGroupRoleAssignmentDTO userRoleAssignmentDTO);
        Task<ApiResponse<bool>> UpdateGroupRoleAssignmentsAsync(UserOrGroupRoleAssignmentDTO userRoleAssignmentDTO);
        Task<ApiResponse<UserOrGroupRoleAssignmentDTO>> GetGroupRoleAssignmentAsync(string groupId);
    }
}
