﻿using AutoMapper;
using System.Threading.Tasks;
using User.API.DbContextClass;
using User.API.Models;
using User.API.EntityModel;
using System.Collections.Generic;
using System.Linq;
using System;
using System.Net;

namespace User.API.Services
{
    internal class UserRoleAssignmentService : IUserRoleAssignmentService
    {
        private readonly UserManagementDbContext _dbContext;
        private readonly IMapper _mapper;
        public UserRoleAssignmentService(UserManagementDbContext dbContext
            , IMapper mapper)
        {
            this._dbContext = dbContext;
            this._mapper = mapper;
        }

        public async Task<ApiResponse<bool>> AddRoleToUsers(RoleUserAssociationDTO roleUserAssociationDTO)
        {
            bool isEntityAdded = false;
            var apiResponse = new ApiResponse<bool>();
            try
            {

                var entityList = new List<TblUserRoleAssignment>();
                roleUserAssociationDTO.Users?.ForEach(user =>
                {
                    if (!_dbContext.TblUserRoleAssignments.Any(ura => ura.user_id == user.Id && ura.role_id == roleUserAssociationDTO.RoleId))
                    {
                        entityList.Add(new TblUserRoleAssignment() { role_id = roleUserAssociationDTO.RoleId, user_id = user.Id });
                    }

                });

                await _dbContext.TblUserRoleAssignments.AddRangeAsync(entityList);

                _dbContext.SaveChanges();
                isEntityAdded = true;

                apiResponse.StatusCode = (int)HttpStatusCode.OK;
                apiResponse.StatusReason = "User(s) added to role successfully.";
            }
            catch (Exception ex)
            {
                apiResponse.StatusCode = (int)HttpStatusCode.InternalServerError;
                apiResponse.StatusReason = ex.Message;
            }

            apiResponse.Data = isEntityAdded;

            return apiResponse;
        }

        public async Task<ApiResponse<bool>> AddUserRoleAssignmentAsync(UserOrGroupRoleAssignmentDTO userRoleAssignmentDTO)
        {
            bool isEntityAdded = false;
            var apiResponse = new ApiResponse<bool>();
            try
            {

                var entityList = new List<TblUserRoleAssignment>();
                userRoleAssignmentDTO.Roles?.ForEach(role =>
                {
                    if (!_dbContext.TblUserRoleAssignments.Any(ura => ura.user_id == userRoleAssignmentDTO.UserOrGroupId && ura.role_id == role.id))
                    {
                        entityList.Add(new TblUserRoleAssignment() { role_id = role.id, user_id = userRoleAssignmentDTO.UserOrGroupId });
                    }

                });

                await _dbContext.TblUserRoleAssignments.AddRangeAsync(entityList);

                _dbContext.SaveChanges();
                isEntityAdded = true;

                apiResponse.StatusCode = (int)HttpStatusCode.OK;
                apiResponse.StatusReason = "Roles(s) added to user successfully.";
            }
            catch (Exception ex)
            {
                apiResponse.StatusCode = (int)HttpStatusCode.InternalServerError;
                apiResponse.StatusReason = ex.Message;
            }

            apiResponse.Data = isEntityAdded;

            return apiResponse;
        }

        public async Task<ApiResponse<bool>> DeleteUserRoleAssignmentsAsync(UserOrGroupRoleAssignmentDTO userRoleAssignmentDTO)
        {
            bool isDeleteOpearionCompleted = false;
            var apiResponse = new ApiResponse<bool>();
            try
            {
                var roleIds = userRoleAssignmentDTO?.Roles?.Select(r => r.id).ToList() ?? new List<string>();
                var entitiesTobeDeleted = _dbContext.TblUserRoleAssignments.Where(ura => ura.user_id == userRoleAssignmentDTO.UserOrGroupId).ToList()
                    .Where(ura => roleIds.Contains(ura.id));

                _dbContext.TblUserRoleAssignments.RemoveRange(entitiesTobeDeleted);
                _dbContext.SaveChanges();

                isDeleteOpearionCompleted = true;

                apiResponse.StatusCode = (int)HttpStatusCode.OK;
                apiResponse.StatusReason = "Roles(s) deleted for the user successfully.";
            }
            catch (Exception ex)
            {
                apiResponse.StatusCode = (int)HttpStatusCode.InternalServerError;
                apiResponse.StatusReason = ex.Message;
            }

            apiResponse.Data = isDeleteOpearionCompleted;

            return apiResponse;
        }

        public async Task<ApiResponse<bool>> DeleteUsersFromRole(RoleUserAssociationDTO userRoleAssignmentDTO)
        {
            bool isDeleteOpearionCompleted = false;
            var apiResponse = new ApiResponse<bool>();
            try
            {
                var userIds = userRoleAssignmentDTO?.Users?.Select(u => u.Id).ToList() ?? new List<string>();
                var entitiesTobeDeleted = _dbContext.TblUserRoleAssignments.Where(ura => ura.role_id == userRoleAssignmentDTO.RoleId).ToList()
                    .Where(ura => userIds.Contains(ura.user_id));

                _dbContext.TblUserRoleAssignments.RemoveRange(entitiesTobeDeleted);
                _dbContext.SaveChanges();

                isDeleteOpearionCompleted = true;

                apiResponse.StatusCode = (int)HttpStatusCode.OK;
                apiResponse.StatusReason = "User(s) deleted for the role successfully.";
            }
            catch (Exception ex)
            {
                apiResponse.StatusCode = (int)HttpStatusCode.InternalServerError;
                apiResponse.StatusReason = ex.Message;
            }

            apiResponse.Data = isDeleteOpearionCompleted;

            return apiResponse;
        }

        public async Task<ApiResponse<UserOrGroupRoleAssignmentDTO>> GetUserRoleAssignmentAsync(string userId)
        {
            var apiResponse = new ApiResponse<UserOrGroupRoleAssignmentDTO>();
            var data = new UserOrGroupRoleAssignmentDTO() { UserOrGroupId = userId };
            try
            {

                var tblUserRoles = (from userRole in _dbContext.TblUserRoleAssignments
                                    join role in _dbContext.TblRoles on userRole.role_id equals role.id
                                    where userRole.user_id == userId
                                    select role).ToList();

                tblUserRoles.ForEach(role => data.Roles.Add(_mapper.Map<RoleDTO>(role)));
            }
            catch (Exception ex)
            {
                apiResponse.StatusCode = (int)HttpStatusCode.InternalServerError;
                apiResponse.StatusReason = ex.Message;
            }

            apiResponse.Data = data;
            return apiResponse;
        }

        public async Task<ApiResponse<RoleUserAssociationDTO>> GetUsersByRoleAsync(string roleId)
        {
            var apiResponse = new ApiResponse<RoleUserAssociationDTO>();
            var data = new RoleUserAssociationDTO() { RoleId = roleId };
            try
            {

                var tblUserRoles = (from userRole in _dbContext.TblUserRoleAssignments
                                    join user in _dbContext.TblUsers on userRole.user_id equals user.id
                                    where userRole.role_id == roleId
                                    select user).ToList();

                tblUserRoles.ForEach(user => data.Users.Add(_mapper.Map<UserDTO>(user)));
            }
            catch (Exception ex)
            {
                apiResponse.StatusCode = (int)HttpStatusCode.InternalServerError;
                apiResponse.StatusReason = ex.Message;
            }

            apiResponse.Data = data;
            return apiResponse;
        }

        public async Task<ApiResponse<List<UserOrGroupRoleAssignmentDTO>>> GetUsersWithRole()
        {
            var returnObj = new List<UserOrGroupRoleAssignmentDTO>();
            var apiResponse = new ApiResponse<List<UserOrGroupRoleAssignmentDTO>>();

            try
            {
                var users = _dbContext.TblUsers.ToList();

                foreach (var user in users)
                {
                    var roles = (from role in _dbContext.TblRoles
                                 join ura in _dbContext.TblUserRoleAssignments on role.id equals ura.role_id
                                 where ura.user_id == user.id
                                 select new RoleDTO()
                                 {
                                     id = role.id,
                                     role_name = role.role_name
                                 }).ToList();
                    returnObj.Add(new UserOrGroupRoleAssignmentDTO()
                    {
                        UserOrGroupId = user.id,
                        UserName = $"{user.first_name} {user.last_name}",
                        Roles = roles
                    });
                }
            }
            catch (Exception ex)
            {
                apiResponse.StatusCode = (int)HttpStatusCode.InternalServerError;
                apiResponse.StatusReason = ex.Message;
            }

            apiResponse.Data = returnObj;
            return apiResponse;
        }

        public async Task<ApiResponse<bool>> UpdateUserRoleAssignmentsAsync(UserOrGroupRoleAssignmentDTO userRoleAssignmentDTO)
        {
            bool isEntityUpdated = false;
            var apiResponse = new ApiResponse<bool>();
            try
            {

                var newRoles = userRoleAssignmentDTO.Roles.Select(perm => perm.id);

                var existingRoles = _dbContext.TblUserRoleAssignments
                    .Where(ura => ura.user_id == userRoleAssignmentDTO.UserOrGroupId)
                    .Select(ura => ura.role_id);

                var rolesToAdd = newRoles.Except(existingRoles).ToList();
                var roleToRemove = existingRoles.Except(newRoles).ToList();

                if (rolesToAdd.Count > 0)
                {
                    var newEntities = new List<TblUserRoleAssignment>();
                    rolesToAdd.ForEach(role => newEntities.Add(new TblUserRoleAssignment()
                    {
                        user_id = userRoleAssignmentDTO.UserOrGroupId,
                        role_id = role
                    }));

                    _dbContext.TblUserRoleAssignments.AddRange(newEntities);
                    _dbContext.SaveChanges();
                }

                if (roleToRemove.Count > 0)
                {
                    _dbContext.TblUserRoleAssignments.RemoveRange(_dbContext.TblUserRoleAssignments
                        .Where(ura => ura.user_id == userRoleAssignmentDTO.UserOrGroupId).ToList()
                        .Where(role => roleToRemove.Contains(role.role_id)));
                    _dbContext.SaveChanges(true);
                }

                isEntityUpdated = true;

            }
            catch (Exception ex)
            {
                apiResponse.StatusCode = (int)HttpStatusCode.InternalServerError;
                apiResponse.StatusReason = ex.Message;
            }

            apiResponse.Data = isEntityUpdated;
            return apiResponse;

        }
    }
}