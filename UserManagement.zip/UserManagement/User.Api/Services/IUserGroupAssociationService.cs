﻿using System.Collections.Generic;
using System.Threading.Tasks;
using User.API.Models;

namespace User.API.Services
{
    public interface IUserGroupAssociationService
    {
        Task<ApiResponse<bool>> AddUsersToGroup(UserGroupAssociationDTO userGroupAssociation);
        Task<ApiResponse<List<UserDTO>>> GetUsersByGroupId(string groupId);
        Task<ApiResponse<bool>> DeleteUsersFromGroup(UserGroupAssociationDTO userGroupAssociation);
        Task<ApiResponse<bool>> UpdateGroupUsers(UserGroupAssociationDTO userGroupAssociation);
    }
}
