﻿using AutoMapper;
using System.Threading.Tasks;
using User.API.DbContextClass;
using User.API.Models;
using User.API.EntityModel;
using System.Collections.Generic;
using System.Linq;
using System;
using System.Net;

namespace User.API.Services
{
    internal class GroupRoleAssignmentService : IGroupRoleAssignmentService
    {
        private readonly UserManagementDbContext _dbContext;
        private readonly IMapper _mapper;
        public GroupRoleAssignmentService(UserManagementDbContext dbContext
            , IMapper mapper)
        {
            this._dbContext = dbContext;
            this._mapper = mapper;
        }
        public async Task<ApiResponse<bool>> AddGroupRoleAssignmentAsync(UserOrGroupRoleAssignmentDTO userRoleAssignmentDTO)
        {
            var apiResponse = new ApiResponse<bool>();
            
            bool isEntityAdded = false;
            try
            {

                var entityList = new List<TblUserRoleAssignment>();
                userRoleAssignmentDTO.Roles?.ForEach(role =>
                {
                    if (!_dbContext.TblUserRoleAssignments.Any(ura => ura.group_id == userRoleAssignmentDTO.UserOrGroupId && ura.role_id == role.id))
                    {
                        entityList.Add(new TblUserRoleAssignment() { role_id = role.id, group_id = userRoleAssignmentDTO.UserOrGroupId });
                    }

                });

                await _dbContext.TblUserRoleAssignments.AddRangeAsync(entityList);

                _dbContext.SaveChanges();

                isEntityAdded = true;

                apiResponse.StatusCode =(int) HttpStatusCode.OK;
                apiResponse.StatusReason = "Role(s) assigned to group successfully.";
            }
            catch (Exception ex)
            {
                apiResponse.StatusCode = (int)HttpStatusCode.InternalServerError;
                apiResponse.StatusReason = ex.Message;
            }

            apiResponse.Data = isEntityAdded;
            return apiResponse;
        }

        public async Task<ApiResponse<bool>> DeleteGroupRoleAssignmentsAsync(UserOrGroupRoleAssignmentDTO userRoleAssignmentDTO)
        {
            var apiResponse = new ApiResponse<bool>();

            bool isDeleteOpearionCompleted = false;
            try
            {
                var roleIds = userRoleAssignmentDTO?.Roles?.Select(r => r.id).ToList() ?? new List<string>();

                var entitiesTobeDeleted = _dbContext.TblUserRoleAssignments.Where(ura => ura.group_id == userRoleAssignmentDTO.UserOrGroupId).ToList()
                    .Where(ura => roleIds.Contains(ura.role_id));

                _dbContext.TblUserRoleAssignments.RemoveRange(entitiesTobeDeleted);
                _dbContext.SaveChanges();
                isDeleteOpearionCompleted = true;

                apiResponse.StatusCode = (int)HttpStatusCode.OK;
                apiResponse.StatusReason = "Role(s) deleted for the group successfully.";
            }
            catch (Exception ex)
            {
                apiResponse.StatusCode = (int)HttpStatusCode.InternalServerError;
                apiResponse.StatusReason = ex.Message;
            }

            apiResponse.Data = isDeleteOpearionCompleted;
            return apiResponse;
        }

        public async Task<ApiResponse<UserOrGroupRoleAssignmentDTO>> GetGroupRoleAssignmentAsync(string groupId)
        {
            var userRoles = new UserOrGroupRoleAssignmentDTO();

            var apiResponse = new ApiResponse<UserOrGroupRoleAssignmentDTO>();
            try
            {
                var tblUserRoles = (from userRole in _dbContext.TblUserRoleAssignments
                                    join role in _dbContext.TblRoles on userRole.role_id equals role.id
                                    where userRole.group_id == groupId
                                    select role).ToList();
                tblUserRoles.ForEach(role => userRoles.Roles.Add(_mapper.Map<RoleDTO>(role)));

                apiResponse.StatusCode = (int)HttpStatusCode.OK;
                apiResponse.StatusReason = "Role(s) assigned to group successfully.";
            }
            catch (Exception ex)
            {
                apiResponse.StatusCode = (int)HttpStatusCode.InternalServerError;
                apiResponse.StatusReason = ex.Message;
            }

            apiResponse.Data = userRoles;

            return apiResponse;
        }

        public async Task<ApiResponse<bool>> UpdateGroupRoleAssignmentsAsync(UserOrGroupRoleAssignmentDTO userRoleAssignmentDTO)
        {
            if ((await DeleteGroupRoleAssignmentsAsync(userRoleAssignmentDTO)).Data)
                return await AddGroupRoleAssignmentAsync(userRoleAssignmentDTO);
            else
                return new ApiResponse<bool>() { Data = false };
        }
    }
}
