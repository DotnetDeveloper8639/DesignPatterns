﻿using System.Collections.Generic;
using System.Threading.Tasks;
using User.Api.Models;
using User.API.Models;

namespace User.API.Services
{
    public interface IUserService
    {
        Task<ApiResponse<List<UserDTO>>> GetUsersAsync();
        Task<ApiResponse<UserDTO>> GetUserByIdAsync(string id);
        Task<ApiResponse<List<UserDTO>>> SearchUser(string searchTerm);
        Task<ApiResponse<bool>> UpdateUserAsync(UserDTO userDTO);
        Task<ApiResponse<string>> UpdateUserProfileAsync(UserProfileDTO userProfileDTO);
        Task<ApiResponse<bool>> DeleteUserAsync(string id);
        Task<ApiResponse<bool>> CreateUserAsync(UserDTO userDTO);
        Task<ApiResponse<List<UserDTO>>> GetUserListsFromAzureAsync();
        Task<ApiResponse<Dictionary<string, bool>>> AddUserToApplication(List<UserDTO> userDTO);
    }
}
