﻿using AutoMapper;
using Azure.Identity;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Graph;
using Microsoft.Identity.Client;
using Microsoft.Identity.Web;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using User.Api.Models;
using User.API.DbContextClass;
using User.API.EntityModel;
using User.API.Models;

namespace User.API.Services
{
    public class UserService : IUserService
    {
        private readonly UserManagementDbContext _dbContext;
        private readonly IMapper _mapper;
        private readonly IConfiguration configuration;
        private readonly IHttpContextAccessor httpContextAccessor;
        private readonly GraphServiceClient _graphClient;

        public UserService(UserManagementDbContext dbContext
            , IMapper mapper
            , IConfiguration configuration
            , IHttpContextAccessor httpContextAccessor)
        {
            this._dbContext = dbContext;
            this._mapper = mapper;
            this.configuration = configuration;
            this.httpContextAccessor = httpContextAccessor;
            _graphClient = GetGraphClientForUser(configuration);
        }

        private GraphServiceClient GetGraphClientForUser(IConfiguration configuration)
        {
            var scopes = new[] { "https://graph.microsoft.com/.default" };

            // Multi-tenant apps can use "common",
            // single-tenant apps must use the tenant ID from the Azure portal
            var tenantId = httpContextAccessor.HttpContext.User.GetTenantId();

            // Values from app registration
            var clientId = configuration["AzureAd:ClientId"];
            var clientSecret = Environment.GetEnvironmentVariable("CLIENT_SECRET");

            var options = new TokenCredentialOptions
            {
                AuthorityHost = AzureAuthorityHosts.AzurePublicCloud
            };

            // https://docs.microsoft.com/dotnet/api/azure.identity.clientsecretcredential
            var clientSecretCredential = new ClientSecretCredential(
                tenantId, clientId, clientSecret, options);

            return new GraphServiceClient(clientSecretCredential, scopes);

            //return new GraphServiceClient(authProvider);

        }
        public async Task<ApiResponse<bool>> CreateUserAsync(UserDTO userDTO)
        {
            bool isUserAdded = false;
            var apiResponse = new ApiResponse<bool>();
            try
            {
                var isExists = _dbContext.TblUsers.Where(u => u.email_address == userDTO.Email_Address).FirstOrDefault() != null;

                if (isExists)
                {
                    apiResponse.StatusCode = (int)HttpStatusCode.BadRequest;
                    apiResponse.StatusReason = "User already exists.";
                }
                else
                {
                    var entity = _mapper.Map<TblUser>(userDTO);
                    entity.id = Guid.NewGuid().ToString();

                    _dbContext.TblUsers.Add(entity);

                    await _dbContext.SaveChangesAsync();

                    isUserAdded = true;
                }
            }
            catch (Exception ex)
            {
                apiResponse.StatusCode = (int)HttpStatusCode.InternalServerError;
                apiResponse.StatusReason = ex.Message;
            }

            apiResponse.Data = isUserAdded;

            return apiResponse;
        }

        public async Task<ApiResponse<bool>> DeleteUserAsync(string id)
        {
            bool isEntityDeleted = false;
            var apiResponse = new ApiResponse<bool>();
            try
            {
                var entityToDelete = _dbContext.TblUsers.FirstOrDefault(u => u.id == id);
                if (entityToDelete != null)
                {
                    _dbContext.TblProjectStaffs
                        .RemoveRange(_dbContext.TblProjectStaffs.Where(ps => ps.user_id == entityToDelete.id));

                    _dbContext.TblUserRoleAssignments
                        .RemoveRange(_dbContext.TblUserRoleAssignments.Where(ura => ura.user_id == entityToDelete.id));

                    _dbContext.TblUsersGroupAssociations
                        .RemoveRange(_dbContext.TblUsersGroupAssociations.Where(uga => uga.members == entityToDelete.id));

                    //_dbContext.TblUsers.Remove(entityToDelete);
                    entityToDelete.isactive = false;
                    _dbContext.TblUsers.Update(entityToDelete);
                    _dbContext.SaveChanges();
                    isEntityDeleted = true;


                    var enterpriseAppServicePrinciple = await _graphClient.ServicePrincipals
                    .Request()
                    .Filter($"appId eq '{configuration["AzureAd:Frontend_ClientId"]}'")
                    .GetAsync();

                    if (enterpriseAppServicePrinciple.Count > 0)
                    {
                        var resourceId = enterpriseAppServicePrinciple[0].Id;

                        var adUser = await _graphClient.Users[entityToDelete.email_address]
                            .Request()
                            .GetAsync();

                        if (adUser is not null)
                        {
                            var appRoleAssignments = await _graphClient.Users[adUser.Id].AppRoleAssignments
                            .Request()
                            .Filter($"resourceId eq {resourceId}")
                            .GetAsync();

                            if (appRoleAssignments.Count > 0)
                            {
                                var appRoleAssignmentId = appRoleAssignments[0].Id;
                                await _graphClient.Users[adUser.Id].AppRoleAssignments[appRoleAssignmentId]
                                .Request()
                                .DeleteAsync();

                                isEntityDeleted = true;
                            }
                        }    
    
                    }

                    //if (isEntityDeleted)
                    //{
                    //    _dbContext.SaveChanges();
                    //    isEntityDeleted = true;
                    //}

                    apiResponse.StatusCode = (int)HttpStatusCode.OK;
                    apiResponse.StatusReason = "User deleted successfully.";
                }
                else
                {
                    apiResponse.StatusCode = (int)HttpStatusCode.NotFound;
                    apiResponse.StatusReason = "User does not exists.";
                }
            }
            catch (Exception ex)
            {
                apiResponse.StatusCode = (int)HttpStatusCode.InternalServerError;
                apiResponse.StatusReason = ex.Message;
            }

            apiResponse.Data = isEntityDeleted;
            return apiResponse;
        }

        public async Task<ApiResponse<UserDTO>> GetUserByIdAsync(string id)
        {
            var userDTO = new UserDTO();
            var apiResponse = new ApiResponse<UserDTO>();
            try
            {
                var userEntity = _dbContext.TblUsers.FirstOrDefault(user => user.id == id);

                if (userEntity != null)
                {
                    userDTO = _mapper.Map<UserDTO>(userEntity);

                    apiResponse.StatusCode = (int)HttpStatusCode.OK;
                    apiResponse.StatusReason = $"Fetching user data for the id {id} completed successfully.";
                }
                else
                {
                    apiResponse.StatusCode = (int)HttpStatusCode.NotFound;
                    apiResponse.StatusReason = "User does not exists.";
                }
            }
            catch (Exception ex)
            {
                apiResponse.StatusCode = (int)HttpStatusCode.InternalServerError;
                apiResponse.StatusReason = ex.Message;
            }

            apiResponse.Data = userDTO;
            return apiResponse;
        }

        public async Task<ApiResponse<List<UserDTO>>> GetUserListsFromAzureAsync()
        {
            var pendingUsers = new List<UserDTO>();
            var apiResponse = new ApiResponse<List<UserDTO>>();

            try
            {
                var enterpriseAppServicePrinciple = await _graphClient.ServicePrincipals
                    .Request()
                    .Filter($"appId eq '{configuration["AzureAd:Frontend_ClientId"]}'")
                    .GetAsync();
                if (enterpriseAppServicePrinciple.Count > 0)
                {
                    var allUsers = await _graphClient.Users.Request().GetAsync();

                    var appUsers = await _graphClient.ServicePrincipals[enterpriseAppServicePrinciple[0].Id].AppRoleAssignedTo
                    .Request()
                    .GetAsync();

                    var appUserIds = appUsers.Select(u => u.PrincipalId.ToString()).ToList();

                    pendingUsers.AddRange(allUsers.Where(u => !appUserIds.Contains(u.Id))
                        .Select(u => new UserDTO()
                        {
                            Display_Name = u.DisplayName,
                            Email_Address = u.Mail,
                            First_Name = u.GivenName,
                            Last_Name = u.Surname,
                            Id = u.Id,
                        }).ToList());
                    while (allUsers.NextPageRequest != null)
                    {
                        allUsers = await allUsers.NextPageRequest.GetAsync();

                        pendingUsers.AddRange(allUsers.Where(u => !appUserIds.Contains(u.Id))
                            .Select(u => new UserDTO()
                            {
                                Display_Name = u.DisplayName,
                                Email_Address = u.Mail,
                                First_Name = u.GivenName,
                                Last_Name = u.Surname,
                                Id = u.Id,
                            }).ToList());
                    }
                }
            }
            catch (Exception ex)
            {
                apiResponse.StatusCode = (int)HttpStatusCode.InternalServerError;
                apiResponse.StatusReason = ex.Message;
            }

            apiResponse.Data = pendingUsers;
            return apiResponse;
            //throw new NotImplementedException();
        }

        public async Task<ApiResponse<List<UserDTO>>> GetUsersAsync()
        {
            var apiResponse = new ApiResponse<List<UserDTO>>();
            var data = new List<UserDTO>();
            try
            {
                data = _mapper.Map<List<UserDTO>>(
                    _dbContext.TblUsers.Where(u =>u.isactive == true)
                    .Select(s =>new UserDTO
                    {
                        Id = s.id,
                        Display_Name = s.display_name,
                        Last_Name = s.last_name,
                        First_Name = s.first_name,
                        Login_Name = s.first_name,
                        Email_Address = s.email_address,
                        User_Roles = (from role in _dbContext.TblRoles
                                      join userRole in _dbContext.TblUserRoleAssignments on role.id equals userRole.role_id
                                      where userRole.user_id == s.id
                                      select role.role_name).ToList()}).ToList());
            }
            catch (Exception ex)
            {
                apiResponse.StatusCode = (int)HttpStatusCode.InternalServerError;
                apiResponse.StatusReason = ex.Message;
            }

            apiResponse.Data = data;

            return apiResponse;
        }

        public async Task<ApiResponse<bool>> UpdateUserAsync(UserDTO userDTO)
        {
            var isEntityUpdated = false;

            var apiResponse = new ApiResponse<bool>();
            try
            {
                var tblEntity = _dbContext.TblUsers.FirstOrDefault(u => u.id == userDTO.Id);
                if (tblEntity != null)
                {
                    tblEntity.display_name = userDTO.Display_Name;
                    tblEntity.email_address = userDTO.Email_Address;
                    tblEntity.last_name = userDTO.Last_Name;
                    tblEntity.first_name = userDTO.First_Name;

                    _dbContext.TblUsers.Update(tblEntity);

                    _dbContext.SaveChanges(true);

                    isEntityUpdated = true;

                    apiResponse.StatusCode = (int)HttpStatusCode.OK;
                    apiResponse.StatusReason = "Role deleted successfully.";
                }
                else
                {
                    apiResponse.StatusCode = (int)HttpStatusCode.NotFound;
                    apiResponse.StatusReason = "User does not exists.";
                }
            }
            catch (Exception ex)
            {
                apiResponse.StatusCode = (int)HttpStatusCode.InternalServerError;
                apiResponse.StatusReason = ex.Message;
            }

            apiResponse.Data = isEntityUpdated;
            return apiResponse;
        }

        public async Task<ApiResponse<Dictionary<string, bool>>> AddUserToApplication(List<UserDTO> userDTO)
        {
            var userAddedStatus = new Dictionary<string, bool>();
            var apiResponse = new ApiResponse<Dictionary<string, bool>>();
            try
            {
                var enterpriseAppServicePrinciple = await _graphClient.ServicePrincipals
                    .Request()
                    .Filter($"appId eq '{configuration["AzureAd:Frontend_ClientId"]}'")
                    .GetAsync();

                if (enterpriseAppServicePrinciple.Count > 0)
                {
                    var resourceId = Guid.Parse(enterpriseAppServicePrinciple[0].Id);
                    foreach (var user in userDTO)
                    {
                        userAddedStatus.Add(user.Id, false);
                        var appRoleAssignment = new AppRoleAssignment
                        {
                            PrincipalId = Guid.Parse(user.Id),
                            ResourceId = resourceId,
                            AppRoleId = Guid.Parse(configuration["AzureAd:AppRoleId"])
                        };

                        try
                        {
                            var result = await _graphClient.Users[user.Id].AppRoleAssignments
                            .Request()
                            .AddAsync(appRoleAssignment);

                            userAddedStatus[user.Id] = result != null;
                        }
                        catch (Exception)
                        {
                            userAddedStatus[user.Id] = false;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                apiResponse.StatusCode = (int)HttpStatusCode.InternalServerError;
                apiResponse.StatusReason = ex.Message;
            }
            apiResponse.Data = userAddedStatus;
            return apiResponse;
        }

        public async Task<ApiResponse<List<UserDTO>>> SearchUser(string searchTerm)
        {
            var apiResponse = new ApiResponse<List<UserDTO>>();
            var data = new List<UserDTO>();
            try
            {
                data = _mapper.Map<List<UserDTO>>(_dbContext.TblUsers
                    .Where(u => u.first_name.Contains(searchTerm)
                    || u.last_name.Contains(searchTerm)
                    || u.display_name.Contains(searchTerm) && u.isactive == true).ToList());
            }
            catch (Exception ex)
            {
                apiResponse.StatusCode = (int)HttpStatusCode.InternalServerError;
                apiResponse.StatusReason = ex.Message;
            }

            apiResponse.Data = data;

            return apiResponse;
        }
        public async Task<ApiResponse<string>> UpdateUserProfileAsync(UserProfileDTO userDTO)
        {
            var apiResponse = new ApiResponse<string>();
            try
            {
                var tblEntity = _dbContext.TblUsers.FirstOrDefault(u => u.id == userDTO.id);
                if (tblEntity != null)
                {
                    tblEntity.profile_data = JsonConvert.SerializeObject(userDTO);
                    _dbContext.SaveChanges();

                    apiResponse.StatusCode = (int)HttpStatusCode.OK;

                    apiResponse.StatusReason = "updated successfully.";
                }
                else
                {
                    apiResponse.StatusCode = (int)HttpStatusCode.NotFound;
                    apiResponse.StatusReason = "updation failed.";
                }
            }
            catch (Exception ex)
            {
                apiResponse.StatusCode = (int)HttpStatusCode.InternalServerError;
                apiResponse.StatusReason = ex.Message;
            }
            apiResponse.Data = JsonConvert.SerializeObject(userDTO);
            return apiResponse;
        }
    }
}
