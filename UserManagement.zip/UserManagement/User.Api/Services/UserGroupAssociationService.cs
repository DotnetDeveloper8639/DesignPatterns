﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using User.API.DbContextClass;
using User.API.EntityModel;
using User.API.Models;

namespace User.API.Services
{
    internal class UserGroupAssociationService : IUserGroupAssociationService
    {
        private readonly UserManagementDbContext _dbContext;
        private readonly IMapper _mapper;
        private readonly IGroupService groupService;

        public UserGroupAssociationService(UserManagementDbContext dbContext
            , IMapper mapper
            , IGroupService groupService)
        {
            this._dbContext = dbContext;
            this._mapper = mapper;
            this.groupService = groupService;
        }
        public async Task<ApiResponse<bool>> AddUsersToGroup(UserGroupAssociationDTO userGroupAssociation)
        {
            bool isEntityAdded = false;
            var apiResponse = new ApiResponse<bool>();
            try
            {

                var entityList = new List<TblUserAndGroupAssociation>();
                userGroupAssociation.Users?.ForEach(user =>
                {
                    if (!_dbContext.TblUsersGroupAssociations
                    .Any(uga => uga.group_id == userGroupAssociation.Group.id && uga.members == user.Id))
                    {
                        entityList.Add(new TblUserAndGroupAssociation()
                        {
                            members = user.Id,
                            group_id = userGroupAssociation.Group.id
                        });
                    }

                });

                await _dbContext.TblUsersGroupAssociations.AddRangeAsync(entityList);

                _dbContext.SaveChanges();
                isEntityAdded = true;

                apiResponse.StatusCode = (int)HttpStatusCode.OK;
                apiResponse.StatusReason = "User(s) added to group successfully.";
            }
            catch (Exception ex)
            {
                apiResponse.StatusCode = (int)HttpStatusCode.InternalServerError;
                apiResponse.StatusReason = ex.Message;
            }

            apiResponse.Data = isEntityAdded;

            return apiResponse;
        }

        public async Task<ApiResponse<bool>> DeleteUsersFromGroup(UserGroupAssociationDTO userGroupAssociation)
        {
            bool isDeleteOpearionCompleted = false;
            var apiResponse = new ApiResponse<bool>();
            try
            {
                var userIds = userGroupAssociation?.Users?.Select(u => u.Id).ToList() ?? new List<string>();

                var entitiesTobeDeleted = _dbContext.TblUsersGroupAssociations
                    .Where(uga => uga.group_id == userGroupAssociation.Group.id)
                    .ToList()
                    .Where(uga => userIds.Contains(uga.members));

                _dbContext.TblUsersGroupAssociations.RemoveRange(entitiesTobeDeleted);
                _dbContext.SaveChanges();

                isDeleteOpearionCompleted = true;

                apiResponse.StatusCode = (int)HttpStatusCode.OK;
                apiResponse.StatusReason = "User(s) deleted from group successfully.";
            }
            catch (Exception ex)
            {
                apiResponse.StatusCode = (int)HttpStatusCode.InternalServerError;
                apiResponse.StatusReason = ex.Message;
            }

            apiResponse.Data = isDeleteOpearionCompleted;

            return apiResponse;
        }

        public async Task<ApiResponse<List<UserDTO>>> GetUsersByGroupId(string groupId)
        {
            var data = new List<UserDTO>();
            var apiResponse = new ApiResponse<List<UserDTO>>();
            try
            {
                data = _mapper.Map<List<UserDTO>>((from u in _dbContext.TblUsers
                                                   join uga in _dbContext.TblUsersGroupAssociations on u.id equals uga.members
                                                   where uga.group_id == groupId
                                                   select u));
            }
            catch (Exception ex)
            {
                apiResponse.StatusCode = (int)HttpStatusCode.InternalServerError;
                apiResponse.StatusReason = ex.Message;
            }

            apiResponse.Data = data;
            return apiResponse;
        }

        public async Task<ApiResponse<bool>> UpdateGroupUsers(UserGroupAssociationDTO userGroupAssociation)
        {
            bool isEntityUpdated = false;
            var apiResponse = new ApiResponse<bool>();
            try
            {
                var isGroupCreated = true;
                var groupCreationOutput = new ApiResponse<string>();
                if (string.IsNullOrEmpty(userGroupAssociation.Group.id))
                {
                    groupCreationOutput = (await groupService.CreateGroupAsync(userGroupAssociation.Group));
                    userGroupAssociation.Group.id = groupCreationOutput.Data;
                    isGroupCreated = groupCreationOutput.StatusCode == (int)HttpStatusCode.OK;
                }
                if (isGroupCreated)
                {
                    var newUsers = userGroupAssociation.Users.Select(perm => perm.Id);

                    var existingUsers = _dbContext.TblUsersGroupAssociations
                        .Where(uga => uga.group_id == userGroupAssociation.Group.id)
                        .Select(uga => uga.members).ToList();

                    var usersToAdd = newUsers.Except(existingUsers).ToList();
                    //var usersToRemove = existingUsers.Except(newUsers).ToList();

                    if (usersToAdd.Count > 0)
                    {
                        var newEntities = new List<TblUserAndGroupAssociation>();
                        usersToAdd.ForEach(user => newEntities.Add(new TblUserAndGroupAssociation()
                        {
                            group_id = userGroupAssociation.Group.id,
                            members = user
                        }));

                        _dbContext.TblUsersGroupAssociations.AddRange(newEntities);
                        _dbContext.SaveChanges();
                    }

                    //if (usersToRemove.Count > 0)
                    //{
                    //    _dbContext.TblUsersGroupAssociations.RemoveRange(_dbContext.TblUsersGroupAssociations
                    //        .Where(uga => uga.group_id == userGroupAssociation.Group.id).ToList()
                    //        .Where(user => usersToRemove.Contains(user.members)));
                    //    _dbContext.SaveChanges(true);
                    //}

                    isEntityUpdated = true;
                }
                else
                {
                    apiResponse.StatusCode = (int)HttpStatusCode.InternalServerError;
                    apiResponse.StatusReason = groupCreationOutput.StatusReason;
                }
                //foreach (var user in userGroupAssociation.Users)
                //{

                //}
            }
            catch (Exception ex)
            {
                apiResponse.StatusCode = (int)HttpStatusCode.InternalServerError;
                apiResponse.StatusReason = ex.Message;
            }

            apiResponse.Data = isEntityUpdated;
            return apiResponse;
        }
    }
}
