﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using User.API.DbContextClass;
using User.API.EntityModel;
using User.API.Models;


namespace User.API.Services
{
    internal class GroupService : IGroupService
    {
        private readonly UserManagementDbContext _dbContext;
        private readonly IMapper _mapper;
        public GroupService(UserManagementDbContext dbContext
            , IMapper mapper)
        {
            this._dbContext = dbContext;
            this._mapper = mapper;
        }
        public async Task<ApiResponse<string>> CreateGroupAsync(GroupDTO groupDTO)
        {
            var apiResponse = new ApiResponse<string>();

            string groupId = "";
            try
            {
                var isExists = _dbContext.TblGroups.Where(g => g.group_name == groupDTO.group_name).FirstOrDefault() != null;
                if (isExists)
                {
                    apiResponse.StatusCode = (int)HttpStatusCode.BadRequest;
                    apiResponse.StatusReason = "Group name already exists.";
                }
                else
                {
                    var entity = _mapper.Map<TblGroup>(groupDTO);
                    entity.id = Guid.NewGuid().ToString();

                    _dbContext.TblGroups.Add(entity);

                    await _dbContext.SaveChangesAsync();

                    groupId = entity.id;

                    apiResponse.StatusCode = (int)HttpStatusCode.OK;
                    apiResponse.StatusReason = "Group created successfully.";
                }
            }
            catch (Exception ex)
            {
                apiResponse.StatusCode = (int)HttpStatusCode.InternalServerError;
                apiResponse.StatusReason = ex.Message;
            }

            apiResponse.Data = groupId;
            return apiResponse;
        }

        public async Task<ApiResponse<bool>> DeleteGroupAsync(string id)
        {
            var apiResponse = new ApiResponse<bool>();

            bool isEntityDeleted = false;
            try
            {
                var entityToDelete = _dbContext.TblGroups.FirstOrDefault(g => g.id == id);
                if (entityToDelete != null)
                {
                    _dbContext.TblUsersGroupAssociations
                        .RemoveRange(_dbContext.TblUsersGroupAssociations.Where(ug => ug.group_id == entityToDelete.id).ToList());

                    _dbContext.TblUserRoleAssignments
                        .RemoveRange(_dbContext.TblUserRoleAssignments.Where(ra => ra.group_id == entityToDelete.id).ToList());

                    _dbContext.TblProjectStaffs
                        .RemoveRange(_dbContext.TblProjectStaffs.Where(ps => ps.group_id == entityToDelete.id).ToList());

                    _dbContext.SaveChanges();

                    _dbContext.TblGroups.Remove(entityToDelete);

                    _dbContext.SaveChanges();

                    isEntityDeleted = true;

                    apiResponse.StatusCode = (int)HttpStatusCode.OK;
                    apiResponse.StatusReason = "Group deleted successfully.";
                }
                else
                {
                    apiResponse.StatusCode = (int)HttpStatusCode.NotFound;
                    apiResponse.StatusReason = "Group does not exists.";
                }
            }
            catch (Exception ex)
            {
                apiResponse.StatusCode = (int)HttpStatusCode.InternalServerError;
                apiResponse.StatusReason = ex.Message;
            }

            apiResponse.Data = isEntityDeleted;
            return apiResponse;
        }

        public async Task<ApiResponse<GroupDTO>> GetGroupByIdAsync(string id)
        {
            var groupDTO = new GroupDTO();
            var apiResponse = new ApiResponse<GroupDTO>();
            try
            {
                var tblEntity = _dbContext.TblGroups.FirstOrDefault(group => group.id == id);

                if (tblEntity != null)
                {
                    groupDTO = _mapper.Map<GroupDTO>(tblEntity);
                    apiResponse.StatusCode = (int)HttpStatusCode.OK;
                    apiResponse.StatusReason = $"Fetching group data for the id {id} completed successfully.";
                }
                else
                {
                    apiResponse.StatusCode = (int)HttpStatusCode.NotFound;
                    apiResponse.StatusReason = "Group does not exists.";
                }
            }
            catch (Exception ex)
            {
                apiResponse.StatusCode = (int)HttpStatusCode.InternalServerError;
                apiResponse.StatusReason = ex.Message;
            }

            apiResponse.Data = groupDTO;

            return apiResponse;
        }

        public async Task<ApiResponse<List<GroupDTO>>> GetGroupsAsync()
        {
            var apiResponse = new ApiResponse<List<GroupDTO>>();
            var data = new List<GroupDTO>();
            try
            {
                data = _mapper.Map<List<GroupDTO>>(_dbContext.TblGroups.ToList());
            }
            catch (Exception ex)
            {
                apiResponse.StatusCode = (int)HttpStatusCode.InternalServerError;
                apiResponse.StatusReason = ex.Message;
            }

            apiResponse.Data = data;

            return apiResponse;

        }

        public async Task<ApiResponse<List<GroupDTOWithUser>>> GetGroupsWithUserCount()
        {
            var returnObj = new List<GroupDTOWithUser>();
            var apiResponse = new ApiResponse<List<GroupDTOWithUser>>();
            try
            {
                var allGroups = _dbContext.TblGroups.ToList();

                foreach (var grp in allGroups)
                {
                    returnObj.Add(new GroupDTOWithUser()
                    {
                        group_email_address = grp.group_email_address,
                        group_name = grp.group_name,
                        id = grp.id,
                        UserCount = _dbContext.TblUsersGroupAssociations.Where(uga => uga.group_id == grp.id).ToList().Count
                    });
                }
            }
            catch (Exception ex)
            {
                apiResponse.StatusCode = (int)HttpStatusCode.InternalServerError;
                apiResponse.StatusReason = ex.Message;
            }

            apiResponse.Data = returnObj;
            return apiResponse;
        }

        public async Task<ApiResponse<bool>> UpdateGroupAsync(GroupDTO groupDTO)
        {
            var isEntityUpdated = false;
            var apiResponse = new ApiResponse<bool>();
            try
            {
                var tblEntity = _dbContext.TblGroups.FirstOrDefault(g => g.id == groupDTO.id);
                if (tblEntity != null)
                {
                    tblEntity.group_email_address = groupDTO.group_email_address;
                    tblEntity.group_name = groupDTO.group_name;
                    
                    _dbContext.TblGroups.Update(tblEntity);

                    _dbContext.SaveChanges(true);

                    isEntityUpdated = true;

                    apiResponse.StatusCode = (int)HttpStatusCode.OK;
                    apiResponse.StatusReason = $"group data updated successfully.";
                }
                else
                {
                    apiResponse.StatusCode = (int)HttpStatusCode.NotFound;
                    apiResponse.StatusReason = "Group does not exists.";
                }
            }
            catch (Exception ex)
            {
                apiResponse.StatusCode = (int)HttpStatusCode.InternalServerError;
                apiResponse.StatusReason = ex.Message;
            }

            apiResponse.Data = isEntityUpdated;

            return apiResponse;
        }
    }
}
