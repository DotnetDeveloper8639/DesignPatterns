﻿using System.Collections.Generic;
using System.Threading.Tasks;
using User.API.Models;

namespace User.API.Services
{
    public interface IGroupService
    {
        Task<ApiResponse<List<GroupDTO>>> GetGroupsAsync();
        Task<ApiResponse<GroupDTO>> GetGroupByIdAsync(string id);
        Task<ApiResponse<bool>> UpdateGroupAsync(GroupDTO groupDTO);
        Task<ApiResponse<bool>> DeleteGroupAsync(string id);
        Task<ApiResponse<string>> CreateGroupAsync(GroupDTO groupDTO);

        Task<ApiResponse<List<GroupDTOWithUser>>> GetGroupsWithUserCount();
    }
}
