﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using User.API.Models;
using User.API.Services;

namespace User.API.Controllers
{
    [Route("/api/group")]
    public class GroupController : BluePrintBaseController
    {
        private readonly IGroupService groupService;

        public GroupController(IGroupService groupService)
        {
            this.groupService = groupService;
        }

        [HttpGet]
        [Authorize(Roles = "Group.Read,Group.Write")]
        [Route("{id}")]
        public async Task<IActionResult> GetGroupById(string id)
        {
            return await FormatOutput(groupService.GetGroupByIdAsync(id));
        }

        [Authorize(Roles = "Group.Write,Group.Edit,Group.Read")]
        [Route("groups")]
        [HttpGet]
        public async Task<IActionResult> GetAllGroups()
        {
            return await FormatOutput(groupService.GetGroupsAsync());
        }

        [Authorize(Roles = "Group.Write,Group.Edit,Group.Read")]
        [Route("groupwithusercount")]
        [HttpGet]
        public async Task<IActionResult> GetAllGroupsWithUserCount()
        {
            return await FormatOutput(groupService.GetGroupsWithUserCount());
        }

        [Authorize(Roles = "Group.Write,Group.Edit,Group.Read")]
        [Route("")]
        [HttpPost]
        public async Task<IActionResult> CreateGroup([FromBody] GroupDTO group)
        {
            return await FormatOutput(groupService.CreateGroupAsync(group));
        }

        [Authorize(Roles = "Group.Write,Group.Read")]
        [Route("")]
        [HttpPut]
        public async Task<IActionResult> UpdateGroup([FromBody] GroupDTO group)
        {
            return await FormatOutput(groupService.UpdateGroupAsync(group));
        }

        [Authorize(Roles = "Group.Delete,Group.Edit")]
        [Route("{id}")]
        [HttpDelete]
        public async Task<IActionResult> DeleteGroup(string id)
        {
            return await FormatOutput(groupService.DeleteGroupAsync(id));
        }
    }
}