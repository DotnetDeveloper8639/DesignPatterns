﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using User.API.Models;
using User.API.Services;

namespace User.API.Controllers
{
    [Route("/api/ugassociation")]
    public class UserGroupAssociationController : BluePrintBaseController
    {
        private readonly IUserGroupAssociationService userGroupAssociationService;

        public UserGroupAssociationController(IUserGroupAssociationService userGroupAssociation)
        {
            this.userGroupAssociationService = userGroupAssociation;
        }

        [Authorize(Roles = "UGAssociation.Read,UGAssociation.Write")]
        [Route("group/{id}/users")]
        [HttpGet]
        public async Task<IActionResult> GetGroupUsers(string id)
        {
            return await FormatOutput(this.userGroupAssociationService.GetUsersByGroupId(id));
        }

        [Authorize(Roles = "UGAssociation.Edit,UGAssociation.Write")]
        [HttpPost]
        public async Task<IActionResult> AddUsersToGroup([FromBody] UserGroupAssociationDTO userGroupAssociationDTO)
        {
            return await FormatOutput(this.userGroupAssociationService.UpdateGroupUsers(userGroupAssociationDTO));
        }

        [Authorize(Roles = "UGAssociation.Delete,UGAssociation.Edit,UGAssociation.Write")]
        [HttpPost]
        [Route("deleteusers")]
        public async Task<IActionResult> RemoveUsersFromGroup([FromBody] UserGroupAssociationDTO userGroupAssociationDTO)
        {
            return await FormatOutput(this.userGroupAssociationService.DeleteUsersFromGroup(userGroupAssociationDTO));
        }
    }
}
