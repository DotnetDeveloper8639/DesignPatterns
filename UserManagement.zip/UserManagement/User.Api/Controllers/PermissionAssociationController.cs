﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using User.API.Models;
using User.API.Services;

namespace User.API.Controllers
{
    [Route("/api/userpermissionassociation")]
    public class PermissionAssociationController : BluePrintBaseController
    {
        private readonly IPermissionAssociationService permissionAssociationService;

        public PermissionAssociationController(IPermissionAssociationService permissionAssociationService)
        {
            this.permissionAssociationService = permissionAssociationService;
        }

        [Authorize(Roles = "PermAssociation.Read,PermAssociation.Write")]
        [Route("getpermissions")]
        [HttpGet]
        public async Task<IActionResult> GetPermissions()
        {
            return await FormatOutput(this.permissionAssociationService.GetAllPermissionAssociations());
        }

        [Authorize(Roles = "PermAssociation.Write,PermAssociation.Read")]
        [Route("updatepermissions")]
        [HttpPost]
        public async Task<IActionResult> UpdatePermisison([FromBody]List<PermissionAssociationDTO> permissionAssociationDTOs)
        {
            return await FormatOutput(this.permissionAssociationService.UpdateRolePermission(permissionAssociationDTOs));
        }

        [Authorize(Roles = "PermAssociation.Write,PermAssociation.Read")]
        [Route("permissions")]
        [HttpGet]
        public async Task<IActionResult> GetAllPermissions()
        {
            return await FormatOutput(this.permissionAssociationService.GetAllPermission());
        }
    }
}
