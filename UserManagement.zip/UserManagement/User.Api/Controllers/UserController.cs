﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using User.Api.Models;
using User.API.Models;
using User.API.Services;

namespace User.API.Controllers
{
    [Route("/api/user")]
    public class UserController : BluePrintBaseController
    {
        private readonly IUserService userService;

        public UserController(IUserService userService)
        {
            this.userService = userService;
        }

        [HttpGet]
        [Authorize(Roles = "User.Edit,User.Write,User.Read")]
        [Route("users")]
        public async Task<IActionResult> GetAllUsers()
        {
            return await FormatOutput(userService.GetUsersAsync());
        }

        [HttpGet]
        [Authorize(Roles = "User.Edit,User.Write,User.Read")]
        [Route("users/{searchTerm}")]
        public async Task<IActionResult> SearchAllUsers(string searchTerm)
        {
            return await FormatOutput(userService.SearchUser(searchTerm));
        }

        [HttpGet]
        [AllowAnonymous]
        [Authorize(Roles = "User.Edit,User.Write,User.Read")]
        [Route("adusers")]
        public async Task<IActionResult> GetAllADUsers()
        {
            return await FormatOutput(userService.GetUserListsFromAzureAsync());
        }

        [HttpGet]
        [Authorize(Roles = "User.Edit,User.Write,User.Read")]
        [Route("{id}")]
        public async Task<IActionResult> GetUser(string id)
        {
            return await FormatOutput(userService.GetUserByIdAsync(id));
        }

        //[HttpPost]
        //[Authorize(Roles = "User.Create,User.Manage")]
        //[Route("")]
        //public async Task<bool> CreateUser([FromBody] UserDTO userDTO)
        //{
        //    return await userService.CreateUserAsync(userDTO);
        //}

        [HttpPost]
        [Authorize(Roles = "User.Write,User.Edit")]
        [Route("addusertoad")]
        public async Task<IActionResult> CreateUserToAD([FromBody]List<UserDTO> userDTO)
        {
            return await FormatOutput(userService.AddUserToApplication(userDTO));
        }

        //[HttpPut]
        //[Authorize(Roles = "User.Update,User.Manage")]
        //[Route("")]
        //public async Task<bool> UpdateUser([FromBody]UserDTO userDTO)
        //{
        //    return await userService.UpdateUserAsync(userDTO);
        //}

        [HttpDelete]
        [Authorize(Roles = "User.Delete,User.Edit")]
        [Route("{id}")]
        public async Task<IActionResult> DeleteUser(string id)
        {
            return await FormatOutput(userService.DeleteUserAsync(id));
        }

        [HttpPut]
        [Authorize(Roles = "User.Write,User.Edit")]
        [Route("userprofile")]
        public async Task<IActionResult> UpdateUserProfile([FromBody] UserProfileDTO userProfileDTO)
        {
            return await FormatOutput(userService.UpdateUserProfileAsync(userProfileDTO));
        }
    }
}
