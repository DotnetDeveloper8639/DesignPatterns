﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using User.API.Models;
using User.API.Services;

namespace User.API.Controllers
{
    [Route("/api/grouproleassociation")]
    public class GroupRoleAssociationController : BluePrintBaseController
    {
        private readonly IGroupRoleAssignmentService groupRoleAssignmentService;

        public GroupRoleAssociationController(IGroupRoleAssignmentService groupRoleAssignmentService)
        {
            this.groupRoleAssignmentService = groupRoleAssignmentService;
        }

        [HttpGet]
        [Authorize(Roles = "GRAssociation.Read,GRAssociation.Write")]
        [Route("{groupId}")]
        public async Task<IActionResult> GetRolesByGroupId(string groupId)
        {
            return await FormatOutput(groupRoleAssignmentService.GetGroupRoleAssignmentAsync(groupId));
        }

        [HttpPost]
        [Authorize(Roles = "GRAssociation.Write,GRAssociation.Read")]
        [Route("updategrouproles")]

        public async Task<IActionResult> UpdateGroupRoles([FromBody] UserOrGroupRoleAssignmentDTO groupRoleDto)
        {
            return await FormatOutput(groupRoleAssignmentService.UpdateGroupRoleAssignmentsAsync(groupRoleDto));  
        }

        [HttpPost]
        [Authorize(Roles = "GRAssociation.Delete,GRAssociation.Edit")]
        [Route("deletegrouproles")]

        public async Task<IActionResult> DeleteGroupRoles([FromBody]UserOrGroupRoleAssignmentDTO groupRoleDto)
        {
            return await FormatOutput(groupRoleAssignmentService.DeleteGroupRoleAssignmentsAsync(groupRoleDto));
        }

        [HttpPost]
        [Authorize(Roles = "GRAssociation.Write,GRAssociation.Edit")]
        [Route("addgrouproles")]

        public async Task<IActionResult> AddGroupRoles([FromBody]UserOrGroupRoleAssignmentDTO groupRoleDto)
        {
            return await FormatOutput(groupRoleAssignmentService.AddGroupRoleAssignmentAsync(groupRoleDto));
        }

    }
}
