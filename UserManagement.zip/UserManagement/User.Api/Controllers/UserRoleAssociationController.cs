﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using User.API.Models;
using User.API.Services;

namespace User.API.Controllers
{
    [Route("/api/userroleassociation")]
    [Authorize]
    public class UserRoleAssociationController : BluePrintBaseController
    {
        private readonly IUserRoleAssignmentService userRoleAssignmentService;

        public UserRoleAssociationController(IUserRoleAssignmentService userRoleAssignmentService)
        {
            this.userRoleAssignmentService = userRoleAssignmentService;
        }

        [HttpGet]
        [Authorize(Roles = "URAssociation.Read,URAssociation.Write,URAssociation.Edit")]
        [Route("{userId}")]
        public async Task<IActionResult> GetRolesByUserId(string userId)
        {
            return await FormatOutput(userRoleAssignmentService.GetUserRoleAssignmentAsync(userId));
        }

        [HttpGet]
        [Authorize(Roles = "URAssociation.Read,URAssociation.Write,URAssociation.Edit")]
        [Route("{roleId}/users")]
        public async Task<IActionResult> GetUserByRoleId(string roleId)
        {
            return await FormatOutput(userRoleAssignmentService.GetUsersByRoleAsync(roleId));
        }

        [HttpGet]
        [Authorize(Roles = "URAssociation.Read,URAssociation.Write")]
        [Route("getuserswithrole")]
        public async Task<IActionResult> GetUsersWithRole()
        {
            return await FormatOutput(userRoleAssignmentService.GetUsersWithRole());
        }

        [HttpPost]
        [Authorize(Roles = "URAssociation.Write,URAssociation.Edit")]
        [Route("updateuserroles")]

        public async Task<IActionResult> UpdateUserRoles([FromBody] UserOrGroupRoleAssignmentDTO userRoleDto)
        {
            return await FormatOutput(userRoleAssignmentService.UpdateUserRoleAssignmentsAsync(userRoleDto));
        }

        [HttpPost]
        [Authorize(Roles = "URAssociation.Delete,URAssociation.Edit")]
        [Route("deleteuserroles")]

        public async Task<IActionResult> DeleteUserRoles([FromBody] UserOrGroupRoleAssignmentDTO userRoleDto)
        {
            return await FormatOutput(userRoleAssignmentService.DeleteUserRoleAssignmentsAsync(userRoleDto));
        }

        [HttpPost]
        [Authorize(Roles = "URAssociation.Delete,URAssociation.Edit")]
        [Route("deleteusersfromrole")]

        public async Task<IActionResult> DeleteRoleUsers([FromBody] RoleUserAssociationDTO roleUserAssociationDTO)
        {
            return await FormatOutput(userRoleAssignmentService.DeleteUsersFromRole(roleUserAssociationDTO));
        }

        [HttpPost]
        [Authorize(Roles = "URAssociation.Write,URAssociation.Edit")]
        [Route("adduserroles")]

        public async Task<IActionResult> AddUserRoles([FromBody] UserOrGroupRoleAssignmentDTO userRoleDto)
        {
            return await FormatOutput(userRoleAssignmentService.AddUserRoleAssignmentAsync(userRoleDto));
        }

        [HttpPost]
        [Authorize(Roles = "URAssociation.Write,URAssociation.Edit")]
        [Route("addroletousers")]

        public async Task<IActionResult> AddRoleToUsers([FromBody] RoleUserAssociationDTO roleUserDto)
        {
            return await FormatOutput(userRoleAssignmentService.AddRoleToUsers(roleUserDto));
        }
    }
}
