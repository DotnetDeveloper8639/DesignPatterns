﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using User.API.Models;
using User.API.Services;

namespace User.API.Controllers
{
    [Route("/api/role")]
    public class RoleController : BluePrintBaseController
    {
        private readonly IRoleService roleService;

        public RoleController(IRoleService roleService)
        {
            this.roleService = roleService;
        }

        [HttpGet]
        [Authorize(Roles = "Role.Read,Role.Wite")]
        [Route("{id}")]
        public async Task<IActionResult> GetRoleById(string id)
        {
            return await FormatOutput(roleService.GetRoleByIdAsync(id));
        }

        [Authorize(Roles = "Role.Read,Role.Wite")]
        [Route("roles")]
        [HttpGet]
        public async Task<IActionResult> GetAllRoles()
        {
            return await FormatOutput(roleService.GetAllRolesAsync());
        }

        [Authorize(Roles = "Role.Read,Role.Wite,Role.Edit")]
        [Route("")]
        [HttpPost]
        public async Task<IActionResult> CreateRole([FromBody] RoleDTO role)
        {
            return await FormatOutput(roleService.AddNewRoleAsync(role));
        }

        [Authorize(Roles = "Role.Read,Role.Wite,Role.Edit")]
        [Route("")]
        [HttpPut]
        public async Task<IActionResult> UpdateRole([FromBody] RoleDTO role)
        {
            return await FormatOutput(roleService.UpdateRoleAsync(role));
        }

        [Authorize(Roles = "Role.Delete,Role.Edit")]
        [Route("{id}")]
        [HttpDelete]
        public async Task<IActionResult> DeleteRole(string id)
        {
            return await FormatOutput(roleService.RemoveRoleAsync(id));
        }
    }
}
