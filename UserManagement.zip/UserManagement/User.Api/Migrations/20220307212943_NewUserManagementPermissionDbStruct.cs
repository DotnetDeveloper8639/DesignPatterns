﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace User.Api.Migrations
{
    public partial class NewUserManagementPermissionDbStruct : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
