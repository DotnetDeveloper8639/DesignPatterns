﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace User.Api.Migrations
{
    public partial class NewUserManagementDbStructure : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            //migrationBuilder.CreateTable(
            //    name: "tblGroups",
            //    columns: table => new
            //    {
            //        id = table.Column<string>(type: "nvarchar(50)", nullable: false),
            //        group_name = table.Column<string>(type: "nvarchar(160)", nullable: false),
            //        group_email_address = table.Column<string>(type: "nvarchar(255)", nullable: true)
            //    },
            //    constraints: table =>
            //    {
            //        table.PrimaryKey("PK_tblGroups", x => x.id);
            //    });

            migrationBuilder.CreateTable(
                name: "tblPermissionAssociation",
                columns: table => new
                {
                    id = table.Column<string>(type: "nvarchar(50)", nullable: false),
                    role_id = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    permission_id = table.Column<string>(type: "nvarchar(50)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblPermissionAssociation", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tblPermissions",
                columns: table => new
                {
                    id = table.Column<string>(type: "nvarchar(50)", nullable: false),
                    name = table.Column<string>(type: "nvarchar(160)", nullable: false),
                    display_name = table.Column<string>(type: "nvarchar(160)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblPermissions", x => x.id);
                });

            //migrationBuilder.CreateTable(
            //    name: "tblRoles",
            //    columns: table => new
            //    {
            //        id = table.Column<string>(type: "nvarchar(50)", nullable: false),
            //        role_name = table.Column<string>(type: "nvarchar(160)", nullable: true)
            //    },
            //    constraints: table =>
            //    {
            //        table.PrimaryKey("PK_tblRoles", x => x.id);
            //    });

            //migrationBuilder.CreateTable(
            //    name: "tblUserAndGroupAssociation",
            //    columns: table => new
            //    {
            //        id = table.Column<string>(type: "nvarchar(50)", nullable: false),
            //        members = table.Column<string>(type: "nvarchar(50)", nullable: true),
            //        group_id = table.Column<string>(type: "nvarchar(50)", nullable: true)
            //    },
            //    constraints: table =>
            //    {
            //        table.PrimaryKey("PK_tblUserAndGroupAssociation", x => x.id);
            //    });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            //migrationBuilder.DropTable(
            //    name: "tblGroups");

            migrationBuilder.DropTable(
                name: "tblPermissionAssociation");

            migrationBuilder.DropTable(
                name: "tblPermissions");

            //migrationBuilder.DropTable(
            //    name: "tblRoles");

            //migrationBuilder.DropTable(
            //    name: "tblUserAndGroupAssociation");
        }
    }
}
