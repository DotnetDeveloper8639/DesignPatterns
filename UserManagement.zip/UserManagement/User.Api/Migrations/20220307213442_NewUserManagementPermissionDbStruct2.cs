﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace User.Api.Migrations
{
    public partial class NewUserManagementPermissionDbStruct2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
