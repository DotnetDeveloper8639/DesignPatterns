﻿using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Tenant.Service;
using User.API.EntityModel;
using Microsoft.Identity.Web;

namespace User.API.DbContextClass
{
    public class UserManagementDbContext : DbContext
    {
        private readonly IConfiguration _configuration;
        private readonly IHttpContextAccessor httpContextAccessor;
        private readonly ITenantService tenantService;

        public UserManagementDbContext()
        {
        }

        public UserManagementDbContext(DbContextOptions<UserManagementDbContext> options
            , IConfiguration configuration
            , IHttpContextAccessor httpContextAccessor
            , ITenantService tenantService)
                     : base(options)
        {
            _configuration = configuration;
            this.httpContextAccessor = httpContextAccessor;
            this.tenantService = tenantService;
        }

        public virtual DbSet<TblUser> TblUsers { get; set; }
        public virtual DbSet<TblUserRoleAssignment> TblUserRoleAssignments { get; set; }
        public virtual DbSet<TblRole> TblRoles { get; set; }
        public virtual DbSet<TblGroup> TblGroups { get; set; }
        public virtual DbSet<TblPermission> TblPermissions { get; set; }
        public virtual DbSet<TblPermissionAssociation> TblPermissionAssociations { get; set; }
        public virtual DbSet<TblUserAndGroupAssociation> TblUsersGroupAssociations { get;set; }
        public virtual DbSet<TblProjectStaff> TblProjectStaffs { get; set; }

        //protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        //{
        //    optionsBuilder.UseSqlServer(_configuration.GetConnectionString("sqlConnection"));
        //}

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            var tenantInfo = "Server=tcp:dna-sql-westeurman-dev01.database.windows.net,1433;Initial Catalog=DNA-Blueprint-Q-DB;Persist Security Info=False;User ID=blueprintschqdbln;Password=YEqxU5kA3P4m;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;";
            //var tenantInfo = "Server=tcp:dna-sql-westeurman-dev01.database.windows.net,1433;Initial Catalog=DNA-BlueprintSchmersalDB;Persist Security Info=False;User ID=blueprintschpdbln;Password=vxNlPLVrM9Aj;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;";


            optionsBuilder.UseSqlServer(tenantInfo);

            base.OnConfiguring(optionsBuilder);
        }
    }
}
