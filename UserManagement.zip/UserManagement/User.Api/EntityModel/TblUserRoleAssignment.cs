﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace User.API.EntityModel
{
    [Table("tblRoleAssignment")]
    public class TblUserRoleAssignment
    {
        public TblUserRoleAssignment()
        {
            this.id = Guid.NewGuid().ToString();
        }

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column(TypeName = "nvarchar(50)")]
        public string id { get; set; }
        [Column("user_id", TypeName = "nvarchar(50)")]
        [ForeignKey("tblUsers")]
        public string? user_id { get; set; }

        [Column("group_id", TypeName = "nvarchar(50)")]
        [ForeignKey("tblGroups")]
        public string? group_id { get; set; }

        [Column("role_id", TypeName = "nvarchar(50)")]
        [ForeignKey("tblRoles")]
        public string role_id { get; set; }
    }
}
