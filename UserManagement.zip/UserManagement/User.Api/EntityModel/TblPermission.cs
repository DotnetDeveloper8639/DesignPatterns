﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System;

namespace User.API.EntityModel
{
    
    [Table("tblPermissions")]
    public class TblPermission
    {
        public TblPermission()
        {
            //this.id = Guid.NewGuid().ToString();
        }

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column(TypeName = "int")]
        public int id { get; set; }

        [Required]
        [Column(TypeName ="nvarchar(160)")]
        public string name { get; set; }

        [Required]
        [Column(TypeName = "nvarchar(160)")]
        public string display_name { get; set; }

        [Column(TypeName = "bit")]
        public bool is_active { get; set; }
        [Column(TypeName = "int")]
        public int serial_number { get; set; }
        [Column(TypeName = "int")]
        public int number { get; set; }
    }
}
