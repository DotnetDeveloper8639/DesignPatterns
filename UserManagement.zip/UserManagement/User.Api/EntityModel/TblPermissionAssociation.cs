﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System;

namespace User.API.EntityModel
{
    [Table("tblPermissionAssociation")]
    public class TblPermissionAssociation
    {
        public TblPermissionAssociation()
        {
            this.id = Guid.NewGuid().ToString();
        }

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column(TypeName = "nvarchar(50)")]
        public string id { get; set; }
        
        [Column(TypeName ="nvarchar(50)")]
        [ForeignKey("tblRoles")]
        public string role_id { get; set; }

        [Column(TypeName = "nvarchar(50)")]
        [ForeignKey("tblPermissions")]
        public int permission_id { get; set; }

    }
}
