﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System;

namespace User.API.EntityModel
{
    [Table("tblRoles")]
    public class TblRole
    {
        public TblRole()
        {
            this.id = Guid.NewGuid().ToString();
        }

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column(TypeName = "nvarchar(50)")]
        public string id { get; set; }

        [Column(TypeName = "nvarchar(160)")]
        public string role_name { get; set; }

        [Column("is_default", TypeName = "bit")]
        public bool IsDefault { get; set; }
        [Column("is_global_admin_role", TypeName = "bit")]
        public bool IsGlobalAdminRole { get; set; }
    }
}
