﻿using SignalRNotifications.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SignalRNotifications.Services
{
    public interface INotificationService
    {
        Task<SchNotification> CreateNotification(SchNotification notification);
        Task<bool> SendNotification(string notification);
        Task<SchNotification> GetNotification();
    }
}
