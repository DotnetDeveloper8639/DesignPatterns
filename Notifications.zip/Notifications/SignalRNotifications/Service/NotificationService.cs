﻿using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;
using SignalRNotifications.Broadcast;
using SignalRNotifications.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SignalRNotifications.Services
{
    public class NotificationService: INotificationService
    {
        private readonly Sch_Context _context;
        private readonly IHubContext<BroadcastHub> _hubClient;
        public NotificationService(Sch_Context context, IHubContext<BroadcastHub> hubClient) : base()
        {
            _context = context;
            _hubClient = hubClient;
        }

        public async Task<SchNotification> CreateNotification(SchNotification notification)
        {
            _context.TblNotification.Add(notification);
            await _context.SaveChangesAsync();
            //await _hubClient.Clients.All.SendAsync("ReceiveMessage", "Project has been created");
            return notification;
        }

        public async Task<bool> SendNotification(string notification)
        {
            await _hubClient.Clients.All.SendAsync("ReceiveMessage", "Hello");
            return true;
        }

        public async Task<SchNotification> GetNotification()
        {
            var result = await _context.TblNotification.ToListAsync();
            var filteredData = result.Last();
            return filteredData;
        }
    }
}
