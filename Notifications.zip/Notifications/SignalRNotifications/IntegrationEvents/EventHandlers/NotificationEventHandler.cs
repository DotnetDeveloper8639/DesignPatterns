﻿using AzureMessageBus;
using Microsoft.AspNetCore.SignalR;
using Microsoft.Extensions.Logging;
using SignalRNotifications.Broadcast;
using SignalRNotifications.IntegrationEvents.Events;
using SignalRNotifications.Models;
using SignalRNotifications.Services;
using System;
using System.Threading.Tasks;

namespace SignalRNotifications.IntegrationEvents.EventHandlers
{
    public class NotificationEventHandler: IIntegrationEventHandler<NotificationEvent>
    {
        private readonly ILogger<NotificationEventHandler> _logger;
        private readonly IHubContext<BroadcastHub> _hubClient;
        private readonly INotificationService _notification;
        public NotificationEventHandler(IHubContext<BroadcastHub> hubClient, ILogger<NotificationEventHandler> logger, INotificationService notification)
        {
            _hubClient = hubClient ?? throw new ArgumentNullException(nameof(hubClient)); ;
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _notification = notification ?? throw new ArgumentNullException(nameof(logger));
        }

        public async Task HandleAsync(NotificationEvent @event)
        {
            var schNotification = new NotificationDTO()
            {
                Message = @event.Message
            };
            await _notification.SendNotification(schNotification.Message);
        }
    }
}
