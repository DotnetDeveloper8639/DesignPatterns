﻿using AzureMessageBus;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SignalRNotifications.IntegrationEvents.Events
{
    public class NotificationEvent: IntegrationEvent
    {
        public string Message { get; set; }
    }
}
