﻿using AzureMessageBus;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using SignalRNotifications.Broadcast;
using SignalRNotifications.IntegrationEvents.Events;
using SignalRNotifications.Models;
using SignalRNotifications.Services;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace SignalRNotifications.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class NotificationController : ControllerBase
    {
        private readonly IHubContext<BroadcastHub> _hubClient;
        private readonly INotificationService _notification;
        private readonly IEventBus _eventBus;

        public NotificationController(IHubContext<BroadcastHub> hubClients,
            INotificationService notification, IEventBus eventBus)
        {
            _hubClient = hubClients;
            _notification = notification;
            _eventBus = eventBus;

        }
        [HttpPost]
        [Route("{message}/broadcastmessage")]
        public async Task<IActionResult> BroadCastMessage(string message)
        {
            try
            {
                message = "Project2 has been created";
                //var notificationId = string.Empty;
                //var notificationStatus = string.Empty;
                //var lastNotification = _notification.GetNotification();

                //if (lastNotification != null)
                //{
                //    notificationId = generateId(lastNotification.Result.NotificationId);
                //}
                //var schNotification = new SchNotification()
                //{
                //    User_Id = "Sruthi",
                //    NotificationId = notificationId,
                //    Notification_Type = "Project has been created",
                //    Notification_Cat = "Information",
                //    Tenant_Id = "87F47A0B-3C28-42DA-A944-4CB3EC7204D7",
                //    Created_By = "Shruti",
                //    Created_Dt = DateTime.Now,
                //    Modified_By = "Shruti",
                //    Modified_Dt = DateTime.Now
                //};
                //var result = _notification.CreateNotification(schNotification);
                //if (result != null)
                //{
                //    await _hubClient.Clients.All.SendAsync("ReceiveMessage", message);
                //    notificationStatus = "Push Notification sent to server";
                //}

                var message1 = new NotificationEvent()
                {
                    Message = "Hello"
                };

                await _eventBus.PublishAsync(message1, "projectnotification");
                return Ok(message);
            }
            catch (Exception e)
            {
                string filePath = @"C:\Error.txt";

                Exception ex = e;

                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine("-----------------------------------------------------------------------------");
                    writer.WriteLine("Date : " + DateTime.Now.ToString());
                    writer.WriteLine();

                    while (ex != null)
                    {
                        writer.WriteLine(ex.GetType().FullName);
                        writer.WriteLine("Message : " + ex.Message);
                        writer.WriteLine("StackTrace : " + ex.StackTrace);

                        ex = ex.InnerException;
                    }
                }
            }
            return Ok();
        }
        private static string generateId(string notificationId)
        {
            string id = notificationId;   //This resets the value to 1 every time you enter.
            return id += 1;
        }
    }
}
