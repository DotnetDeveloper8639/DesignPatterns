﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace SignalRNotifications.Migrations
{
    public partial class notifications : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "tblNotifications",
                columns: table => new
                {
                    NotificationId = table.Column<string>(type: "nvarchar(80)", nullable: false),
                    Notification_Type = table.Column<string>(type: "nvarchar(80)", nullable: true),
                    Notification_Cat = table.Column<string>(type: "nvarchar(80)", nullable: true),
                    User_Id = table.Column<string>(type: "nvarchar(80)", nullable: true),
                    Tenant_Id = table.Column<string>(type: "nvarchar(80)", nullable: true),
                    Created_By = table.Column<string>(type: "nvarchar(80)", nullable: true),
                    Created_Dt = table.Column<DateTimeOffset>(type: "DateTimeOffset", nullable: false),
                    Modified_By = table.Column<string>(type: "nvarchar(80)", nullable: true),
                    Modified_Dt = table.Column<DateTimeOffset>(type: "DateTimeOffset", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblNotifications", x => x.NotificationId);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "tblNotifications");
        }
    }
}
