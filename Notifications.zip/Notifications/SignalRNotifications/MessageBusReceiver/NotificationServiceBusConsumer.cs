﻿using Azure.Messaging.ServiceBus;
using AzureMessageBus;
using Microsoft.AspNetCore.SignalR;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using SignalRNotifications.Broadcast;
using SignalRNotifications.Models;
using SignalRNotifications.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SignalRNotifications.MessageBusReceiver
{
    public class NotificationServiceBusConsumer : INotificationServiceBusConsumer
    {
        private readonly string serviceBusConnectionString;
        private readonly string Projectsubscription;
        private readonly string ProjectMessageTopic;
        private readonly string offerMessageTopic;
        private readonly string offerMessagSubscription;
        private readonly string machineMessageTopic;
        private readonly string machineMessagSubscription;

        private readonly INotificationService _notificationService;

        private ServiceBusProcessor notificationCreateProcessor;
        private ServiceBusProcessor OfferNotificationCreateProcessor;
        private ServiceBusProcessor MachineNotificationCreateProcessor;

        private readonly IConfiguration _configuration;
        private readonly IMessageBus _messageBus;
        private readonly IHubContext<BroadcastHub> _hubClient;

        public NotificationServiceBusConsumer(INotificationService notificationService, 
            IConfiguration configuration, 
            IMessageBus messageBus, 
            IHubContext<BroadcastHub> hubClient)
        {
            _notificationService = notificationService;
            _configuration = configuration;
            _messageBus = messageBus;
            _hubClient = hubClient;

            serviceBusConnectionString = _configuration.GetValue<string>("ServiceBusConnectionString");
            Projectsubscription = _configuration.GetValue<string>("ProjectSubscription");
            ProjectMessageTopic = _configuration.GetValue<string>("ProjectMessageTopic");
            offerMessagSubscription = _configuration.GetValue<string>("OfferSubscription");
            offerMessageTopic = _configuration.GetValue<string>("OfferMessageTopic");
            machineMessagSubscription = _configuration.GetValue<string>("MachineSubscription");
            machineMessageTopic = _configuration.GetValue<string>("MachineMessageTopic");

            var client = new ServiceBusClient(serviceBusConnectionString);

            notificationCreateProcessor = client.CreateProcessor(ProjectMessageTopic, Projectsubscription);
            OfferNotificationCreateProcessor = client.CreateProcessor(offerMessageTopic, offerMessagSubscription);
            MachineNotificationCreateProcessor = client.CreateProcessor(machineMessageTopic, machineMessagSubscription);
        }

        public async Task Start()
        {
            notificationCreateProcessor.ProcessMessageAsync += OnProjectNotificationMessageReceived;
            notificationCreateProcessor.ProcessErrorAsync += ErrorHandler;
            await notificationCreateProcessor.StartProcessingAsync();

            OfferNotificationCreateProcessor.ProcessMessageAsync += OnOfferNotificationMessageReceived;
            notificationCreateProcessor.ProcessErrorAsync += ErrorHandler;
            await notificationCreateProcessor.StartProcessingAsync();

            MachineNotificationCreateProcessor.ProcessMessageAsync += OnMachineNotificationMessageReceived;
            notificationCreateProcessor.ProcessErrorAsync += ErrorHandler;
            await notificationCreateProcessor.StartProcessingAsync();
        }
        public async Task Stop()
        {
            await notificationCreateProcessor.StopProcessingAsync();
            await notificationCreateProcessor.DisposeAsync();

            await OfferNotificationCreateProcessor.StopProcessingAsync();
            await notificationCreateProcessor.DisposeAsync();

            await MachineNotificationCreateProcessor.StopProcessingAsync();
            await notificationCreateProcessor.DisposeAsync();
        }
        Task ErrorHandler(ProcessErrorEventArgs args)
        {
            Console.WriteLine(args.Exception.ToString());
            return Task.CompletedTask;
        }

        private async Task OnProjectNotificationMessageReceived(ProcessMessageEventArgs args)
        {
            var message = args.Message;
            var body = Encoding.UTF8.GetString(message.Body);

            NotificationDTO notification = JsonConvert.DeserializeObject<NotificationDTO>(body);

            var schNotification = new NotificationDTO()
            {
                Message = notification.Message
            };

            
            await _hubClient.Clients.All.SendAsync("ReceiveMessage", schNotification.Message);

            try
            {
                await args.CompleteMessageAsync(args.Message);
            }

            catch (Exception e)
            {
                throw e;
            }

        }
        private async Task OnOfferNotificationMessageReceived(ProcessMessageEventArgs args)
        {
            var message = args.Message;
            var body = Encoding.UTF8.GetString(message.Body);

            NotificationDTO notification = JsonConvert.DeserializeObject<NotificationDTO>(body);

            var schNotification = new NotificationDTO()
            {
                Message = notification.Message
            };

            await _hubClient.Clients.All.SendAsync("ReceiveMessage", schNotification.Message);

            try
            {
                await args.CompleteMessageAsync(args.Message);
            }
            catch (Exception e)
            {
                throw e;
            }

        }
        private async Task OnMachineNotificationMessageReceived(ProcessMessageEventArgs args)
        {
            var message = args.Message;
            var body = Encoding.UTF8.GetString(message.Body);

            NotificationDTO notification = JsonConvert.DeserializeObject<NotificationDTO>(body);

            var schNotification = new NotificationDTO()
            {
                Message = notification.Message
            };

            await _hubClient.Clients.All.SendAsync("ReceiveMessage", schNotification.Message);

            try
            {
                await args.CompleteMessageAsync(args.Message);
            }
            catch (Exception e)
            {
                throw e;
            }

        }
    }
}
