﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SignalRNotifications.MessageBusReceiver
{
    public interface INotificationServiceBusConsumer
    {
        Task Start();
        Task Stop();
    }
}
