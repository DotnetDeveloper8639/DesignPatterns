﻿using AutoMapper;
using NotificationService.EntityModel;
using NotificationService.Models;

namespace NotificationService
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<NotificationDto, TblNotification>().ReverseMap();
        }
    }
}