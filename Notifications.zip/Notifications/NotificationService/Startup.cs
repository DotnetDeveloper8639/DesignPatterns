using EventBus;
using EventBus.Abstractions;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using NotificationService.Controllers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.SignalR;
using Dapr.Client;
using System.Security.Claims;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using System.Reflection;
using NotificationService.DbContextClass;
using Microsoft.EntityFrameworkCore;
using Microsoft.OpenApi.Models;
using NotificationService.Extensions;
using NotificationService.Services;
using Tenant.Service;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using Microsoft.Identity.Web;

namespace NotificationService
{
    public class Startup
    {
        private const string AppName = "Notification Service";
        readonly string corsPolicy = "CORSPolicy";
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllers();//.AddDapr();

            services.AddScoped<IEventBus, DaprEventBus>();

            //services.AddDaprClient();
            services.AddDaprClient(config =>
            config.UseJsonSerializationOptions(new System.Text.Json.JsonSerializerOptions()
            {
                PropertyNamingPolicy = null,
            }));

            services.AddAuthentication(options =>
            {
                // Identity made Cookie authentication the default.
                // However, we want JWT Bearer Auth to be the default.
                options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            })
                .AddJwtBearer(options =>
                {
                    options.TokenValidationParameters = new TokenValidationParameters
                    {
                        ValidateIssuer = true,
                        ValidateAudience = true,
                        ValidateLifetime = true,
                        ValidateIssuerSigningKey = true,
                        ValidIssuer = Environment.GetEnvironmentVariable("TOKEN_SERVER"),
                        ValidAudience = "blueprint-api",
                        IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(Environment.GetEnvironmentVariable("JWT_KEY")))
                    };
                });

            // adds an authorization policy to make sure the token is for scope 'api1'
            services.AddAuthorization(options =>
            {
                options.AddPolicy("ApiScope", policy =>
                {
                    policy.RequireAuthenticatedUser();
                    policy.RequireClaim(ClaimTypes.Role);
                    policy.RequireClaim(ClaimConstants.TenantId);
                });
            });

            //var migrationsAssembly = typeof(Startup).GetTypeInfo().Assembly.GetName().Name;

            //services.AddDbContext<NotificationDbContext>(options =>
            //options.UseSqlServer(Configuration.GetConnectionString("sqlConnection"),
            //sql => sql.MigrationsAssembly(migrationsAssembly)), ServiceLifetime.Singleton);

            services.AddDbContext<NotificationDbContext>(ServiceLifetime.Scoped);
            services.RegisterTenantService(Configuration);

            //services.AddSwaggerGen(c =>
            //{
            //    c.SwaggerDoc("v1", new OpenApiInfo { Title = $"Trianz - {AppName}", Version = "v1" });

            //    c.AddSecurityDefinition("oauth2", new OpenApiSecurityScheme
            //    {
            //        Type = SecuritySchemeType.OAuth2,
            //        Flows = new OpenApiOAuthFlows()
            //        {
            //            Implicit = new OpenApiOAuthFlow()
            //            {
            //                AuthorizationUrl = new Uri($"{identityUrlExternal}/connect/authorize"),
            //                TokenUrl = new Uri($"{identityUrlExternal}/connect/token"),
            //                Scopes = new Dictionary<string, string>()
            //                {
            //                    { "blueprint.api", AppName },
            //                    { "profile","Get User Info" }
            //                }
            //            }
            //        }
            //    });


            //    c.OperationFilter<AuthorizeCheckOperationFilter>();
            //});
            services.AddSwaggerGen(options =>
            {
                options.SwaggerDoc("v1", new OpenApiInfo { Title = $"Trianz - {AppName}", Version = "v1" });
            });
            services.AddAutoMapper(typeof(Startup));

            services.AddScoped<INotificationService, NotificationManagementService>();

            string[] allowedOrigin = Environment.GetEnvironmentVariable("ALLOWED_ORIGIN").Split(',');

            services.AddCors(options =>
            {
                options.AddPolicy(name: corsPolicy,
                                  builder =>
                                  {
                                      builder.WithOrigins(allowedOrigin)
                        .AllowAnyMethod()
                        .AllowAnyHeader()
                        .AllowCredentials();
                                  });
            });

            services.AddSignalR()
            .AddAzureSignalR(Environment.GetEnvironmentVariable("SIGNAL_R_CONNECTION_STRING"));

        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseCors(corsPolicy);
            app.UseSwagger(options =>
            {
                options.RouteTemplate = "notification/swagger/{documentName}/swagger.json";
            });

            app.UseSwaggerUI(options =>
            {
                options.SwaggerEndpoint("/notification/swagger/v1/swagger.json", $"{AppName} API");
                options.RoutePrefix = "notification/swagger";
            });

            //app.UseHttpsRedirection();
            //app.UseCors(builder => builder
            //  .AllowAnyHeader()
            //  .AllowAnyMethod()
            //  //.AllowAnyOrigin()
            //  .SetIsOriginAllowed((host) => true)
            //.AllowCredentials()
            //);

            app.UseRouting();

            app.UseAuthentication();
            app.UseAuthorization();
            app.UseCloudEvents();
            app.UseAzureSignalR(routes =>
            {
                routes.MapHub<NotificationHub>("/hub/notificationhub");
            });

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
                endpoints.MapSubscribeHandler();
            });

            
        }
    }
}
