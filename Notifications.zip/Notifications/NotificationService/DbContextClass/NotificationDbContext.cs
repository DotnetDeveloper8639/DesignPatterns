﻿using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using NotificationService.EntityModel;
using Tenant.Service;
using Microsoft.Identity.Web;
using System;

namespace NotificationService.DbContextClass
{
    public class NotificationDbContext : DbContext
    {
        private readonly IConfiguration _configuration;
        private readonly IHttpContextAccessor httpContextAccessor;
        private readonly ITenantService tenantService;

        public NotificationDbContext()
        {
        }

        public NotificationDbContext(DbContextOptions<NotificationDbContext> options
            , IConfiguration configuration
            , IHttpContextAccessor httpContextAccessor
            , ITenantService tenantService)
                     : base(options)
        {
            _configuration = configuration;
            this.httpContextAccessor = httpContextAccessor;
            this.tenantService = tenantService;
        }

        public virtual DbSet<TblNotification> TblNotifications { get; set; }
        public virtual DbSet<TblConnection> TblConnection { get; set; }
        public virtual DbSet<TblUser> TblUser { get; set; }

        //protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        //{
        //    optionsBuilder.UseSqlServer(_configuration.GetConnectionString("sqlConnection"));
        //}
        //protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        //{
        //    var tid = httpContextAccessor.HttpContext.User.GetTenantId();

        //    var tenantInfo = tenantService.GetTenantInfo(tid);

        //    optionsBuilder.UseSqlServer(tenantInfo.Connectionstring);

        //    base.OnConfiguring(optionsBuilder);
        //}
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            var tenantInfo = Environment.GetEnvironmentVariable("CONNECTION_STRING");

            optionsBuilder.UseSqlServer(tenantInfo);

            base.OnConfiguring(optionsBuilder);
        }
    }
}
