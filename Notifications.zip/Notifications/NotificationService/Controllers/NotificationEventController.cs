﻿using Microsoft.AspNetCore.Mvc;
using Dapr;
using System.Threading.Tasks;
using Microsoft.AspNetCore.SignalR;
using NotificationService.IntegrationEvents.Events;
using Newtonsoft.Json;
using Microsoft.AspNetCore.Authorization;
using EventBus.Abstractions;
using System.Collections.Generic;
using NotificationService.Services;
using System.Linq;

namespace NotificationService.Controllers
{
    [Route("/api/notificationsvc")]
    [ApiController]
    [Authorize]
    public class NotificationEventController : ControllerBase
    {
        private const string DAPR_PUBSUB_NAME = "pubsub";
        private readonly IEventBus eventBus;
        private readonly INotificationService notificationService;

        public NotificationEventController(IEventBus eventBus
            ,INotificationService notificationService)
        {
            this.eventBus = eventBus;
            this.notificationService = notificationService;
        }

        //[AllowAnonymous]
        //[HttpGet("PublishMessage")]
        //public async Task<IActionResult> Get()
        //{
        //    eventBus.PublishToQueue(new NotificationReceivedEvent(new List<string>{ "jmistri@ainvector.com" },"ProjectStatusChanged","","Jigar Sent you a Message") { TopicName = "NotificationReceived" });
        //    return Ok();
        //}

        [AllowAnonymous]
        [HttpPost("NotificationReceived")]
        //[Topic(DAPR_PUBSUB_NAME, "notificationtopic")]
        public async Task HandleAsync(
        [FromBody]NotificationReceivedEvent integrationEvent)
        {
            HttpContext.Items["CurrentTenantId"] = integrationEvent.Tid;
            notificationService.SendNotificationAsync(integrationEvent);
        }

    }
}
