﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.SignalR;
using NotificationService.DbContextClass;
using NotificationService.EntityModel;
using NotificationService.Services;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Threading.Tasks;

namespace NotificationService.Controllers
{
    [Authorize]
    public class NotificationHub : Hub
    {
        public override async Task OnConnectedAsync()
        {
            await Groups.AddToGroupAsync(Context.ConnectionId, GetUserId());
            await base.OnConnectedAsync();
            try
            {
                var userid = Context.User.Claims.First(c => c.Type == JwtRegisteredClaimNames.Email).Value;
                using (var _context = new NotificationDbContext())
                {
                    var userConnections = _context.TblConnection.Where(u => u.UserEmail == userid).FirstOrDefault() ?? null;

                    if (userConnections == null)
                    {
                        TblConnection connection = new();
                        connection.id = Guid.NewGuid().ToString();
                        connection.UserEmail = userid;
                        connection.UserId = userid;
                        connection.ConnectionID = Context.ConnectionId;
                        connection.Connected = true;
                        _context.TblConnection.Add(connection);

                        var pendingNotifications = _context.TblNotifications.Where(n => n.UserId == userid && n.Is_Read == false).ToList();

                        foreach (var item in pendingNotifications)
                        {
                           var status = SendPendingNotifications(userid, item);

                            if (status.Result == true)
                            {
                                item.Is_Read = true;
                                _context.SaveChanges();
                            }
                        }
                        _context.SaveChanges();
                    }else if(userConnections != null && userConnections.Connected == false)
                    {
                        userConnections.Connected = true;
                        userConnections.ConnectionID = Context.ConnectionId;

                        var pendingNotifications = _context.TblNotifications.Where(n => n.UserId == userid && n.Is_Read == false).ToList();

                        foreach (var item in pendingNotifications)
                        {
                            var status = SendPendingNotifications(userid, item);

                            if (status.Result == true)
                            {
                                item.Is_Read = true;
                                _context.SaveChanges();
                            }
                        }
                        _context.SaveChanges();
                    }
                    else
                    {
                        var pendingNotifications = _context.TblNotifications.Where(n => n.UserId == userid && n.Is_Read == false).ToList();

                        foreach (var item in pendingNotifications)
                        {
                            var status = SendPendingNotifications(userid, item);

                            if (status.Result == true)
                            {
                                item.Is_Read = true;
                                _context.SaveChanges();
                            }
                        }
                    }
                };
            }catch(Exception ex)
            {
                Console.WriteLine(ex);
            }
            
        }

        public override async Task OnDisconnectedAsync(Exception? ex)
        {
            try
            {
                using (var _context = new NotificationDbContext())
                {
                    var connection = _context.TblConnection.Where(c => c.ConnectionID == Context.ConnectionId).FirstOrDefault() ?? null;
                    if (connection != null)
                    {
                        connection.Connected = false;
                        _context.SaveChanges();
                    }
                }
            }
            catch (Exception)
            {
                //Console.WriteLine(ex);
            }
            await Groups.RemoveFromGroupAsync(Context.ConnectionId, GetUserId());
            await base.OnDisconnectedAsync(ex);
            
        }
        public async Task<bool> SendPendingNotifications(string userId, TblNotification message)
        {

            await Clients.Client(Context.ConnectionId).SendAsync("ClientNotification", message.Message, message.Erp_Id, message.Blueprint_Id, message.NotificationEvent);
            return true;
        }
        private string GetUserId() => Context.User.Claims.First(c => c.Type == JwtRegisteredClaimNames.Email).Value;
    }
}
