﻿using AutoMapper;
using Microsoft.AspNetCore.SignalR;
using NotificationService.Controllers;
using NotificationService.DbContextClass;
using NotificationService.EntityModel;
using NotificationService.IntegrationEvents.Events;
using NotificationService.Models;
using System;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace NotificationService.Services
{
    public class NotificationManagementService : INotificationService
    {
        private readonly NotificationDbContext _dbContext;
        private readonly IMapper _mapper;
        private readonly IHubContext<NotificationHub> hubContext;

        //private readonly IRole
        public NotificationManagementService(NotificationDbContext dbContext
            , IMapper mapper
            , IHubContext<NotificationHub> hubContext)
        {
            this._dbContext = dbContext;
            this._mapper = mapper;
            this.hubContext = hubContext;
        }
        public async Task<ApiResponse<bool>> AddNewNotificationAsync(NotificationDto notificationDto)
        {
            var apiResponse = new ApiResponse<bool>();

            bool isNotificationCreated = false;
            try
            {
                var entity = _mapper.Map<TblNotification>(notificationDto);
                entity.id = Guid.NewGuid().ToString();

                _dbContext.TblNotifications.Add(entity);

                _dbContext.SaveChanges();

                isNotificationCreated = true;

                apiResponse.StatusCode = (int)HttpStatusCode.OK;
                apiResponse.StatusReason = "Notification created successfully.";

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex);
                apiResponse.StatusCode = (int)HttpStatusCode.InternalServerError;
                apiResponse.StatusReason = ex.Message;
            }

            apiResponse.Data = isNotificationCreated;
            return apiResponse;
        }

        public async Task<ApiResponse<bool>> SendNotificationAsync(NotificationReceivedEvent notificationReceivedEvent)
        {
            var apiResponse = new ApiResponse<bool>();

            foreach (var userId in notificationReceivedEvent.UserId)
            {
                try
                {
                    await hubContext.Clients
                    .Group(userId)
                    .SendAsync("ClientNotification", notificationReceivedEvent.Message, notificationReceivedEvent.Erp_Id, notificationReceivedEvent.Blueprint_Id, notificationReceivedEvent);

                    var userConnected = _dbContext.TblConnection.Where(c => c.UserId == userId && c.Connected == true).FirstOrDefault();
                    if (userConnected != null && userConnected.Connected == true)
                    {
                        AddNewNotificationAsync(new NotificationDto()
                        {
                            Message = notificationReceivedEvent.Message,
                            NotificationType = notificationReceivedEvent.NotificationType,
                            UserId = userId,
                            Is_Read = true,
                            Erp_Id = notificationReceivedEvent.Erp_Id,
                            Blueprint_Id = notificationReceivedEvent.Blueprint_Id,
                            NotificationEvent = notificationReceivedEvent.NotificationEvent,
                            created_by = notificationReceivedEvent.CreatedByUserId
                        });
                    }
                    else
                    {
                        AddNewNotificationAsync(new NotificationDto()
                        {
                            Message = notificationReceivedEvent.Message,
                            NotificationType = notificationReceivedEvent.NotificationType,
                            UserId = userId,
                            Is_Read = false,
                            Erp_Id = notificationReceivedEvent.Erp_Id,
                            Blueprint_Id = notificationReceivedEvent.Blueprint_Id,
                            NotificationEvent = notificationReceivedEvent.NotificationEvent,
                            created_by = notificationReceivedEvent.CreatedByUserId
                        });
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex);
                }
            }

            apiResponse.Data = true;
            return apiResponse;
        }

        public async Task<bool> SendPendingNotifications(string userId, string message)
        {
            bool isSuccess = false;
            if (userId != null)
            {
                var messages = _dbContext.TblNotifications.Where(m => m.UserId == userId && m.Is_Read == false).ToList();
                //var userDetails = _dbContext.TblUser.Where(u => u.id == userId).FirstOrDefault();
                foreach (var item in messages)
                {
                    await hubContext.Clients
                        .Group(userId)
                        .SendAsync("ClientNotification", item.Message, item.Erp_Id, item.Blueprint_Id, item.NotificationEvent);

                    item.Is_Read = true;

                    _dbContext.SaveChanges();
                }
                isSuccess = true;
            }
            return isSuccess;
        }
    }
}
