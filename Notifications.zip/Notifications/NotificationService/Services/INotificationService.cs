﻿using NotificationService.IntegrationEvents.Events;
using NotificationService.Models;
using System.Threading.Tasks;

namespace NotificationService.Services
{
    public interface INotificationService
    {
        Task<ApiResponse<bool>> AddNewNotificationAsync(NotificationDto notificationDto);
        Task<ApiResponse<bool>> SendNotificationAsync(NotificationReceivedEvent notificationReceivedEvent);
        Task<bool> SendPendingNotifications(string userId, string message);
    }
}
