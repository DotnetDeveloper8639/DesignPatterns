﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace NotificationService.EntityModel
{
    [Table("tblNotifications")]
    public class TblNotification
    {
        [Key]
        [Column(TypeName = "nvarchar(80)")]
        public string id { get; set; }

        [Column("Notification_Type", TypeName = "varchar(80)")]
        public string NotificationType { get; set; }

        [Column("User_Id", TypeName = "varchar(80)")]
        public string UserId { get; set; }

        [Column("Message", TypeName = "varchar(500)")]
        public string Message { get; set; }
        [Column("is_read", TypeName = "bit")]
        public bool Is_Read { get; set; }
        [Column("erp_id", TypeName = "nvarchar(50)")]
        public string Erp_Id { get; set; }
        [Column("blueprint_id", TypeName = "nvarchar(50)")]
        public string Blueprint_Id { get; set; }
        [Column("notificationevent", TypeName = "nvarchar(50)")]
        public string NotificationEvent { get; set; }

        [Column(TypeName = "datetimeoffset(7)")]
        public DateTimeOffset created_at { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string created_by { get; set; }
        [Column(TypeName = "datetimeoffset(7)")]
        public DateTimeOffset modified_at { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string modified_by { get; set; }
    }
}
