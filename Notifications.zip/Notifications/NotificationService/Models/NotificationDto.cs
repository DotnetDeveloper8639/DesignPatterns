﻿using System;

namespace NotificationService.Models
{
    public class NotificationDto
    {
        public string id { get; set; }
        public string NotificationType { get; set; }
        public string UserId { get; set; }
        public string Message { get; set; }
        public bool Is_Read { get; set; }
        public string Erp_Id { get; set; }
        public string Blueprint_Id { get; set; }
        public string NotificationEvent { get; set; }
        public DateTimeOffset created_at { get; set; } = DateTimeOffset.Now;
        public string created_by { get; set; }
        public DateTimeOffset modified_at { get; set; }
        public string modified_by { get; set; }
    }
}
