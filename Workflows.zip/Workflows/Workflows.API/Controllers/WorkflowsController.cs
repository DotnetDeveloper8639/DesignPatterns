﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Mime;
using System.Text;
using System.Threading.Tasks;
using Workflows.API.DbContextClass;
using Workflows.API.Models;
using Workflows.API.Services;

namespace Workflows.API.Controllers
{
    [Route("/api/workflows")]
    [ApiController]
    [AllowAnonymous]
    [Authorize(Policy = "ApiScope")]
    public class WorkflowsController : ControllerBase
    {
        public readonly IHttpClientFactory _clientFactory;
        public readonly IWorkflowService _workflowService;
        private readonly Workflow_Context _context;

        public WorkflowsController(IHttpClientFactory clientFactory, IWorkflowService workflowService, Workflow_Context context)
        {
            _clientFactory = clientFactory;
            _workflowService = workflowService;
            _context = context;
        }

        [Route("generatequote")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Produces("application/json")]
        [HttpPost]
        public async Task<IActionResult> GenerateQuote(JObject commercialQuotationDTO)
        {
            try
            {
                var triggeringUrl = _context.TblWorkflows
                    .FirstOrDefault(l => l.workflow_type == WorkFlowType.LayoutedQuote)
                    ?.trigger_url ?? string.Empty;

                if (string.IsNullOrEmpty(triggeringUrl))
                    return Ok(new LayoutedQuotationResponseDTO());

                var jsonBody = JsonConvert.SerializeObject(commercialQuotationDTO);
                var request = new HttpRequestMessage
                {
                    Method = HttpMethod.Post,
                    RequestUri = new Uri(triggeringUrl),
                    Content = new StringContent(jsonBody, Encoding.UTF8, MediaTypeNames.Application.Json /* or "application/json" in older versions */),
                };
                var client = _clientFactory.CreateClient();
                var response = await client.SendAsync(request);
                var result = JsonConvert.DeserializeObject<LayoutedQuotationResponseDTO>(response.Content.ReadAsStringAsync().Result);

                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }

        [Route("lquoteconvertpdf")]
        [AllowAnonymous]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Produces("application/json")]
        [HttpPost]
        public async Task<IActionResult> WordToPDF(JObject jobject)
        {
            try
            {
                //var triggerUrl = "https://blueprint-workflows.azurewebsites.net:443/api/blueprint-lquote-convert-pdf-qa/triggers/manual/invoke?api-version=2022-05-01&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=Zr4A4z01SIlXU1cKeJL40FIWiDzDtFhFJ3u11Ta7s60";
                var triggerUrl = Environment.GetEnvironmentVariable("TRIGGER_URL");
                var jsonBody = JsonConvert.SerializeObject(jobject);
                var request = new HttpRequestMessage
                {
                    Method = HttpMethod.Post,
                    RequestUri = new Uri(triggerUrl),
                    Content = new StringContent(jsonBody, Encoding.UTF8, MediaTypeNames.Application.Json /* or "application/json" in older versions */),
                };
                var client = _clientFactory.CreateClient();
                var response = await client.SendAsync(request);
                var result = JsonConvert.DeserializeObject<JObject>(response.Content.ReadAsStringAsync().Result);

                return Ok(result);
            }
            catch (Exception ex)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }
        
    }
}
