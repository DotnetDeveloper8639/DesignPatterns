﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Workflows.API.EntityModels
{
    [Table("tblWorkflow")]
    public class TblWorkflow
    {
        [Key]
        [Column(TypeName = "varchar(50)")]
        public string id { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string workflow_type { get; set; }
        [Column(TypeName = "nvarchar(1000)")]
        public string trigger_url { get; set; }
    }
}
