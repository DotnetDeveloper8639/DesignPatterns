﻿namespace Workflows.API.Models
{
    public class WorkFlowType
    {
        public static string LayoutedQuote = "LayoutedQuote";
    }
}
