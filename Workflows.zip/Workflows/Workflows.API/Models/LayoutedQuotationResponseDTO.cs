﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Workflows.API.Models
{
    public class LayoutedQuotationResponseDTO
    {
        public DateTime Created_time { get; set; }
        public string Display_name { get; set; }
        public string Email { get; set; }
        public string Full_path { get; set; }
        public DateTime Modified_time { get; set; }
        public string Name { get; set; }
        public string Path { get; set; }
        public string Template_name { get; set; }
        public string Web_url { get; set; }
        public string Offer_Id { get; set; }
    }
}
