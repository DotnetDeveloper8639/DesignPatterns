﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Workflows.API.Models
{
    public class LayoutedQuotationDTO
    {
        public LayoutedQuotation Layouted_Quotation { get; set; }
    }
    public class LayoutedQuotation
    {
        public string Quotation_Generation_Date { get; set; }
        public string Offer_Contact_Display_name { get; set; }
        public string Offer_Contact_Firstname { get; set; }
        public string Company_Name { get; set; }
        public string Company_Address { get; set; }
        public string Company_City { get; set; }
        public string Company_Zipcode { get; set; }
        public string Offer_Contact_Email { get; set; }
        public string Offer_Contact_Phone_Number { get; set; }
        public string Offer_Erp_Wbs_Id { get; set; }
        public List<LayoutedService> Services { get; set; }
        public string Template_Site_Url { get; set; }
        public string Template_Location_Id { get; set; }
        public string Template_Path { get; set; }
        public string Save_As_Site_Address { get; set; }
        public string Save_As_Folder_Path { get; set; }
        public string Save_As_Filename { get; set; }
    }
    public class LayoutedMachine
    {
        public string Machine_Name { get; set; }
        public string Machine_Type { get; set; }
        public string Machine_Manufacturer { get; set; }
    }
    public class LayoutedService
    {
        public string Service_Start_Date { get; set; }
        public string Service_End_Date { get; set; }
        public string Service_Product_Id { get; set; }
        public string Service_Description { get; set; }
        public string Service_Contact_Display_Name { get; set; }
        public string Service_Contact_Email { get; set; }
        public string Service_Contact_Phone_Number { get; set; }
        public List<LayoutedMachine> Machines { get; set; }
    }
}
