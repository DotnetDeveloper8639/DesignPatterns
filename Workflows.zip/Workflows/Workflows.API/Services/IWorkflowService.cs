﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Workflows.API.Models;

namespace Workflows.API.Services
{
    public interface IWorkflowService
    {
    }
}
