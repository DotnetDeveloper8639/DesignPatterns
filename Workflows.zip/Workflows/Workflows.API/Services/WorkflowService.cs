﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Workflows.API.DbContextClass;
using Workflows.API.EntityModels;
using Workflows.API.Models;

namespace Workflows.API.Services
{
    public class WorkflowService: IWorkflowService
    {
        private readonly Workflow_Context _context;
        public WorkflowService(Workflow_Context context)
        {
            _context = context;
        }
    }
}
