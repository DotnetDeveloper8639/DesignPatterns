﻿using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Identity.Web;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Tenant.Service;
using Workflows.API.EntityModels;

namespace Workflows.API.DbContextClass
{
    public class Workflow_Context : DbContext
    {
        private readonly IConfiguration _configuration;
        private readonly IHttpContextAccessor httpContextAccessor;
        private readonly ITenantService tenantService;
        public Workflow_Context()
        {
        }

        public Workflow_Context(DbContextOptions<Workflow_Context> options
            , IConfiguration configuration
            , IHttpContextAccessor httpContextAccessor
            , ITenantService tenantService)
                     : base(options)
        {
            _configuration = configuration;
            this.httpContextAccessor = httpContextAccessor;
            this.tenantService = tenantService;
        }
        public virtual DbSet<TblWorkflow> TblWorkflows { get; set; }

        //protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        //{
        //    optionsBuilder.UseSqlServer("Server=tcp:schdev.database.windows.net,1433;Initial Catalog=Sch_Dev;Persist Security Info=False;User ID=sch_dev001;Password=Connectme@123;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=60;");
        //}

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            string tid = string.Empty;
            var currentTenantId = httpContextAccessor.HttpContext.Items["CurrentTenantId"];
            if (currentTenantId != null)
                tid = Convert.ToString(currentTenantId);
            else
                tid = httpContextAccessor.HttpContext.User.GetTenantId();

            var tenantInfo = tenantService.GetTenantInfo(tid);

            optionsBuilder.UseSqlServer(tenantInfo.Connectionstring);

            base.OnConfiguring(optionsBuilder);
        }
    }
}
