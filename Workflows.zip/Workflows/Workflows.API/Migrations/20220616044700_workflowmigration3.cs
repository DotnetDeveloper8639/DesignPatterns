﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Workflows.API.Migrations
{
    public partial class workflowmigration3 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "tblLogicAppURL",
                columns: table => new
                {
                    id = table.Column<string>(type: "varchar(50)", nullable: false),
                    QuotationName = table.Column<string>(type: "varchar(100)", nullable: true),
                    QuotationURL = table.Column<string>(type: "varchar(1000)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblLogicAppURL", x => x.id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "tblLogicAppURL");
        }
    }
}
