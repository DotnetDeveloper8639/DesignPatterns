﻿namespace Token.Api.DbContextClass
{
    using Token.Api.EntityModel;
    using Microsoft.EntityFrameworkCore;
    using Microsoft.Extensions.Configuration;
    using Microsoft.AspNetCore.Http;
    using Microsoft.Identity.Web;
    using Tenant.Service;

    public class UserManagementDbContext : DbContext
    {
        private readonly IConfiguration _configuration;
        private readonly ITenantService tenantService;
        private readonly IHttpContextAccessor httpContextAccessor;
        public UserManagementDbContext()
        {
        }

        public UserManagementDbContext(DbContextOptions<UserManagementDbContext> options
            , IConfiguration configuration
            , IHttpContextAccessor httpContextAccessor
            , ITenantService tenantService)
                     : base(options)
        {
            _configuration = configuration;
            this.httpContextAccessor = httpContextAccessor;
            this.tenantService = tenantService;
        }

        public virtual DbSet<TblUser> TblUsers { get; set; }
        public virtual DbSet<TblUserRoleAssignment> TblUserRoleAssignments { get; set; }
        public virtual DbSet<TblPermissionAssociation> TblPermissionAssociations { get; set; }
        public virtual DbSet<TblPermission> TblPermissions { get; set; }
        public virtual DbSet<TblUserAndGroupAssociation> TblUserAndGroupAssociations { get; set; }
        public virtual DbSet<TblRole> TblRoles { get; set; }


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            var tid = httpContextAccessor.HttpContext.User.GetTenantId();

            var tenantInfo = tenantService.GetTenantInfo(tid);

            optionsBuilder.UseSqlServer(tenantInfo.Connectionstring);

            base.OnConfiguring(optionsBuilder);
        }
    }
}
