﻿namespace Token.Api
{
    using AutoMapper;
    using Token.Api.EntityModel;
    using Token.Api.Models;
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<UserDto, TblUser>().ReverseMap();

            CreateMap<RefreshTokenDto, TblRefreshToken>().ReverseMap();
        }
    }
}
