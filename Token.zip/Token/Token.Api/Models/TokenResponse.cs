﻿namespace Token.Api.Models
{
    public class TokenResponse
    {
        public UserDto ApiUser { get; set; }
        public string RefreshToken { get; set; }
        public string AccessToken { get; set; }
    }
}
