﻿using System.Collections.Generic;

namespace Token.Api.Models
{
    public class UserDto
    {
        public string Id { get; set; }
        public string First_Name { get; set; }
        public string Last_Name { get; set; }
        public string Display_Name { get; set; }
        public string Login_Name { get; set; }
        public string Email_Address { get; set; }
        public string Profile_Data { get; set; }
        public bool IsActive { get; set; }

        public List<string> Permissions { get; set; }
        public List<string> Roles { get; set; }
        public string TID { get; set; }
        public bool IsGlobalAdmin { get; set; } = false;
    }
}
