﻿using System.Collections.Generic;

namespace Token.Api.Models
{
    public class UserRoleMapDto
    {
        public string UserId { get; set; }
        public bool IsGlobalAdmin { get; set; }
        public string Profile_Data { get; set; }
        public List<string> Permissions { get; set; }
        public List<string> Roles { get; set; }
    }
}
