﻿using System.Net;

namespace Token.Api.Models
{
    public class ApiResponse<T>
    {
        public ApiResponse()
        {
            this.StatusCode = (int)HttpStatusCode.OK;
        }
        public T Data { get; set; }
        public int StatusCode { get; set; }
        public string StatusReason { get; set; }
    }
}
