﻿using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Token.Api.EntityModel;
using Token.Api.Models;
using System.Security.Cryptography;
using Microsoft.Extensions.Configuration;
using Microsoft.Identity.Web;

namespace Token.Api.Services
{
    public class JwtUtils : IJwtUtils
    {
        public async Task<string> GenerateJwtToken(UserDto user)
        {
            var jwtTokenHandler = new JwtSecurityTokenHandler();

            var key = Encoding.ASCII.GetBytes(Environment.GetEnvironmentVariable("JWT_KEY"));

            var perClaims = new List<Claim>();
            var roleClaims = new List<Claim>();

            user.Permissions.ForEach(c => perClaims.Add(new Claim(ClaimTypes.Role, c)));
            user.Roles.ForEach(c => roleClaims.Add(new Claim(ClaimTypes.Role, c)));
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new[]
                {
                    new Claim("Id", user.Id),
                    new Claim(ClaimConstants.TenantId, user.TID),
                    new Claim(ClaimConstants.Tid, user.TID),
                    new Claim(JwtRegisteredClaimNames.Email, user.Email_Address),
                    new Claim(JwtRegisteredClaimNames.Sub, user.Email_Address),
                    new Claim(JwtRegisteredClaimNames.GivenName, user.First_Name),
                    new Claim(JwtRegisteredClaimNames.FamilyName, user.Last_Name),
                    new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
                }),
                Expires = DateTime.UtcNow.AddHours(6),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature),
                Audience = "blueprint-api",
                Issuer = Environment.GetEnvironmentVariable("TOKEN_SERVER")
            };

            tokenDescriptor.Subject.AddClaims(perClaims);
            tokenDescriptor.Subject.AddClaims(roleClaims);

            var token = jwtTokenHandler.CreateToken(tokenDescriptor);
            var jwtToken = jwtTokenHandler.WriteToken(token);

            return jwtToken;
        }

        public RefreshTokenDto GenerateRefreshToken(string ipAddress)
        {
            // generate token that is valid for 7 days
            using var rngCryptoServiceProvider = new RNGCryptoServiceProvider();
            var randomBytes = new byte[64];
            rngCryptoServiceProvider.GetBytes(randomBytes);
            var refreshToken = new RefreshTokenDto
            {
                Token = Convert.ToBase64String(randomBytes),
                Expires = DateTime.UtcNow.AddDays(7),
                Created = DateTime.UtcNow,
                CreatedByIp = ipAddress
            };

            return refreshToken;
        }

        public int? ValidateJwtToken(string token)
        {
            throw new System.NotImplementedException();
        }
    }
}
