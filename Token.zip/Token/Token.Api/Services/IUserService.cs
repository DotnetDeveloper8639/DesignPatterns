﻿using System.Threading.Tasks;
using Token.Api.Models;

namespace Token.Api.Services
{
    public interface IUserService
    {
        Task<bool> CheckIfUserActive(string userId); 
        Task<ApiResponse<string>> CreateUserAsync(UserDto userDTO);

        Task<ApiResponse<bool>> AddRefreshTokenToUser(string userId, RefreshTokenDto refreshToken);

        Task<ApiResponse<TokenResponse>> RefreshAccessToken(string refreshToken, string ipAddress, string tid);

        Task<ApiResponse<TokenResponse>> CreateTokenResponse(UserDto userDTO,string ipAddress);

    }
}
