﻿using Token.Api.DbContextClass;
using System.Linq;
using System.Threading.Tasks;
using Token.Api.Models;
using System;
using System.Net;
using Token.Api.EntityModel;
using AutoMapper;
using System.Collections.Generic;

namespace Token.Api.Services
{
    public class UserService : IUserService
    {
        private readonly UserManagementDbContext dbContext;
        private readonly IMapper mapper;
        private readonly IJwtUtils jwtUtils;
        private readonly IUserRoleAssignmentService userRoleAssignmentService;

        public UserService(UserManagementDbContext dbContext
            , IMapper mapper
            , IJwtUtils jwtUtils
            , IUserRoleAssignmentService userRoleAssignmentService)
        {
            this.dbContext = dbContext;
            this.mapper = mapper;
            this.jwtUtils = jwtUtils;
            this.userRoleAssignmentService = userRoleAssignmentService;
        }

        public async Task<ApiResponse<bool>> AddRefreshTokenToUser(string userId, RefreshTokenDto refreshToken)
        {
            var apiResponse = new ApiResponse<bool>();
            bool isTokenAdded = false;

            try
            {
                 var user = dbContext.TblUsers.FirstOrDefault(u => u.id == userId);

                var isExists = user != null;

                if (isExists)
                {
                    var refreshTokenEntity = mapper.Map<TblRefreshToken>(refreshToken);

                    user.RefreshTokens.Add(refreshTokenEntity);

                    dbContext.Update(user);

                    dbContext.SaveChanges();

                    isTokenAdded = true;

                    apiResponse.StatusCode = (int)HttpStatusCode.OK;
                    apiResponse.StatusReason = "Token Added successfully";

                    user.RefreshTokens.RemoveAll(x => !x.IsActive && x.Created.AddDays(7) <= DateTime.UtcNow);
                }
                else
                {

                    apiResponse.StatusCode = (int)HttpStatusCode.NotFound;
                    apiResponse.StatusReason = "User does not exists.";
                }
            }
            catch (Exception ex)
            {
                apiResponse.StatusCode = (int)HttpStatusCode.InternalServerError;
                apiResponse.StatusReason = ex.Message;
            }

            apiResponse.Data = isTokenAdded;

            return apiResponse;
        }

        public async Task<bool> CheckIfUserActive(string userId)
        {
            var user = dbContext.TblUsers.Where(u => u.email_address == userId && u.isactive == true).FirstOrDefault();

            return user != null;
        }

        public async Task<ApiResponse<string>> CreateUserAsync(UserDto userDTO)
        {
            bool isUserAdded = false;
            string userId = string.Empty;
            var apiResponse = new ApiResponse<string>();
            try
            {
                var userFromDb = dbContext.TblUsers.Where(u => u.email_address == userDTO.Email_Address && u.isactive == true).FirstOrDefault();
                var isExists = userFromDb != null;

                if (isExists)
                {
                    userId = userFromDb.id;
                    apiResponse.StatusCode = (int)HttpStatusCode.BadRequest;
                    apiResponse.StatusReason = "User already exists.";
                }
                else
                {
                    var users = dbContext.TblUsers.Where(u => u.email_address == userDTO.Email_Address).FirstOrDefault();
                    if (users != null)
                    {
                        users.isactive = true;
                        dbContext.TblUsers.Update(users);
                        dbContext.SaveChanges();
                    }
                    else
                    {
                        userDTO.IsActive = true;
                        var entity = mapper.Map<TblUser>(userDTO);
                        entity.id = Guid.NewGuid().ToString();

                        dbContext.TblUsers.Add(entity);

                        await dbContext.SaveChangesAsync();

                        isUserAdded = true;

                        userId = entity.id;

                    }

                    apiResponse.StatusCode = (int)HttpStatusCode.OK;
                    apiResponse.StatusReason = "User Added successfully";
                }
            }
            catch (Exception ex)
            {
                apiResponse.StatusCode = (int)HttpStatusCode.InternalServerError;
                apiResponse.StatusReason = ex.Message;
            }

            apiResponse.Data = userId;

            return apiResponse;
        }

        public async Task<ApiResponse<TokenResponse>> RefreshAccessToken(string refreshToken, string ipAddress, string tid)
        {
            var response = new ApiResponse<TokenResponse>();

            var errorResponse = new ApiResponse<TokenResponse>() { Data = null, StatusCode = (int)HttpStatusCode.BadRequest, StatusReason = "Invalid Refresh Token" };
            var user = dbContext.TblUsers.SingleOrDefault(u => u.RefreshTokens.Any(t => t.Token == refreshToken));
            if (user == null) 
                return errorResponse;

            var token = user.RefreshTokens.Single(x => x.Token == refreshToken);

            if (token.IsRevoked)
            {
                // revoke all descendant tokens in case this token has been compromised
                revokeDescendantRefreshTokens(token, user, ipAddress, $"Attempted reuse of revoked ancestor token: {token}");
                dbContext.Update(user);
                dbContext.SaveChangesAsync();
            }

            if (!token.IsActive)
                return errorResponse;

            // replace old refresh token with a new one (rotate token)
            var newRefreshToken = rotateRefreshToken(token, ipAddress);
            user.RefreshTokens.Add(newRefreshToken);

            // remove old refresh tokens from user
            removeOldRefreshTokens(user);

            // save changes to db
            dbContext.Update(user);
            dbContext.SaveChangesAsync();

            var userDto = mapper.Map<UserDto>(user);

            userDto.TID = tid;

            var userPermisson = await userRoleAssignmentService.GetUserPermissionsByUserEmailAsync(userDto.Email_Address);

            userDto.Permissions = userPermisson?.Permissions ?? new List<string>();
            userDto.IsGlobalAdmin = userPermisson?.IsGlobalAdmin ?? false;
            userDto.Profile_Data = userPermisson?.Profile_Data ?? string.Empty;
            userDto.Roles = userPermisson?.Roles ?? new List<string>();
            // generate new jwt
            var jwtToken = await  jwtUtils.GenerateJwtToken(userDto);

            return new ApiResponse<TokenResponse>()
            {
                Data = new TokenResponse()
                {
                    AccessToken = jwtToken,
                    ApiUser = userDto,
                    RefreshToken = newRefreshToken.Token
                },
                StatusCode = (int)HttpStatusCode.OK,
                StatusReason = "Token Generated Successfully"
            };
        }

        public async Task<ApiResponse<TokenResponse>> CreateTokenResponse(UserDto userDto, string ipAddress)
        {
            if (string.IsNullOrEmpty(userDto.Id) || string.IsNullOrEmpty(userDto.TID)) return null;

            var userPermission = await userRoleAssignmentService.GetUserPermissionsByUserEmailAsync(userDto.Email_Address);

            userDto.Permissions = userPermission.Permissions;
            userDto.IsGlobalAdmin = userPermission.IsGlobalAdmin;
            userDto.Profile_Data = userPermission.Profile_Data;
            userDto.Roles = userPermission.Roles;
            var jwtToken = await jwtUtils.GenerateJwtToken(userDto);
            var refreshToken = jwtUtils.GenerateRefreshToken(ipAddress);

            AddRefreshTokenToUser(userDto.Id, refreshToken);

            return new ApiResponse<TokenResponse>() 
            {
                Data = new TokenResponse()
                {
                    AccessToken = jwtToken,
                    ApiUser=userDto,
                    RefreshToken = refreshToken.Token
                },
                StatusCode= (int)HttpStatusCode.OK,
                StatusReason = "Token response created successfully."
            };
        }

        private void revokeDescendantRefreshTokens(TblRefreshToken refreshToken, TblUser user, string ipAddress, string reason)
        {
            // recursively traverse the refresh token chain and ensure all descendants are revoked
            if (!string.IsNullOrEmpty(refreshToken.ReplacedByToken))
            {
                var childToken = user.RefreshTokens.SingleOrDefault(x => x.Token == refreshToken.ReplacedByToken);
                if (childToken.IsActive)
                    revokeRefreshToken(childToken, ipAddress, reason);
                else
                    revokeDescendantRefreshTokens(childToken, user, ipAddress, reason);
            }
        }

        private void revokeRefreshToken(TblRefreshToken token, string ipAddress, string reason = null, string replacedByToken = null)
        {
            token.Revoked = DateTime.UtcNow;
            token.RevokedByIp = ipAddress;
            token.ReasonRevoked = reason;
            token.ReplacedByToken = replacedByToken;
        }

        private TblRefreshToken rotateRefreshToken(TblRefreshToken refreshToken, string ipAddress)
        {
            var newRefreshToken = mapper.Map<TblRefreshToken>(jwtUtils.GenerateRefreshToken(ipAddress));
            revokeRefreshToken(refreshToken, ipAddress, "Replaced by new token", newRefreshToken.Token);
            return newRefreshToken;
        }

        private void removeOldRefreshTokens(TblUser user)
        {
            // remove old inactive refresh tokens from user based on TTL in app settings
            user.RefreshTokens.RemoveAll(x =>
                !x.IsActive &&
                x.Created.AddDays(7) <= DateTime.UtcNow);
        }
    }
}
