﻿using Token.Api.DbContextClass;
using Token.Api.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Token.Api.EntityModel;
using System.Net;

namespace Token.Api.Services
{
    public class UserRoleAssignmentService : IUserRoleAssignmentService
    {
        private readonly UserManagementDbContext dbContext;
        private readonly IRoleService roleService;

        public UserRoleAssignmentService(UserManagementDbContext dbContext
            ,IRoleService roleService)
        {
            this.dbContext = dbContext;
            this.roleService = roleService;
        }

        public async Task<ApiResponse<bool>> AssignDefaultRoleToUser(string userId)
        {
            var roleResponse = await roleService.CreateDefaultRoleIfNotExists();

            var isRoleAssigned = false;
            var apiResponse = new ApiResponse<bool>();

            try
            {
                if (!string.IsNullOrEmpty(roleResponse.Data))
                {
                    var isDefaultRoleExists = dbContext.TblUserRoleAssignments
                        .FirstOrDefault(ura => ura.user_id == userId && ura.role_id == roleResponse.Data) != null;

                    if(!isDefaultRoleExists)
                    {
                        var roleAssignment = new TblUserRoleAssignment()
                        {
                            user_id = userId,
                            role_id = roleResponse.Data,
                            id = Guid.NewGuid().ToString()
                        };

                        dbContext.TblUserRoleAssignments.Add(roleAssignment);

                        dbContext.SaveChanges();

                        isRoleAssigned = true;

                        apiResponse.StatusCode = (int)HttpStatusCode.OK;
                        apiResponse.StatusReason = "User(s) added to role successfully.";
                    }

                    else
                    {
                        isRoleAssigned = true;

                        apiResponse.StatusCode = (int)HttpStatusCode.OK;
                        apiResponse.StatusReason = "Default role to user already exists.";
                    }
                }
            }
            catch (Exception ex)
            {
                apiResponse.StatusCode = (int)HttpStatusCode.InternalServerError;
                apiResponse.StatusReason = ex.Message;
            }

            apiResponse.Data = isRoleAssigned;

            return apiResponse;
        }

        public async Task<UserRoleMapDto> GetUserPermissionsByUserEmailAsync(string email)
        {
            var userRolesMapModel = new UserRoleMapDto();
            var user = dbContext.TblUsers.FirstOrDefault(user => user.email_address == email);

            if (user != null)
            {
                userRolesMapModel.UserId = user.id;
                userRolesMapModel.Profile_Data = user.profile_data;

                //var builtInRoles = allBuiltInRoles.Where()

                var isGlobalAdminRole = (from role in dbContext.TblRoles
                                        join userRole in dbContext.TblUserRoleAssignments on role.id equals userRole.role_id
                                        where userRole.user_id == user.id && role.IsGlobalAdminRole select role).Count() > 0;
                var userRoles = (from role in dbContext.TblRoles
                                 join userRole in dbContext.TblUserRoleAssignments on role.id equals userRole.role_id
                                 where userRole.user_id == user.id
                                 select role.role_name);
                userRolesMapModel.Roles = userRoles.ToList();
                userRolesMapModel.IsGlobalAdmin = isGlobalAdminRole;

                if (isGlobalAdminRole)
                {
                    userRolesMapModel.Permissions = dbContext.TblPermissions.Where(p => p.is_active).Select(perm => perm.name).ToList();
                }
                else
                {
                    var userPermissions = (from permission in dbContext.TblPermissions
                                           join rolePerms in dbContext.TblPermissionAssociations on permission.id equals rolePerms.permission_id
                                           join userRole in dbContext.TblUserRoleAssignments on rolePerms.role_id equals userRole.role_id
                                           where userRole.user_id == user.id && permission.is_active
                                           select permission.name).ToList();

                    var userGroup = dbContext.TblUserAndGroupAssociations.Where(uga => uga.members == user.id);
                    List<string> groupPermissions = new List<string>();
                    if (userGroup != null)
                    {
                        var groupIds = userGroup.Select(uga => uga.group_id).ToList();

                        groupPermissions = (from permission in dbContext.TblPermissions
                                            join rolePerms in dbContext.TblPermissionAssociations on permission.id equals rolePerms.permission_id
                                            join userRole in dbContext.TblUserRoleAssignments on rolePerms.role_id equals userRole.role_id
                                            where groupIds.Contains(userRole.group_id) && permission.is_active
                                            select permission.name).ToList();
                    }
                    //builtInRoles.Union()

                    userRolesMapModel.Permissions = userPermissions.Union(groupPermissions).ToList();
                }
                
            }

            return userRolesMapModel;
        }

        //private List<string> GetGroupRolesByGroupIds(List<string> groupIds)
        //{

        //}

        //private List<string> GetA(List<string> groupIds)
        //{

        //}
    }
}
