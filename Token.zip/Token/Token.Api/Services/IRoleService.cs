﻿using System.Threading.Tasks;
using Token.Api.Models;

namespace Token.Api.Services
{
    public interface IRoleService
    {
        Task<ApiResponse<string>> CreateDefaultRoleIfNotExists();
    }
}
