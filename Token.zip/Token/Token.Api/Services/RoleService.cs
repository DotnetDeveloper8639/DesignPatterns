﻿using System;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Token.Api.DbContextClass;
using Token.Api.EntityModel;
using Token.Api.Models;

namespace Token.Api.Services
{
    public class RoleService : IRoleService
    {
        private readonly UserManagementDbContext dbContext;

        public RoleService(UserManagementDbContext dbContext)
        {
            this.dbContext = dbContext;
        }
        public async Task<ApiResponse<string>> CreateDefaultRoleIfNotExists()
        {
            string createdRoleId = string.Empty;
            var apiResponse = new ApiResponse<string>();
            try
            {
                var defaultRole = dbContext.TblRoles.FirstOrDefault(r => r.IsDefault);
                if (defaultRole == null)
                {
                    string roleId = Guid.NewGuid().ToString();
                    var newEntity = new TblRole()
                    {
                        id = roleId,
                        IsDefault = true,
                        IsGlobalAdminRole = true,
                        role_name = "Global Admin"
                    };

                    dbContext.TblRoles.Add(newEntity);

                    dbContext.SaveChanges();

                    createdRoleId = roleId;

                    apiResponse.StatusCode = (int)HttpStatusCode.OK;
                    apiResponse.StatusReason = "Role created successfully.";
                }
                else
                {
                    createdRoleId = defaultRole.id;
                    apiResponse.StatusCode = (int)HttpStatusCode.BadRequest;
                    apiResponse.StatusReason = "Role name already exists.";
                }
            }
            catch (Exception ex)
            {
                apiResponse.StatusCode = (int)HttpStatusCode.InternalServerError;
                apiResponse.StatusReason = ex.Message;
            }

            apiResponse.Data = createdRoleId;

            return apiResponse;
        }
    }
}
