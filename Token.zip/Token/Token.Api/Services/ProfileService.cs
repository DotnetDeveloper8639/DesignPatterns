﻿//using IdentityModel;
//using IdentityServer4.Models;
//using IdentityServer4.Services;
//using System.Security.Claims;
//using System.Threading.Tasks;
//using IdentityServer4.Extensions;
//using System.Linq;
//using System.Collections.Generic;

//namespace IdentityServer.API.Services
//{
//    public class ProfileService : IProfileService
//    {
//        private readonly IUserRoleAssignmentService roleUserMappingService;
//        private readonly IUserService userService;

//        public ProfileService(IUserRoleAssignmentService roleUserMappingService
//            ,IUserService userService)
//        {
//            this.roleUserMappingService = roleUserMappingService;
//            this.userService = userService;
//        }
//        public async Task GetProfileDataAsync(ProfileDataRequestContext context)
//        {
//            var emailId = context.Subject.Claims.FirstOrDefault(c => c.Type == JwtClaimTypes.Subject)?.Value;
//            var existingClaims = context.Subject.Claims.ToList();

//            if (!existingClaims.Any(c => c.Type == JwtClaimTypes.Role)
//                || !existingClaims.Any(c => c.Type == JwtClaimTypes.Name)
//                || !existingClaims.Any(c => c.Type == JwtClaimTypes.Id))
//            {
//                var roles = await roleUserMappingService.GetUserPermissionsByUserEmailAsync(emailId);

//                roles.Permissions.ForEach(c => existingClaims.Add(new Claim(JwtClaimTypes.Role, c)));
//                existingClaims.Add(new Claim(JwtClaimTypes.Id, roles.UserId));
//                //var roles = dbContext.TblUsers
//                //existingClaims.Add(new Claim(JwtClaimTypes.PhoneNumber, "1234567890"));
//                //existingClaims.Add(new Claim(JwtClaimTypes.Role, "securedFiles.admin"));
//                //existingClaims.Add(new Claim(JwtClaimTypes.Role, "securedFiles.user"));
//                //existingClaims.Add(new Claim(JwtClaimTypes.Role, "securedFiles"));
//                //existingClaims.Add(new Claim(JwtClaimTypes.Role, "Project.Get"));
//                existingClaims.Add(new Claim(JwtClaimTypes.Name, context.Subject.GetDisplayName()));
//            }
//            context.IssuedClaims = existingClaims;

//        }

//        public async Task IsActiveAsync(IsActiveContext context)
//        {
//            var sub = context.Subject.GetSubjectId();
//            //var user = await _userManager.FindByIdAsync(sub);
//            context.IsActive =  await userService.CheckIfUserActive(sub);
//        }
//    }
//}
