﻿using System.Threading.Tasks;
using Token.Api.EntityModel;
using Token.Api.Models;

namespace Token.Api.Services
{
    public interface IJwtUtils
    {
        public Task<string> GenerateJwtToken(UserDto user);
        public int? ValidateJwtToken(string token);
        public RefreshTokenDto GenerateRefreshToken(string ipAddress);
    }
}
