﻿using Token.Api.Models;
using System.Threading.Tasks;

namespace Token.Api.Services
{
    public interface IUserRoleAssignmentService
    {
        Task<UserRoleMapDto> GetUserPermissionsByUserEmailAsync(string email);
        Task<ApiResponse<bool>> AssignDefaultRoleToUser(string userId);
    }
}
