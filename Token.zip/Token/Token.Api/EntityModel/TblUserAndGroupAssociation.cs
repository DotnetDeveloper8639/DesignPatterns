﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Token.Api.EntityModel
{
    [Table("tblUserAndGroupAssociation")]
    public class TblUserAndGroupAssociation
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column(TypeName = "nvarchar(50)")]
        public string id { get; set; }

        [Column(TypeName ="nvarchar(50)")]
        [ForeignKey("TblUsers")]
        public string members { get; set; }

        [Column(TypeName ="nvarchar(50)")]
        [ForeignKey("TblGroups")]
        public string group_id { get; set; }
    }
}
