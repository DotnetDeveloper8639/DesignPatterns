﻿namespace Token.Api.EntityModel
{
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System;
    using System.Text.Json.Serialization;
    using System.Collections.Generic;

    [Table("tblUsers")]
    public class TblUser
    {
        public TblUser()
        {
            this.id = Guid.NewGuid().ToString();
        }

        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column(TypeName = "nvarchar(50)")]
        public string id { get; set; }
        [Column(TypeName = "varchar(80)")]
        public string first_name { get; set; }
        [Column(TypeName = "varchar(80)")]
        public string last_name { get; set; }
        [Column(TypeName = "varchar(160)")]
        public string display_name { get; set; }
        //[Column(TypeName = "varchar(90)")]
        //public string login_name { get; set; }
        [Column(TypeName = "varchar(150)")]
        public string email_address { get; set; }

        [Column(TypeName = "varchar(80)")]
        public string middle_initials { get; set; }
        [Column(TypeName = "varchar(255)")]
        public string user_principal_name { get; set; }
        [Column(TypeName = "varchar(100)")]
        public string tenant_id { get; set; }

        [Column(TypeName = "nvarchar(1000)")]
        public string user_image { get; set; }

        [Column(TypeName = "nvarchar(1000)")]
        public string profile_data { get; set; }
        [Column(TypeName = "bit")]
        public bool isactive { get; set; }

        [JsonIgnore]
        public List<TblRefreshToken> RefreshTokens { get; set; }
    }
}
