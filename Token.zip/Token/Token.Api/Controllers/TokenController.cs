﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Identity.Web;
using Microsoft.Identity.Web.Resource;
using Newtonsoft.Json;
using System;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using Token.Api.Models;
using Token.Api.Services;

namespace Token.Api.Controllers
{
    [Authorize]
    [Route("[controller]")]
    [ApiController]
    public class TokenController : ControllerBase
    {
        static readonly string[] scopeRequiredByApi = new string[] { "access_as_user" };
        private readonly ITokenAcquisition _tokenAcquisition;
        private readonly IUserService userService;
        private readonly IJwtUtils jwtUtils;
        private readonly IUserRoleAssignmentService userRoleAssignmentService;

        public TokenController(ITokenAcquisition tokenAcquisition
            , IUserService userService
            , IJwtUtils jwtUtils
            , IUserRoleAssignmentService userRoleAssignmentService)
        {
            _tokenAcquisition = tokenAcquisition;
            this.userService = userService;
            this.jwtUtils = jwtUtils;
            this.userRoleAssignmentService = userRoleAssignmentService;
        }

        [HttpGet]
        public async Task<IActionResult> GetAccessToken()
        {
            HttpContext.VerifyUserHasAnyAcceptedScope(scopeRequiredByApi);

            var userDto = new UserDto()
            {
                Display_Name = User.Claims.FirstOrDefault(c => c.Type == "name")?.Value ?? string.Empty,
                Email_Address = User.Claims.FirstOrDefault(c => c.Type == "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/upn")?.Value ?? string.Empty,
                First_Name = User.Claims.FirstOrDefault(c => c.Type == "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/givenname")?.Value ?? string.Empty,
                Last_Name = User.Claims.FirstOrDefault(c => c.Type == "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/surname")?.Value ?? string.Empty
            };

            var response = await userService.CreateUserAsync(userDto);

            if (response.StatusCode != (int)HttpStatusCode.InternalServerError)
            {
                userDto.Id = response.Data;
                userDto.TID = User.GetTenantId();

                // Assign Default Role to user
                //await userRoleAssignmentService.AssignDefaultRoleToUser(userDto.Id);

                // authentication successful so generate jwt and refresh tokens

                var tokenResponse = await userService.CreateTokenResponse(userDto, ipAddress());

                if(tokenResponse is null)
                    return new ContentResult()
                    {
                        StatusCode = (int) HttpStatusCode.BadRequest,
                        Content = "Failed to generate token",
                        ContentType = "text/plain"
                    };

                setTokenCookie(tokenResponse.Data?.RefreshToken ?? String.Empty);

                return new ContentResult()
                {
                    Content = JsonConvert.SerializeObject(tokenResponse),
                    ContentType = "application/json",
                    StatusCode = (int)HttpStatusCode.OK
                };
            }
            else
            {
                return new ContentResult()
                {
                    StatusCode = response.StatusCode,
                    Content = JsonConvert.SerializeObject(response),
                    ContentType = "application/json"
                };
            }
            //string accessToken = await _tokenAcquisition.GetAccessTokenForUserAsync(scopeRequiredByApi);
        }

        [AllowAnonymous]
        [HttpPost("refresh-token")]
        public async Task<IActionResult> RefreshToken()
        {
            var refreshToken = Request.Cookies["refreshToken"];
            var response = await userService.RefreshAccessToken(refreshToken, ipAddress(),User.GetTenantId());

            if (response.StatusCode == (int)HttpStatusCode.OK)
            setTokenCookie(response?.Data?.RefreshToken ?? string.Empty);

            return new ContentResult()
            {
                StatusCode = response.StatusCode,
                Content = JsonConvert.SerializeObject(response),
                ContentType = "application/json"
            };
        }

        private string ipAddress()
        {
            // get source ip address for the current request
            if (Request.Headers.ContainsKey("X-Forwarded-For"))
                return Request.Headers["X-Forwarded-For"];
            else
                return HttpContext.Connection.RemoteIpAddress.MapToIPv4().ToString();
        }

        private void setTokenCookie(string token)
        {
            // append cookie with refresh token to the http response
            var cookieOptions = new CookieOptions
            {
                HttpOnly = true,
                Expires = DateTime.UtcNow.AddDays(7)
            };
            Response.Cookies.Append("refreshToken", token, cookieOptions);
        }
    }
}
