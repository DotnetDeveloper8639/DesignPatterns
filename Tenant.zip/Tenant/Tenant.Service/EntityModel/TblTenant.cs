﻿namespace Tenant.Service.EntityModel
{
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;

    [Table("tblTenant")]
    public class TblTenant
    {
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Key]
        public int Id { get; set; }

        [Column(TypeName = "nvarchar(50)")]
        public string TID { get; set; }

        [Column(TypeName = "varchar(250)")]
        public string Name { get; set; }

        [Column(TypeName = "nvarchar(250)")]
        public string Domain { get; set; }

        [Column(TypeName = "nvarchar(1000)")]
        public string Connectionstring { get; set; }
    }
}
