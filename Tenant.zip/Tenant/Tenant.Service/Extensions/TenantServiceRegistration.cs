﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Reflection;
using Tenant.Service.DbContextClass;

namespace Tenant.Service
{
    public static class TenantServiceRegistration
    {
        public static void RegisterTenantService(this IServiceCollection services, IConfiguration configuration)
        {
            var migrationsAssembly = typeof(TenantServiceRegistration).GetTypeInfo().Assembly.GetName().Name;

            var tenantConnectionString = Environment.GetEnvironmentVariable("TENANTCONNECTION");

            services.AddMemoryCache();

            services.AddDbContext<TenantCatalogDbContext>(options =>
             options.UseSqlServer(tenantConnectionString,
             sql => sql.MigrationsAssembly(migrationsAssembly)), ServiceLifetime.Scoped);

            services.AddScoped<ITenantService, TenantService>();

            services.AddAutoMapper(typeof(TenantServiceRegistration));
        }
    }
}
