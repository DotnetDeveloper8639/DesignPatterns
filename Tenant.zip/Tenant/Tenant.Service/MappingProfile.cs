﻿namespace Tenant.Service
{
    using AutoMapper;
    using Tenant.Service.EntityModel;
    using Tenant.Service.Models;

    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<TenantDto, TblTenant>().ReverseMap();
        }
    }
}
