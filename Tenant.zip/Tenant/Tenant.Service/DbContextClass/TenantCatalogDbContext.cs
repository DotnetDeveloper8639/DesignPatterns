﻿namespace Tenant.Service.DbContextClass
{
    using Microsoft.EntityFrameworkCore;
    using Microsoft.Extensions.Configuration;
    using Tenant.Service.EntityModel;

    public class TenantCatalogDbContext : DbContext
    {
        private readonly IConfiguration _configuration;
        public TenantCatalogDbContext()
        {
        }

        public TenantCatalogDbContext(DbContextOptions<TenantCatalogDbContext> options, IConfiguration configuration)
                     : base(options)
        {
            _configuration = configuration;
        }

        public virtual DbSet<TblTenant> TblTenants { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {

            //optionsBuilder.UseSqlServer(_configuration.GetConnectionString("sqlConnection"), o => o.);
        }
    }
}
