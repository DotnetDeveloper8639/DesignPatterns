﻿using Tenant.Service.Models;
using System.Threading.Tasks;

namespace Tenant.Service
{
    public interface ITenantService
    {
        TenantDto GetTenantInfo(string tid);
    }
}
