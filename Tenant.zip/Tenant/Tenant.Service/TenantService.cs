﻿using AutoMapper;
using System.Linq;
using Tenant.Service.DbContextClass;
using Tenant.Service.Models;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using System;
using System.Collections.Generic;

namespace Tenant.Service
{
    public class TenantService : ITenantService
    {
        private readonly TenantCatalogDbContext dbContext;
        private readonly IMapper mapper;
        private readonly IMemoryCache _memoryCache;

        public TenantService(TenantCatalogDbContext dbContext
            , IMapper mapper
            , IMemoryCache memoryCache)
        {
            this.dbContext = dbContext;
            this.mapper = mapper;
            this._memoryCache = memoryCache;
        }
        public TenantDto GetTenantInfo(string tid)
        {
            if (!_memoryCache.TryGetValue("TenantInfo", out List<TenantDto> tenantInfo))
            {
                //cacheValue = CurrentDateTime;
                tenantInfo = new List<TenantDto>();

                var tenantsFromDb = dbContext.TblTenants.ToList();

                tenantInfo = mapper.Map<List<TenantDto>>(tenantsFromDb);

                var cacheEntryOptions = new MemoryCacheEntryOptions()
                    .SetSlidingExpiration(TimeSpan.FromHours(730));

                _memoryCache.Set("TenantInfo", tenantInfo, cacheEntryOptions);

            }

            return tenantInfo.FirstOrDefault(t => t.TID == tid);

        }
    }
}
