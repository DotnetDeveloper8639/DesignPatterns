﻿using AutoMapper;
using EventBus.Abstractions;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Offer.API.DbContextClass;
using Offer.API.EntityModels;
using Offer.API.IntegrationEvents.Events;
using Offer.API.Models.EnumClasses;
using Offer.API.Models.OfferDTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Threading.Tasks;
using Microsoft.Identity.Web;
using System.IdentityModel.Tokens.Jwt;
using Offer.API.IntegrationEvents.NotifcatonEvents;
using System.Security.Claims;
using System.Text;
using EventBus.Events;
using Newtonsoft.Json;
using Offer.API.Helper;

namespace Offer.API.Services
{
    public class OfferStatusService : RepositoryBase<TblOffer>, IOfferStatusService
    {
        private readonly Sch_Context _context;
        private readonly IEventBus _messageBus;
        private readonly IMapper mapper;
        private readonly IHttpContextAccessor httpContextAccessor;
        public IDataProtector _protection;
        public IMasterMachineService _masterMachines;
        public readonly string offerSecurityString = "InpupOffeRR!@!$oTe*&*cti&onS%ch*em#aRsal!";
        private readonly IEventBus eventBus;
        public OfferStatusService(Sch_Context context
             , IEventBus messageBus
             //, IDataProtectionProvider protection
             , IMapper mapper
             , IHttpContextAccessor httpContextAccessor
             , IEventBus _eventBus
             , IMasterMachineService masterMachines) : base(context)
        {
            _context = context;
            _messageBus = messageBus;
            this.mapper = mapper;
            this.httpContextAccessor = httpContextAccessor;
            //_protection = protection.CreateProtector(offerSecurityString);
            eventBus = _eventBus;
            _masterMachines = masterMachines;
        }
        public async Task<string> CreateOffer(CreateOfferDTO createOfferAPIModel)
        {
            string Result = string.Empty;
            bool isServiceCreated = false;

            try
            {
                List<TblService> tblServiceList = new();
                List<TblMachine> tblMachineList = new();
                List<TblContact> tblContactList = new();
                List<TblServiceMachine> tblServiceMachinesList = new();
                TblContact tblContact = new();
                List<TblMachineCustomerAssociation> machineCustomerAssociationList = new();
                List<TblControlSystem> controlSystemList = new();
                List<TblSpecificFeature> specificFeatureList = new();
                List<TblMachineType> machineTypeList = new();
                List<TblApplication> applicationList = new();
                List<TblMachineCustomerAssociationTimeStamp> machineCustomerAssociationTimeStampList = new();
                List<TblControlSystemTimeStamp> controlSystemTimeStampList = new();
                List<TblSpecificFeatureTimeStamp> specificFeatureTimeStampList = new();
                List<TblMachineTypeTimeStamp> machineTypeTimeStampList = new();
                List<TblApplicationTimeStamp> applicationTimeStampList = new();
                List<TblMachineTypeAssociation> machineTypeAssociationList = new();
                List<TblMachineSpecificFeature> machineSpecificFeatureList = new();
                List<TblMachineApplication> machineApplicationList = new();
                List<TblMachineControlSystem> machineControlSystemList = new();
                List<TblMachineMediaMaster> machineMediaMasterList = new();

                var offerId = GenerateOfferId();

                createOfferAPIModel.Offer.offer_id = offerId;

                TblOpportunity tblOpportunity = new();
                string OpportunityId = GenerateOpportunityId();
                tblOpportunity.id = OpportunityId.ToString();
                tblOpportunity.customer_name = createOfferAPIModel.Customer.customer_name;
                tblOpportunity.status = "In Progress";
                tblOpportunity.project_id = createOfferAPIModel.Offer.project_id;
                tblOpportunity.created_at = DateTimeOffset.Now;
                tblOpportunity.modified_at = DateTimeOffset.Now;

                _context.TblOpportunity.Add(tblOpportunity);



                TblOffer tblOffer = new();
                tblOffer.id = offerId;
                tblOffer.opportunity_id = OpportunityId.ToString();
                tblOffer.project_id = createOfferAPIModel.Offer.project_id;
                tblOffer.contact_id = createOfferAPIModel.Offer.contact_id;
                tblOffer.notes = createOfferAPIModel.Offer.notes;
                tblOffer.quote_template_type = createOfferAPIModel.Offer.quote_template_type;
                tblOffer.quote_type = createOfferAPIModel.Offer.quote_type;
                tblOffer.status = createOfferAPIModel.Offer.status;
                tblOffer.offer_kpi_id = _context.TblOfferKPI.FirstOrDefault()?.id ?? String.Empty;
                tblOffer.is_commercial_quote = false;
                tblOffer.created_by = GetCurrentUserId();
                tblOffer.modified_by = string.Empty;
                tblOffer.created_at = DateTimeOffset.Now;
                tblOffer.modified_at = DateTimeOffset.Now;

                _context.TblOffers.Add(tblOffer);

                #region Log AuditEntry
                TblAuditEntry tblAuditEntry = new();
                tblAuditEntry.id = Guid.NewGuid().ToString();
                tblAuditEntry.project_id = createOfferAPIModel.Offer.project_id;
                tblAuditEntry.erp_project_id = _context.TblProjects.FirstOrDefault(p => p.id == createOfferAPIModel.Offer.project_id).erp_project_id ?? null;
                tblAuditEntry.offer_id = offerId;
                tblAuditEntry.action = "Create";
                tblAuditEntry.scope = "New Offer " + offerId + " has been added";
                tblAuditEntry.created_at = DateTimeOffset.UtcNow;
                tblAuditEntry.user_id = _context.TblUser.FirstOrDefault(p => p.id == GetCurrentUserId())?.email_address ?? null;
                tblAuditEntry.affected_table = "TblOffer";
                _context.TblAuditEntry.Add(tblAuditEntry);
                #endregion

                string conId = createOfferAPIModel.Contact.contact_id; ///checking contact in offer lever
                if (!string.IsNullOrEmpty(conId))
                {
                    TblContact contact = _context.TblContacts.Where(x => x.contact_id == conId).FirstOrDefault();
                    if (contact == null)
                    {

                        tblContact.contact_id = createOfferAPIModel.Contact.contact_id;
                        tblContact.phone_number = createOfferAPIModel.Contact.phone_number;
                        tblContact.display_name = createOfferAPIModel.Contact.display_name;
                        tblContact.email_address = createOfferAPIModel.Contact.email_address;
                        tblContact.created_by = createOfferAPIModel.Contact.created_by;
                        tblContact.modified_by = createOfferAPIModel.Contact.modified_by;
                        tblContact.created_at = DateTimeOffset.Now;
                        tblContact.modified_at = DateTimeOffset.Now;
                        tblContactList.Add(tblContact);

                    }
                }
                string serviceId = string.Empty;
                #region Service Creation Start
                for (var i = 0; i < createOfferAPIModel.Offer.Service.Count; i++)
                {
                    #region Checking_Contact_InServiceLevel
                    string service_ContctId = createOfferAPIModel.Offer.Service[i].contact_id; ///checking contact in offer lever
                    if (!string.IsNullOrEmpty(service_ContctId))
                    {
                        TblContact service_contact = _context.TblContacts.Where(x => x.contact_id == service_ContctId).FirstOrDefault();
                        if (service_contact == null)
                        {
                            TblContact tblErpContact = new();

                            tblErpContact = _context.TblContacts.Where(y => y.contact_id == service_ContctId).FirstOrDefault();
                            if (tblErpContact != null)
                            {
                                tblContact.contact_id = tblErpContact.contact_id;
                                tblContact.first_name = tblErpContact.first_name;
                                tblContact.last_name = tblErpContact.last_name;
                                tblContact.phone_number = tblErpContact.phone_number;
                                tblContact.display_name = tblErpContact.display_name;
                                tblContact.email_address = tblErpContact.email_address;
                                tblContact.created_by = tblErpContact.created_by;
                                tblContact.modified_by = tblErpContact.modified_by;
                                tblContact.created_at = DateTimeOffset.Now;
                                tblContact.modified_at = DateTimeOffset.Now;
                                tblContactList.Add(tblContact);
                            }
                        }
                    }
                    #endregion

                    TblService tblService = new TblService();

                    if (i == 0)
                    {
                        serviceId = GenerateServiceId();
                    }
                    else
                    {
                        serviceId = GenerateServiceId(serviceId);
                    }
                    createOfferAPIModel.Offer.Service[i].id = serviceId;

                    tblService.id = serviceId.ToString();
                    tblService.erp_wbs_id = createOfferAPIModel.Offer.Service[i].erp_wbs_id;
                    tblService.project_id = createOfferAPIModel.Offer.Service[i].project_id;
                    tblService.offer_id = offerId;
                    tblService.contact_id = createOfferAPIModel.Offer.Service[i].contact_id;
                    tblService.service_type = createOfferAPIModel.Offer.Service[i].service_type;
                    tblService.service_location = createOfferAPIModel.Offer.Service[i].service_location;
                    tblService.is_active = createOfferAPIModel.Offer.Service[i].is_active;
                    tblService.created_by = createOfferAPIModel.Offer.Service[i].created_by;
                    tblService.modified_by = createOfferAPIModel.Offer.Service[i].modified_by;
                    tblService.actual_hours = createOfferAPIModel.Offer.Service[i].actual_hours;
                    tblService.total_estimated_hours = createOfferAPIModel.Offer.Service[i].total_estimated_hours;
                    tblService.start_date = createOfferAPIModel.Offer.Service[i].start_date;
                    tblService.end_date = createOfferAPIModel.Offer.Service[i].end_date;
                    tblService.service_description = createOfferAPIModel.Offer.Service[i].service_description;
                    tblService.service_region = createOfferAPIModel.Offer.Service[i].service_region;
                    tblService.is_ra_external = createOfferAPIModel.Offer.Service[i].is_ra_external;
                    tblService.external_ra_notes = createOfferAPIModel.Offer.Service[i].external_ra_notes;
                    tblService.service_kpi_id = _context.TblServiceKPI.FirstOrDefault()?.id ?? string.Empty;
                    tblService.created_at = DateTimeOffset.Now;
                    tblService.modified_at = DateTimeOffset.Now;
                    tblService.status = MachineStatus.NOT_STARTED;

                    tblServiceList.Add(tblService);
                    #region Log AuditEntry
                    TblAuditEntry tblServiceAuditEntry = new();
                    tblServiceAuditEntry.id = Guid.NewGuid().ToString();
                    tblServiceAuditEntry.project_id = createOfferAPIModel.Offer.project_id;
                    tblServiceAuditEntry.erp_project_id = _context.TblProjects.FirstOrDefault(p => p.id == createOfferAPIModel.Offer.project_id).erp_project_id ?? null;
                    tblServiceAuditEntry.offer_id = offerId;
                    tblServiceAuditEntry.service_id = tblService.id;
                    tblServiceAuditEntry.action = "Create";
                    tblServiceAuditEntry.scope = "New Service " + tblService.id ?? String.Empty + " has been added";
                    tblServiceAuditEntry.created_at = DateTimeOffset.UtcNow;
                    tblServiceAuditEntry.user_id = _context.TblUser.FirstOrDefault(p => p.id == GetCurrentUserId())?.email_address ?? null; ;
                    tblServiceAuditEntry.affected_table = "TblService";
                    _context.TblAuditEntry.Add(tblServiceAuditEntry);
                    #endregion
                    isServiceCreated = true;
                    #region Machine Creation Start
                    if (createOfferAPIModel.Offer.Service[i].Machine.Count != 0)
                    {
                        for (var j = 0; j < createOfferAPIModel.Offer.Service[i].Machine.Count; j++)
                        {
                            if (createOfferAPIModel.Offer.Service[i].Machine[j].id != string.Empty)
                            {
                                TblServiceMachine tblServiceMachine = new TblServiceMachine();
                                Guid guid = Guid.NewGuid();
                                tblServiceMachine.id = Convert.ToString(guid);
                                tblServiceMachine.service_id = serviceId.ToString();
                                tblServiceMachine.machine_id = createOfferAPIModel.Offer.Service[i].Machine[j].id;
                                tblServiceMachine.estimated_hours = createOfferAPIModel.Offer.Service[i].Machine[j].estimated_hours;
                                tblServiceMachine.created_at = DateTimeOffset.Now;
                                tblServiceMachine.modified_at = DateTimeOffset.Now;
                                tblServiceMachinesList.Add(tblServiceMachine);
                                #region Add Roadmap and Hazard details to machine
                                if (createOfferAPIModel.Offer.Service[i].is_risk_assessment == true)
                                {
                                    if (createOfferAPIModel.Offer.Service[i].Machine[j].roadmap_details != null)
                                    {
                                        var smId = _context.TblServiceMachines.Where(sm => sm.machine_id == createOfferAPIModel.Offer.Service[i].Machine[j].id && sm.service_id == tblService.id).FirstOrDefault();
                                        await CreateRoadmap(createOfferAPIModel.Offer.Service[i].Machine[j].roadmap_details, guid.ToString());
                                    }
                                }
                                //For creating roadmaps for RiskReAssessment
                                if (createOfferAPIModel.Offer.Service[i].is_risk_reassessment == true)
                                {
                                    var smId = _context.TblServiceMachines.Where(sm => sm.machine_id == createOfferAPIModel.Offer.Service[i].Machine[j].id && sm.service_id == tblService.id).FirstOrDefault();
                                    var roadmaps = await GetAllMachineRoadmaps(createOfferAPIModel.Offer.Service[i].Machine[j].id);
                                    if (roadmaps.Any())
                                    {
                                        await RiskReAssessmentRoadmap(roadmaps, guid.ToString());
                                    }
                                }
                                #endregion
                                #region Log AuditEntry
                                TblAuditEntry tblMachineAuditEntry = new();
                                tblMachineAuditEntry.id = Guid.NewGuid().ToString();
                                tblMachineAuditEntry.project_id = createOfferAPIModel.Offer.project_id;
                                tblMachineAuditEntry.erp_project_id = _context.TblProjects.FirstOrDefault(p => p.id == createOfferAPIModel.Offer.project_id)?.erp_project_id ?? null;
                                tblMachineAuditEntry.offer_id = offerId;
                                tblMachineAuditEntry.service_id = serviceId.ToString();
                                tblMachineAuditEntry.action = "Create";
                                tblMachineAuditEntry.scope = "New Machine " + createOfferAPIModel.Offer.Service[i].Machine[j].machine_name + " has been added";
                                tblMachineAuditEntry.created_at = DateTimeOffset.UtcNow;
                                tblMachineAuditEntry.user_id = _context.TblUser.FirstOrDefault(p => p.id == GetCurrentUserId())?.email_address ?? null;
                                tblMachineAuditEntry.affected_table = "TblMachine";
                                _context.TblAuditEntry.Add(tblMachineAuditEntry);
                                _context.SaveChanges();
                                #endregion
                                createOfferAPIModel.Offer.Service[i].Machine[j].id = Convert.ToString(guid);
                            }
                            else
                            {

                                TblMachine tblMachine = new();
                                TblMachineCustomerAssociation machineCustomerAssociation = new();
                                TblControlSystem controlSystem = new();
                                TblSpecificFeature specificFeature = new();
                                TblMachineType machineType = new();
                                TblApplication application = new();
                                TblMachineCustomerAssociationTimeStamp machineCustomerAssociationTimeStamp = new();
                                TblControlSystemTimeStamp controlSystemTimeStamp = new();
                                TblSpecificFeatureTimeStamp specificFeatureTimeStamp = new();
                                TblMachineTypeTimeStamp machineTypeTimeStamp = new();
                                TblApplicationTimeStamp applicationTimeStamp = new();
                                TblMachineTypeAssociation machineTypeAssociation = new();
                                TblMachineSpecificFeature machineSpecificFeature = new();
                                TblMachineApplication machineApplication = new();
                                TblMachineControlSystem machineControlSystem = new();

                                var duplicateMachine = _context.TblMachines.Where(m => m.machine_name.ToLower() == createOfferAPIModel.Offer.Service[i].Machine[j].machine_name.ToLower()).FirstOrDefault();
                                if (duplicateMachine == null)
                                {

                                    Guid guidMachineId = Guid.NewGuid();
                                    GetMachineDto materMachines = new()
                                    {
                                        Machine_Name = createOfferAPIModel.Offer.Service[i].Machine[j].machine_name,
                                        Machine_Type = createOfferAPIModel.Offer.Service[i].Machine[j].machine_type,
                                        Asset_Number = createOfferAPIModel.Offer.Service[i].Machine[j].asset_id,
                                        Serial_Number = createOfferAPIModel.Offer.Service[i].Machine[j].serial_number,
                                        Description = createOfferAPIModel.Offer.Service[i].Machine[j].machine_description,
                                        Customer_Id = createOfferAPIModel.Offer.Service[i].Machine[j].Customer_Id,
                                        IndustrySegment = createOfferAPIModel.Offer.Service[i].Machine[j].IndustrySegment,
                                        Id = Convert.ToString(guidMachineId)
                                    };

                                    var machineStatus = await _masterMachines.CreateMasterMachine(materMachines);

                                    if (machineStatus)
                                    {
                                        TblServiceMachine tblServiceMachine = new TblServiceMachine();
                                        Guid guid = Guid.NewGuid();
                                        tblServiceMachine.id = Convert.ToString(guid);
                                        tblServiceMachine.service_id = serviceId.ToString();
                                        tblServiceMachine.machine_id = Convert.ToString(guidMachineId);
                                        tblServiceMachine.estimated_hours = tblMachine.estimated_hours;
                                        tblServiceMachine.created_at = DateTimeOffset.Now;
                                        tblServiceMachine.modified_at = DateTimeOffset.Now;
                                        tblServiceMachinesList.Add(tblServiceMachine);

                                        machineCustomerAssociation.id = Guid.NewGuid().ToString();
                                        machineCustomerAssociation.machine_id = Convert.ToString(guidMachineId);
                                        machineCustomerAssociation.customer_id = createOfferAPIModel.Offer.Service[i].Machine[j]?.Customer_Id;
                                        machineCustomerAssociation.segments = createOfferAPIModel.Offer.Service[i].Machine[j]?.IndustrySegment;

                                        machineCustomerAssociationTimeStamp.id = Guid.NewGuid().ToString();
                                        machineCustomerAssociationTimeStamp.machinecustomerassociation_id = machineCustomerAssociation.id;
                                        machineCustomerAssociationTimeStamp.created_at = DateTimeOffset.Now;
                                        machineCustomerAssociationTimeStamp.created_by = GetCurrentUserId();
                                        machineCustomerAssociationTimeStamp.modified_at = DateTimeOffset.Now;
                                        machineCustomerAssociationTimeStamp.modified_by = GetCurrentUserId();
                                        machineCustomerAssociationTimeStampList.Add(machineCustomerAssociationTimeStamp);
                                        machineCustomerAssociationList.Add(machineCustomerAssociation);

                                        for (int m = 0; m < createOfferAPIModel.Offer.Service[i].Machine[j].MachineMetadata.Count; m++)
                                        {
                                            for (int con = 0; con < createOfferAPIModel.Offer.Service[i].Machine[j].MachineMetadata[m].ControlSystem.Count; con++)
                                            {
                                                controlSystemTimeStamp.id = Guid.NewGuid().ToString();
                                                controlSystemTimeStamp.controlsystem_id = createOfferAPIModel.Offer.Service[i].Machine[j].MachineMetadata[m]?.ControlSystem[con];
                                                controlSystemTimeStamp.created_at = DateTimeOffset.Now;
                                                controlSystemTimeStamp.created_by = GetCurrentUserId();
                                                controlSystemTimeStamp.modified_at = DateTimeOffset.Now;
                                                controlSystemTimeStamp.modified_by = GetCurrentUserId();
                                                controlSystemTimeStampList.Add(controlSystemTimeStamp);

                                                machineControlSystem.id = Guid.NewGuid().ToString();
                                                machineControlSystem.machine_id = Convert.ToString(guid);
                                                machineControlSystem.controlsystem_id = createOfferAPIModel.Offer.Service[i].Machine[j].MachineMetadata[m]?.ControlSystem[con];
                                                machineControlSystem.created_at = DateTimeOffset.Now;
                                                machineControlSystem.created_by = GetCurrentUserId();
                                                machineControlSystem.modified_at = DateTimeOffset.Now;
                                                machineControlSystem.modified_by = GetCurrentUserId();
                                                machineControlSystemList.Add(machineControlSystem);
                                            }

                                            applicationTimeStamp.id = Guid.NewGuid().ToString();
                                            applicationTimeStamp.application_id = createOfferAPIModel.Offer.Service[i].Machine[j].MachineMetadata[m]?.Application;
                                            applicationTimeStamp.created_at = DateTimeOffset.Now;
                                            applicationTimeStamp.created_by = GetCurrentUserId();
                                            applicationTimeStamp.modified_at = DateTimeOffset.Now;
                                            applicationTimeStamp.modified_by = GetCurrentUserId();

                                            machineApplication.id = Guid.NewGuid().ToString();
                                            machineApplication.machine_id = Convert.ToString(guidMachineId);
                                            machineApplication.application_id = createOfferAPIModel.Offer.Service[i].Machine[j].MachineMetadata[m]?.Application;
                                            machineApplication.created_at = DateTimeOffset.Now;
                                            machineApplication.created_by = GetCurrentUserId();
                                            machineApplication.modified_at = DateTimeOffset.Now;
                                            machineApplication.modified_by = GetCurrentUserId();
                                            machineApplicationList.Add(machineApplication);
                                            applicationTimeStampList.Add(applicationTimeStamp);

                                            for (int spf = 0; spf < createOfferAPIModel.Offer.Service[i].Machine[j].MachineMetadata[m].SpecificFeature.Count; spf++)
                                            {
                                                specificFeatureTimeStamp.id = Guid.NewGuid().ToString();
                                                specificFeatureTimeStamp.specificfeature_id = createOfferAPIModel.Offer.Service[i].Machine[j].MachineMetadata[m]?.SpecificFeature[spf];
                                                specificFeatureTimeStamp.created_at = DateTimeOffset.Now;
                                                specificFeatureTimeStamp.created_by = GetCurrentUserId();
                                                specificFeatureTimeStamp.modified_at = DateTimeOffset.Now;
                                                specificFeatureTimeStamp.modified_by = GetCurrentUserId();

                                                machineSpecificFeature.id = Guid.NewGuid().ToString();
                                                machineSpecificFeature.machine_id = Convert.ToString(guidMachineId);
                                                machineSpecificFeature.specificfeature_id = createOfferAPIModel.Offer.Service[i].Machine[j].MachineMetadata[m]?.SpecificFeature[spf];
                                                machineSpecificFeature.created_at = DateTimeOffset.Now;
                                                machineSpecificFeature.created_by = GetCurrentUserId();
                                                machineSpecificFeature.modified_at = DateTimeOffset.Now;
                                                machineSpecificFeature.modified_by = GetCurrentUserId();
                                                machineSpecificFeatureList.Add(machineSpecificFeature);
                                                specificFeatureTimeStampList.Add(specificFeatureTimeStamp);
                                            }

                                            machineTypeTimeStamp.id = Guid.NewGuid().ToString();
                                            machineTypeTimeStamp.machinetype_id = createOfferAPIModel.Offer.Service[i].Machine[j].MachineMetadata[m]?.MachineType;
                                            machineTypeTimeStamp.created_at = DateTimeOffset.Now;
                                            machineTypeTimeStamp.created_by = GetCurrentUserId();
                                            machineTypeTimeStamp.modified_at = DateTimeOffset.Now;
                                            machineTypeTimeStamp.modified_by = GetCurrentUserId();

                                            machineTypeAssociation.id = Guid.NewGuid().ToString();
                                            machineTypeAssociation.machine_id = Convert.ToString(guidMachineId);
                                            machineTypeAssociation.machinetype_id = createOfferAPIModel.Offer.Service[i].Machine[j].MachineMetadata[m]?.MachineType;
                                            machineTypeAssociation.created_at = DateTimeOffset.Now;
                                            machineTypeAssociation.created_by = GetCurrentUserId();
                                            machineTypeAssociation.modified_at = DateTimeOffset.Now;
                                            machineTypeAssociation.modified_by = GetCurrentUserId();

                                            machineTypeAssociationList.Add(machineTypeAssociation);
                                            machineTypeTimeStampList.Add(machineTypeTimeStamp);
                                        }

                                        #region Add Roadmap and Hazard details to machine
                                        if (createOfferAPIModel.Offer.Service[i].is_risk_assessment == true)
                                        {
                                            if (createOfferAPIModel.Offer.Service[i].Machine[j].roadmap_details != null)
                                            {
                                                var smId = _context.TblServiceMachines.Where(sm => sm.machine_id == tblMachine.id && sm.service_id == tblService.id).FirstOrDefault();
                                                await CreateRoadmap(createOfferAPIModel.Offer.Service[i].Machine[j].roadmap_details, guid.ToString());
                                            }
                                        }
                                        //For creating roadmaps for RiskReAssessment
                                        if (createOfferAPIModel.Offer.Service[i].is_risk_reassessment == true)
                                        {
                                            var smId = _context.TblServiceMachines.Where(sm => sm.machine_id == tblMachine.id && sm.service_id == tblService.id).FirstOrDefault();
                                            var roadmaps = await GetAllMachineRoadmaps(createOfferAPIModel.Offer.Service[i].Machine[j].id);
                                            if (roadmaps.Any())
                                            {
                                                await RiskReAssessmentRoadmap(roadmaps, guid.ToString());
                                            }
                                        }
                                        #endregion
                                        #region Log AuditEntry
                                        TblAuditEntry tblMachineAuditEntry = new();
                                        tblMachineAuditEntry.id = Guid.NewGuid().ToString();
                                        tblMachineAuditEntry.project_id = createOfferAPIModel.Offer.project_id;
                                        tblMachineAuditEntry.erp_project_id = _context.TblProjects.FirstOrDefault(p => p.id == createOfferAPIModel.Offer.project_id)?.erp_project_id ?? null;
                                        tblMachineAuditEntry.offer_id = offerId;
                                        tblMachineAuditEntry.service_id = serviceId.ToString();
                                        tblMachineAuditEntry.action = "Create";
                                        tblMachineAuditEntry.scope = "New Machine " + createOfferAPIModel.Offer.Service[i].Machine[j].machine_name + " has been added";
                                        tblMachineAuditEntry.created_at = DateTimeOffset.UtcNow;
                                        tblMachineAuditEntry.user_id = _context.TblUser.FirstOrDefault(p => p.id == GetCurrentUserId())?.email_address ?? null;
                                        tblMachineAuditEntry.affected_table = "TblMachine";
                                        _context.TblAuditEntry.Add(tblMachineAuditEntry);
                                        _context.SaveChanges();
                                        #endregion
                                        createOfferAPIModel.Offer.Service[i].Machine[j].id = Convert.ToString(guid);
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        TblServiceMachine tblServiceMachine = new();
                        tblServiceMachine.id = Guid.NewGuid().ToString();
                        tblServiceMachine.service_id = serviceId.ToString();
                        tblServiceMachine.machine_id = "00000000-0000-0000-0000-000000000000";
                        tblServiceMachine.created_at = DateTimeOffset.Now;
                        tblServiceMachine.modified_at = DateTimeOffset.Now;

                        tblServiceMachinesList.Add(tblServiceMachine);
                    }
                    #endregion

                }
                #endregion
                _context.TblContacts.AddRange(tblContactList);
                _context.TblServices.AddRange(tblServiceList);
                //_context.TblMachines.AddRange(tblMachineList);
                _context.TblServiceMachines.AddRange(tblServiceMachinesList);
                _context.TblMachineCustomerAssociation.AddRange(machineCustomerAssociationList);
                _context.TblMachineCustomerAssociationTimeStamp.AddRange(machineCustomerAssociationTimeStampList);
                _context.TblMachineTypeTimeStamp.AddRange(machineTypeTimeStampList);
                _context.TblSpecificFeatureTimeStamp.AddRange(specificFeatureTimeStampList);
                _context.TblApplicationTimeStamp.AddRange(applicationTimeStampList);
                _context.TblControlSystemTimeStamp.AddRange(controlSystemTimeStampList);
                _context.TblMachineTypeAssociation.AddRange(machineTypeAssociationList);
                _context.TblMachineSpecificFeature.AddRange(machineSpecificFeatureList);
                _context.TblMachineApplication.AddRange(machineApplicationList);
                _context.TblMachineControlSystem.AddRange(machineControlSystemList);
                _context.SaveChanges();
                Result = "Offer Created Successfully";

                PublishOfferCreationToERP(createOfferAPIModel);
            }
            catch (Exception ex)
            {
                Console.Write(ex);
                Result = "Offer Creation Failed";
            }
            //sive code end
            return Result;
        }
        private string GenerateServiceId(string value)
        {
            //var serviceId = string.Empty;
            Task.Delay(100);
            var Id = Convert.ToInt32(value.Substring(3));
            Id++;

            string serviceId = $"{Id:0000000000}";
            string newServiceId = "SRV" + serviceId;

            return newServiceId;
        }
        private string GenerateServiceId()
        {
            Task.Delay(100);

            var lastRecord = _context.TblServices.OrderBy(sr => sr.created_at)?.LastOrDefault()?.id ?? string.Empty;

            var Id = string.IsNullOrEmpty(lastRecord) || lastRecord.Contains("-") ? 0 : Convert.ToInt32(lastRecord.Substring(3)); //Convert.ToInt32(lastRecord.id.Substring(3));
            Id++;

            string serviceId = $"{Id:0000000000}";
            string newServiceId = "SRV" + serviceId;

            return newServiceId;
        }

        private string GenerateOfferId()
        {
            //var serviceId = string.Empty;
            Task.Delay(100);

            var lastRecord = _context.TblOffers.OrderBy(or => or.created_at).LastOrDefault()?.id ?? string.Empty;

            var Id = string.IsNullOrEmpty(lastRecord) || lastRecord.Contains("-") ? 0 : Convert.ToInt32(lastRecord.Substring(3)); //Convert.ToInt32(lastRecord.id.Substring(3));
            Id++;

            string offerId = $"{Id:0000000000}";
            string newOfferd = "OFR" + offerId;

            return newOfferd;
        }
        private string GenerateOpportunityId()
        {
            Task.Delay(100);

            var lastRecord = _context.TblOpportunity.OrderBy(op => op.created_at).LastOrDefault() ?? null;

            var Id = lastRecord != null ? Convert.ToInt32(lastRecord.id.Substring(3)) : 0; //Convert.ToInt32(lastRecord.id.Substring(3));
            Id++;

            string opportunityId = $"{Id:0000000000}";
            string newOpportunityId = "OPR" + opportunityId;

            return newOpportunityId;
        }
        private async Task PublishOfferCreationToERP(CreateOfferDTO createOfferAPIModel)
        {
            try
            {
                var dbProject = _context.TblProjects.FirstOrDefault(p => p.id == createOfferAPIModel.Offer.project_id);
                var companyCode = dbProject?.company_id ?? String.Empty;

                var techincalHeader = new RequestTechnicalHeader()
                {
                    TenantID = httpContextAccessor.HttpContext?.User?.GetTenantId() ?? String.Empty,
                    CompanyCode = companyCode,
                    EmailAddress = httpContextAccessor.HttpContext?.User?.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Email)?.Value ?? String.Empty,
                    RequestID = Guid.NewGuid().ToString(),
                    Timestamp = DateTime.UtcNow
                };
                var wbsOffer = mapper.Map<WbsOffer>(createOfferAPIModel);

                var erpProjectId = dbProject?.erp_project_id ?? String.Empty;

                wbsOffer.ERPProjectID = erpProjectId;
                wbsOffer.ProjectID = createOfferAPIModel.Offer.project_id;

                var services = mapper.Map<List<WbsService>>(createOfferAPIModel.Offer.Service);
                foreach (var service in services.Select((value, index) => new { value, index }))
                {
                    var dtoService = createOfferAPIModel.Offer.Service[service.index] ?? null;
                    var serviceProduct = dtoService?.service_type?.Split('-') ?? new List<string>().ToArray();

                    service.value.ServiceProductID = serviceProduct.Count() > 0 ? serviceProduct[0].Trim() : String.Empty;
                    service.value.Type = serviceProduct.Count() > 1 ? serviceProduct[1].Trim() : String.Empty;

                    service.value.TotalSumInHours = dtoService?.Machine?.Sum(m => m.estimated_hours) ?? 0;

                    var machines = mapper.Map<List<WbsMachine>>(dtoService.Machine);

                    var machineIdList = dtoService?.Machine?.Select(m => new { masterId = m.master_machine_id, Id = m.id });

                    var masterMachineIds = machineIdList.Select(m => m.masterId).ToList();

                    var machineManufacturer = _context.TblMasterMachines.Where(mm => masterMachineIds.Contains(mm.id)).ToList();

                    var dbContact = _context.TblContacts.FirstOrDefault(c => c.contact_id == dtoService.contact_id);

                    if (dbContact is not null)
                    {
                        service.value.ContactPerson = dbContact.display_name;
                        service.value.ContactNumber = dbContact.phone_number;
                        service.value.ContactEmail = dbContact.email_address;
                    }

                    foreach (var machine in machines)
                    {
                        machine.Manufacturer = machineManufacturer
                            .FirstOrDefault(m => m.id == machineIdList.FirstOrDefault(ml => ml.Id == machine.MachineID).masterId)?
                            .manufacturer ?? string.Empty;
                    }

                    service.value.MachineDetails.Machines.AddRange(machines);
                }

                wbsOffer.Services.AddRange(services);

                var wbsRequestoToSAP = new WbsRequestEvent()
                {
                    TopicName = "wbsrequest",
                    Offer = wbsOffer,
                    TechnicalHeader = techincalHeader
                };

                _messageBus.PublishToQueue(wbsRequestoToSAP, true);
            }
            catch (Exception ex)
            {

            }
        }

        public string GetEnumMemberAttrValue(Type enumType, object enumVal)
        {
            var memInfo = enumType.GetMember(enumVal.ToString());
            var attr = memInfo[0].GetCustomAttributes(false).OfType<EnumMemberAttribute>().FirstOrDefault();
            if (attr != null)
            {
                return attr.Value;
            }

            return null;
        }
        public string GeneateServiceId(int value)
        {
            string serviceId = (from record in _context.TblServices orderby record.id select record.id).LastOrDefault();
            if (serviceId != "" && serviceId != null)
            {
                string newServiceId = serviceId.Substring(3);
                int increaseServiceId = value + 1;
                int newValue = int.Parse(newServiceId);


            }
            return "";
        }
        public string DeleteMachineById(List<string> list)
        {
            string msg = string.Empty;
            string deleteServiceMachineTable = string.Format("DELETE FROM [dbo].[tblServiceMachine] where machine_id IN ('{0}')", string.Join("','", list));
            //string adeleteMachineTable = string.Format("DELETE FROM [dbo].[tblMachine] where id IN ('{0}')", string.Join("','", list));
            //_context.Database.ExecuteSqlRaw(deleteServiceMachineTable);
            //int result = _context.Database.ExecuteSqlRaw(adeleteMachineTable);
            //if (result > 0)
            //{


            #region Delete Machine request to ERP

            var offer = (from offr in _context.TblOffers
                         join service in _context.TblServices on offr.id equals service.offer_id
                         join machine in _context.TblServiceMachines on service.id equals machine.service_id
                         join project in _context.TblProjects on offr.project_id equals project.id
                         join cust in _context.TblCustomers on project.customer_id equals cust.id
                         join offrContact in _context.TblContacts on offr.contact_id equals offrContact.contact_id
                         join projectContact in _context.TblContacts on project.contact_id equals projectContact.contact_id
                         //join serviceContact in _context.TblContacts on service.contact_id equals serviceContact.contact_id
                         where list.Contains(machine.machine_id)
                         select new
                         {
                             offerId = offr.id,
                             //serviceId = service.id,
                             //serviceMachineId = machine.id,
                             projectId = offr.project_id,
                             offer_contact_person = offrContact.display_name,
                             offer_wbs_id = offr.WBSID,
                             erp_project_id = project.erp_project_id,
                             offer_status = offr.status,
                             offer_contact_email = offrContact.email_address,
                             offer_contact_number = offrContact.phone_number,
                             offer_quote_type = offr.quote_type,
                             offer_contact_id = offr.contact_id,
                             project_contact_id = project.contact_id,
                             companyCode = project.company_id
                         }).FirstOrDefault();

            //var wbsDeleteRequest = new List<WbsUpdateRequestEvent>();
            var wbsDeleteObject = new WbsUpdateRequestEvent();
            if (offer is not null)
            {


                wbsDeleteObject.Offer = new WbsUpdateRequestOffer();
                wbsDeleteObject.Offer.ContactPerson = offer.offer_contact_person;
                wbsDeleteObject.Offer.ERPProjectID = offer.erp_project_id;
                wbsDeleteObject.Offer.Status = offer.offer_status;
                wbsDeleteObject.Offer.ContactEmail = offer.offer_contact_email;
                wbsDeleteObject.Offer.ContactNumber = offer.offer_contact_number;
                wbsDeleteObject.Offer.OfferID = offer.offerId;
                wbsDeleteObject.Offer.ProjectID = offer.projectId;
                wbsDeleteObject.Offer.QuoteType = offer.offer_quote_type;
                wbsDeleteObject.Offer.WBSID = offer.offer_wbs_id;
                wbsDeleteObject.Offer.Services = new List<WbsUpdateRequestService>();

                var serviceDetails = (from service in _context.TblServices
                                          //join contact in _context.TblContacts on service.contact_id equals contact.contact_id

                                      select new
                                      {
                                          contactEmail = string.Empty,//contact.email_address,
                                          region = service.service_region,
                                          endDate = service.end_date,
                                          startDate = service.start_date,
                                          contactNumber = string.Empty,//contact.phone_number,
                                          contactPerson = string.Empty,//contact.display_name,
                                          description = service.service_description,
                                          location = service.service_location,
                                          serviceId = service.id,
                                          serviceProductId = service.service_type
                                      }).ToList();


                foreach (var service in serviceDetails)
                {
                    var includeService = _context.TblServiceMachines.Any(sm => sm.service_id == service.serviceId && list.Contains(sm.machine_id));
                    if (includeService)
                    {
                        var wbsService = new WbsUpdateRequestService();
                        var totalSumInHour = 0m;
                        var serviceProduct = service.serviceProductId?.Split('-') ?? new List<string>().ToArray();

                        wbsService.Action = "None";
                        wbsService.ContactEmail = service.contactEmail;
                        wbsService.Region = service.region;
                        wbsService.EndDate = service.endDate.Value;
                        wbsService.ContactNumber = service.contactNumber;
                        wbsService.ContactPerson = service.contactPerson;
                        wbsService.Description = service.description;
                        wbsService.Location = service.location;
                        wbsService.ServiceID = service.serviceId;
                        wbsService.ServiceProductID = serviceProduct.Count() > 0 ? serviceProduct[0].Trim() : String.Empty;
                        wbsService.StartDate = service.startDate.Value;
                        wbsService.Type = String.Empty;

                        var machines = (from machine in _context.TblMachines
                                        join serviceMachine in _context.TblServiceMachines on machine.id equals serviceMachine.machine_id
                                        where list.Contains(machine.id)
                                        select new
                                        {
                                            machineName = machine.machine_name,
                                            assetNumber = machine.asset_id,
                                            description = machine.machine_description,
                                            estimatedHour = machine.estimated_hours,
                                            machineId = serviceMachine.id,
                                            serialNumber = machine.serial_number,
                                            type = machine.machine_type,
                                            wbsId = serviceMachine.erp_wbs_id
                                        }).ToList();

                        var machineDetail = new WbsUpdateRequestMachineDetails();
                        machineDetail.Machines = new List<WbsUpdateMachine>();

                        foreach (var machine in machines)
                        {
                            var wbsMachine = new WbsUpdateMachine();

                            totalSumInHour = machine.estimatedHour + totalSumInHour;

                            wbsMachine.MachineName = machine.machineName;
                            wbsMachine.Action = "DELETE";
                            wbsMachine.AssetNumber = machine.assetNumber;
                            wbsMachine.Description = machine.description;
                            wbsMachine.EstimatedHours = machine.estimatedHour;
                            wbsMachine.MachineID = machine.machineId;
                            wbsMachine.Manufacturer = String.Empty;
                            wbsMachine.SerialNumber = machine.serialNumber;
                            wbsMachine.Type = machine.type;
                            wbsMachine.WBSID = machine.wbsId;

                            machineDetail.Machines.Add(wbsMachine);
                        }

                        wbsService.MachineDetails = machineDetail;
                        wbsService.TotalSumInHours = totalSumInHour;

                        wbsDeleteObject.Offer.Services.Add(wbsService);
                    }
                }

                var techincalHeader = new RequestTechnicalHeader()
                {
                    TenantID = httpContextAccessor.HttpContext?.User?.GetTenantId() ?? String.Empty,
                    CompanyCode = offer.companyCode,
                    EmailAddress = httpContextAccessor.HttpContext?.User?.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Email)?.Value ?? String.Empty,
                    RequestID = Guid.NewGuid().ToString(),
                    Timestamp = DateTime.UtcNow
                };


                wbsDeleteObject.TopicName = "wbsrequest";
                wbsDeleteObject.TechnicalHeader = techincalHeader;
            }

            #endregion


            int result = _context.Database.ExecuteSqlRaw(deleteServiceMachineTable);
            //int result = _context.Database.ExecuteSqlRaw(adeleteMachineTable);

            if (result > 0)
            {
                msg = "Machine Deleted Successfully";
                _messageBus.PublishToQueue(wbsDeleteObject, true);

                //var enumType = typeof(OfferNotificationTypes);
                //var enumVal = OfferNotificationTypes.MachineDeleted;
                //var userEmail = httpContextAccessor.HttpContext?.User?.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Email)?.Value ?? String.Empty;
                //var tenantId = httpContextAccessor.HttpContext?.User?.GetTenantId() ?? String.Empty;
                //eventBus.PublishToQueue(new OfferNotificationEvent(new List<string> { userEmail }, "Delete", "", tenantId, enumVal.ToString()) { TopicName = "offernotificationrequest" });
            }
            else
            {
                msg = "Machine failed to delete";
            }

            //}

            return msg;
        }
        public string DeleteOfferById(List<string> list)
        {
            string msg = string.Empty;
            //string deleteMachine = string.Format("DELETE FROM [dbo].[tblMachine] where id IN (SELECT machine_id from [dbo].[tblServiceMachine] where service_id in (SELECT id from tblService where offer_id in ('{0}')))", string.Join("','", list));
            string deleteServiceMachine = string.Format("DELETE FROM [dbo].[tblServiceMachine] where service_id IN(select id from tblService where offer_id in ('{0}'))", string.Join("','", list));
            string deleteService = string.Format("DELETE FROM [dbo].[tblService] where offer_id IN ('{0}')", string.Join("','", list));
            string deleteOffer = string.Format("DELETE FROM [dbo].[tblOffer] where id IN ('{0}')", string.Join("','", list));

            //_context.Database.ExecuteSqlRaw(deleteMachine);
            _context.Database.ExecuteSqlRaw(deleteServiceMachine);
            _context.Database.ExecuteSqlRaw(deleteService);
            int result = _context.Database.ExecuteSqlRaw(deleteOffer);
            if (result > 0)
            {
                msg = "Deleted Successfully";

                #region Delete Machine request to ERP

                var offerList = (from offr in _context.TblOffers
                                 join project in _context.TblProjects on offr.project_id equals project.id
                                 join cust in _context.TblCustomers on project.customer_id equals cust.id
                                 join offrContact in _context.TblContacts on offr.contact_id equals offrContact.contact_id
                                 join projectContact in _context.TblContacts on project.contact_id equals projectContact.contact_id
                                 //join serviceContact in _context.TblContacts on service.contact_id equals serviceContact.contact_id
                                 where list.Contains(offr.id)
                                 select new
                                 {
                                     offerId = offr.id,
                                     projectId = offr.project_id,
                                     offer_contact_person = offrContact.display_name,
                                     offer_wbs_id = offr.WBSID,
                                     erp_project_id = project.erp_project_id,
                                     offer_status = offr.status,
                                     offer_contact_email = offrContact.email_address,
                                     offer_contact_number = offrContact.phone_number,
                                     offer_quote_type = offr.quote_type,
                                     offer_contact_id = offr.contact_id,
                                     project_contact_id = project.contact_id,
                                     companyCode = project.company_id
                                 }).ToList();
                foreach (var offer in offerList)
                {
                    var wbsDeleteObject = new WbsUpdateRequestEvent();

                    wbsDeleteObject.Offer = new WbsUpdateRequestOffer();
                    wbsDeleteObject.Offer.ContactPerson = offer.offer_contact_person;
                    wbsDeleteObject.Offer.ERPProjectID = offer.erp_project_id;
                    wbsDeleteObject.Offer.Status = offer.offer_status;
                    wbsDeleteObject.Offer.ContactEmail = offer.offer_contact_email;
                    wbsDeleteObject.Offer.ContactNumber = offer.offer_contact_number;
                    wbsDeleteObject.Offer.OfferID = offer.offerId;
                    wbsDeleteObject.Offer.ProjectID = offer.projectId;
                    wbsDeleteObject.Offer.QuoteType = offer.offer_quote_type;
                    wbsDeleteObject.Offer.WBSID = offer.offer_wbs_id;
                    wbsDeleteObject.Offer.Services = new List<WbsUpdateRequestService>();

                    var serviceDetails = (from service in _context.TblServices
                                              //join contact in _context.TblContacts on service.contact_id equals contact.contact_id
                                          select new
                                          {
                                              contactEmail = string.Empty,//contact.email_address,
                                              region = service.service_region,
                                              endDate = service.end_date,
                                              startDate = service.start_date,
                                              contactNumber = string.Empty,//contact.phone_number,
                                              contactPerson = string.Empty,//contact.display_name,
                                              description = service.service_description,
                                              location = service.service_location,
                                              serviceId = service.id,
                                              serviceProductId = service.service_type
                                          }).ToList();

                    foreach (var service in serviceDetails)
                    {

                        var wbsService = new WbsUpdateRequestService();
                        var totalSumInHour = 0m;
                        var serviceProduct = service.serviceProductId?.Split('-') ?? new List<string>().ToArray();

                        wbsService.Action = "DELETE";
                        wbsService.ContactEmail = service.contactEmail;
                        wbsService.Region = service.region;
                        wbsService.EndDate = service.endDate.Value;
                        wbsService.ContactNumber = service.contactNumber;
                        wbsService.ContactPerson = service.contactPerson;
                        wbsService.Description = service.description;
                        wbsService.Location = service.location;
                        wbsService.ServiceID = service.serviceId;
                        wbsService.ServiceProductID = serviceProduct.Count() > 0 ? serviceProduct[0].Trim() : String.Empty;
                        wbsService.StartDate = service.startDate.Value;
                        wbsService.Type = String.Empty;

                        var machines = (from machine in _context.TblMachines
                                        join serviceMachine in _context.TblServiceMachines on machine.id equals serviceMachine.machine_id
                                        where list.Contains(machine.id)
                                        select new
                                        {
                                            machineName = machine.machine_name,
                                            assetNumber = machine.asset_id,
                                            description = machine.machine_description,
                                            estimatedHour = machine.estimated_hours,
                                            machineId = serviceMachine.id,
                                            serialNumber = machine.serial_number,
                                            type = machine.machine_type,
                                            wbsId = serviceMachine.erp_wbs_id
                                        }).ToList();

                        var machineDetail = new WbsUpdateRequestMachineDetails();
                        machineDetail.Machines = new List<WbsUpdateMachine>();

                        foreach (var machine in machines)
                        {
                            var wbsMachine = new WbsUpdateMachine();

                            totalSumInHour = machine.estimatedHour + totalSumInHour;

                            wbsMachine.MachineName = machine.machineName;
                            wbsMachine.Action = "DELETE";
                            wbsMachine.AssetNumber = machine.assetNumber;
                            wbsMachine.Description = machine.description;
                            wbsMachine.EstimatedHours = machine.estimatedHour;
                            wbsMachine.MachineID = machine.machineId;
                            wbsMachine.Manufacturer = String.Empty;
                            wbsMachine.SerialNumber = machine.serialNumber;
                            wbsMachine.Type = machine.type;
                            wbsMachine.WBSID = machine.wbsId;

                            machineDetail.Machines.Add(wbsMachine);
                        }

                        wbsService.MachineDetails = machineDetail;
                        wbsService.TotalSumInHours = totalSumInHour;

                        wbsDeleteObject.Offer.Services.Add(wbsService);
                    }

                    var techincalHeader = new RequestTechnicalHeader()
                    {
                        TenantID = httpContextAccessor.HttpContext?.User?.GetTenantId() ?? String.Empty,
                        CompanyCode = offer.companyCode,
                        EmailAddress = httpContextAccessor.HttpContext?.User?.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Email)?.Value ?? String.Empty,
                        RequestID = Guid.NewGuid().ToString(),
                        Timestamp = DateTime.UtcNow
                    };


                    wbsDeleteObject.TopicName = "wbsrequest";
                    wbsDeleteObject.TechnicalHeader = techincalHeader;

                    _messageBus.PublishToQueue(wbsDeleteObject, true);
                }

                #endregion

                #region Delete Offer Notification
                //foreach (var item in list)
                //{
                //    var tenantId = httpContextAccessor.HttpContext?.User?.GetTenantId() ?? String.Empty;
                //    var offerDetails = _context.TblOffers.Where(ofr => ofr.id == item).FirstOrDefault();
                //    var projectStaff = _context.TblProjectStaffs.Where(p => p.project_id == offerDetails.project_id).ToList();
                //    var email = GetStaffedUserEmails(projectStaff);
                //    eventBus.PublishToQueue(new OfferNotificationEvent(email, "Delete", "", tenantId, "The Offer with "+offerDetails.WBSID+" has been deleted") { TopicName = "offernotificationrequest" });

                //}
                #endregion


                //TODO : Change Notification Code here

                //var message = new NotificationMessage()
                //{
                //    Message = GetEnumMemberAttrValue(enumType, enumVal)
                //};
                //_messageBus.PublishMessage(message, "offernotification");
            }
            else
            {
                msg = "Offer failed to delete";

                //TODO : Change Notification Code here

                //var message = new NotificationMessage()
                //{
                //    Message = msg
                //};
                //_messageBus.PublishMessage(message, "offernotification");
            }
            return msg;

        }
        public string DeleteOfferServiceById(List<string> list)
        {
            string msg = string.Empty;
            foreach (var item in list)
            {
                var order = _context.TblOrder.Where(x => x.service_id == item).FirstOrDefault();
                if (order != null)
                {
                    return msg = "Can not delete service " + item + " associated with order";
                }
            }
            //string machineDelete = string.Format("DELETE FROM [dbo].[tblMachine] where id IN (SELECT machine_id from [dbo].[tblServiceMachine] where service_id in ('{0}'))", string.Join("','", list));
            string serviceMachineDelete = string.Format("DELETE FROM [dbo].[tblServiceMachine] where service_id IN ('{0}')", string.Join("','", list));
            string ServiceDelete = string.Format("DELETE FROM [dbo].[tblService] where id IN ('{0}')", string.Join("','", list));


            //if (result > 0)
            //{


            #region Delete Machine request to ERP

            var offer = (from offr in _context.TblOffers
                         join service in _context.TblServices on offr.id equals service.offer_id
                         join project in _context.TblProjects on offr.project_id equals project.id
                         join cust in _context.TblCustomers on project.customer_id equals cust.id
                         join offrContact in _context.TblContacts on offr.contact_id equals offrContact.contact_id
                         join projectContact in _context.TblContacts on project.contact_id equals projectContact.contact_id
                         //join serviceContact in _context.TblContacts on service.contact_id equals serviceContact.contact_id
                         where list.Contains(service.id)
                         select new
                         {
                             offerId = offr.id,
                             //serviceId = service.id,
                             //serviceMachineId = machine.id,
                             projectId = offr.project_id,
                             offer_contact_person = offrContact.display_name,
                             offer_wbs_id = offr.WBSID,
                             erp_project_id = project.erp_project_id,
                             offer_status = offr.status,
                             offer_contact_email = offrContact.email_address,
                             offer_contact_number = offrContact.phone_number,
                             offer_quote_type = offr.quote_type,
                             offer_contact_id = offr.contact_id,
                             project_contact_id = project.contact_id,
                             companyCode = project.company_id
                         }).FirstOrDefault();

            //var wbsDeleteRequest = new List<WbsUpdateRequestEvent>();

            var wbsDeleteObject = new WbsUpdateRequestEvent();

            if (offer is not null)
            {
                wbsDeleteObject.Offer = new WbsUpdateRequestOffer();
                wbsDeleteObject.Offer.ContactPerson = offer.offer_contact_person;
                wbsDeleteObject.Offer.ERPProjectID = offer.erp_project_id;
                wbsDeleteObject.Offer.Status = offer.offer_status;
                wbsDeleteObject.Offer.ContactEmail = offer.offer_contact_email;
                wbsDeleteObject.Offer.ContactNumber = offer.offer_contact_number;
                wbsDeleteObject.Offer.OfferID = offer.offerId;
                wbsDeleteObject.Offer.ProjectID = offer.projectId;
                wbsDeleteObject.Offer.QuoteType = offer.offer_quote_type;
                wbsDeleteObject.Offer.WBSID = offer.offer_wbs_id;
                wbsDeleteObject.Offer.Services = new List<WbsUpdateRequestService>();

                var serviceDetails = (from service in _context.TblServices
                                          //join contact in _context.TblContacts on service.contact_id equals contact.contact_id
                                      where list.Contains(service.id)
                                      select new
                                      {
                                          contactEmail = string.Empty,//contact.email_address,
                                          region = service.service_region,
                                          endDate = service.end_date,
                                          startDate = service.start_date,
                                          contactNumber = string.Empty,//contact.phone_number,
                                          contactPerson = string.Empty,//contact.display_name,
                                          description = service.service_description,
                                          location = service.service_location,
                                          serviceId = service.id,
                                          serviceProductId = service.service_type
                                      }).ToList();

                foreach (var service in serviceDetails)
                {

                    var wbsService = new WbsUpdateRequestService();
                    var totalSumInHour = 0m;
                    var serviceProduct = service.serviceProductId?.Split('-') ?? new List<string>().ToArray();

                    wbsService.Action = "DELETE";
                    wbsService.ContactEmail = service.contactEmail;
                    wbsService.Region = service.region;
                    wbsService.EndDate = service.endDate.Value;
                    wbsService.ContactNumber = service.contactNumber;
                    wbsService.ContactPerson = service.contactPerson;
                    wbsService.Description = service.description;
                    wbsService.Location = service.location;
                    wbsService.ServiceID = service.serviceId;
                    wbsService.ServiceProductID = serviceProduct.Count() > 0 ? serviceProduct[0].Trim() : String.Empty;
                    wbsService.StartDate = service.startDate.Value;
                    wbsService.Type = String.Empty;

                    var machines = (from machine in _context.TblMachines
                                    join serviceMachine in _context.TblServiceMachines on machine.id equals serviceMachine.machine_id
                                    where list.Contains(machine.id)
                                    select new
                                    {
                                        machineName = machine.machine_name,
                                        assetNumber = machine.asset_id,
                                        description = machine.machine_description,
                                        estimatedHour = machine.estimated_hours,
                                        machineId = serviceMachine.id,
                                        serialNumber = machine.serial_number,
                                        type = machine.machine_type,
                                        wbsId = serviceMachine.erp_wbs_id
                                    }).ToList();

                    var machineDetail = new WbsUpdateRequestMachineDetails();
                    machineDetail.Machines = new List<WbsUpdateMachine>();

                    foreach (var machine in machines)
                    {
                        var wbsMachine = new WbsUpdateMachine();

                        totalSumInHour = machine.estimatedHour + totalSumInHour;

                        wbsMachine.MachineName = machine.machineName;
                        wbsMachine.Action = "DELETE";
                        wbsMachine.AssetNumber = machine.assetNumber;
                        wbsMachine.Description = machine.description;
                        wbsMachine.EstimatedHours = machine.estimatedHour;
                        wbsMachine.MachineID = machine.machineId;
                        wbsMachine.Manufacturer = String.Empty;
                        wbsMachine.SerialNumber = machine.serialNumber;
                        wbsMachine.Type = machine.type;
                        wbsMachine.WBSID = machine.wbsId;

                        machineDetail.Machines.Add(wbsMachine);
                    }

                    wbsService.MachineDetails = machineDetail;
                    wbsService.TotalSumInHours = totalSumInHour;

                    wbsDeleteObject.Offer.Services.Add(wbsService);
                }

                var techincalHeader = new RequestTechnicalHeader()
                {
                    TenantID = httpContextAccessor.HttpContext?.User?.GetTenantId() ?? String.Empty,
                    CompanyCode = offer.companyCode,
                    EmailAddress = httpContextAccessor.HttpContext?.User?.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Email)?.Value ?? String.Empty,
                    RequestID = Guid.NewGuid().ToString(),
                    Timestamp = DateTime.UtcNow
                };


                wbsDeleteObject.TopicName = "wbsrequest";
                wbsDeleteObject.TechnicalHeader = techincalHeader;
            }




            #endregion

            //_context.Database.ExecuteSqlRaw(machineDelete);
            _context.Database.ExecuteSqlRaw(serviceMachineDelete);
            int result = _context.Database.ExecuteSqlRaw(ServiceDelete);

            if (result > 0)
            {
                msg = "Deleted Successfully";
                _messageBus.PublishToQueue(wbsDeleteObject, true);

                var enumType = typeof(OfferNotificationTypes);
                var enumVal = OfferNotificationTypes.OfferDeleted;

            }
            else
            {
                msg = "Failed to delete";
            }
            //}

            return msg;
        }

        public async Task<List<OfferStatusDTO>> GetOfferManagementDeatails()
        {
            //var userId = httpContextAccessor.HttpContext.User.Claims.FirstOrDefault(c => c.Type == "Id")?.Value ?? String.Empty;
            var result = new List<OfferStatusDTO>();
            try
            {
                if (IsUserOfferManager())
                    result = await (from offer in _context.TblOffers
                                    join p in _context.TblProjects on offer.project_id equals p.id
                                    join service1 in _context.TblServices on offer.id equals service1.offer_id into serviceGP
                                    from service in serviceGP.DefaultIfEmpty()   //left join to the offer table
                                    join customer in _context.TblCustomers on p.customer_id equals customer.id
                                    join con in _context.TblContacts on service.contact_id equals con.contact_id into contactGrp   //Contact details need to display service level
                                    from contact in contactGrp.DefaultIfEmpty()
                                    join assigneuser in _context.TblUsers on offer.assignee equals assigneuser.id into assignee
                                    from assignTo in assignee.DefaultIfEmpty() //left join to the offer table
                                    join offerkpi in _context.TblOfferKPI on offer.offer_kpi_id equals offerkpi.id into kpigj
                                    from offrKpi in kpigj.DefaultIfEmpty()
                                        //join prjstaff in _context.TblProjectStaffs on new { userId = GetCurrentUserId(), projectId = p.id } equals new { userId = prjstaff.user_id, projectId = prjstaff.project_id }
                                    orderby offer.created_at descending
                                    select new OfferStatusDTO
                                    {
                                        offer_id = offer.id,
                                        erp_wbs_id = offer.WBSID,
                                        project_id = p.id,
                                        erp_project_id = p.erp_project_id,
                                        encrypted_project_id = String.Empty,//_protection.Protect(p.id),
                                        Status = offer.status,
                                        notes = offer.notes,
                                        quote_template_type = offer.quote_template_type,
                                        offer_date = offer.created_at != null ? offer.created_at.ToString("dd/MM/yyyy") : null,
                                        Start_Date = service.start_date != null ? service.start_date.Value.ToString("dd/MM/yyyy") : null,
                                        End_Date = service.end_date != null ? service.end_date.Value.ToString("dd/MM/yyyy") : null,
                                        customer_name = customer.customer_name,
                                        customer_id = customer.customer_id,
                                        erp_customer_id = customer.erp_customer_id,
                                        service_type = service.service_type,
                                        service_id = service.id,
                                        service_wbs_id = service.erp_wbs_id,
                                        service_region = service.service_region,
                                        service_description = service.service_description,
                                        project_description = p.description,
                                        contact_id = contact.contact_id,
                                        contact_email = contact.email_address,
                                        contact_name = contact.first_name + " " + contact.last_name,
                                        contact_number = contact.phone_number,
                                        opportunity_date = null,
                                        roadmap_progress = offrKpi == null ? 0 : offrKpi.roadmap_progress,
                                        hours_progress = offrKpi == null ? 0 : offrKpi.hours_progress,
                                        assigned_to = assignTo == null ? string.Empty : assignTo.display_name,
                                        assignee = offer.assignee,
                                        erp_service_wbs_id = service.erp_wbs_id,
                                        is_commercial_quote = offer.is_commercial_quote
                                    }).ToListAsync();
                else
                    result = await (from offer in _context.TblOffers
                                    join p in _context.TblProjects on offer.project_id equals p.id
                                    join service1 in _context.TblServices on offer.id equals service1.offer_id into serviceGP
                                    from service in serviceGP.DefaultIfEmpty()   //left join to the offer table
                                    join customer in _context.TblCustomers on p.customer_id equals customer.id
                                    join con in _context.TblContacts on service.contact_id equals con.contact_id into contactGrp   //Contact details need to display service level
                                    from contact in contactGrp.DefaultIfEmpty()
                                    join assigneuser in _context.TblUsers on offer.assignee equals assigneuser.id into assignee
                                    from assignTo in assignee.DefaultIfEmpty() //left join to the offer table
                                    join offerkpi in _context.TblOfferKPI on offer.offer_kpi_id equals offerkpi.id into kpigj
                                    from offrKpi in kpigj.DefaultIfEmpty()
                                    join prjstaff in _context.TblProjectStaffs on new { userId = GetCurrentUserId(), projectId = p.id } equals new { userId = prjstaff.user_id, projectId = prjstaff.project_id }
                                    orderby offer.created_at descending
                                    select new OfferStatusDTO
                                    {
                                        offer_id = offer.id,
                                        erp_wbs_id = offer.WBSID,
                                        project_id = p.id,
                                        erp_project_id = p.erp_project_id,
                                        encrypted_project_id = String.Empty,//_protection.Protect(p.id),
                                        Status = offer.status,
                                        notes = offer.notes,
                                        quote_template_type = offer.quote_template_type,
                                        offer_date = offer.created_at != null ? offer.created_at.ToString("dd/MM/yyyy") : null,
                                        Start_Date = service.start_date != null ? service.start_date.Value.ToString("dd/MM/yyyy") : null,
                                        End_Date = service.end_date != null ? service.end_date.Value.ToString("dd/MM/yyyy") : null,
                                        customer_name = customer.customer_name,
                                        customer_id = customer.customer_id,
                                        erp_customer_id = customer.erp_customer_id,
                                        service_type = service.service_type,
                                        service_id = service.id,
                                        service_wbs_id = service.erp_wbs_id,
                                        service_region = service.service_region,
                                        service_description = service.service_description,
                                        project_description = p.description,
                                        contact_id = contact.contact_id,
                                        contact_email = contact.email_address,
                                        contact_name = contact.first_name + " " + contact.last_name,
                                        contact_number = contact.phone_number,
                                        opportunity_date = null,
                                        roadmap_progress = offrKpi == null ? 0 : offrKpi.roadmap_progress,
                                        hours_progress = offrKpi == null ? 0 : offrKpi.hours_progress,
                                        assigned_to = assignTo == null ? string.Empty : assignTo.display_name,
                                        assignee = offer.assignee,
                                        erp_service_wbs_id = service.erp_wbs_id,
                                        is_commercial_quote = offer.is_commercial_quote
                                    }).ToListAsync();
                return result;
            }
            catch (Exception ex)
            {
                Console.Write(ex);
                return null;
            }

        }
        public async Task<List<OfferStatusDTO>> GetOfferStatusDetailsById(string projectid, string offerId)
        {
            var result = new List<OfferStatusDTO>();
            if (IsUserOfferManager())
                result = await (from offer in _context.TblOffers
                                join p in _context.TblProjects on offer.project_id equals p.id
                                join service1 in _context.TblServices on offer.id equals service1.offer_id into serviceGP
                                from service in serviceGP.DefaultIfEmpty() //left join the offer table
                                join con in _context.TblContacts on offer.contact_id equals con.contact_id into contactGrp   //Contact details need to display service level
                                from contact in contactGrp.DefaultIfEmpty()
                                join customer in _context.TblCustomers on p.customer_id equals customer.id
                                join company in _context.TblCompanies on p.company_id equals company.company_code
                                join assigneuser in _context.TblUsers on offer.assignee equals assigneuser.id into assignee
                                from assignTo in assignee.DefaultIfEmpty() //left join to the offer table
                                where p.id == projectid && offer.id == offerId
                                select new OfferStatusDTO
                                {
                                    offer_id = offer.id,
                                    project_id = p.id,
                                    erp_project_id = p.erp_project_id,
                                    erp_wbs_id = offer.WBSID,
                                    encrypted_project_id = String.Empty,//_protection.Protect(p.id),
                                    Status = offer.status,
                                    notes = offer.notes,
                                    quote_type = offer.quote_type,
                                    quote_template_type = offer.quote_template_type,
                                    customer_name = customer.customer_name,
                                    customer_id = customer.customer_id,
                                    erp_customer_id = customer.erp_customer_id,
                                    street = customer.street,
                                    country_code = customer.country_code,
                                    zipcode = customer.zipcode,
                                    city = customer.city,
                                    service_type = service.service_type,
                                    service_id = service.id,
                                    project_description = p.description,
                                    contact_id = contact.contact_id,
                                    contact_email = contact.email_address,
                                    contact_name = contact.first_name + " " + contact.last_name,
                                    contact_number = contact.phone_number,
                                    company_code = company.company_code,
                                    company_name = company.company_name,
                                    assigned_to = assignTo.display_name,
                                    assignee = offer.assignee,
                                    erp_service_wbs_id = service.erp_wbs_id,
                                    is_commercial_quote = offer.is_commercial_quote,
                                    Project_Start_Date = p.start_date != null ? p.start_date.Value.ToString("dd/MM/yyyy") : null,
                                    Project_End_Date = p.end_date != null ? p.end_date.Value.ToString("dd/MM/yyyy") : null,
                                    IndustrySegment = _context.TblIndustrySegments.Where(i => i.id == customer.customer_id).FirstOrDefault().segments ?? null,
                                    job_Order_id = _context.TblOrder.Where(o => o.offer_id == offer.id && o.project_id == projectid).FirstOrDefault().erp_order_id ?? null
                                }).ToListAsync();
            else
                result = await (from offer in _context.TblOffers
                                join p in _context.TblProjects on offer.project_id equals p.id
                                join service1 in _context.TblServices on offer.id equals service1.offer_id into serviceGP
                                from service in serviceGP.DefaultIfEmpty() //left join the offer table
                                join con in _context.TblContacts on offer.contact_id equals con.contact_id into contactGrp   //Contact details need to display service level
                                from contact in contactGrp.DefaultIfEmpty()
                                join customer in _context.TblCustomers on p.customer_id equals customer.id
                                join company in _context.TblCompanies on p.company_id equals company.company_code
                                join assigneuser in _context.TblUsers on offer.assignee equals assigneuser.id into assignee
                                from assignTo in assignee.DefaultIfEmpty() //left join to the offer table
                                join prjstaff in _context.TblProjectStaffs on new { userId = GetCurrentUserId(), projectId = p.id } equals new { userId = prjstaff.user_id, projectId = prjstaff.project_id }
                                where p.id == projectid && offer.id == offerId
                                select new OfferStatusDTO
                                {
                                    offer_id = offer.id,
                                    project_id = p.id,
                                    erp_project_id = p.erp_project_id,
                                    erp_wbs_id = offer.WBSID,
                                    encrypted_project_id = String.Empty,//_protection.Protect(p.id),
                                    Status = offer.status,
                                    notes = offer.notes,
                                    quote_type = offer.quote_type,
                                    quote_template_type = offer.quote_template_type,
                                    customer_name = customer.customer_name,
                                    customer_id = customer.customer_id,
                                    erp_customer_id = customer.erp_customer_id,
                                    street = customer.street,
                                    country_code = customer.country_code,
                                    zipcode = customer.zipcode,
                                    city = customer.city,
                                    service_type = service.service_type,
                                    service_id = service.id,
                                    project_description = p.description,
                                    contact_id = contact.contact_id,
                                    contact_email = contact.email_address,
                                    contact_name = contact.first_name + " " + contact.last_name,
                                    contact_number = contact.phone_number,
                                    company_code = company.company_code,
                                    company_name = company.company_name,
                                    assigned_to = assignTo.display_name,
                                    assignee = offer.assignee,
                                    erp_service_wbs_id = service.erp_wbs_id,
                                    is_commercial_quote = offer.is_commercial_quote,
                                    Project_Start_Date = p.start_date != null ? p.start_date.Value.ToString("dd/MM/yyyy") : null,
                                    Project_End_Date = p.end_date != null ? p.end_date.Value.ToString("dd/MM/yyyy") : null,
                                    IndustrySegment = _context.TblIndustrySegments.Where(i => i.customer_id == customer.customer_id).FirstOrDefault().segments ?? null,
                                    job_Order_id = _context.TblOrder.Where(o => o.offer_id == offer.id && o.project_id == projectid).FirstOrDefault().erp_order_id ?? null
                                }).ToListAsync();
            return result;
        }
        public async Task<OfferStatusDTO> GetOfferServiceDetails(string serviceId)
        {
            var result = new OfferStatusDTO();

            if (IsUserOfferManager())
                result = await (from offer in _context.TblOffers
                                join p in _context.TblProjects on offer.project_id equals p.id
                                join service in _context.TblServices on offer.id equals service.offer_id
                                join customer in _context.TblCustomers on p.customer_id equals customer.id
                                join con in _context.TblContacts on service.contact_id equals con.contact_id into contactGrp   //Contact details need to display service level
                                from contact in contactGrp.DefaultIfEmpty()
                                join company in _context.TblCompanies on p.company_id equals company.company_code
                                where service.id == serviceId
                                select new OfferStatusDTO
                                {
                                    offer_id = offer.id,
                                    project_id = p.id,
                                    erp_project_id = p.erp_project_id,
                                    opportunity_id = offer.opportunity_id ?? null,
                                    erp_wbs_id = offer.WBSID,
                                    encrypted_project_id = String.Empty, //_protection.Protect(p.id),
                                    Status = offer.status,
                                    customer_name = customer.customer_name,
                                    customer_id = customer.customer_id,
                                    erp_customer_id = customer.erp_customer_id,
                                    street = customer.street,
                                    country_code = customer.country_code,
                                    zipcode = customer.zipcode,
                                    city = customer.city,
                                    customer_phonenumber = customer.phone_number,
                                    Start_Date = service.start_date != null ? service.start_date.Value.ToString("dd/MM/yyyy") : null,
                                    End_Date = service.end_date != null ? service.end_date.Value.ToString("dd/MM/yyyy") : null,
                                    service_type = service.service_type,
                                    service_location = service.service_location,
                                    service_id = service.id,
                                    service_description = service.service_description,
                                    service_region = service.service_region,
                                    actual_hours = service.actual_hours,
                                    total_estimated_hours = service.total_estimated_hours,
                                    is_ra_external = service.is_ra_external,
                                    external_ra_notes = service.external_ra_notes,
                                    contact_id = contact.contact_id,
                                    contact_email = contact.email_address,
                                    contact_name = contact.first_name + " " + contact.last_name,
                                    contact_number = contact.phone_number,
                                    region = service.service_region,
                                    company_code = company.company_code,
                                    company_name = company.company_name,
                                    erp_service_wbs_id = service.erp_wbs_id
                                }).FirstOrDefaultAsync();
            else
                result = await (from offer in _context.TblOffers
                                join p in _context.TblProjects on offer.project_id equals p.id
                                join service in _context.TblServices on offer.id equals service.offer_id
                                join customer in _context.TblCustomers on p.customer_id equals customer.id
                                join con in _context.TblContacts on service.contact_id equals con.contact_id into contactGrp   //Contact details need to display service level
                                from contact in contactGrp.DefaultIfEmpty()
                                join company in _context.TblCompanies on p.company_id equals company.company_code
                                join prjstaff in _context.TblProjectStaffs on new { userId = GetCurrentUserId(), projectId = p.id } equals new { userId = prjstaff.user_id, projectId = prjstaff.project_id }
                                where service.id == serviceId
                                select new OfferStatusDTO
                                {
                                    offer_id = offer.id,
                                    project_id = p.id,
                                    erp_project_id = p.erp_project_id,
                                    opportunity_id = offer.opportunity_id ?? null,
                                    erp_wbs_id = offer.WBSID,
                                    encrypted_project_id = String.Empty, //_protection.Protect(p.id),
                                    Status = offer.status,
                                    customer_name = customer.customer_name,
                                    customer_id = customer.customer_id,
                                    erp_customer_id = customer.erp_customer_id,
                                    street = customer.street,
                                    country_code = customer.country_code,
                                    zipcode = customer.zipcode,
                                    city = customer.city,
                                    customer_phonenumber = customer.phone_number,
                                    Start_Date = service.start_date != null ? service.start_date.Value.ToString("dd/MM/yyyy") : null,
                                    End_Date = service.end_date != null ? service.end_date.Value.ToString("dd/MM/yyyy") : null,
                                    service_type = service.service_type,
                                    service_location = service.service_location,
                                    service_id = service.id,
                                    service_description = service.service_description,
                                    service_region = service.service_region,
                                    actual_hours = service.actual_hours,
                                    total_estimated_hours = service.total_estimated_hours,
                                    is_ra_external = service.is_ra_external,
                                    external_ra_notes = service.external_ra_notes,
                                    contact_id = contact.contact_id,
                                    contact_email = contact.email_address,
                                    contact_name = contact.first_name + " " + contact.last_name,
                                    contact_number = contact.phone_number,
                                    region = service.service_region,
                                    company_code = company.company_code,
                                    company_name = company.company_name,
                                    erp_service_wbs_id = service.erp_wbs_id
                                }).FirstOrDefaultAsync();
            return result;
        }
        public async Task<List<OfferStatusDTO>> GetOfferMachineDetails(string projectid, string offerId, string serviceId)
        {
            var result = new List<OfferStatusDTO>();
            if (IsUserOfferManager())
                result = await (
                                    from machine in _context.TblMachines
                                    join serviceMachine in _context.TblServiceMachines on machine.id equals serviceMachine.machine_id
                                    join service in _context.TblServices on serviceMachine.service_id equals service.id
                                    join offer in _context.TblOffers on service.offer_id equals offer.id
                                    join p in _context.TblProjects on offer.project_id equals p.id
                                    where p.id == projectid && offer.id == offerId && service.id == serviceId && machine.is_delete == false
                                    select new OfferStatusDTO
                                    {
                                        offer_id = offer.id,
                                        project_id = p.id,
                                        erp_wbs_id = offer.WBSID,
                                        erp_project_id = p.erp_project_id,
                                        encrypted_project_id = String.Empty,// _protection.Protect(p.id),
                                        service_id = service.id,
                                        asset_id = machine.asset_id,
                                        machine_name = machine.machine_name,
                                        machine_type = _context.TblMachineTypeAssociation.FirstOrDefault(m => m.machinetype_id == machine.id).machinetype_id ?? null,
                                        serial_number = machine.serial_number,
                                        machine_id = machine.id,
                                        machine_description = machine.machine_description,
                                        erp_service_wbs_id = service.erp_wbs_id,
                                        erp_machine_wbs_id = serviceMachine.erp_wbs_id,
                                        global_id = machine.global_id,
                                        customer_id = _context.TblMachineCustomerAssociation.Where(m => m.machine_id == machine.id).FirstOrDefault().customer_id ?? null
                                    }).ToListAsync();
            else
                result = await (
                                from machine in _context.TblMachines
                                join serviceMachine in _context.TblServiceMachines on machine.id equals serviceMachine.machine_id
                                join service in _context.TblServices on serviceMachine.service_id equals service.id
                                join offer in _context.TblOffers on service.offer_id equals offer.id
                                join p in _context.TblProjects on offer.project_id equals p.id
                                join prjstaff in _context.TblProjectStaffs on new { userId = GetCurrentUserId(), projectId = p.id } equals new { userId = prjstaff.user_id, projectId = prjstaff.project_id }
                                where p.id == projectid && offer.id == offerId && service.id == serviceId && machine.is_delete == false
                                select new OfferStatusDTO
                                {
                                    offer_id = offer.id,
                                    project_id = p.id,
                                    erp_wbs_id = offer.WBSID,
                                    erp_project_id = p.erp_project_id,
                                    encrypted_project_id = String.Empty,// _protection.Protect(p.id),
                                    service_id = service.id,
                                    asset_id = machine.asset_id,
                                    machine_name = machine.machine_name,
                                    machine_type = _context.TblMachineTypeAssociation.FirstOrDefault(m => m.machinetype_id == machine.id).machinetype_id ?? null,
                                    serial_number = machine.serial_number,
                                    machine_id = machine.id,
                                    machine_description = machine.machine_description,
                                    erp_service_wbs_id = service.erp_wbs_id,
                                    erp_machine_wbs_id = serviceMachine.erp_wbs_id,
                                    global_id = machine.global_id,
                                    customer_id = _context.TblMachineCustomerAssociation.Where(m => m.machine_id == machine.id).FirstOrDefault().customer_id ?? null
                                }).ToListAsync();
            return result;
        }

        public async Task<bool> AddFinalQuotation(AddFinalQuotationDTO addFinalQuotationDTO)
        {
            bool isSuccess = false;
            try
            {
                TblFinalQuotation finalQuotation = new();

                finalQuotation.id = Guid.NewGuid().ToString();
                finalQuotation.url = addFinalQuotationDTO.URL;
                finalQuotation.name = addFinalQuotationDTO.FileName;
                finalQuotation.driveId = addFinalQuotationDTO.DriveId;
                finalQuotation.itemId = addFinalQuotationDTO.ItemId;
                finalQuotation.offerId = addFinalQuotationDTO.OfferId;
                finalQuotation.version = addFinalQuotationDTO.VersionNumber;
                finalQuotation.created_by = addFinalQuotationDTO.GeneratedBy;
                finalQuotation.created_date = addFinalQuotationDTO.CreatedDate;

                _context.TblFinalQuotations.Add(finalQuotation);
                _context.SaveChanges();

                isSuccess = true;
            }
            catch (Exception ex)
            {

            }
            return isSuccess;
        }

        public string GenerateLayoutQuotationByCommercialQuotationNumber(AddEditLayoutQuotationDTO addEditLayoutQuotationDTO)
        {
            string msg = string.Empty;

            try
            {
                TblCommercialQuotation tblCommercialQuotation = _context.TblCommercialQuotations.Where(x => x.quotationnumber == addEditLayoutQuotationDTO.QuotationNumber).FirstOrDefault();
                if (tblCommercialQuotation != null)
                {
                    var jObjectArr = new List<dynamic>();

                    if (!string.IsNullOrEmpty(tblCommercialQuotation.layout_quotation_details))
                        jObjectArr = JsonConvert.DeserializeObject<List<dynamic>>(tblCommercialQuotation.layout_quotation_details);

                    var newQuotation = JsonConvert.DeserializeObject<List<dynamic>>(addEditLayoutQuotationDTO.LayoutQuotationDetails);
                    jObjectArr.Add(newQuotation.FirstOrDefault());

                    var layoutQuotationDetails = JsonConvert.SerializeObject(jObjectArr);
                    tblCommercialQuotation.layout_quotation_details = layoutQuotationDetails;
                    _context.SaveChanges();
                    msg = "Layout Quotation updated successfully";
                }
                else
                {
                    msg = "Layout Quotation not updated";
                }


            }
            catch (Exception ex)
            {
                msg = "Failed to update";
            }
            return msg;
        }
        public string UpdateOffer(EditOfferDTO editOffer)
        {
            string msg = string.Empty;


            try
            {
                TblOffer tblOffer = _context.TblOffers.Where(x => x.id == editOffer.OfferId).FirstOrDefault();
                if (tblOffer != null)
                {
                    tblOffer.notes = editOffer.AdditionalNotes?? tblOffer.notes;
                    tblOffer.contact_id = editOffer.ContactId?? tblOffer.contact_id;
                    tblOffer.status = editOffer.Status?? tblOffer.status;
                    tblOffer.assignee = editOffer.Assignee?? tblOffer.assignee;
                    tblOffer.modified_at = DateTimeOffset.Now;
                    _context.SaveChanges();
                    msg = "Offer updated successfully";

                    if (editOffer.Status.ToLower() == "approved")
                    {
                        #region Offer Notification

                        var tenantId = httpContextAccessor.HttpContext?.User?.GetTenantId() ?? String.Empty;
                        var projectStaff = _context.TblProjectStaffs.Where(p => p.project_id == tblOffer.project_id).ToList();
                        var assignee = tblOffer.assignee != "" ? _context.TblUsers.Where(a => a.id == tblOffer.assignee).FirstOrDefault().display_name : null;
                        //string assignee =  string.Empty;
                        var email = GetStaffedUserEmails(projectStaff);
                        eventBus.PublishToQueue(new OfferNotificationEvent(email, "Create", "", tenantId, "The Quotation for the " + tblOffer.WBSID + ", has been Approved by " + assignee + "", tblOffer.WBSID, tblOffer.id, "Update Offer") { TopicName = "offernotificationrequest" });

                        #endregion
                    }
                }
                else
                {
                    msg = "Offer not updated";
                }
            }
            catch (Exception ex)
            {
                msg = "Failed to update";
            }
            return msg;
        }
        public Dictionary<string, int> GetOffertMetrics()
        {
            Dictionary<string, int> dataList = new();
            var totalOffers = _context.TblOffers.ToList().Count;
            var offersApproved = _context.TblOffers.Where(offer => offer.status.ToLower() == "approved").ToList().Count;

            var offerConvertedOrder = (from offer in _context.TblOffers
                                       join order in _context.TblOrder on offer.id equals order.offer_id
                                       select new { order.offer_id }).Distinct().Count();
            var pendingAssignment = _context.TblOffers.Where(p => p.status.ToLower() == "new").ToList().Count;
            var pendingApproval = _context.TblOffers.Where(p => p.status.ToLower() == "pending approval").ToList().Count;

            dataList.Add("TotalOffers", totalOffers);
            dataList.Add("OffersApproved", offersApproved);
            dataList.Add("OfferConvertedOrder", offerConvertedOrder);
            dataList.Add("OfferPendingAssignment", pendingAssignment);
            dataList.Add("OfferPendingApproval", pendingApproval);
            return dataList;
        }
        /// <summary>
        /// Get Daily Metrics
        /// </summary>
        /// <param name="range"></param>
        /// <returns></returns>
        public async Task<Dictionary<string, List<OfferEffortMetricsDto>>> GetOfferDailyEffortMetrics(string range)
        {
            try
            {
                var result = new Dictionary<string, List<OfferEffortMetricsDto>>();
                result = range.ToLower() switch
                {
                    OfferDataRange.WEEK => GetWeekDataMetrics(),
                    OfferDataRange.MONTH => GetMonthMetrics(),
                    OfferDataRange.DAY => GetDayDataMetrics(),
                    _ => GetMonthMetrics(),
                };
                return result;
            }
            catch (Exception)
            {
                throw;
            }
        }
        /// <summary>
        /// Get Weekly Metrics
        /// </summary>
        /// <returns></returns>
        private Dictionary<string, List<OfferEffortMetricsDto>> GetWeekDataMetrics()
        {
            try
            {
                Dictionary<string, List<OfferEffortMetricsDto>> dataList = new();
                DateTime endDate = DateTime.Today;
                DateTime startDate = endDate.AddDays(-6);
                var totalOffers = Enumerable.Range(0, 7)
                    .Select(offset => startDate.AddDays(offset))
                          .Select(day => new OfferEffortMetricsDto
                          {
                              DayOfWeek = day.DayOfWeek.ToString(),
                              Date = day.Date,
                              Data = _context.TblOffers
                                 .Where(e => e.created_at.Date.Date == day)
                                 .Count()
                          }).ToList();
                var offersApproved = Enumerable.Range(0, 7)
                    .Select(offset => startDate.AddDays(offset))
                          .Select(day => new OfferEffortMetricsDto
                          {
                              DayOfWeek = day.DayOfWeek.ToString(),
                              Date = day.Date,
                              Data = _context.TblOffers
                                 .Where(e => e.status.ToLower() == "approved" && e.created_at.Date.Date == day)
                                 .Count()
                          }).ToList();
                var offerConvertedOrder = Enumerable.Range(0, 7)
                    .Select(offset => startDate.AddDays(offset))
                          .Select(day => new OfferEffortMetricsDto
                          {
                              DayOfWeek = day.DayOfWeek.ToString(),
                              Date = day.Date,
                              Data = (from offer in _context.TblOffers
                                      join order in _context.TblOrder on offer.id equals order.offer_id
                                      where order.created_at.Date.Date == day
                                      select new { order.offer_id }).Distinct().Count()
                          }).ToList();
                var pendingAssignment = Enumerable.Range(0, 7)
                    .Select(offset => startDate.AddDays(offset))
                          .Select(day => new OfferEffortMetricsDto
                          {
                              DayOfWeek = day.DayOfWeek.ToString(),
                              Date = day.Date,
                              Data = _context.TblOffers.Where(e => e.status.ToLower() == "new" && e.modified_at.Date.Date == day).Distinct().Count()
                          }).ToList();
                var pendingApproval = Enumerable.Range(0, 7)
                    .Select(offset => startDate.AddDays(offset))
                          .Select(day => new OfferEffortMetricsDto
                          {
                              DayOfWeek = day.DayOfWeek.ToString(),
                              Date = day.Date,
                              Data = _context.TblOffers.Where(e => e.status.ToLower() == "pending approval" && e.modified_at.Date.Date == day).Distinct().Count()
                          }).ToList();
                dataList.Add("TotalOffers", totalOffers);
                dataList.Add("OffersApproved", offersApproved);
                dataList.Add("OfferConvertedOrder", offerConvertedOrder);
                dataList.Add("OfferPendingAssignment", pendingAssignment);
                dataList.Add("OfferPendingApproval", pendingApproval);
                return dataList;
            }
            catch (Exception)
            {

                throw;
            }
        }
        /// <summary>
        /// Get Monthly Metrics
        /// </summary>
        /// <returns></returns>
        private Dictionary<string, List<OfferEffortMetricsDto>> GetMonthMetrics()
        {
            Dictionary<string, List<OfferEffortMetricsDto>> dataList = new();
            DateTime endDate = DateTime.Today;
            DateTime startDate = endDate.AddDays(-29); // Subtract 29 to get the last 30 days
            var totalOffers = Enumerable.Range(0, 5)
            .Select(week => startDate.AddDays(week * 7))
            .Select((startOfWeek, index) => new OfferEffortMetricsDto
            {
                WeekStartDate = startOfWeek,
                WeekEndDate = startOfWeek.AddDays(6),
                Data = _context.TblOffers
                                 .Where(e => e.created_at.Date >= startOfWeek && e.created_at.Date <= startOfWeek.AddDays(6))
                                 .Count(),
                WeekCount = $"Week{index + 1}"
            }).ToList();
            var offersApproved = Enumerable.Range(0, 5)
            .Select(week => startDate.AddDays(week * 7))
            .Select((startOfWeek, index) => new OfferEffortMetricsDto
            {
                WeekStartDate = startOfWeek,
                WeekEndDate = startOfWeek.AddDays(6),
                Data = _context.TblOffers
                                 .Where(e => e.status.ToLower() == "approved" && e.modified_at.Date >= startOfWeek && e.modified_at.Date <= startOfWeek.AddDays(6))
                                 .Count(),
                WeekCount = $"Week{index + 1}"
            }).ToList();
            var offerConvertedOrder = Enumerable.Range(0, 5)
            .Select(week => startDate.AddDays(week * 7))
            .Select((startOfWeek, index) => new OfferEffortMetricsDto
            {
                WeekStartDate = startOfWeek,
                WeekEndDate = startOfWeek.AddDays(6),
                Data = (from offer in _context.TblOffers
                                  join order in _context.TblOrder on offer.id equals order.offer_id
                                  where order.created_at.Date >= startOfWeek && order.created_at.Date <= startOfWeek.AddDays(6)
                        select new { order.offer_id }).Distinct().Count(),
                WeekCount = $"Week{index + 1}"
            }).ToList();
            var pendingAssignment = Enumerable.Range(0, 5)
            .Select(week => startDate.AddDays(week * 7))
            .Select((startOfWeek, index) => new OfferEffortMetricsDto
            {
                WeekStartDate = startOfWeek,
                WeekEndDate = startOfWeek.AddDays(6),
                Data = _context.TblOffers.Where(e => e.status.ToLower() == "new" && e.modified_at.Date >= startOfWeek && e.modified_at.Date <= startOfWeek.AddDays(6)).Distinct().Count(),
                WeekCount = $"Week{index + 1}"
            }).ToList();
            var pendingApproval = Enumerable.Range(0, 5)
            .Select(week => startDate.AddDays(week * 7))
            .Select((startOfWeek, index) => new OfferEffortMetricsDto
            {
                WeekStartDate = startOfWeek,
                WeekEndDate = startOfWeek.AddDays(6),
                Data = _context.TblOffers.Where(e => e.status.ToLower() == "pending approval" && e.modified_at.Date >= startOfWeek && e.modified_at.Date <= startOfWeek.AddDays(6)).Distinct().Count(),
                WeekCount = $"Week{index + 1}"
            }).ToList();
            dataList.Add("TotalOffers", totalOffers);
            dataList.Add("OffersApproved", offersApproved);
            dataList.Add("OfferConvertedOrder", offerConvertedOrder);
            dataList.Add("OfferPendingAssignment", pendingAssignment);
            dataList.Add("OfferPendingApproval", pendingApproval);
            return dataList;
        }
        /// <summary>
        /// Get Day Metrics
        /// </summary>
        /// <returns></returns>
        private Dictionary<string, List<OfferEffortMetricsDto>> GetDayDataMetrics()
        {
            try
            {
                Dictionary<string, List<OfferEffortMetricsDto>> dataList = new();
                DateTimeOffset currentDate = DateTimeOffset.Now;

                var last48hrsOffers = _context.TblOffers
                                 .Where(e => e.created_at.Date >= currentDate.AddHours(-48) && e.created_at.Date < currentDate)
                                 .Select(s => new
                                 {
                                     OfferId = s.id,
                                     CreatedDate = s.created_at
                                 }).ToList();
                var totalOffers = Enumerable.Range(0, 24)
                    .Select(hour => new OfferEffortMetricsDto
                    {
                        Hours = hour,
                        HourStart = currentDate.AddHours(-hour).AddHours(-1),
                        HourEnd = currentDate.AddHours(-hour),
                        Data = last48hrsOffers.Where(t => t.CreatedDate >= currentDate.AddHours(-24) && t.CreatedDate < currentDate && t.CreatedDate.Hour == hour)
                        .ToList().Count
                    }).ToList();
                var last48OffersApproved = _context.TblOffers
                                 .Where(e => e.status.ToLower() == "approved" && e.modified_at >= currentDate.AddHours(-48) && e.modified_at < currentDate)
                                 .Select(s => new
                                 {
                                     OfferId = s.id,
                                     ModifiedDate = s.modified_at
                                 }).ToList();

                var offersApproved = Enumerable.Range(0, 24)
                    .Select(hour =>  new OfferEffortMetricsDto
                    {
                        Hours = hour,
                        HourStart = currentDate.AddHours(-hour).AddHours(-1),
                        HourEnd = currentDate.AddHours(-hour),
                        Data = last48OffersApproved.Where(t => t.ModifiedDate >= currentDate.AddHours(-24) && t.ModifiedDate < currentDate && t.ModifiedDate.Hour == hour)
                        .ToList().Count
                    }).ToList();
                var last48OfferConvertedOrder = (from offer in _context.TblOffers
                                                 join order in _context.TblOrder on offer.id equals order.offer_id
                                                 where order.created_at >= currentDate.AddHours(-24) && order.created_at < currentDate
                                                 select new { OfferId = order.offer_id, CreatedDate = order.created_at }).Distinct().ToList();
                var offerConvertedOrder = Enumerable.Range(0, 24)
                    .Select(hour => new OfferEffortMetricsDto
                    {
                        Hours = hour,
                        HourStart = currentDate.AddHours(-hour).AddHours(-1),
                        HourEnd = currentDate.AddHours(-hour),
                        Data = last48OfferConvertedOrder.Where(t => t.CreatedDate >= currentDate.AddHours(-24) && t.CreatedDate < currentDate && t.CreatedDate.Hour == hour)
                        .ToList().Count
                }).ToList();
                var last48hrsPendingAssignment = _context.TblOffers.Where(e => e.status.ToLower() == "new" && e.modified_at >= currentDate.AddHours(-48) && e.modified_at < currentDate)
                    .Select(s => new
                    {
                        OfferId = s.id,
                        ModifiedDate = s.modified_at
                    }).Distinct().ToList();
                var pendingAssignment = Enumerable.Range(0, 24)
                    .Select(hour =>  new OfferEffortMetricsDto
                    {
                        Hours = hour,
                        HourStart = currentDate.AddHours(-hour).AddHours(-1),
                        HourEnd = currentDate.AddHours(-hour),
                        Data = last48hrsPendingAssignment.Where(t => t.ModifiedDate >= currentDate.AddHours(-24) && t.ModifiedDate < currentDate && t.ModifiedDate.Hour == hour).Count()
                }).ToList();
                var last48hrsPendingApproval = _context.TblOffers.Where(e => e.status.ToLower() == "pending approval" && e.modified_at >= currentDate.AddHours(-48) && e.modified_at < currentDate)
                    .Select(s => new
                    {
                        OfferId = s.id,
                        ModifiedDate = s.modified_at
                    })
                    .Distinct().ToList();
                var pendingApproval = Enumerable.Range(0, 24)
                    .Select(hour =>  new OfferEffortMetricsDto
                    {
                        Hours = hour,
                        HourStart = currentDate.AddHours(-hour).AddHours(-1),
                        HourEnd = currentDate.AddHours(-hour),
                        Data = last48hrsPendingApproval.Where(t => t.ModifiedDate >= currentDate.AddHours(-24) && t.ModifiedDate < currentDate && t.ModifiedDate.Hour == hour).Count()
                }).ToList();
                dataList.Add("TotalOffers", totalOffers);
                dataList.Add("OffersApproved", offersApproved);
                dataList.Add("OfferConvertedOrder", offerConvertedOrder);
                dataList.Add("OfferPendingAssignment", pendingAssignment);
                dataList.Add("OfferPendingApproval", pendingApproval);
                return dataList;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public string GetOfferId()
        {
            string offerId = (from record in _context.TblOffers orderby record.id select record.id).LastOrDefault();
            string generatedOfferId = string.Empty;
            if (offerId != "" && offerId != null)
            {
                string[] newOfferId = offerId.Split("-");
                int numberOfferId = Int32.Parse(newOfferId[1]) + 1;
                generatedOfferId = "OFD" + DateTime.Now.Year.ToString() + "" + DateTime.Now.ToString("MM") + "" + DateTime.Now.ToString("dd") + "-" + numberOfferId;
            }
            else
            {
                generatedOfferId = "OFD" + DateTime.Now.Year.ToString() + "" + DateTime.Now.ToString("MM") + "" + DateTime.Now.ToString("dd") + "-" + 1;

            }

            return generatedOfferId;

        }

        public async Task<List<CustomerDTO>> GetCustomerName(string customerName)
        {
            var customers = await _context.TblCustomers
             .Where(c => c.customer_name.Contains(customerName))
             .Select(c => new CustomerDTO
             {
                 id = c.id,
                 customer_name = c.customer_name,
                 customer_id = c.customer_id,
                 erp_customer_id = c.erp_customer_id,
                 country_code = c.country_code,
                 city = c.city,
                 zipcode = c.zipcode,
                 street = c.street,
                 phone_number = c.phone_number,
             }).ToListAsync();
            return customers;
        }
        public List<string> GetMachineName()
        {
            List<string> list = (from m in _context.TblMasterMachines
                                 select m.machine_name
                         ).ToList();
            return list;

        }
        public List<ResponseProjectDTO> GetProjectsByCustomerId(string customerName)
        {
            List<ResponseProjectDTO> list = new List<ResponseProjectDTO>();
            if (IsUserOfferManager())
                list = (from p in _context.TblProjects
                        join c in _context.TblCustomers on p.customer_id equals c.id
                        where c.customer_name == customerName
                        select new ResponseProjectDTO
                        {
                            Project_Id = p.id,
                            Erp_Project_Id = p.erp_project_id
                        }
                         ).Distinct().ToList();
            else
                list = (from p in _context.TblProjects
                        join prjstaff in _context.TblProjectStaffs on new { userId = GetCurrentUserId(), projectId = p.id } equals new { userId = prjstaff.user_id, projectId = prjstaff.project_id }
                        join c in _context.TblCustomers on p.customer_id equals c.id
                        where c.customer_name == customerName
                        select new ResponseProjectDTO
                        {
                            Project_Id = p.id,
                            Erp_Project_Id = p.erp_project_id
                        }
                     ).Distinct().ToList();
            return list;


        }
        public List<LoginUserDTO> GetLoginUsers(string user)
        {
            List<LoginUserDTO> obj = new List<LoginUserDTO>();
            obj = (from users in _context.TblUser
                   where users.display_name.Contains(user)
                   select new LoginUserDTO
                   {
                       Id = users.id,
                       Name = users.display_name,
                       Email = users.email_address
                   }
                   ).ToList();
            return obj;
        }
        public async Task<GetOfferOpportunityDTO> GetOfferByOpportunityId(string opportunityId)
        {
            var result = new GetOfferOpportunityDTO();
            if (IsUserOfferManager())
                result = await (
                                    from offer in _context.TblOffers
                                    join p in _context.TblProjects on offer.project_id equals p.id
                                    //join prjstaff in _context.TblProjectStaffs on new { userId = GetCurrentUserId(), projectId = p.id } equals new { userId = prjstaff.user_id, projectId = prjstaff.project_id }
                                    join opp in _context.TblOpportunity on offer.opportunity_id equals opp.id
                                    join cus in _context.TblCustomers on p.customer_id equals cus.id
                                    where offer.opportunity_id == opportunityId
                                    select new GetOfferOpportunityDTO
                                    {

                                        Offer = _context.TblOffers.Where(x => x.opportunity_id == opportunityId).Select(off => new OpportunityOfferDTO
                                        {
                                            offer_id = off.id,
                                            erp_wbs_id = off.WBSID,
                                            erp_project_id = p.erp_project_id,
                                            project_id = off.project_id,
                                            quote_type = off.quote_type,
                                            notes = off.notes,
                                            quote_template_type = off.quote_template_type,
                                            status = off.status,
                                            assignee = off.assignee,
                                            created_by = off.created_by,
                                            is_commercial_quote = off.is_commercial_quote,
                                            Service = _context.TblServices.Where(x => x.offer_id == off.id).Select(ser => new OpportunityServiceDTO
                                            {
                                                id = ser.id,
                                                offer_id = ser.offer_id,
                                                erp_wbs_id = ser.erp_wbs_id,
                                                actual_hours = ser.actual_hours,
                                                is_active = ser.is_active,
                                                service_type = ser.service_type,
                                                service_region = ser.service_region,
                                                service_location = ser.service_location,
                                                service_description = ser.service_description,
                                                is_ra_external = ser.is_ra_external,
                                                external_ra_notes = ser.external_ra_notes,
                                                total_estimated_hours = ser.total_estimated_hours,
                                                start_date = ser.start_date,
                                                end_date = ser.end_date,
                                                Machine = (from sermachine in _context.TblServiceMachines
                                                           join mac in _context.TblMachines
                                                           on sermachine.machine_id equals mac.id
                                                           where sermachine.service_id == ser.id && sermachine.machine_id == mac.id && mac.is_delete == false
                                                           select new MachineDTO
                                                           {
                                                               id = mac.id,
                                                               serial_number = mac.serial_number,
                                                               estimated_hours = sermachine.estimated_hours,
                                                               asset_id = mac.asset_id,
                                                               machine_description = mac.machine_description,
                                                               machine_location = mac.machine_location,
                                                               machine_name = mac.machine_name,
                                                               machine_type = mac.machine_type,
                                                               industry_type = mac.industry_type,
                                                               created_at = mac.created_at,
                                                               created_by = mac.created_by,
                                                               erp_wbs_id = sermachine.erp_wbs_id
                                                           }).ToList(),
                                                Contact = (from contact in _context.TblContacts
                                                           join servi in _context.TblServices on contact.contact_id equals servi.contact_id
                                                           where servi.id == ser.id
                                                           select new ContactDTO
                                                           {
                                                               contact_id = contact.contact_id,
                                                               display_name = contact.display_name,
                                                               email_address = contact.email_address,
                                                               phone_number = contact.phone_number,
                                                               first_name = contact.first_name,
                                                               last_name = contact.last_name,
                                                           }).ToList(),
                                                Customer = new List<CustomerDTO>{
                                                new CustomerDTO()
                                                {
                                                    id = cus.id,
                                                    customer_id = cus.customer_id,
                                                    erp_customer_id = cus.erp_customer_id,
                                                    customer_name = cus.customer_name,
                                                    street = cus.street,
                                                    city = cus.city,
                                                    country_code = cus.country_code,
                                                    phone_number = cus.phone_number,
                                                    language = cus.language,
                                                    zipcode = cus.zipcode,
                                                }}
                                            }).ToList(),

                                        }).FirstOrDefault(),
                                        Contact = _context.TblContacts.Where(x => x.contact_id == offer.contact_id).Select(con => new ContactDTO
                                        {
                                            contact_id = con.contact_id,
                                            display_name = con.display_name,
                                            email_address = con.email_address,
                                            phone_number = con.phone_number,
                                            first_name = con.first_name,
                                            last_name = con.last_name
                                        }).FirstOrDefault(),
                                        Customer = new CustomerDTO
                                        {
                                            id = cus.id,
                                            customer_id = cus.customer_id,
                                            erp_customer_id = cus.erp_customer_id,
                                            customer_name = cus.customer_name,
                                            street = cus.street,
                                            city = cus.city,
                                            country_code = cus.country_code,
                                            phone_number = cus.phone_number,
                                            language = cus.language,
                                            zipcode = cus.zipcode,
                                        }
                                    }).FirstOrDefaultAsync();
            else
                result = await (
                                from offer in _context.TblOffers
                                join p in _context.TblProjects on offer.project_id equals p.id
                                join prjstaff in _context.TblProjectStaffs on new { userId = GetCurrentUserId(), projectId = p.id } equals new { userId = prjstaff.user_id, projectId = prjstaff.project_id }
                                join opp in _context.TblOpportunity on offer.opportunity_id equals opp.id
                                join cus in _context.TblCustomers on p.customer_id equals cus.id
                                where offer.opportunity_id == opportunityId
                                select new GetOfferOpportunityDTO
                                {

                                    Offer = _context.TblOffers.Where(x => x.opportunity_id == opportunityId).Select(off => new OpportunityOfferDTO
                                    {
                                        offer_id = off.id,
                                        erp_wbs_id = off.WBSID,
                                        erp_project_id = p.erp_project_id,
                                        project_id = off.project_id,
                                        quote_type = off.quote_type,
                                        notes = off.notes,
                                        quote_template_type = off.quote_template_type,
                                        status = off.status,
                                        assignee = off.assignee,
                                        created_by = off.created_by,
                                        is_commercial_quote = off.is_commercial_quote,
                                        Service = _context.TblServices.Where(x => x.offer_id == off.id).Select(ser => new OpportunityServiceDTO
                                        {
                                            id = ser.id,
                                            offer_id = ser.offer_id,
                                            erp_wbs_id = ser.erp_wbs_id,
                                            actual_hours = ser.actual_hours,
                                            is_active = ser.is_active,
                                            service_type = ser.service_type,
                                            service_region = ser.service_region,
                                            service_location = ser.service_location,
                                            service_description = ser.service_description,
                                            is_ra_external = ser.is_ra_external,
                                            external_ra_notes = ser.external_ra_notes,
                                            total_estimated_hours = ser.total_estimated_hours,
                                            start_date = ser.start_date,
                                            end_date = ser.end_date,
                                            Machine = (from sermachine in _context.TblServiceMachines
                                                       join mac in _context.TblMachines
                                                       on sermachine.machine_id equals mac.id
                                                       where sermachine.service_id == ser.id && sermachine.machine_id == mac.id && mac.is_delete == false
                                                       select new MachineDTO
                                                       {
                                                           id = mac.id,
                                                           serial_number = mac.serial_number,
                                                           estimated_hours = sermachine.estimated_hours,
                                                           asset_id = mac.asset_id,
                                                           machine_description = mac.machine_description,
                                                           machine_location = mac.machine_location,
                                                           machine_name = mac.machine_name,
                                                           machine_type = mac.machine_type,
                                                           industry_type = mac.industry_type,
                                                           created_at = mac.created_at,
                                                           created_by = mac.created_by,
                                                           erp_wbs_id = sermachine.erp_wbs_id
                                                       }).ToList(),
                                            Contact = (from contact in _context.TblContacts
                                                       join servi in _context.TblServices on contact.contact_id equals servi.contact_id
                                                       where servi.id == ser.id
                                                       select new ContactDTO
                                                       {
                                                           contact_id = contact.contact_id,
                                                           display_name = contact.display_name,
                                                           email_address = contact.email_address,
                                                           phone_number = contact.phone_number,
                                                           first_name = contact.first_name,
                                                           last_name = contact.last_name,
                                                       }).ToList(),
                                            Customer = new List<CustomerDTO>{
                                                new CustomerDTO()
                                                {
                                                    id = cus.id,
                                                    customer_id = cus.customer_id,
                                                    erp_customer_id = cus.erp_customer_id,
                                                    customer_name = cus.customer_name,
                                                    street = cus.street,
                                                    city = cus.city,
                                                    country_code = cus.country_code,
                                                    phone_number = cus.phone_number,
                                                    language = cus.language,
                                                    zipcode = cus.zipcode,
                                                }}
                                        }).ToList(),

                                    }).FirstOrDefault(),
                                    Contact = _context.TblContacts.Where(x => x.contact_id == offer.contact_id).Select(con => new ContactDTO
                                    {
                                        contact_id = con.contact_id,
                                        display_name = con.display_name,
                                        email_address = con.email_address,
                                        phone_number = con.phone_number,
                                        first_name = con.first_name,
                                        last_name = con.last_name
                                    }).FirstOrDefault(),
                                    Customer = new CustomerDTO
                                    {
                                        id = cus.id,
                                        customer_id = cus.customer_id,
                                        erp_customer_id = cus.erp_customer_id,
                                        customer_name = cus.customer_name,
                                        street = cus.street,
                                        city = cus.city,
                                        country_code = cus.country_code,
                                        phone_number = cus.phone_number,
                                        language = cus.language,
                                        zipcode = cus.zipcode,
                                    }
                                }).FirstOrDefaultAsync();
            return result;
        }
        public string CreateServiceProduct(ServiceMaterialRequestEvent serviceMaterial)
        {
            if (serviceMaterial != null)
            {
                List<TblServiceMaterial> serviceMaterials = new List<TblServiceMaterial>();

                foreach (var material in serviceMaterial.Materials)
                {
                    foreach (var description in material.Descriptions)
                    {
                        var duplicateSm = _context.TblServiceMaterials
                    .FirstOrDefault(sm => sm.company_code == serviceMaterial.TechnicalHeader.CompanyCode && sm.language.ToUpper() == description.LanguageCode.ToUpper());
                        if (duplicateSm is null)
                        {
                            string valueType = GetValue(description.SalesText);
                            serviceMaterials.Add(new TblServiceMaterial()
                            {
                                id = Guid.NewGuid().ToString(),
                                company_code = serviceMaterial.TechnicalHeader.CompanyCode,
                                language = description.LanguageCode,
                                service_product_id = material.ServiceProductID,
                                value = description.Value,
                                sales_text = description.SalesText,
                                value_type = valueType ?? null
                            });
                        }
                        else
                        {
                            string valueType = GetValue(description.SalesText);
                            duplicateSm.sales_text = description.SalesText;
                            duplicateSm.value_type = valueType;
                            _context.TblServiceMaterials.Update(duplicateSm);
                            _context.SaveChanges();
                        }
                    }
                }
                _context.TblServiceMaterials.AddRange(serviceMaterials);
                _context.SaveChanges();
                return "Service Material Updated";
            }
            return "Service Material Failed to Updated";
        }
        /// <summary>
        /// Get Commercial Quotation
        /// </summary>
        /// <param name="offerId"></param>
        /// <returns>CommercialQuotation</returns>
        public async Task<CommercialQuotation> GetCommercialQuotation(string offerId)
        {
            var quotationFromDb = _context.TblCommercialQuotations
                .Where(q => q.id == offerId)
                .FirstOrDefault();

            var commercialQuote = new CommercialQuotation();

            if (quotationFromDb is not null)
                //commercialQuote = mapper.Map<CommercialQuotation>(quotationFromDb);

                commercialQuote.OfferID = quotationFromDb.offer_id;
            commercialQuote.ProjectID = quotationFromDb.project_id;
            commercialQuote.ERPProjectID = quotationFromDb.erp_project_id;
            commercialQuote.Data = Encoding.ASCII.GetString(quotationFromDb.data);
            commercialQuote.ContentType = quotationFromDb.content_type;
            commercialQuote.EncodingFormat = quotationFromDb.encoding_format;
            commercialQuote.QuotationNumber = quotationFromDb.quotationnumber;
            commercialQuote.verion = quotationFromDb.version;
            commercialQuote.ERPOfferID = quotationFromDb.offer_id != null ? _context.TblOffers.Where(o => o.id == quotationFromDb.offer_id).FirstOrDefault().WBSID : null;
            commercialQuote.LayoutQuotationDetails = quotationFromDb.layout_quotation_details;
            return commercialQuote;
        }
        /// <summary>
        /// Get the version of Commercial Quotation
        /// </summary>
        /// <param name="offerId"></param>
        /// <returns>CommercialQuotation</returns>
        public async Task<List<CommercialQuotation>> GetCommercialQuotationVersion(string offerId)
        {
            var quotationFromDb = _context.TblCommercialQuotations
                .Where(q => q.offer_id == offerId).Select(c => new CommercialQuotation
                {
                    Id = c.id,
                    OfferID = c.offer_id,
                    ProjectID = c.project_id,
                    ERPProjectID = c.erp_project_id,
                    verion = c.version,
                    QuotationNumber = c.quotationnumber,
                    ERPOfferID = c.offer_id != null ? _context.TblOffers.Where(o => o.id == c.offer_id).FirstOrDefault().WBSID : null,
                    LayoutQuotationDetails = c.layout_quotation_details

                }).OrderBy(o => o.verion).ToList();

            return quotationFromDb;
        }

        /// <summary>
        /// Get the version of Commercial Quotation
        /// </summary>
        /// <param name="offerId"></param>
        /// <returns>CommercialQuotation</returns>
        public async Task<List<FinalQuotationsDTO>> GetFinalQuotationVersions(string offerId)
        {
            var quotationFromDb = _context.TblFinalQuotations
                .Where(q => q.offerId == offerId).Select(c => new FinalQuotationsDTO
                {
                    Id = c.id,
                    OfferId = c.offerId,
                    DriveId = c.driveId,
                    FileName = c.name,
                    ItemId = c.itemId,
                    Url = c.url,
                    VersionNumber = c.version,
                    CreatedDate = c.created_date,
                    GenerateBy = c.created_by

                }).OrderBy(o => o.CreatedDate).ToList();

            return quotationFromDb;
        }
        public async Task WbsResponseProcess(WbsResponseEvent wbsResponse)
        {
            var offer = _context.TblOffers.FirstOrDefault(o => o.id == wbsResponse.Offer.OfferID);
            var projectStaff = _context.TblProjectStaffs.Where(p => p.project_id == offer.project_id).ToList();
            var email = GetStaffedUserEmails(projectStaff);
            if (offer is not null)
            {
                #region Log AuditEntry
                if (offer?.WBSID is null)
                {
                    var auditEntry = _context.TblAuditEntry.Where(a => a.offer_id == wbsResponse.Offer.OfferID && a.project_id == offer.project_id && a.action == "Create" && a.service_id == null).FirstOrDefault();
                    if (auditEntry is not null)
                    {
                        auditEntry.scope = "New Offer " + wbsResponse?.Offer?.WBSID + " has been added";
                        _context.TblAuditEntry.Update(auditEntry);
                        _context.SaveChanges();
                    }
                }
                #endregion
                offer.WBSID = wbsResponse.Offer.WBSID;

                _context.TblOffers.Update(offer);

                var serviceIds = wbsResponse.Offer?.Services?.Select(s => new { serviceId = s.ServiceID, wbsId = s.WBSID });
                var localServiceIds = serviceIds.Select(s => s.serviceId).ToList();

                var services = _context.TblServices.Where(s => localServiceIds.Contains(s.id)).ToList();

                foreach (var service in services)
                {
                    #region Log AuditEntry
                    var auditserviceEntry = _context.TblAuditEntry.Where(a => a.offer_id == wbsResponse.Offer.OfferID && a.project_id == offer.project_id && a.action == "Create" && a.service_id == service.id && a.affected_table.ToLower() == "tblservice").FirstOrDefault();
                    if (auditserviceEntry is not null)
                    {
                        var serviceID = serviceIds.FirstOrDefault(s => s.serviceId == service.id)?.wbsId;
                        auditserviceEntry.scope = "New Service " + serviceID + " has been added";
                        _context.TblAuditEntry.Update(auditserviceEntry);
                        _context.SaveChanges();
                    }
                    #endregion

                    service.erp_wbs_id = serviceIds.FirstOrDefault(s => s.serviceId == service.id)?.wbsId ?? String.Empty;

                    var machineIds = wbsResponse.Offer?.Services.FirstOrDefault(s => s.ServiceID == service.id)?.MachineDetails?.Machines?
                        .Select(m => new { machineId = m.MachineID, wbsId = m.WBSID });
                    var localMachineIds = machineIds.Select(m => m.machineId).ToList();

                    var machines = _context.TblServiceMachines.Where(m => localMachineIds.Contains(m.id)).ToList();

                    machines.ForEach(m => m.erp_wbs_id = machineIds.FirstOrDefault(lm => lm.machineId == m.id).wbsId);

                    _context.TblServiceMachines.UpdateRange(machines);
                }

                _context.TblServices.UpdateRange(services);

                _context.SaveChanges(true);

                #region Offer Notification

                var tenantId = wbsResponse.TechnicalHeader.TenantID ?? String.Empty;
                eventBus.PublishToQueue(new OfferNotificationEvent(email, "Create", "", tenantId, "The Offer with " + wbsResponse.Offer.WBSID + " is created", wbsResponse.Offer.WBSID, offer.id, "Create Offer") { TopicName = "offernotificationrequest" });

                #endregion
            }
        }

        public async Task UpdatePlannedCost(ErpPlannedCostResponseEvent wbsResponse)
        {
            try
            {
                foreach (var service in wbsResponse.PlannedCost.Services)
                {
                    var ifServiceExists = _context.TblServices.FirstOrDefault(s => s.id == service.ServiceID) != null;
                    if (ifServiceExists)
                    {
                        var localService = _context.TblServicePlannedCosts.FirstOrDefault(spc => spc.service_id == service.ServiceID);
                        if (localService == null)
                        {
                            var servicePlannedCost = new TblServicePlannedCost()
                            {
                                id = Guid.NewGuid().ToString(),
                                service_id = service.ServiceID,
                                cost_type = service.CostType,
                                currency = service.Currency,
                                current_value = Convert.ToDecimal(service.CurrentValue)
                            };


                            _context.TblServicePlannedCosts.Add(servicePlannedCost);
                        }
                        else
                        {
                            localService.cost_type = service.CostType;
                            localService.currency = service.Currency;
                            localService.current_value = Convert.ToDecimal(service.CurrentValue);

                            _context.TblServicePlannedCosts.Update(localService);
                        }

                        foreach (var machine in service.MachineDetails?.Machines ?? new List<ErpMachineCost>())
                        {
                            var ifMachineExists = _context.TblServiceMachines.FirstOrDefault(m => m.id == machine.MachineID) != null;
                            if (ifMachineExists)
                            {
                                var localMachine = _context.TblMachinePlannedCosts.FirstOrDefault(mpc => mpc.service_machine_id == machine.MachineID);
                                if (localMachine == null)
                                {
                                    var machinePlannedCost = new TblMachinePlannedCost()
                                    {
                                        id = Guid.NewGuid().ToString(),
                                        service_machine_id = machine.MachineID,
                                        cost_type = machine.CostType,
                                        currency = machine.Currency,
                                        current_value = Convert.ToDecimal(machine.CurrentValue)
                                    };


                                    _context.TblMachinePlannedCosts.Add(machinePlannedCost);
                                }
                                else
                                {
                                    localMachine.cost_type = machine.CostType;
                                    localMachine.currency = machine.Currency;
                                    localMachine.current_value = Convert.ToDecimal(machine.CurrentValue);

                                    _context.TblMachinePlannedCosts.Update(localMachine);
                                }
                            }

                        }
                        _context.SaveChanges();
                    }

                }
            }
            catch (Exception ex)
            {

                throw;
            }


        }

        public async Task UpdateActualCost(ErpActualCostResponseEvent wbsResponse)
        {
            foreach (var service in wbsResponse.ActualCost.Services)
            {

                var ifServiceExists = _context.TblServices.FirstOrDefault(s => s.id == service.ServiceID) != null;

                if (ifServiceExists)
                {
                    var localService = _context.TblServiceActualCosts.FirstOrDefault(spc => spc.service_id == service.ServiceID);
                    if (localService == null)
                    {
                        var serviceActualCost = new TblServiceActualCost()
                        {
                            id = Guid.NewGuid().ToString(),
                            service_id = service.ServiceID,
                            cost_type = service.CostType,
                            currency = service.Currency,
                            current_value = Convert.ToDecimal(service.CurrentValue)
                        };
                        _context.TblServiceActualCosts.Add(serviceActualCost);
                    }
                    else
                    {
                        localService.cost_type = service.CostType;
                        localService.currency = service.Currency;
                        localService.current_value = Convert.ToDecimal(service.CurrentValue);

                        _context.TblServiceActualCosts.Update(localService);
                    }

                    foreach (var machine in service.MachineDetails?.Machines ?? new List<ErpMachineCost>())
                    {
                        var ifMachineExists = _context.TblServiceMachines.FirstOrDefault(m => m.id == machine.MachineID) != null;
                        if (ifMachineExists)
                        {
                            var localMachine = _context.TblMachineActualCosts.FirstOrDefault(mpc => mpc.service_machine_id == machine.MachineID);
                            if (localMachine == null)
                            {
                                var machineActualCost = new TblMachineActualCost()
                                {
                                    id = Guid.NewGuid().ToString(),
                                    service_machine_id = machine.MachineID,
                                    cost_type = machine.CostType,
                                    currency = machine.Currency,
                                    current_value = Convert.ToDecimal(machine.CurrentValue)
                                };


                                _context.TblMachineActualCosts.Add(machineActualCost);
                            }
                            else
                            {
                                localMachine.cost_type = machine.CostType;
                                localMachine.currency = machine.Currency;
                                localMachine.current_value = Convert.ToDecimal(machine.CurrentValue);

                                _context.TblMachineActualCosts.Update(localMachine);
                            }
                        }

                    }
                    _context.SaveChanges();
                }

            }
        }

        public async Task UpdateCalculatedHour(ErpCalculatedHourResponseEvent erpCalculatedHour)
        {
            var json = Newtonsoft.Json.JsonConvert.SerializeObject(erpCalculatedHour);
            try
            {
                foreach (var service in erpCalculatedHour.Offer.Services)
                {
                    var ifServiceExists = _context.TblServices.FirstOrDefault(s => s.id == service.ServiceID) != null;
                    if (ifServiceExists)
                    {
                        var localServiceHour = _context.TblServiceHours.FirstOrDefault(spc => spc.service_id == service.ServiceID);
                        if (localServiceHour == null)
                        {
                            var tblServiceHour = new TblServiceHour()
                            {
                                id = Guid.NewGuid().ToString(),
                                service_id = service.ServiceID,
                                calculated_hours = Convert.ToDecimal(service.CalculatedHours),
                                total_sum_in_hour = Convert.ToDecimal(service.TotalSumInHours)
                            };

                            _context.TblServiceHours.Add(tblServiceHour);
                        }
                        else
                        {
                            localServiceHour.calculated_hours = Convert.ToDecimal(service.CalculatedHours);
                            localServiceHour.total_sum_in_hour = Convert.ToDecimal(service.TotalSumInHours);

                            _context.TblServiceHours.Update(localServiceHour);
                        }

                        var localServiceCost = _context.TblServiceCosts.FirstOrDefault(spc => spc.service_id == service.ServiceID);

                        if (localServiceCost == null)
                        {
                            var tblServiceHour = new TblServiceCost()
                            {
                                id = Guid.NewGuid().ToString(),
                                service_id = service.ServiceID,
                                total_calculated_cost = Convert.ToDecimal(service.TotalCalculatedCost)
                            };

                            _context.TblServiceCosts.Add(tblServiceHour);
                        }
                        else
                        {
                            localServiceCost.total_calculated_cost = Convert.ToDecimal(service.TotalCalculatedCost);

                            _context.TblServiceCosts.Update(localServiceCost);
                        }

                        foreach (var machine in service.MachineDetails?.Machines ?? new List<ErpCalculatedMachine>())
                        {
                            var ifMachineExists = _context.TblServiceMachines.FirstOrDefault(m => m.id == machine.MachineID) != null;
                            if (ifMachineExists)
                            {
                                var localMachineHour = _context.TblMachineHours.FirstOrDefault(mh => mh.service_machine_id == machine.MachineID);
                                if (localMachineHour == null)
                                {
                                    var tblMachineHour = new TblMachineHour()
                                    {
                                        id = Guid.NewGuid().ToString(),
                                        service_machine_id = machine.MachineID,
                                        calculated_hours = Convert.ToDecimal(machine.CalculatedHours)
                                    };

                                    _context.TblMachineHours.Add(tblMachineHour);
                                }
                                else
                                {
                                    localMachineHour.calculated_hours = Convert.ToDecimal(machine.CalculatedHours);

                                    _context.TblMachineHours.Attach(localMachineHour);
                                    var entry = _context.Entry(localMachineHour);
                                    entry.State = EntityState.Modified;
                                    _context.SaveChanges();
                                }

                                var localMachineCost = _context.TblMachineCosts.FirstOrDefault(mc => mc.service_machine_id == machine.MachineID);

                                if (localMachineCost == null)
                                {
                                    var tblMachineCost = new TblMachineCost()
                                    {
                                        id = Guid.NewGuid().ToString(),
                                        service_machine_id = machine.MachineID,
                                        item_cost = Convert.ToDecimal(machine.ItemCost),
                                        currency = machine.Currency
                                    };

                                    _context.TblMachineCosts.Add(tblMachineCost);
                                }
                                else
                                {
                                    localMachineCost.item_cost = Convert.ToDecimal(machine.ItemCost);
                                    localMachineCost.currency = machine.Currency;
                                    _context.TblMachineCosts.Update(localMachineCost);
                                }

                                machine.SubCost?.ForEach(sc =>
                                {
                                    _context.TblMachineSubCosts.Add(new TblMachineSubCost()
                                    {
                                        cost = Convert.ToDecimal(sc.Cost),
                                        description = sc.Description,
                                        id = Guid.NewGuid().ToString(),
                                        quantity = Convert.ToDecimal(sc.Quantity),
                                        service_machine_id = machine.MachineID,
                                        unit = sc.Unit
                                    });
                                });
                            }
                        }
                        _context.SaveChanges();
                    }

                }
            }
            catch (Exception ex)
            {
            }

        }

        public async Task UpdateActualSales(ErpActualSaleResponseEvent actualSaleResponse)
        {
            foreach (var service in actualSaleResponse.ActualSales.Services)
            {
                var ifServiceExists = _context.TblServices.FirstOrDefault(s => s.id == service.ServiceID) != null;
                if (ifServiceExists)
                {
                    var localService = _context.TblServiceActualSales.FirstOrDefault(sas => sas.service_id == service.ServiceID);
                    if (localService == null)
                    {
                        var serviceActualSales = new TblServiceActualSale()
                        {
                            id = Guid.NewGuid().ToString(),
                            service_id = service.ServiceID,
                            cost_type = service.CostType,
                            currency = service.Currency,
                            actual_sale_value = Convert.ToDecimal(service.ActualSaleValue)
                        };


                        _context.TblServiceActualSales.Add(serviceActualSales);
                    }
                    else
                    {
                        localService.cost_type = service.CostType;
                        localService.currency = service.Currency;
                        localService.actual_sale_value = Convert.ToDecimal(service.ActualSaleValue);

                        _context.TblServiceActualSales.Update(localService);
                    }

                    foreach (var machine in service.MachineDetails?.Machines ?? new List<ErpActualSaleMachine>())
                    {
                        var ifMachineExists = _context.TblServiceMachines.FirstOrDefault(m => m.id == machine.MachineID) != null;
                        if (ifMachineExists)
                        {
                            var localMachine = _context.TblMachineActualSales.FirstOrDefault(mas => mas.service_machine_id == machine.MachineID);
                            if (localMachine == null)
                            {
                                var machineActualSales = new TblMachineActualSale()
                                {
                                    id = Guid.NewGuid().ToString(),
                                    service_machine_id = machine.MachineID,
                                    cost_type = machine.CostType,
                                    currency = machine.Currency,
                                    actual_sale_value = Convert.ToDecimal(machine.ActualSaleValue)
                                };


                                _context.TblMachineActualSales.Add(machineActualSales);
                            }
                            else
                            {
                                localMachine.cost_type = machine.CostType;
                                localMachine.currency = machine.Currency;
                                localMachine.actual_sale_value = Convert.ToDecimal(machine.ActualSaleValue);

                                _context.TblMachineActualSales.Update(localMachine);
                            }

                        }

                    }
                    _context.SaveChanges();
                }


            }
        }

        public async Task UpdatePlannedSales(ErpPlannedSalesResponseEvent plannedSaleResponse)
        {
            foreach (var service in plannedSaleResponse.PlannedSale.Services)
            {
                var ifServiceExists = _context.TblServices.FirstOrDefault(s => s.id == service.ServiceID) != null;
                if (ifServiceExists)
                {
                    var localService = _context.TblServicePlannedSales.FirstOrDefault(sps => sps.service_id == service.ServiceID);
                    if (localService == null)
                    {
                        var servicePlannedSales = new TblServicePlannedSale()
                        {
                            id = Guid.NewGuid().ToString(),
                            service_id = service.ServiceID,
                            cost_type = service.CostType,
                            currency = service.Currency,
                            planned_sale_value = Convert.ToDecimal(service.PlannedSaleValue)
                        };


                        _context.TblServicePlannedSales.Add(servicePlannedSales);
                    }
                    else
                    {
                        localService.cost_type = service.CostType;
                        localService.currency = service.Currency;
                        localService.planned_sale_value = Convert.ToDecimal(service.PlannedSaleValue);

                        _context.TblServicePlannedSales.Update(localService);
                    }

                    foreach (var machine in service.MachineDetails?.Machines ?? new List<ErpPlannedSaleMachine>())
                    {
                        var ifMachineExists = _context.TblServiceMachines.FirstOrDefault(m => m.id == machine.MachineID) != null;
                        if (ifMachineExists)
                        {
                            var localMachine = _context.TblMachinePlannedSales.FirstOrDefault(mps => mps.service_machine_id == machine.MachineID);
                            if (localMachine == null)
                            {
                                var machinePlannedSales = new TblMachinePlannedSale()
                                {
                                    id = Guid.NewGuid().ToString(),
                                    service_machine_id = machine.MachineID,
                                    cost_type = machine.CostType,
                                    currency = machine.Currency,
                                    planned_sale_value = Convert.ToDecimal(machine.PlannedSaleValue)
                                };


                                _context.TblMachinePlannedSales.Add(machinePlannedSales);
                            }
                            else
                            {
                                localMachine.cost_type = machine.CostType;
                                localMachine.currency = machine.Currency;
                                localMachine.planned_sale_value = Convert.ToDecimal(machine.PlannedSaleValue);

                                _context.TblMachinePlannedSales.Update(localMachine);
                            }
                        }

                    }
                    _context.SaveChanges();
                }

            }
        }
        /// <summary>
        /// Process Commercial Quotation
        /// </summary>
        /// <param name="commercialQuotation"></param>
        /// <returns></returns>
        public async Task AddCommercialQuotation(CommercialQuotationResponseEvent commercialQuotation)
        {
            try
            {
                //var qoutation = mapper.Map<TblCommercialQuotation>(commercialQuotation?.CommercialQuotation);
                string incrementValue = "V1";
                var comqoutation = _context.TblCommercialQuotations
                .Where(q => q.offer_id == commercialQuotation.CommercialQuotation.OfferID).OrderByDescending(q => q.created_at)
                .FirstOrDefault();
                if (comqoutation != null)
                {
                    int version = Convert.ToInt32(comqoutation.version != null ? comqoutation.version[1..] : 1);
                    version = ++version;
                    incrementValue = "V" + version.ToString();
                    TblCommercialQuotation quotation = new();
                    quotation.id = Guid.NewGuid().ToString();
                    quotation.content_type = commercialQuotation?.CommercialQuotation?.ContentType;
                    quotation.data = Encoding.ASCII.GetBytes(commercialQuotation.CommercialQuotation.Data);
                    quotation.encoding_format = commercialQuotation?.CommercialQuotation?.EncodingFormat;
                    quotation.erp_project_id = commercialQuotation?.CommercialQuotation?.ERPProjectID;
                    quotation.project_id = commercialQuotation?.CommercialQuotation?.ProjectID;
                    quotation.offer_id = commercialQuotation?.CommercialQuotation?.OfferID;
                    quotation.quotationnumber = commercialQuotation?.CommercialQuotation?.QuotationNumber;
                    quotation.created_at = DateTimeOffset.Now;
                    quotation.version = incrementValue;

                    _context.TblCommercialQuotations.Add(quotation);

                    _context.SaveChanges();

                    #region 
                    var offers = _context.TblOffers.Where(offr => offr.id == quotation.offer_id).FirstOrDefault();

                    if (offers != null)
                    {
                        offers.is_commercial_quote = true;

                        _context.Update(offers);

                        _context.SaveChanges();
                    }
                    #endregion
                    #region Commertial Quotation Notification
                    var tenantId = commercialQuotation.TechnicalHeader.TenantID ?? String.Empty;
                    var projectStaff = _context.TblProjectStaffs.Where(p => p.project_id == commercialQuotation.CommercialQuotation.ProjectID).ToList();
                    var email = GetStaffedUserEmails(projectStaff);
                    eventBus.PublishToQueue(new OfferNotificationEvent(email, "Create", "", tenantId, "The Commercial Quotation for the Offer with " + offers?.WBSID + " is received", offers?.WBSID, offers.id, "CommertialQuotation") { TopicName = "offernotificationrequest" });

                    #endregion
                }
                else
                {
                    TblCommercialQuotation quotation = new();
                    quotation.id = Guid.NewGuid().ToString();
                    quotation.content_type = commercialQuotation.CommercialQuotation.ContentType;
                    quotation.data = Encoding.ASCII.GetBytes(commercialQuotation.CommercialQuotation.Data);
                    quotation.encoding_format = commercialQuotation.CommercialQuotation.EncodingFormat;
                    quotation.erp_project_id = commercialQuotation.CommercialQuotation.ERPProjectID;
                    quotation.project_id = commercialQuotation.CommercialQuotation.ProjectID;
                    quotation.offer_id = commercialQuotation.CommercialQuotation.OfferID;
                    quotation.quotationnumber = commercialQuotation.CommercialQuotation.QuotationNumber;
                    quotation.created_at = DateTimeOffset.Now;
                    quotation.version = "V1";

                    _context.TblCommercialQuotations.Add(quotation);

                    _context.SaveChanges();

                    #region 
                    var offers = _context.TblOffers.Where(offr => offr.id == quotation.offer_id).FirstOrDefault();

                    if (offers != null)
                    {
                        offers.is_commercial_quote = true;

                        _context.Update(offers);

                        _context.SaveChanges();
                    }
                    #endregion
                    #region Commertial Quotation Notification
                    var tenantId = commercialQuotation.TechnicalHeader.TenantID ?? String.Empty;
                    var projectStaff = _context.TblProjectStaffs.Where(p => p.project_id == commercialQuotation.CommercialQuotation.ProjectID).ToList();
                    var email = GetStaffedUserEmails(projectStaff);
                    eventBus.PublishToQueue(new OfferNotificationEvent(email, "Create", GetCurrentUserId(), tenantId, "The Commercial Quotation for the Offer with " + offers?.WBSID + " is received", offers?.WBSID, offers.id, "CommertialQuotation") { TopicName = "offernotificationrequest" });

                    #endregion
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }

        }


        public async Task AddCommercialQuotationV1(CommercialQuotationResponseEventV1 commercialQuotation)
        {
            try
            {
                //Steps
                //1 Store Chunk Request in tblCommercialQuotationChunk Table
                var commercialQuotationChunk = new TblCommercialQuotationChunk
                {
                    id = Guid.NewGuid().ToString(),
                    project_id = commercialQuotation.CommercialQuotation.ProjectID,
                    erp_project_id = commercialQuotation.CommercialQuotation.ERPProjectID,
                    offer_id = commercialQuotation.CommercialQuotation.OfferID,
                    quotation_number = commercialQuotation.CommercialQuotation.QuotationNumber,
                    content_type = commercialQuotation.CommercialQuotation.ContentType,
                    encoding_format = commercialQuotation.CommercialQuotation.EncodingFormat,
                    data = Encoding.ASCII.GetBytes(commercialQuotation.CommercialQuotation.Data),
                    current_chunk_number =Convert.ToInt32(commercialQuotation.CommercialQuotation.CurrentChunkNumber.Trim()),
                    next_chunk_number =Convert.ToInt32(commercialQuotation.CommercialQuotation.NextChunkNumber.Trim()),
                    total_chunk = Convert.ToInt32(commercialQuotation.CommercialQuotation.TotalChunk.Trim()),
                    created_at = DateTimeOffset.UtcNow
                };
                _context.TblCommercialQuotationChunks.Add(commercialQuotationChunk);
                await _context.SaveChangesAsync();

                //2 check quotation number in db available check total chunk count
                int chunkCount = await _context.TblCommercialQuotationChunks
                                               .Where(x => x.quotation_number == commercialQuotation.CommercialQuotation.QuotationNumber)
                                               .CountAsync();
                string _data = string.Empty;
                bool isAllChunkMerged = false;
                //3 if total chunk count equals will need to merge file
                if (chunkCount == Convert.ToInt32(commercialQuotation.CommercialQuotation.TotalChunk.Trim()))
                {
                    //4 get all chunk and merge it
                    var chunkList = await _context.TblCommercialQuotationChunks
                                                  .Where(x => x.quotation_number == commercialQuotation.CommercialQuotation.QuotationNumber)
                                                  .OrderBy(x => x.current_chunk_number).ToListAsync();
                    foreach (var item in chunkList)
                    {
                        Encoding encoding = Encoding.UTF8;
                        _data += encoding.GetString(item.data);
                    }
                    isAllChunkMerged = true;
                    //5 delete current quotation chunks
                    List<TblCommercialQuotationChunk> removeChunks = await _context.TblCommercialQuotationChunks
                                                    .Where(x => x.quotation_number == commercialQuotation.CommercialQuotation.QuotationNumber)
                                                    .ToListAsync();
                    _context.TblCommercialQuotationChunks.RemoveRange(removeChunks);
                    await _context.SaveChangesAsync();
                    //6 then pass data  in commercialQuotation field
                }



                //Steps Approach 2

                //1 Store 1 Chunk Request in tblCommercialQuotation Table
                //2 check next chunk if 2 then process else store in tblCommercialQuotationChunk Table
                //3 if current_chunk equals to total_chunk return
                //4 delete current quotation chunks
                //5 then pass data  in commercialQuotation field

                if (isAllChunkMerged)
                {
                    string incrementValue = "V1";
                    var comqoutation = _context.TblCommercialQuotations
                    .Where(q => q.offer_id == commercialQuotation.CommercialQuotation.OfferID).OrderByDescending(q => q.created_at)
                    .FirstOrDefault();
                    if (comqoutation != null)
                    {
                        int version = Convert.ToInt32(comqoutation.version != null ? comqoutation.version[1..] : 1);
                        version = ++version;
                        incrementValue = "V" + version.ToString();
                        TblCommercialQuotation quotation = new();
                        quotation.id = Guid.NewGuid().ToString();
                        quotation.content_type = commercialQuotation?.CommercialQuotation?.ContentType;
                        quotation.data = Encoding.ASCII.GetBytes(_data);
                        quotation.encoding_format = commercialQuotation?.CommercialQuotation?.EncodingFormat;
                        quotation.erp_project_id = commercialQuotation?.CommercialQuotation?.ERPProjectID;
                        quotation.project_id = commercialQuotation?.CommercialQuotation?.ProjectID;
                        quotation.offer_id = commercialQuotation?.CommercialQuotation?.OfferID;
                        quotation.quotationnumber = commercialQuotation?.CommercialQuotation?.QuotationNumber;
                        quotation.created_at = DateTimeOffset.Now;
                        quotation.version = incrementValue;

                        _context.TblCommercialQuotations.Add(quotation);

                        _context.SaveChanges();

                        #region 
                        var offers = _context.TblOffers.Where(offr => offr.id == quotation.offer_id).FirstOrDefault();

                        if (offers != null)
                        {
                            offers.is_commercial_quote = true;

                            _context.Update(offers);

                            _context.SaveChanges();
                        }
                        #endregion
                        #region Commertial Quotation Notification
                        var tenantId = commercialQuotation.TechnicalHeader.TenantID ?? String.Empty;
                        var projectStaff = _context.TblProjectStaffs.Where(p => p.project_id == commercialQuotation.CommercialQuotation.ProjectID).ToList();
                        var email = GetStaffedUserEmails(projectStaff);
                        await eventBus.PublishToQueue(new OfferNotificationEvent(email, "Create", "", tenantId, "The Commercial Quotation for the Offer with " + offers?.WBSID + " is received", offers?.WBSID, offers.id, "CommertialQuotation") { TopicName = "offernotificationrequest" });

                        #endregion
                    }
                    else
                    {
                        TblCommercialQuotation quotation = new();
                        quotation.id = Guid.NewGuid().ToString();
                        quotation.content_type = commercialQuotation.CommercialQuotation.ContentType;
                        quotation.data = Encoding.ASCII.GetBytes(_data);
                        quotation.encoding_format = commercialQuotation.CommercialQuotation.EncodingFormat;
                        quotation.erp_project_id = commercialQuotation.CommercialQuotation.ERPProjectID;
                        quotation.project_id = commercialQuotation.CommercialQuotation.ProjectID;
                        quotation.offer_id = commercialQuotation.CommercialQuotation.OfferID;
                        quotation.quotationnumber = commercialQuotation.CommercialQuotation.QuotationNumber;
                        quotation.created_at = DateTimeOffset.Now;
                        quotation.version = "V1";

                        _context.TblCommercialQuotations.Add(quotation);

                        _context.SaveChanges();

                        #region 
                        var offers = _context.TblOffers.Where(offr => offr.id == quotation.offer_id).FirstOrDefault();

                        if (offers != null)
                        {
                            offers.is_commercial_quote = true;

                            _context.Update(offers);

                            _context.SaveChanges();
                        }
                        #endregion
                        #region Commertial Quotation Notification
                        var tenantId = commercialQuotation.TechnicalHeader.TenantID ?? String.Empty;
                        var projectStaff = _context.TblProjectStaffs.Where(p => p.project_id == commercialQuotation.CommercialQuotation.ProjectID).ToList();
                        var email = GetStaffedUserEmails(projectStaff);
                        await eventBus.PublishToQueue(new OfferNotificationEvent(email, "Create", GetCurrentUserId(), tenantId, "The Commercial Quotation for the Offer with " + offers?.WBSID + " is received", offers?.WBSID, offers.id, "CommertialQuotation") { TopicName = "offernotificationrequest" });

                        #endregion
                    }
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }

        }

        public async Task<bool> DeleteOpprtunity(DeleteOpportunityDTO deleteOpportunity)
        {
            var isSuccess = false;

            try
            {
                var offerDetails = _context.TblOffers.Where(o => o.id == deleteOpportunity.Offer_Id).FirstOrDefault();

                if (offerDetails.is_commercial_quote == true)
                {
                    var opportunity = _context.TblOpportunity.Where(op => op.id == offerDetails.opportunity_id && op.project_id == deleteOpportunity.Project_Id).FirstOrDefault();

                    offerDetails.opportunity_id = null;

                    _context.TblOpportunity.Remove(opportunity);

                    _context.SaveChanges();

                    isSuccess = true;
                }

                return isSuccess;
            }
            catch (Exception ex)
            {
                return isSuccess;
            }

        }
        public async Task<string> AssignOffer(EditOfferDTO editOffer)
        {
            try
            {
                string msg = "Offer not updated";
                var users = _context.TblUsers.Where(usr => usr.id == editOffer.Assignee).ToList();
                var allPermissions = new List<string>();
                var isGlobalAdminRole = (from role in _context.TblRoles
                                         join userRole in _context.TblUserRoleAssignment on role.id equals userRole.role_id
                                         where userRole.user_id == editOffer.Assignee && role.IsGlobalAdminRole
                                         select role).Count() > 0;
                if (isGlobalAdminRole)
                {
                    allPermissions = _context.TblPermission.Where(p => p.is_active).Select(perm => perm.name).ToList();
                }
                else
                {
                    var userGroup = _context.TblUserAndGroupAssociation.Where(uga => uga.members == editOffer.Assignee);
                    var perm = (from permission in _context.TblPermission
                                join rolePerms in _context.TblPermissionAssociation on permission.id equals rolePerms.permission_id
                                join userRole in _context.TblUserRoleAssignment on rolePerms.role_id equals userRole.role_id
                                where userRole.user_id == editOffer.Assignee && permission.is_active
                                select permission.name
                            ).ToList();
                    List<string> groupPermissions = new List<string>();
                    if (userGroup != null)
                    {
                        var groupIds = userGroup.Select(uga => uga.group_id).ToList();

                        groupPermissions = (from permission in _context.TblPermission
                                            join rolePerms in _context.TblPermissionAssociation on permission.id equals rolePerms.permission_id
                                            join userRole in _context.TblUserRoleAssignment on rolePerms.role_id equals userRole.role_id
                                            where groupIds.Contains(userRole.group_id) && permission.is_active
                                            select permission.name).ToList();
                    }
                    allPermissions = perm.Union(groupPermissions).ToList();
                }
                if (allPermissions.Contains("Offer.Approve"))
                {
                    TblOffer tblOffer = _context.TblOffers.Where(x => x.id == editOffer.OfferId).FirstOrDefault();
                    if (tblOffer != null)
                    {
                        tblOffer.notes = editOffer.AdditionalNotes ?? tblOffer.notes;
                        tblOffer.contact_id = editOffer.ContactId ?? tblOffer.contact_id;
                        tblOffer.status = editOffer.Status ?? tblOffer.status;
                        tblOffer.assignee = editOffer.Assignee ?? tblOffer.assignee;
                        _context.SaveChanges();
                        msg = "Offer updated successfully";
                    }
                    else
                    {
                        msg = "Offer not updated";
                    }
                }
                else
                {
                    msg = "Assigned user don't have Offer Approve Permission";
                }
                return msg;
            }
            catch (Exception)
            {

                throw;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="modeName"></param>
        /// <returns></returns>
        private string GetModeId(string modeName)
        {
            try
            {
                if (modeName != null)
                {
                    var Id = _context.TblModes.FirstOrDefault(m => m.mode_name.ToLower().Trim() == modeName.ToLower().Trim()) != null ? _context.TblModes.FirstOrDefault(m => m.mode_name.ToLower().Trim() == modeName.ToLower().Trim()).id : null;
                    return Id;
                }
                else
                {
                    return null;
                }

            }
            catch (Exception ex)
            {
                return null;
            }
        }
        private async Task<bool> CreateRoadmap(List<RoadMapMasterDTO> roadmapList, string servicemachineId)
        {
            var totalSteps = 0;
            var answeredSteps = 0;
            var roadmapProgress = 0;
            try
            {
                for (int raodmaps = 0; raodmaps < roadmapList.Count; raodmaps++)
                {
                    var roadmapData = await GetRoadmapDetailsById(roadmapList[raodmaps].RoadMapMasterId);
                    if (roadmapData != null)
                    {
                        TblRoadmapMaster rm = new();
                        rm.roadmap_id = Guid.NewGuid().ToString();
                        rm.roadmap_name = roadmapData.RoadMapName;
                        rm.iscustom = true;
                        rm.user_id = GetCurrentUserId();
                        rm.created_at = DateTimeOffset.UtcNow;
                        rm.created_by = GetCurrentUserId();
                        rm.modified_at = DateTimeOffset.UtcNow;
                        rm.modified_by = GetCurrentUserId();

                        TblMachineRoadmap machineRoadmap = new();
                        machineRoadmap.id = Guid.NewGuid().ToString();
                        machineRoadmap.service_machine_id = servicemachineId;
                        machineRoadmap.roadmap_id = rm.roadmap_id;
                        machineRoadmap.istype = "RA";
                        machineRoadmap.created_at = DateTimeOffset.UtcNow;
                        machineRoadmap.created_by = GetCurrentUserId();
                        machineRoadmap.modified_at = DateTimeOffset.UtcNow;
                        machineRoadmap.modified_by = GetCurrentUserId();

                        TblProjectRoadmapAssociation roadmapAssociation = new();
                        roadmapAssociation.id = Guid.NewGuid().ToString();
                        roadmapAssociation.project_id = roadmapData.Project_Id;
                        roadmapAssociation.roadmap_id = rm.roadmap_id;
                        roadmapAssociation.created_at = DateTimeOffset.UtcNow;

                        #region Log AuditEntry
                        TblAuditEntry tblAuditEntry = new();
                        tblAuditEntry.id = Guid.NewGuid().ToString();
                        tblAuditEntry.project_id = roadmapData.Project_Id;
                        tblAuditEntry.erp_project_id = _context.TblProjects.FirstOrDefault(p => p.id == roadmapData.Project_Id).erp_project_id ?? null;
                        tblAuditEntry.action = "Create";
                        tblAuditEntry.scope = "New Roadmap " + roadmapData.RoadMapName + " has been added";
                        tblAuditEntry.created_at = DateTimeOffset.UtcNow;
                        tblAuditEntry.user_id = _context.TblUser.FirstOrDefault(p => p.id == GetCurrentUserId())?.email_address ?? null;
                        tblAuditEntry.affected_table = "TblRoadmapMaster";
                        _context.TblAuditEntry.Add(tblAuditEntry);
                        #endregion
                        _context.TblRoadmapMaster.Add(rm);
                        _context.TblMachineRoadmap.Add(machineRoadmap);
                        _context.TblProjectRoadmapAssociation.Add(roadmapAssociation);
                        _context.SaveChanges();
                        for (int s = 0; s < roadmapData.RoadMapSections.Count; s++)
                        {
                            TblRoadmapSection rs = new();
                            rs.roadmap_id = rm.roadmap_id;
                            rs.id = Guid.NewGuid().ToString();
                            rs.section = roadmapData.RoadMapSections[s].SectionName;
                            rs.created_at = DateTimeOffset.UtcNow;
                            rs.created_by = GetCurrentUserId();
                            rs.modified_at = DateTimeOffset.UtcNow;
                            rs.modified_by = GetCurrentUserId();

                            _context.TblRoadmapSection.Add(rs);
                            _context.SaveChanges();
                            for (int sb = 0; sb < roadmapData.RoadMapSections[s].RoadMapSubSection.Count; sb++)
                            {
                                TblRoadmapSubSectionMster submaster = new();

                                submaster.id = Guid.NewGuid().ToString();
                                submaster.Sub_Section = roadmapData.RoadMapSections[s].RoadMapSubSection[sb].SubSectionName;
                                submaster.section_id = rs.id;
                                submaster.created_at = DateTimeOffset.UtcNow;
                                submaster.created_by = GetCurrentUserId();
                                submaster.modified_at = DateTimeOffset.UtcNow;
                                submaster.modified_by = GetCurrentUserId();

                                _context.TblRoadmapSubSectionMster.Add(submaster);
                                _context.SaveChanges();
                                for (int stm = 0; stm < roadmapData.RoadMapSections[s].RoadMapSubSection[sb].StepMaster.Count; stm++)
                                {
                                    TblStepMaster sm = new();
                                    TblServiceMachineSteps servicemsteps = new();
                                    TblStepMachineAssociation stepMachineAssociation = new();
                                    #region Creating new step and Adding answers to the step
                                    sm.step_id = Guid.NewGuid().ToString();
                                    sm.roadmap_section_id = submaster.id;
                                    sm.step_body = roadmapData.RoadMapSections[s].RoadMapSubSection[sb].StepMaster[stm].StepBody;
                                    sm.step_notes = roadmapData.RoadMapSections[s].RoadMapSubSection[sb].StepMaster[stm].Notes;
                                    sm.padlock = false;
                                    sm.created_at = DateTimeOffset.UtcNow;
                                    sm.created_by = GetCurrentUserId();
                                    sm.modified_at = DateTimeOffset.UtcNow;
                                    sm.modified_by = GetCurrentUserId();

                                    stepMachineAssociation.id = Guid.NewGuid().ToString();
                                    stepMachineAssociation.servicemachine_id = servicemachineId;
                                    stepMachineAssociation.step_id = sm.step_id;
                                    stepMachineAssociation.created_at = DateTimeOffset.UtcNow;

                                    _context.TblStepMaster.Add(sm);
                                    _context.TblStepMachineAssociation.Add(stepMachineAssociation);
                                    _context.SaveChanges();

                                    ///Count total steps for Roadmap
                                    totalSteps++;
                                    if (roadmapList[raodmaps].IsSelected == true)
                                    {
                                        for (int ans = 0; ans < roadmapData.RoadMapSections[s].RoadMapSubSection[sb].StepMaster[stm].Answers.Count; ans++)
                                        {
                                            if (roadmapData.RoadMapSections[s].RoadMapSubSection[sb].StepMaster[stm].Answers[ans].HazardDetails.Any())
                                            {
                                                servicemsteps.service_machine_steps_id = Guid.NewGuid().ToString();
                                                servicemsteps.step_id = sm.step_id;
                                                servicemsteps.not_applicable = false;
                                                servicemsteps.compliant = false;
                                                servicemsteps.hazard = true;
                                                servicemsteps.servicemachine_id = servicemachineId;
                                                servicemsteps.user_id = GetCurrentUserId();
                                                servicemsteps.ispreferred = true;
                                                servicemsteps.created_at = DateTimeOffset.UtcNow;
                                                servicemsteps.created_by = GetCurrentUserId();
                                                servicemsteps.modified_at = DateTimeOffset.UtcNow;
                                                servicemsteps.modified_by = GetCurrentUserId();

                                                _context.TblServiceMachineSteps.Add(servicemsteps);
                                                _context.SaveChanges();
                                                answeredSteps++;
                                                if (roadmapData.RoadMapSections[s].RoadMapSubSection[sb].StepMaster[stm].Answers[ans].HazardDetails != null)
                                                {
                                                    foreach (var hazards in roadmapData.RoadMapSections[s].RoadMapSubSection[sb].StepMaster[stm].Answers[ans].HazardDetails)
                                                    {
                                                        TblMachineHazards machineHazards = new();
                                                        TblHazardType hazardTypes = new();
                                                        List<TblHazardSource> hazardSourceList = new();
                                                        List<TblHazardConsequences> hazardConsequencesList = new();
                                                        var hazardDetails = await GethazardDetailsById(hazards.Id);
                                                        if (hazardDetails != null)
                                                        {
                                                            machineHazards.id = Guid.NewGuid().ToString();
                                                            machineHazards.name = hazardDetails.Name;
                                                            machineHazards.initial_hazard = hazardDetails.Initial_hazard;
                                                            machineHazards.counter_measure = hazardDetails.Counter_measure;
                                                            machineHazards.service_machine_steps_id = servicemsteps.service_machine_steps_id;
                                                            machineHazards.hazard_status = "Yet to Start";
                                                            machineHazards.created_at = DateTimeOffset.UtcNow;
                                                            machineHazards.created_by = GetCurrentUserId();
                                                            machineHazards.modified_at = DateTimeOffset.UtcNow;
                                                            machineHazards.modified_by = GetCurrentUserId();

                                                            _context.TblMachineHazards.Add(machineHazards);
                                                            _context.SaveChanges();

                                                            TblPerformanceLevelRating levelRating = new();
                                                            levelRating.id = Guid.NewGuid().ToString();
                                                            levelRating.PLR = hazardDetails.PLR;
                                                            levelRating.machine_hazard_id = machineHazards.id;
                                                            levelRating.category = hazardDetails.Category;
                                                            levelRating.created_at = DateTimeOffset.UtcNow;
                                                            levelRating.created_by = GetCurrentUserId();
                                                            levelRating.modified_at = DateTimeOffset.UtcNow;
                                                            levelRating.modified_by = GetCurrentUserId();

                                                            _context.TblPerformanceLevelRating.Add(levelRating);
                                                            _context.SaveChanges();

                                                            if (hazardDetails.HazardMedia != null)
                                                            {
                                                                for (int hazmed = 0; hazmed < hazardDetails.HazardMedia.Count; hazmed++)
                                                                {
                                                                    TblHazardMedia media = new();
                                                                    media.id = Guid.NewGuid().ToString();
                                                                    media.machine_hazard_id = machineHazards.id;
                                                                    media.type = hazardDetails.HazardMedia[hazmed].Type;
                                                                    media.url = hazardDetails.HazardMedia[hazmed].URL;
                                                                    media.name = hazardDetails.HazardMedia[hazmed].FileName;
                                                                    media.drive_id = hazardDetails.HazardMedia[hazmed].DriveId != null ? hazardDetails.HazardMedia[hazmed].DriveId.Trim() : null;
                                                                    media.item_id = hazardDetails.HazardMedia[hazmed].ItemId != null ? hazardDetails.HazardMedia[hazmed].ItemId.Trim() : null;
                                                                    media.image_size = hazardDetails.HazardMedia[hazmed].Image_Size;
                                                                    media.created_at = DateTimeOffset.UtcNow;
                                                                    media.created_by = GetCurrentUserId();
                                                                    media.modified_at = DateTimeOffset.UtcNow;
                                                                    media.modified_by = GetCurrentUserId();

                                                                    _context.TblHazardMedia.Add(media);
                                                                    _context.SaveChanges();
                                                                }
                                                            }

                                                            if (hazardDetails.HazardType != null)
                                                            {
                                                                for (int haztyp = 0; haztyp < hazardDetails.HazardType.Count; haztyp++)
                                                                {
                                                                    hazardTypes.id = Guid.NewGuid().ToString();
                                                                    hazardTypes.type = hazardDetails.HazardType[haztyp].HazardTypeName;
                                                                    hazardTypes.hazard_id = machineHazards.id;
                                                                    hazardTypes.created_at = DateTimeOffset.UtcNow;
                                                                    hazardTypes.created_by = GetCurrentUserId();
                                                                    hazardTypes.modified_at = DateTimeOffset.UtcNow;
                                                                    hazardTypes.modified_by = GetCurrentUserId();

                                                                    _context.TblHazardType.Add(hazardTypes);
                                                                    _context.SaveChanges();

                                                                    if (hazardDetails.HazardType[haztyp].HazardSources != null)
                                                                    {
                                                                        for (int hazsor = 0; hazsor < hazardDetails.HazardType[haztyp].HazardSources.Count; hazsor++)
                                                                        {
                                                                            TblHazardSource hazardSource = new();
                                                                            hazardSource.id = Guid.NewGuid().ToString();
                                                                            hazardSource.source = hazardDetails.HazardType[haztyp].HazardSources[hazsor].Source;
                                                                            hazardSource.hazard_type_id = hazardTypes.id;
                                                                            hazardSource.created_at = DateTimeOffset.UtcNow;
                                                                            hazardSource.created_by = GetCurrentUserId();
                                                                            hazardSource.modified_at = DateTimeOffset.UtcNow;
                                                                            hazardSource.modified_by = GetCurrentUserId();

                                                                            hazardSourceList.Add(hazardSource);
                                                                        }
                                                                    }
                                                                    if (hazardDetails.HazardType[haztyp].HazardConsequences != null)
                                                                    {
                                                                        for (int hazcon = 0; hazcon < hazardDetails.HazardType[haztyp].HazardConsequences.Count; hazcon++)
                                                                        {
                                                                            TblHazardConsequences hazardConsequences = new();
                                                                            hazardConsequences.id = Guid.NewGuid().ToString();
                                                                            hazardConsequences.consequence = hazardDetails.HazardType[haztyp].HazardConsequences[hazcon].Consequences;
                                                                            hazardConsequences.hazard_type_id = hazardTypes.id;
                                                                            hazardConsequences.created_at = DateTimeOffset.UtcNow;
                                                                            hazardConsequences.created_by = GetCurrentUserId();
                                                                            hazardConsequences.modified_at = DateTimeOffset.UtcNow;
                                                                            hazardConsequences.modified_by = GetCurrentUserId();

                                                                            hazardConsequencesList.Add(hazardConsequences);
                                                                        }
                                                                    }

                                                                }
                                                            }

                                                            _context.TblHazardSource.AddRange(hazardSourceList);
                                                            _context.TblHazardConsequences.AddRange(hazardConsequencesList);
                                                            _context.SaveChanges();
                                                            if (hazardDetails.HRNCalculations != null)
                                                            {
                                                                for (int hazcal = 0; hazcal < hazardDetails.HRNCalculations.Count; hazcal++)
                                                                {
                                                                    TblHRNCalculations hRNCalculations = new();
                                                                    hRNCalculations.id = Guid.NewGuid().ToString();
                                                                    hRNCalculations.PO = hazardDetails.HRNCalculations[hazcal].PO;
                                                                    hRNCalculations.SD = hazardDetails.HRNCalculations[hazcal].SD;
                                                                    hRNCalculations.NP = hazardDetails.HRNCalculations[hazcal].NP;
                                                                    hRNCalculations.FE = hazardDetails.HRNCalculations[hazcal].FE;
                                                                    hRNCalculations.rating = hazardDetails.HRNCalculations[hazcal].Rating;
                                                                    hRNCalculations.type = hazardDetails.HRNCalculations[hazcal].Type;
                                                                    hRNCalculations.modes = GetModeId(hazardDetails.HRNCalculations[hazcal].Mode);
                                                                    hRNCalculations.version = hazardDetails.HRNCalculations[hazcal].Version;
                                                                    hRNCalculations.machine_hazard_id = machineHazards.id;
                                                                    hRNCalculations.created_at = DateTimeOffset.UtcNow;
                                                                    hRNCalculations.created_by = GetCurrentUserId();
                                                                    hRNCalculations.modified_at = DateTimeOffset.UtcNow;
                                                                    hRNCalculations.modified_by = GetCurrentUserId();

                                                                    _context.TblHRNCalculations.Add(hRNCalculations);
                                                                    _context.SaveChanges();
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                            if (roadmapData.RoadMapSections[s].RoadMapSubSection[sb].StepMaster[stm].Answers[ans].YesComplaint)
                                            {
                                                servicemsteps.service_machine_steps_id = Guid.NewGuid().ToString();
                                                servicemsteps.step_id = sm.step_id;
                                                servicemsteps.not_applicable = false;
                                                servicemsteps.compliant = true;
                                                servicemsteps.hazard = false;
                                                servicemsteps.servicemachine_id = servicemachineId;
                                                servicemsteps.user_id = GetCurrentUserId();
                                                servicemsteps.ispreferred = true;
                                                servicemsteps.created_at = DateTimeOffset.UtcNow;
                                                servicemsteps.created_by = GetCurrentUserId();
                                                servicemsteps.modified_at = DateTimeOffset.UtcNow;
                                                servicemsteps.modified_by = GetCurrentUserId();

                                                _context.TblServiceMachineSteps.Add(servicemsteps);
                                                _context.SaveChanges();
                                                answeredSteps++;
                                            }
                                            if (roadmapData.RoadMapSections[s].RoadMapSubSection[sb].StepMaster[stm].Answers[ans].NotApplicable)
                                            {
                                                servicemsteps.service_machine_steps_id = Guid.NewGuid().ToString();
                                                servicemsteps.step_id = sm.step_id;
                                                servicemsteps.not_applicable = true;
                                                servicemsteps.compliant = false;
                                                servicemsteps.hazard = false;
                                                servicemsteps.servicemachine_id = servicemachineId;
                                                servicemsteps.user_id = GetCurrentUserId();
                                                servicemsteps.ispreferred = true;
                                                servicemsteps.created_at = DateTimeOffset.UtcNow;
                                                servicemsteps.created_by = GetCurrentUserId();
                                                servicemsteps.modified_at = DateTimeOffset.UtcNow;
                                                servicemsteps.modified_by = GetCurrentUserId();

                                                _context.TblServiceMachineSteps.Add(servicemsteps);
                                                _context.SaveChanges();
                                                answeredSteps++;
                                            }
                                        }
                                    }
                                    #endregion
                                }
                            }
                        }

                        /// Update Roadmap Status when MarkAsComplete true and calculate Roadmap Progress
                        roadmapProgress = answeredSteps != 0 ? (int)100 * answeredSteps / totalSteps : 0;
                        var roadMap = _context.TblMachineRoadmap.FirstOrDefault(r => r.roadmap_id == rm.roadmap_id && r.service_machine_id == servicemachineId);
                        if (roadMap != null)
                        {
                            roadMap.roadmap_status = "In-Progress";
                            roadMap.roadmap_progress = roadmapProgress;
                            _context.TblMachineRoadmap.Update(roadMap);
                            _context.SaveChanges();
                        }
                    }
                }

                return true;
            }
            catch (Exception)
            {

                throw;
            }
        }
        private async Task<MachineHazardDto> GethazardDetailsById(string hazardId)
        {
            try
            {
                var result = await (from hazard in _context.TblMachineHazards
                                    join level in _context.TblPerformanceLevelRating on hazard.id equals level.machine_hazard_id
                                    where hazard.id == hazardId
                                    select new MachineHazardDto
                                    {
                                        Id = hazard.id,
                                        Initial_hazard = hazard.initial_hazard ?? "NA",
                                        Name = hazard.name ?? "NA",
                                        Version = hazard.version ?? "NA",
                                        Counter_measure = hazard.counter_measure ?? "NA",
                                        PLR = level.PLR != "" ? level.PLR : "NA",
                                        Category = level.category != "" ? level.category : "NA",
                                        //Notes = _context.TblFourEyesQualityCheck.FirstOrDefault(h => h.hazard_id == hazard.id).notes ?? "NA",
                                        HazardType = (from type in _context.TblHazardType
                                                      where type.hazard_id == hazard.id
                                                      select new HazardType
                                                      {
                                                          HazardTypeId = type.id,
                                                          HazardTypeName = type.type ?? "NA",
                                                          HazardSources = _context.TblHazardSource.Where(h => h.hazard_type_id == type.id).Select(s => new HazardSource
                                                          {
                                                              Id = s.id,
                                                              Source = s.source ?? "NA"
                                                          }).ToList(),
                                                          HazardConsequences = _context.TblHazardConsequences.Where(h => h.hazard_type_id == type.id).Select(s => new HazardConsequence
                                                          {
                                                              Id = s.id,
                                                              Consequences = s.consequence ?? "NA"
                                                          }).ToList()
                                                      }).ToList(),
                                        HazardMedia = (from media in _context.TblHazardMedia
                                                       where media.machine_hazard_id == hazard.id
                                                       select new HazardMedia
                                                       {
                                                           Id = media.id,
                                                           URL = media.url,
                                                           Type = media.type,
                                                           FileName = media.name,
                                                           DriveId = media.drive_id.Trim(),
                                                           ItemId = media.item_id.Trim(),
                                                           Image_Size = media.image_size
                                                       }).ToList(),
                                        HRNCalculations = _context.TblHRNCalculations.Where(hrn => hrn.machine_hazard_id == hazard.id).Select(s => new HRNCalculations
                                        {
                                            Mode = s.modes != null ? _context.TblModes.FirstOrDefault(m => m.id == s.modes).mode_name : null,
                                            Id = s.id,
                                            PO = s.PO,
                                            FE = s.FE,
                                            SD = s.SD,
                                            NP = s.NP,
                                            Rating = s.rating,
                                            Version = s.version,
                                            Type = s.type
                                        }).ToList()
                                    }).FirstOrDefaultAsync();
                return result;
            }
            catch (Exception)
            {

                throw;
            }
        }
        private async Task<RoadMapMasterDTO> GetRoadmapDetailsById(string roadmapId)
        {
            try
            {
                var result = await (from roadMap in _context.TblRoadmapMaster.Where(r => r.roadmap_id == roadmapId)
                                    select new RoadMapMasterDTO
                                    {
                                        RoadMapMasterId = roadMap.roadmap_id,
                                        RoadMapName = roadMap.roadmap_name,
                                        RoadMapSections = _context.TblRoadmapSection.Where(s => s.roadmap_id == roadMap.roadmap_id).Select(rm => new RoadMapSectionDTO
                                        {
                                            SectionName = rm.section,
                                            RoadMapSectionId = rm.id,
                                            RoadMapSubSection = _context.TblRoadmapSubSectionMster.Where(sub => sub.section_id == rm.id).Select(sub => new RoadMapSubSectionDTO
                                            {
                                                RoadMapSubSectionId = sub.id,
                                                SubSectionName = sub.Sub_Section,
                                                StepMaster = _context.TblStepMaster.Where(s => s.roadmap_section_id == sub.id)
                                                .Select(stp => new StepMasterDTO
                                                {
                                                    StepMasterId = stp.step_id,
                                                    StepBody = stp.step_body,
                                                    Notes = stp.step_notes,
                                                    Answers = _context.TblServiceMachineSteps.Where(s => s.step_id == stp.step_id && s.ispreferred == true).Select(answr => new Answers
                                                    {
                                                        ServiceMachineStepId = answr.service_machine_steps_id,
                                                        YesComplaint = answr.compliant,
                                                        NotApplicable = answr.not_applicable,
                                                        Hazard = answr.hazard,
                                                        ReportedBy = answr.created_by,
                                                        HazardDetails = _context.TblMachineHazards.Where(s => s.service_machine_steps_id == answr.service_machine_steps_id).Select(h => new MachineHazardDto
                                                        {
                                                            Id = h.id,
                                                        }).ToList(),
                                                        //ComplaintMedia = answr.compliant == true ? _context.TblComplaintMedia.Where(s => s.service_machinestep_id == answr.service_machine_steps_id).Select(s => new FileDto
                                                        //{
                                                        //    FileName = s.name,
                                                        //    ContentType = s.type,
                                                        //    URL = s.url,
                                                        //    Id = s.id,
                                                        //    ItemId = s.item_id,
                                                        //    DriveId = s.drive_id,
                                                        //    Image_Size = s.image_size
                                                        //}).ToList() : null,
                                                    }).ToList(),
                                                }).ToList()
                                            }).ToList()
                                        }).ToList()
                                    }).FirstOrDefaultAsync();
                return result;
            }
            catch (Exception)
            {

                throw;
            }
        }
        private async Task<bool> RiskReAssessmentRoadmap(List<RoadMapMasterDTO> roadmapList, string servicemachineId)
        {
            var totalSteps = 0;
            var answeredSteps = 0;
            var roadmapProgress = 0;
            try
            {
                for (int raodmaps = 0; raodmaps < roadmapList.Count; raodmaps++)
                {
                    //Get Roadmap details by Roadmap Id
                    var roadmapData = await GetRoadmapDetailsById(roadmapList[raodmaps].RoadMapMasterId);
                    if (roadmapData != null)
                    {
                        TblRoadmapMaster rm = new();
                        rm.roadmap_id = Guid.NewGuid().ToString();
                        rm.roadmap_name = roadmapData.RoadMapName;
                        rm.iscustom = true;
                        rm.is_risk_reassessment = true;
                        rm.user_id = GetCurrentUserId();
                        rm.created_at = DateTimeOffset.UtcNow;
                        rm.created_by = GetCurrentUserId();
                        rm.modified_at = DateTimeOffset.UtcNow;
                        rm.modified_by = GetCurrentUserId();

                        TblMachineRoadmap machineRoadmap = new();
                        machineRoadmap.id = Guid.NewGuid().ToString();
                        machineRoadmap.service_machine_id = servicemachineId;
                        machineRoadmap.roadmap_id = rm.roadmap_id;
                        machineRoadmap.istype = "RRA";
                        machineRoadmap.created_at = DateTimeOffset.UtcNow;
                        machineRoadmap.created_by = GetCurrentUserId();
                        machineRoadmap.modified_at = DateTimeOffset.UtcNow;
                        machineRoadmap.modified_by = GetCurrentUserId();

                        TblProjectRoadmapAssociation roadmapAssociation = new();
                        roadmapAssociation.id = Guid.NewGuid().ToString();
                        roadmapAssociation.project_id = roadmapData.Project_Id;
                        roadmapAssociation.roadmap_id = rm.roadmap_id;
                        roadmapAssociation.created_at = DateTimeOffset.UtcNow;

                        #region Log AuditEntry
                        TblAuditEntry tblAuditEntry = new();
                        tblAuditEntry.id = Guid.NewGuid().ToString();
                        tblAuditEntry.project_id = roadmapData.Project_Id;
                        tblAuditEntry.erp_project_id = _context.TblProjects.FirstOrDefault(p => p.id == roadmapData.Project_Id).erp_project_id ?? null;
                        tblAuditEntry.action = "Create";
                        tblAuditEntry.scope = "New Roadmap " + roadmapData.RoadMapName + " has been added";
                        tblAuditEntry.created_at = DateTimeOffset.UtcNow;
                        tblAuditEntry.user_id = _context.TblUser.FirstOrDefault(p => p.id == GetCurrentUserId())?.email_address ?? null;
                        tblAuditEntry.affected_table = "TblRoadmapMaster";
                        _context.TblAuditEntry.Add(tblAuditEntry);
                        #endregion
                        _context.TblRoadmapMaster.Add(rm);
                        _context.TblMachineRoadmap.Add(machineRoadmap);
                        _context.TblProjectRoadmapAssociation.Add(roadmapAssociation);
                        _context.SaveChanges();
                        for (int s = 0; s < roadmapData.RoadMapSections.Count; s++)
                        {
                            TblRoadmapSection rs = new();
                            rs.roadmap_id = rm.roadmap_id;
                            rs.id = Guid.NewGuid().ToString();
                            rs.section = roadmapData.RoadMapSections[s].SectionName;
                            rs.created_at = DateTimeOffset.UtcNow;
                            rs.created_by = GetCurrentUserId();
                            rs.modified_at = DateTimeOffset.UtcNow;
                            rs.modified_by = GetCurrentUserId();

                            _context.TblRoadmapSection.Add(rs);
                            _context.SaveChanges();
                            for (int sb = 0; sb < roadmapData.RoadMapSections[s].RoadMapSubSection.Count; sb++)
                            {
                                TblRoadmapSubSectionMster submaster = new();

                                submaster.id = Guid.NewGuid().ToString();
                                submaster.Sub_Section = roadmapData.RoadMapSections[s].RoadMapSubSection[sb].SubSectionName;
                                submaster.section_id = rs.id;
                                submaster.created_at = DateTimeOffset.UtcNow;
                                submaster.created_by = GetCurrentUserId();
                                submaster.modified_at = DateTimeOffset.UtcNow;
                                submaster.modified_by = GetCurrentUserId();

                                _context.TblRoadmapSubSectionMster.Add(submaster);
                                _context.SaveChanges();
                                for (int stm = 0; stm < roadmapData.RoadMapSections[s].RoadMapSubSection[sb].StepMaster.Count; stm++)
                                {
                                    TblStepMaster sm = new();
                                    TblServiceMachineSteps servicemsteps = new();
                                    TblStepMachineAssociation stepMachineAssociation = new();
                                    #region Creating new step and Adding answers to the step
                                    sm.step_id = Guid.NewGuid().ToString();
                                    sm.roadmap_section_id = submaster.id;
                                    sm.step_body = roadmapData.RoadMapSections[s].RoadMapSubSection[sb].StepMaster[stm].StepBody;
                                    sm.step_notes = roadmapData.RoadMapSections[s].RoadMapSubSection[sb].StepMaster[stm].Notes;
                                    sm.padlock = false;
                                    sm.created_at = DateTimeOffset.UtcNow;
                                    sm.created_by = GetCurrentUserId();
                                    sm.modified_at = DateTimeOffset.UtcNow;
                                    sm.modified_by = GetCurrentUserId();

                                    stepMachineAssociation.id = Guid.NewGuid().ToString();
                                    stepMachineAssociation.servicemachine_id = servicemachineId;
                                    stepMachineAssociation.step_id = sm.step_id;
                                    stepMachineAssociation.created_at = DateTimeOffset.UtcNow;

                                    _context.TblStepMaster.Add(sm);
                                    _context.TblStepMachineAssociation.Add(stepMachineAssociation);
                                    _context.SaveChanges();

                                    ///Count total steps for Roadmap
                                    totalSteps++;
                                    for (int ans = 0; ans < roadmapData.RoadMapSections[s].RoadMapSubSection[sb].StepMaster[stm].Answers.Count; ans++)
                                    {
                                        if (roadmapData.RoadMapSections[s].RoadMapSubSection[sb].StepMaster[stm].Answers[ans].HazardDetails.Any())
                                        {
                                            servicemsteps.service_machine_steps_id = Guid.NewGuid().ToString();
                                            servicemsteps.step_id = sm.step_id;
                                            servicemsteps.not_applicable = false;
                                            servicemsteps.compliant = false;
                                            servicemsteps.hazard = true;
                                            servicemsteps.servicemachine_id = servicemachineId;
                                            servicemsteps.user_id = GetCurrentUserId();
                                            servicemsteps.ispreferred = true;
                                            servicemsteps.created_at = DateTimeOffset.UtcNow;
                                            servicemsteps.created_by = GetCurrentUserId();
                                            servicemsteps.modified_at = DateTimeOffset.UtcNow;
                                            servicemsteps.modified_by = GetCurrentUserId();

                                            _context.TblServiceMachineSteps.Add(servicemsteps);
                                            _context.SaveChanges();
                                            answeredSteps++;
                                            if (roadmapData.RoadMapSections[s].RoadMapSubSection[sb].StepMaster[stm].Answers[ans].HazardDetails != null)
                                            {
                                                foreach (var hazards in roadmapData.RoadMapSections[s].RoadMapSubSection[sb].StepMaster[stm].Answers[ans].HazardDetails)
                                                {
                                                    TblMachineHazards machineHazards = new();
                                                    TblHazardType hazardTypes = new();
                                                    List<TblHazardSource> hazardSourceList = new();
                                                    List<TblHazardConsequences> hazardConsequencesList = new();
                                                    var hazardDetails = await GethazardDetailsById(hazards.Id);
                                                    if (hazardDetails != null)
                                                    {
                                                        machineHazards.id = Guid.NewGuid().ToString();
                                                        machineHazards.name = hazardDetails.Name;
                                                        machineHazards.initial_hazard = hazardDetails.Initial_hazard;
                                                        machineHazards.counter_measure = hazardDetails.Counter_measure;
                                                        machineHazards.service_machine_steps_id = servicemsteps.service_machine_steps_id;
                                                        machineHazards.hazard_status = "Yet to Start";
                                                        machineHazards.created_at = DateTimeOffset.UtcNow;
                                                        machineHazards.created_by = GetCurrentUserId();
                                                        machineHazards.modified_at = DateTimeOffset.UtcNow;
                                                        machineHazards.modified_by = GetCurrentUserId();

                                                        _context.TblMachineHazards.Add(machineHazards);
                                                        _context.SaveChanges();

                                                        TblPerformanceLevelRating levelRating = new();
                                                        levelRating.id = Guid.NewGuid().ToString();
                                                        levelRating.PLR = hazardDetails.PLR;
                                                        levelRating.machine_hazard_id = machineHazards.id;
                                                        levelRating.category = hazardDetails.Category;
                                                        levelRating.created_at = DateTimeOffset.UtcNow;
                                                        levelRating.created_by = GetCurrentUserId();
                                                        levelRating.modified_at = DateTimeOffset.UtcNow;
                                                        levelRating.modified_by = GetCurrentUserId();

                                                        _context.TblPerformanceLevelRating.Add(levelRating);
                                                        _context.SaveChanges();

                                                        if (hazardDetails.HazardMedia != null)
                                                        {
                                                            for (int hazmed = 0; hazmed < hazardDetails.HazardMedia.Count; hazmed++)
                                                            {
                                                                TblHazardMedia media = new();
                                                                media.id = Guid.NewGuid().ToString();
                                                                media.machine_hazard_id = machineHazards.id;
                                                                media.type = hazardDetails.HazardMedia[hazmed].Type;
                                                                media.url = hazardDetails.HazardMedia[hazmed].URL;
                                                                media.name = hazardDetails.HazardMedia[hazmed].FileName;
                                                                media.drive_id = hazardDetails.HazardMedia[hazmed].DriveId != null ? hazardDetails.HazardMedia[hazmed].DriveId.Trim() : null;
                                                                media.item_id = hazardDetails.HazardMedia[hazmed].ItemId != null ? hazardDetails.HazardMedia[hazmed].ItemId.Trim() : null;
                                                                media.image_size = hazardDetails.HazardMedia[hazmed].Image_Size;
                                                                media.created_at = DateTimeOffset.UtcNow;
                                                                media.created_by = GetCurrentUserId();
                                                                media.modified_at = DateTimeOffset.UtcNow;
                                                                media.modified_by = GetCurrentUserId();

                                                                _context.TblHazardMedia.Add(media);
                                                                _context.SaveChanges();
                                                            }
                                                        }

                                                        if (hazardDetails.HazardType != null)
                                                        {
                                                            for (int haztyp = 0; haztyp < hazardDetails.HazardType.Count; haztyp++)
                                                            {
                                                                hazardTypes.id = Guid.NewGuid().ToString();
                                                                hazardTypes.type = hazardDetails.HazardType[haztyp].HazardTypeName;
                                                                hazardTypes.hazard_id = machineHazards.id;
                                                                hazardTypes.created_at = DateTimeOffset.UtcNow;
                                                                hazardTypes.created_by = GetCurrentUserId();
                                                                hazardTypes.modified_at = DateTimeOffset.UtcNow;
                                                                hazardTypes.modified_by = GetCurrentUserId();

                                                                _context.TblHazardType.Add(hazardTypes);
                                                                _context.SaveChanges();

                                                                if (hazardDetails.HazardType[haztyp].HazardSources != null)
                                                                {
                                                                    for (int hazsor = 0; hazsor < hazardDetails.HazardType[haztyp].HazardSources.Count; hazsor++)
                                                                    {
                                                                        TblHazardSource hazardSource = new();
                                                                        hazardSource.id = Guid.NewGuid().ToString();
                                                                        hazardSource.source = hazardDetails.HazardType[haztyp].HazardSources[hazsor].Source;
                                                                        hazardSource.hazard_type_id = hazardTypes.id;
                                                                        hazardSource.created_at = DateTimeOffset.UtcNow;
                                                                        hazardSource.created_by = GetCurrentUserId();
                                                                        hazardSource.modified_at = DateTimeOffset.UtcNow;
                                                                        hazardSource.modified_by = GetCurrentUserId();

                                                                        hazardSourceList.Add(hazardSource);
                                                                    }
                                                                }
                                                                if (hazardDetails.HazardType[haztyp].HazardConsequences != null)
                                                                {
                                                                    for (int hazcon = 0; hazcon < hazardDetails.HazardType[haztyp].HazardConsequences.Count; hazcon++)
                                                                    {
                                                                        TblHazardConsequences hazardConsequences = new();
                                                                        hazardConsequences.id = Guid.NewGuid().ToString();
                                                                        hazardConsequences.consequence = hazardDetails.HazardType[haztyp].HazardConsequences[hazcon].Consequences;
                                                                        hazardConsequences.hazard_type_id = hazardTypes.id;
                                                                        hazardConsequences.created_at = DateTimeOffset.UtcNow;
                                                                        hazardConsequences.created_by = GetCurrentUserId();
                                                                        hazardConsequences.modified_at = DateTimeOffset.UtcNow;
                                                                        hazardConsequences.modified_by = GetCurrentUserId();

                                                                        hazardConsequencesList.Add(hazardConsequences);
                                                                    }
                                                                }
                                                            }
                                                        }

                                                        _context.TblHazardSource.AddRange(hazardSourceList);
                                                        _context.TblHazardConsequences.AddRange(hazardConsequencesList);
                                                        _context.SaveChanges();
                                                        if (hazardDetails.HRNCalculations != null)
                                                        {
                                                            for (int hazcal = 0; hazcal < hazardDetails.HRNCalculations.Count; hazcal++)
                                                            {
                                                                TblHRNCalculations hRNCalculations = new();
                                                                hRNCalculations.id = Guid.NewGuid().ToString();
                                                                hRNCalculations.PO = hazardDetails.HRNCalculations[hazcal].PO;
                                                                hRNCalculations.SD = hazardDetails.HRNCalculations[hazcal].SD;
                                                                hRNCalculations.NP = hazardDetails.HRNCalculations[hazcal].NP;
                                                                hRNCalculations.FE = hazardDetails.HRNCalculations[hazcal].FE;
                                                                hRNCalculations.rating = hazardDetails.HRNCalculations[hazcal].Rating;
                                                                hRNCalculations.type = hazardDetails.HRNCalculations[hazcal].Type;
                                                                hRNCalculations.modes = GetModeId(hazardDetails.HRNCalculations[hazcal].Mode);
                                                                hRNCalculations.version = hazardDetails.HRNCalculations[hazcal].Version;
                                                                hRNCalculations.machine_hazard_id = machineHazards.id;
                                                                hRNCalculations.created_at = DateTimeOffset.UtcNow;
                                                                hRNCalculations.created_by = GetCurrentUserId();
                                                                hRNCalculations.modified_at = DateTimeOffset.UtcNow;
                                                                hRNCalculations.modified_by = GetCurrentUserId();

                                                                _context.TblHRNCalculations.Add(hRNCalculations);
                                                                _context.SaveChanges();
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        if (roadmapData.RoadMapSections[s].RoadMapSubSection[sb].StepMaster[stm].Answers[ans].YesComplaint)
                                        {
                                            servicemsteps.service_machine_steps_id = Guid.NewGuid().ToString();
                                            servicemsteps.step_id = sm.step_id;
                                            servicemsteps.not_applicable = false;
                                            servicemsteps.compliant = true;
                                            servicemsteps.hazard = false;
                                            servicemsteps.servicemachine_id = servicemachineId;
                                            servicemsteps.user_id = GetCurrentUserId();
                                            servicemsteps.ispreferred = true;
                                            servicemsteps.created_at = DateTimeOffset.UtcNow;
                                            servicemsteps.created_by = GetCurrentUserId();
                                            servicemsteps.modified_at = DateTimeOffset.UtcNow;
                                            servicemsteps.modified_by = GetCurrentUserId();

                                            _context.TblServiceMachineSteps.Add(servicemsteps);
                                            _context.SaveChanges();
                                            answeredSteps++;
                                        }
                                        if (roadmapData.RoadMapSections[s].RoadMapSubSection[sb].StepMaster[stm].Answers[ans].NotApplicable)
                                        {
                                            servicemsteps.service_machine_steps_id = Guid.NewGuid().ToString();
                                            servicemsteps.step_id = sm.step_id;
                                            servicemsteps.not_applicable = true;
                                            servicemsteps.compliant = false;
                                            servicemsteps.hazard = false;
                                            servicemsteps.servicemachine_id = servicemachineId;
                                            servicemsteps.user_id = GetCurrentUserId();
                                            servicemsteps.ispreferred = true;
                                            servicemsteps.created_at = DateTimeOffset.UtcNow;
                                            servicemsteps.created_by = GetCurrentUserId();
                                            servicemsteps.modified_at = DateTimeOffset.UtcNow;
                                            servicemsteps.modified_by = GetCurrentUserId();

                                            _context.TblServiceMachineSteps.Add(servicemsteps);
                                            _context.SaveChanges();
                                            answeredSteps++;
                                        }
                                    }

                                    #endregion
                                }
                            }
                        }

                        /// Update Roadmap Status when MarkAsComplete true and calculate Roadmap Progress
                        roadmapProgress = answeredSteps != 0 ? (int)100 * answeredSteps / totalSteps : 0;
                        var roadMap = _context.TblMachineRoadmap.FirstOrDefault(r => r.roadmap_id == rm.roadmap_id && r.service_machine_id == servicemachineId);
                        if (roadMap != null)
                        {
                            roadMap.roadmap_status = "In-Progress";
                            roadMap.roadmap_progress = roadmapProgress;
                            _context.TblMachineRoadmap.Update(roadMap);
                            _context.SaveChanges();
                        }
                    }
                }

                return true;
            }
            catch (Exception)
            {

                throw;
            }
        }
        private async Task<List<RoadMapMasterDTO>> GetAllMachineRoadmaps(string machineId)
        {
            try
            {
                var result = await (from machine in _context.TblMachines.Where(m => m.id == machineId)
                                    join ser in _context.TblServiceMachines on machine.id equals ser.machine_id into ser1
                                    from servicemachine in ser1.DefaultIfEmpty()
                                    join mr in _context.TblMachineRoadmap on servicemachine.id equals mr.service_machine_id into mr1
                                    from machineroadmap in mr1.DefaultIfEmpty()
                                    join roadMap in _context.TblRoadmapMaster on machineroadmap.roadmap_id equals roadMap.roadmap_id
                                    select new RoadMapMasterDTO
                                    {
                                        RoadMapMasterId = roadMap.roadmap_id,
                                        RoadMapName = roadMap.roadmap_name,
                                    }).ToListAsync();
                return result;

            }
            catch (Exception)
            {

                throw;
            }
        }
        private string GetCurrentUserId() => httpContextAccessor.HttpContext.User.Claims.FirstOrDefault(c => c.Type == "Id")?.Value ?? String.Empty;

        private bool IsUserOfferManager() => httpContextAccessor.HttpContext.User.Claims.Where(c => c.Type == ClaimTypes.Role).Any(c => c.Value == "Global Admin");
        private bool IsUserAssignOffer() => httpContextAccessor.HttpContext.User.Claims.Where(c => c.Type == ClaimTypes.Role).Any(c => c.Value == "Offer.Approve");

        private List<string> GetStaffedUserEmails(List<TblProjectStaff> projectStaffs)
        {
            var emails = new List<string>();
            foreach (var item in projectStaffs)
            {
                var email = _context.TblUsers.Where(u => u.id == item.user_id).FirstOrDefault();
                emails.Add(email?.email_address);
            }

            return emails;
        }
        private static async Task LogAuditEntry(AuditLogEntryEvent auditLogEntryEvent)
        {
            try
            {
                using var context = new Sch_Context();
                TblAuditEntry tblAuditEntry = new();
                tblAuditEntry.id = Guid.NewGuid().ToString();
                tblAuditEntry.project_id = auditLogEntryEvent?.Project_Id;
                tblAuditEntry.action = auditLogEntryEvent?.Action;
                tblAuditEntry.scope = auditLogEntryEvent?.Scope;
                tblAuditEntry.created_at = DateTimeOffset.UtcNow;
                tblAuditEntry.user_id = auditLogEntryEvent?.User_Id;
                tblAuditEntry.old_value = auditLogEntryEvent?.Old_Value;
                tblAuditEntry.new_value = auditLogEntryEvent?.New_Value;
                tblAuditEntry.affected_table = auditLogEntryEvent?.Affected_Table;
                tblAuditEntry.offer_id = auditLogEntryEvent?.Offer_Id;
                tblAuditEntry.service_id = auditLogEntryEvent?.Service_Id;
                context.TblAuditEntry.Add(tblAuditEntry);
                await context.SaveChangesAsync();
            }
            catch (Exception ex)
            {

                throw;
            }
        }
        private static string GetValue(string value)
        {
            string[] arr = Array.Empty<string>();
            string riskAssessment = string.Empty;
            if (!string.IsNullOrEmpty(value))
            {
                arr = value.Split('\n');
                if (arr.Any())
                {
                    riskAssessment = arr.LastOrDefault();
                }
            }

            return riskAssessment;
        }

        private bool disposed = false;
        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    _context.Dispose();
                }
            }
            this.disposed = true;
        }
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}
