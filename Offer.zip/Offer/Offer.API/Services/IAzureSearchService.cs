﻿using Offer.API.Models.OfferDTO;

namespace Offer.API.Services
{
    public interface IAzureSearchService
    {
        public AzureGlobalSearchResponseDTO AzureGlobalSearch();
    }
}
