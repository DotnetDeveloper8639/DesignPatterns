﻿
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Offer.API.DbContextClass;
using Offer.API.EntityModels;
using Offer.API.Models.OfferDTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;

namespace Offer.API.Services
{
    public class RoadMapService : RepositoryBase<TblRoadmapMaster>, IRoadMapService
    {
        private readonly Sch_Context _context;
        public IConfiguration _configuration { get; }

        public RoadMapService(Sch_Context context, IConfiguration configuration) : base(context)
        {
            _context = context;
            _configuration = configuration;

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="roadMaps"></param>
        /// <returns></returns>
        public ApiResponse<Dictionary<string, string>> SaveRoadMap(UploadRoadmapDTO roadMaps)
        {

            string result = "Failed to save data";
            List<TblTemplateRoadmapMaster> roadMapMasterList = new();
            List<TblTemplateRoadmapSection> roadMapSectionList = new();
            List<TblTemplateRoadmapSubSection> roadMapSubSectionList = new();
            List<TblTemplateRoadmapStep> stepMasterList = new();
            var apiresponse = new ApiResponse<Dictionary<string, string>>();
            var duplicateRoadmapStatus = new Dictionary<string, string>();
            TblLegislationsMedia reportMedia = new();
            apiresponse.StatusReason = result;
            try
            {
                for (var item = 0; item < roadMaps.RoadMap.Count; item++)
                {
                    TblTemplateRoadmapMaster roadMapMaster = new();
                    var duplicateRoadmap = _context.TblTemplateRoadmapMaster.Where(r => r.roadmap_name.Trim().ToLower() == roadMaps.RoadMap[item].RoadMapName.Trim().ToLower() && r.is_library == true).FirstOrDefault();
                    if (duplicateRoadmap == null)
                    {
                        Guid guidRoadMapId = Guid.NewGuid();

                        roadMapMaster.roadmap_id = Convert.ToString(guidRoadMapId);
                        roadMapMaster.roadmap_name = roadMaps.RoadMap[item].RoadMapName;
                        roadMapMaster.roadmap_version = roadMaps.RoadMap[item].RoadMapVersion;
                        roadMapMaster.description = roadMaps.RoadMap[item].Description;
                        roadMapMaster.is_library = true;
                        roadMapMaster.legislation_id = roadMaps.Legislations.Id;
                        roadMapMaster.created_at = DateTimeOffset.Now;
                        roadMapMaster.modified_at = DateTimeOffset.Now;
                        roadMapMaster.modified_by = "";
                        roadMapMaster.created_by = "";
                        _context.TblTemplateRoadmapMaster.Add(roadMapMaster);
                        _context.SaveChanges();
                        //roadMapMasterList.Add(roadMapMaster);
                        for (int i = 0; i < roadMaps.RoadMap[item].RoadMapSections.Count; i++)
                        {
                            TblTemplateRoadmapSection roadMapSection = new();
                            Guid roadMapSectionId = Guid.NewGuid();

                            roadMapSection.id = roadMapSectionId.ToString();
                            roadMapSection.roadmap_id = Convert.ToString(guidRoadMapId);
                            roadMapSection.section = roadMaps.RoadMap[item].RoadMapSections[i].SectionName;
                            roadMapSection.created_at = DateTimeOffset.Now;
                            roadMapSection.modified_at = DateTimeOffset.Now;
                            _context.TblTemplateRoadmapSection.Add(roadMapSection);
                            _context.SaveChanges();
                            //roadMapSectionList.Add(roadMapSection);

                            for (int j = 0; j < roadMaps.RoadMap[item].RoadMapSections[i].RoadMapSubSection.Count; j++)
                            {
                                TblTemplateRoadmapSubSection roadMapSubSection = new();
                                Guid roadMapSubSectionId = Guid.NewGuid();
                                roadMapSubSection.id = roadMapSubSectionId.ToString();
                                roadMapSubSection.section_id = roadMapSectionId.ToString();
                                roadMapSubSection.Sub_Section = roadMaps.RoadMap[item].RoadMapSections[i].RoadMapSubSection[j].SubSectionName;
                                roadMapSubSection.created_at = DateTimeOffset.Now;
                                roadMapSubSection.modified_at = DateTimeOffset.Now;
                                _context.TblTemplateRoadmapSubSection.Add(roadMapSubSection);
                                _context.SaveChanges();
                                //roadMapSubSectionList.Add(roadMapSubSection);

                                for (int k = 0; k < roadMaps.RoadMap[item].RoadMapSections[i].RoadMapSubSection[j].StepMaster.Count; k++)
                                {
                                    TblTemplateRoadmapStep stepMaster = new();
                                    Guid stepMasterId = Guid.NewGuid();
                                    stepMaster.step_id = stepMasterId.ToString();
                                    stepMaster.roadmap_section_id = roadMapSubSectionId.ToString();
                                    stepMaster.step_body = roadMaps.RoadMap[item].RoadMapSections[i].RoadMapSubSection[j].StepMaster[k].StepBody;
                                    stepMaster.created_at = DateTimeOffset.Now;
                                    stepMaster.modified_at = DateTimeOffset.Now;
                                    _context.TblTemplateRoadmapStep.Add(stepMaster);
                                    _context.SaveChanges();
                                    //stepMasterList.Add(stepMaster);

                                }
                            }
                        }

                        //_context.TblTemplateRoadmapMaster.AddRange(roadMapMasterList);
                        //_context.TblTemplateRoadmapSection.AddRange(roadMapSectionList);
                        //_context.TblTemplateRoadmapSubSection.AddRange(roadMapSubSectionList);
                        //_context.TblTemplateRoadmapStep.AddRange(stepMasterList);
                        //_context.SaveChanges();
                        apiresponse.StatusReason = "Data saved Successfully";
                        apiresponse.StatusCode = (int)System.Net.HttpStatusCode.OK;
                    }
                    //else
                    //{
                    //    var deletedata = DeleteRoadmapData(duplicateRoadmap.roadmap_id);
                    //    if (deletedata == true)
                    //    {
                    //        var roadmap = _context.TblTemplateRoadmapMaster.Where(r => r.roadmap_id == duplicateRoadmap.roadmap_id).FirstOrDefault();
                    //        if (roadmap!= null)
                    //        {
                    //            roadmap.description = roadMaps.RoadMap[item]?.Description ?? roadmap?.description;
                    //            roadmap.roadmap_version = roadMaps.RoadMap[item]?.RoadMapVersion ?? roadmap?.roadmap_version;
                    //            _context.TblTemplateRoadmapMaster.Update(roadmap);
                    //            _context.SaveChanges();
                    //        }
                    //        foreach (var sec in roadMaps.RoadMap[item].RoadMapSections)
                    //        {
                    //            TblTemplateRoadmapSection roadMapSection = new();
                    //            Guid roadMapSectionId = Guid.NewGuid();

                    //            roadMapSection.id = roadMapSectionId.ToString();
                    //            roadMapSection.roadmap_id = duplicateRoadmap?.roadmap_id;
                    //            roadMapSection.section = sec.SectionName;
                    //            roadMapSection.created_at = DateTimeOffset.Now;
                    //            roadMapSection.modified_at = DateTimeOffset.Now;
                    //            roadMapSectionList.Add(roadMapSection);
                    //            _context.TblTemplateRoadmapSection.Add(roadMapSection);
                    //            _context.SaveChanges();
                    //            foreach (var subsec in sec.RoadMapSubSection)
                    //            {
                    //                TblTemplateRoadmapSubSection roadMapSubSection = new();
                    //                Guid roadMapSubSectionId = Guid.NewGuid();
                    //                roadMapSubSection.id = roadMapSubSectionId.ToString();
                    //                roadMapSubSection.section_id = roadMapSectionId.ToString();
                    //                roadMapSubSection.Sub_Section = subsec.SubSectionName;
                    //                roadMapSubSection.created_at = DateTimeOffset.Now;
                    //                roadMapSubSection.modified_at = DateTimeOffset.Now;
                    //                roadMapSubSectionList.Add(roadMapSubSection);
                    //                _context.TblTemplateRoadmapSubSection.Add(roadMapSubSection);
                    //                _context.SaveChanges();
                    //                foreach (var step in subsec.StepMaster)
                    //                {
                    //                    TblTemplateRoadmapStep stepMaster = new();
                    //                    Guid stepMasterId = Guid.NewGuid();
                    //                    stepMaster.step_id = stepMasterId.ToString();
                    //                    stepMaster.roadmap_section_id = roadMapSubSectionId.ToString();
                    //                    stepMaster.step_body = step.StepBody;
                    //                    stepMaster.created_at = DateTimeOffset.Now;
                    //                    stepMaster.modified_at = DateTimeOffset.Now;
                    //                    _context.TblTemplateRoadmapStep.Add(stepMaster);
                    //                    _context.SaveChanges();
                    //                }
                    //            }
                    //        }
                    //        apiresponse.StatusReason = "Data Updated Successfully";
                    //        apiresponse.StatusCode = (int)System.Net.HttpStatusCode.OK;
                    //    }
                    //}

                    duplicateRoadmapStatus.Add(roadMaps.RoadMap[item].RoadMapName, "Duplicate Roadmap Name");
                }
                apiresponse.Data = duplicateRoadmapStatus;
                return apiresponse;
            }
            catch (Exception ex)
            {
                apiresponse.StatusReason = "Failed to save data";
                apiresponse.StatusCode = (int)System.Net.HttpStatusCode.InternalServerError;
                return apiresponse;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="roadMaps"></param>
        /// <returns></returns>
        public string SaveTemplateRoadMap(List<TemplateRoadmapDto> roadMaps)
        {

            string result = "Roadmap Already Existed";
            List<TblTemplateRoadmapMaster> roadMapMasterList = new();
            List<TblTemplateRoadmapSection> roadMapSectionList = new();
            List<TblTemplateRoadmapSubSection> roadMapSubSectionList = new();
            List<TblTemplateRoadmapStep> stepMasterList = new();

            try
            {

                for (var item = 0; item < roadMaps.Count; item++)
                {
                    var duplicateTemplateRM = _context.TblTemplateRoadmapMaster.Where(s => s.projectroadmap_id.Contains(roadMaps[item].ProjectRoadMapId)).FirstOrDefault();
                    var rmConfiguration = _context.TblMachineRoadmap.Where(m => m.roadmap_id == roadMaps[item].ProjectRoadMapId && m.service_machine_id == roadMaps[item].ServiceMachineId).FirstOrDefault();
                    if (duplicateTemplateRM == null)
                    {
                        TblTemplateRoadmapMaster roadMapMaster = new();
                        Guid guidRoadMapId = Guid.NewGuid();

                        roadMapMaster.roadmap_id = Convert.ToString(guidRoadMapId);
                        roadMapMaster.roadmap_name = roadMaps[item].RoadMapName;
                        roadMapMaster.roadmap_version = roadMaps[item].RoadMapVersion;
                        roadMapMaster.description = roadMaps[item].Description;
                        roadMapMaster.projectroadmap_id = roadMaps[item].ProjectRoadMapId;
                        roadMapMaster.is_library = false;
                        roadMapMaster.created_at = DateTimeOffset.Now;
                        roadMapMaster.modified_at = DateTimeOffset.Now;
                        roadMapMaster.modified_by = "";
                        roadMapMaster.created_by = "";
                        roadMapMasterList.Add(roadMapMaster);
                        if (rmConfiguration != null)
                        {
                            rmConfiguration.masteroadmap_id = roadMapMaster.roadmap_id;
                            _context.SaveChanges();
                        }
                        for (int i = 0; i < roadMaps[item].RoadMapSections.Count; i++)
                        {
                            TblTemplateRoadmapSection roadMapSection = new();
                            Guid roadMapSectionId = Guid.NewGuid();

                            roadMapSection.id = roadMapSectionId.ToString();
                            roadMapSection.roadmap_id = Convert.ToString(guidRoadMapId);
                            roadMapSection.section = roadMaps[item].RoadMapSections[i].SectionName;
                            roadMapSection.created_at = DateTimeOffset.Now;
                            roadMapSection.modified_at = DateTimeOffset.Now;
                            roadMapSectionList.Add(roadMapSection);

                            for (int j = 0; j < roadMaps[item].RoadMapSections[i].RoadMapSubSection.Count; j++)
                            {
                                TblTemplateRoadmapSubSection roadMapSubSection = new();
                                Guid roadMapSubSectionId = Guid.NewGuid();
                                roadMapSubSection.id = roadMapSubSectionId.ToString();
                                roadMapSubSection.section_id = roadMapSectionId.ToString();
                                roadMapSubSection.Sub_Section = roadMaps[item].RoadMapSections[i].RoadMapSubSection[j].SubSectionName;
                                roadMapSubSection.created_at = DateTimeOffset.Now;
                                roadMapSubSection.modified_at = DateTimeOffset.Now;
                                roadMapSubSectionList.Add(roadMapSubSection);

                                for (int k = 0; k < roadMaps[item].RoadMapSections[i].RoadMapSubSection[j].StepMaster.Count; k++)
                                {
                                    TblTemplateRoadmapStep stepMaster = new();
                                    Guid stepMasterId = Guid.NewGuid();
                                    stepMaster.step_id = stepMasterId.ToString();
                                    stepMaster.roadmap_section_id = roadMapSubSectionId.ToString();
                                    stepMaster.step_body = roadMaps[item].RoadMapSections[i].RoadMapSubSection[j].StepMaster[k].StepBody;
                                    stepMaster.created_at = DateTimeOffset.Now;
                                    stepMaster.modified_at = DateTimeOffset.Now;
                                    stepMasterList.Add(stepMaster);
                                }
                            }
                        }
                        _context.TblTemplateRoadmapMaster.AddRange(roadMapMasterList);
                        _context.TblTemplateRoadmapSection.AddRange(roadMapSectionList);
                        _context.TblTemplateRoadmapSubSection.AddRange(roadMapSubSectionList);
                        _context.TblTemplateRoadmapStep.AddRange(stepMasterList);
                        _context.SaveChanges();
                        result = "Data saved Successfully";
                    }
                    else
                    {
                        var deletedata = DeleteRoadmapData(duplicateTemplateRM.roadmap_id);
                        if (deletedata == true)
                        {
                            foreach (var road in roadMaps)
                            {
                                foreach (var sec in road.RoadMapSections)
                                {
                                    TblTemplateRoadmapSection roadMapSection = new();
                                    Guid roadMapSectionId = Guid.NewGuid();

                                    roadMapSection.id = roadMapSectionId.ToString();
                                    roadMapSection.roadmap_id = duplicateTemplateRM.roadmap_id;
                                    roadMapSection.section = sec.SectionName;
                                    roadMapSection.created_at = DateTimeOffset.Now;
                                    roadMapSection.modified_at = DateTimeOffset.Now;
                                    roadMapSectionList.Add(roadMapSection);
                                    foreach (var subsec in sec.RoadMapSubSection)
                                    {
                                        TblTemplateRoadmapSubSection roadMapSubSection = new();
                                        Guid roadMapSubSectionId = Guid.NewGuid();
                                        roadMapSubSection.id = roadMapSubSectionId.ToString();
                                        roadMapSubSection.section_id = roadMapSectionId.ToString();
                                        roadMapSubSection.Sub_Section = subsec.SubSectionName;
                                        roadMapSubSection.created_at = DateTimeOffset.Now;
                                        roadMapSubSection.modified_at = DateTimeOffset.Now;
                                        roadMapSubSectionList.Add(roadMapSubSection);
                                        foreach (var step in subsec.StepMaster)
                                        {
                                            TblTemplateRoadmapStep stepMaster = new();
                                            Guid stepMasterId = Guid.NewGuid();
                                            stepMaster.step_id = stepMasterId.ToString();
                                            stepMaster.roadmap_section_id = roadMapSubSectionId.ToString();
                                            stepMaster.step_body = step.StepBody;
                                            stepMaster.created_at = DateTimeOffset.Now;
                                            stepMaster.modified_at = DateTimeOffset.Now;
                                            stepMasterList.Add(stepMaster);
                                        }
                                    }
                                }
                                _context.TblTemplateRoadmapSection.AddRange(roadMapSectionList);
                                _context.TblTemplateRoadmapSubSection.AddRange(roadMapSubSectionList);
                                _context.TblTemplateRoadmapStep.AddRange(stepMasterList);
                                _context.SaveChanges();
                                result = "Data updated Successfully";
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                result = "Failed to save data";
            }

            return result;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public List<RoadMapMasterDTO> GetRoadMap()
        {
            try
            {
                var result = _context.TblTemplateRoadmapMaster.Select(roadMap =>
                                               new RoadMapMasterDTO
                                               {
                                                   RoadMapName = roadMap.roadmap_name,
                                                   RoadMapMasterId = roadMap.roadmap_id,
                                                   RoadMapVersion = roadMap.roadmap_version,
                                                   CreatedAt = roadMap.created_at,
                                                   RoadMapSections = _context.TblTemplateRoadmapSection.Where(section => roadMap.roadmap_id == section.roadmap_id).Select(sect => new RoadMapSectionDTO
                                                   {
                                                       RoadMapMasterId = sect.roadmap_id,
                                                       RoadMapSectionId = sect.id,
                                                       SectionName = sect.section,
                                                       Created_At = sect.created_at,
                                                       RoadMapSubSection = _context.TblTemplateRoadmapSubSection.Where(sub => sect.id == sub.section_id).Select(subsection => new RoadMapSubSectionDTO
                                                       {
                                                           SubSectionName = subsection.Sub_Section,
                                                           RoadMapSubSectionId = subsection.id,
                                                           Created_At = subsection.created_at,
                                                           StepMaster = _context.TblTemplateRoadmapStep.Where(step => step.roadmap_section_id == subsection.id).Select(step1 => new StepMasterDTO
                                                           {
                                                               StepMasterId = step1.step_id,
                                                               StepBody = step1.step_body,
                                                               Created_At = step1.created_at
                                                           }).OrderBy(s => s.Created_At).ToList()
                                                       }).OrderBy(s => s.Created_At).ToList()
                                                   }).OrderBy(s => s.Created_At).ToList()
                                               }).OrderByDescending(x => x.CreatedAt).ToList();
                return result;
            }
            catch (Exception ex)
            {

                throw;
            }


        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="roadmapId"></param>
        /// <returns></returns>
        public async Task<List<RoadMapMasterDTO>> GetRoadMap(string roadmapId)
        {
            try
            {
                var result = await _context.TblTemplateRoadmapMaster.Where(r => r.roadmap_id == roadmapId).Select(roadMap =>
                                                new RoadMapMasterDTO
                                                {
                                                    RoadMapName = roadMap.roadmap_name,
                                                    RoadMapMasterId = roadMap.roadmap_id,
                                                    RoadMapVersion = roadMap.roadmap_version,
                                                    CreatedAt = roadMap.created_at,
                                                    RoadMapSections = _context.TblTemplateRoadmapSection.Where(section => roadMap.roadmap_id == section.roadmap_id).Select(sect => new RoadMapSectionDTO
                                                    {
                                                        RoadMapMasterId = sect.roadmap_id,
                                                        RoadMapSectionId = sect.id,
                                                        SectionName = sect.section,
                                                        Created_At = sect.created_at,
                                                        RoadMapSubSection = _context.TblTemplateRoadmapSubSection.Where(sub => sect.id == sub.section_id).Select(subsection => new RoadMapSubSectionDTO
                                                        {
                                                            SubSectionName = subsection.Sub_Section,
                                                            RoadMapSubSectionId = subsection.id,
                                                            Created_At = subsection.created_at,
                                                            StepMaster = _context.TblTemplateRoadmapStep.Where(step => step.roadmap_section_id == subsection.id).Select(step1 => new StepMasterDTO
                                                            {
                                                                StepMasterId = step1.step_id,
                                                                Created_At = step1.created_at,
                                                                StepBody = step1.step_body
                                                            }).OrderBy(s => s.Created_At).ToList()
                                                        }).OrderBy(s => s.Created_At).ToList()
                                                    }).OrderBy(s => s.Created_At).ToList()
                                                }).OrderByDescending(x => x.CreatedAt).ToListAsync();
                return result;
            }
            catch (Exception ex)
            {

                throw;
            }


        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public List<RoadMapMasterDTO> GetCustomTemplateRoadMap()
        {
            try
            {
                var result = _context.TblTemplateRoadmapMaster.Where(t => t.is_library == false).Select(roadMap =>
                                                new RoadMapMasterDTO
                                                {
                                                    RoadMapName = roadMap.roadmap_name,
                                                    RoadMapMasterId = roadMap.roadmap_id,
                                                    RoadMapVersion = roadMap.roadmap_version,
                                                    CreatedAt = roadMap.created_at
                                                }).OrderByDescending(x => x.CreatedAt).ToList();
                return result;
            }
            catch (Exception ex)
            {

                throw;
            }


        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public List<RoadMapMasterDTO> GetPredefinedTemplateRoadMap()
        {
            try
            {
                var result = _context.TblTemplateRoadmapMaster.Where(t => t.is_library == true).Select(roadMap =>
                                                new RoadMapMasterDTO
                                                {
                                                    RoadMapName = roadMap.roadmap_name,
                                                    RoadMapMasterId = roadMap.roadmap_id,
                                                    RoadMapVersion = roadMap.roadmap_version,
                                                    CreatedAt = roadMap.created_at
                                                }).OrderByDescending(x => x.CreatedAt).ToList();
                return result;
            }
            catch (Exception ex)
            {

                throw;
            }


        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="roadmap"></param>
        /// <returns></returns>
        public async Task<string> UpdateLibraryRoadmap(EditPredefinedRoadmapDto roadmap)
        {
            string isSuccess = "Failed to update";
            try
            {
                var roadmapDetails = _context.TblTemplateRoadmapMaster.Where(r => r.roadmap_id == roadmap.RoadMapMasterId).FirstOrDefault();
                if (roadmapDetails != null)
                {
                    roadmapDetails.roadmap_name = roadmap.RoadMapName?? roadmapDetails.roadmap_name;
                    foreach (var section in roadmap.RoadMapSection)
                    {
                        if (section.RoadMapSectionId != null && section.IsEdit == true)
                        {
                            var sectionDetails = _context.TblTemplateRoadmapSection.Where(s => s.id == section.RoadMapSectionId).FirstOrDefault();
                            sectionDetails.section = section.SectionName;
                            _context.TblTemplateRoadmapSection.Update(sectionDetails);
                            _context.SaveChanges();
                            for (int sub = 0; sub < section.RoadMapSubSection.Count; sub++)
                            {
                                if (section.RoadMapSubSection[sub].RoadMapSubSectionId != null && section.RoadMapSubSection[sub].IsEdit == true)
                                {
                                    var subSectionDetails = _context.TblTemplateRoadmapSubSection.Where(s => s.id == section.RoadMapSubSection[sub].RoadMapSubSectionId).FirstOrDefault();
                                    if (subSectionDetails != null)
                                    {
                                        subSectionDetails.Sub_Section = section.RoadMapSubSection[sub].SubSectionName ?? subSectionDetails.Sub_Section;
                                        _context.TblTemplateRoadmapSubSection.Update(subSectionDetails);
                                        _context.SaveChanges();
                                        for (int i = 0; i < section.RoadMapSubSection[sub].StepMaster.Count; i++)
                                        {
                                            if (section.RoadMapSubSection[sub].StepMaster[i].IsEdit == true && section.RoadMapSubSection[sub].StepMaster[i].StepMasterId != null)
                                            {
                                                var stepDetails = _context.TblTemplateRoadmapStep.Where(stp => stp.step_id == section.RoadMapSubSection[sub].StepMaster[i].StepMasterId).FirstOrDefault();
                                                if (stepDetails != null)
                                                {
                                                    stepDetails.step_body = section.RoadMapSubSection[sub].StepMaster[i].StepBody;
                                                    _context.TblTemplateRoadmapStep.Update(stepDetails);
                                                    _context.SaveChanges();
                                                }
                                            }
                                            else
                                            {
                                                TblTemplateRoadmapStep stepMaster = new();
                                                Guid stepMasterId = Guid.NewGuid();
                                                stepMaster.step_id = stepMasterId.ToString();
                                                stepMaster.roadmap_section_id = section.RoadMapSubSection[sub].RoadMapSubSectionId;
                                                stepMaster.step_body = section.RoadMapSubSection[sub].StepMaster[i].StepBody;
                                                stepMaster.created_at = DateTimeOffset.Now;
                                                stepMaster.modified_at = DateTimeOffset.Now;
                                                _context.TblTemplateRoadmapStep.Add(stepMaster);
                                                _context.SaveChanges();
                                            }
                                        }
                                    }
                                }
                                else
                                {
                                    TblTemplateRoadmapSubSection roadMapSubSection = new();
                                    Guid roadMapSubSectionId = Guid.NewGuid();
                                    roadMapSubSection.id = roadMapSubSectionId.ToString();
                                    roadMapSubSection.section_id = section.RoadMapSectionId;
                                    roadMapSubSection.id = Guid.NewGuid().ToString();
                                    roadMapSubSection.Sub_Section = section.RoadMapSubSection[sub].SubSectionName;
                                    roadMapSubSection.created_at = DateTimeOffset.Now;
                                    roadMapSubSection.modified_at = DateTimeOffset.Now;
                                    _context.TblTemplateRoadmapSubSection.Add(roadMapSubSection);
                                    _context.SaveChanges();
                                    foreach (var step in section.RoadMapSubSection[sub].StepMaster)
                                    {
                                        TblTemplateRoadmapStep stepMaster = new();
                                        Guid stepMasterId = Guid.NewGuid();
                                        stepMaster.step_id = stepMasterId.ToString();
                                        stepMaster.roadmap_section_id = roadMapSubSectionId.ToString();
                                        stepMaster.step_body = step.StepBody;
                                        stepMaster.created_at = DateTimeOffset.Now;
                                        stepMaster.modified_at = DateTimeOffset.Now;
                                        _context.TblTemplateRoadmapStep.Add(stepMaster);
                                        _context.SaveChanges();
                                    };
                                }

                            }
                        }
                        else
                        {
                            TblTemplateRoadmapSection roadMapSection = new();
                            Guid roadMapSectionId = Guid.NewGuid();

                            roadMapSection.id = roadMapSectionId.ToString();
                            roadMapSection.roadmap_id = Convert.ToString(roadmap.RoadMapMasterId);
                            roadMapSection.section = section.SectionName;
                            roadMapSection.created_at = DateTimeOffset.Now;
                            roadMapSection.modified_at = DateTimeOffset.Now;
                            _context.TblTemplateRoadmapSection.Add(roadMapSection);
                            _context.SaveChanges();
                            foreach (var subsec in section.RoadMapSubSection)
                            {
                                TblTemplateRoadmapSubSection roadMapSubSection = new();
                                Guid roadMapSubSectionId = Guid.NewGuid();
                                roadMapSubSection.id = roadMapSubSectionId.ToString();
                                roadMapSubSection.section_id = roadMapSectionId.ToString();
                                roadMapSubSection.Sub_Section = subsec.SubSectionName;
                                roadMapSubSection.created_at = DateTimeOffset.Now;
                                roadMapSubSection.modified_at = DateTimeOffset.Now;
                                _context.TblTemplateRoadmapSubSection.Add(roadMapSubSection);
                                _context.SaveChanges();
                                foreach (var step in subsec.StepMaster)
                                {
                                    TblTemplateRoadmapStep stepMaster = new();
                                    Guid stepMasterId = Guid.NewGuid();
                                    stepMaster.step_id = stepMasterId.ToString();
                                    stepMaster.roadmap_section_id = roadMapSubSectionId.ToString();
                                    stepMaster.step_body = step.StepBody;
                                    stepMaster.created_at = DateTimeOffset.Now;
                                    stepMaster.modified_at = DateTimeOffset.Now;
                                    _context.TblTemplateRoadmapStep.Add(stepMaster);
                                    _context.SaveChanges();
                                }
                            }
                        }
                    }
                    await _context.SaveChangesAsync();
                    isSuccess = "Roadmap Updated Successfully";
                }
            }
            catch (Exception)
            {

                throw;
            }
            return isSuccess;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="UserId"></param>
        /// <returns></returns>
        public List<TblLibrary> GetLibrary(string UserId)
        {
            var result = (from library in _context.TblLibrary
                          join bookMark in _context.TblBookmarks
                          on library.id equals bookMark.library_id
                          where bookMark.user_id == UserId
                          orderby library.created_at descending
                          select library
                          ).ToList();
            return result;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="libraryId"></param>
        /// <returns></returns>
        public string DeleteBookMark(string[] libraryId)
        {
            string result = string.Empty;
            try
            {
                string bookMarkQuery = string.Format("DELETE FROM [dbo].[tblBookmarks] where library_id IN ('{0}')", string.Join("','", libraryId));
                string libraryQuery = string.Format("DELETE FROM [dbo].[tbllibrary] where Id  IN ('{0}')", string.Join("','", libraryId));

                _context.Database.ExecuteSqlRaw(bookMarkQuery);
                int i = _context.Database.ExecuteSqlRaw(libraryQuery);
                if (i > 0)
                {
                    result = "Bookmark deleted successfully";
                }
                else
                {
                    result = "Bookmark delete failed";
                }
            }
            catch (Exception ex)
            {

                throw ex;
            }

            return result;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="listLibrary"></param>
        /// <param name="userId"></param>
        /// <returns></returns>
        public string CreateLibrary(List<LibraryDTO> listLibrary, string userId)
        {
            string result = string.Empty;
            string machineExist = string.Empty;
            List<TblLibrary> list = new List<TblLibrary>();
            List<TblBookmarks> listBookMark = new List<TblBookmarks>();

            foreach (var item in listLibrary)
            {

                Guid libraryId = Guid.NewGuid();
                Guid bookMarkId = Guid.NewGuid();
                TblLibrary library = new TblLibrary()
                {
                    id = libraryId.ToString(),
                    name = item.Name,
                    content_type = item.ContentType,
                    url = item.Url,
                    version = item.Version,
                    preview_image_url = item.PreviewImageUrl,
                    type = item.Type,
                    item_id = item?.ItemId ?? null,
                    drive_id = item?.DriveId ?? null,
                    created_at = DateTimeOffset.Now,
                    modified_at = DateTimeOffset.Now
                };
                TblBookmarks tblBookmarks = new TblBookmarks()
                {
                    id = bookMarkId.ToString(),
                    user_id = userId,
                    library_id = libraryId.ToString(),
                    created_at = DateTimeOffset.Now,
                    modified_at = DateTimeOffset.Now
                };
                listBookMark.Add(tblBookmarks);
                list.Add(library);


                result = "Bookmark added successfully";
            }
            _context.TblLibrary.AddRange(list);
            _context.TblBookmarks.AddRange(listBookMark);
            _context.SaveChanges();

            return result;

        }

        #region Custom_Roadmap_Creation
        /// <summary>
        /// 
        /// </summary>
        /// <param name="roadmaps"></param>
        /// <returns></returns>
        public string CustomRoadmap(List<RoadmapDTO> roadmaps)
        {
            var isSuccess = "Failed to create Custom Roadmap";
            try
            {
                if (roadmaps?.Count > 0)
                {
                    foreach (var roadmap in roadmaps)
                    {
                        TblRoadmapMaster roadMapMaster = new TblRoadmapMaster();
                        Guid guidRoadMapId = Guid.NewGuid();

                        roadMapMaster.roadmap_id = Convert.ToString(guidRoadMapId);
                        roadMapMaster.roadmap_name = roadmap.RoadMapName;
                        roadMapMaster.roadmap_version = roadmap.RoadMapVersion;
                        roadMapMaster.description = roadmap.Description;
                        roadMapMaster.iscustom = roadmap.IsCustom;
                        _context.TblRoadmapMaster.Add(roadMapMaster);
                        _context.SaveChanges();
                    }
                    isSuccess = "Create Custom Roadmap Successful";
                }
                return isSuccess;
            }
            catch (Exception ex)
            {

                return isSuccess;
            }


        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="sections"></param>
        /// <returns></returns>
        public string CustomSection(List<SectionMasterDTO> sections)
        {
            var isSuccess = "Failed to create Custom Section";
            if (sections?.Count > 0)
            {
                foreach (var section in sections)
                {
                    TblRoadmapSection roadMapSection = new TblRoadmapSection();
                    Guid roadMapSectionId = Guid.NewGuid();

                    roadMapSection.id = roadMapSectionId.ToString();
                    roadMapSection.roadmap_id = section.RoadMapMasterId;
                    roadMapSection.section = section.SectionName;


                    _context.TblRoadmapSection.Add(roadMapSection);
                    _context.SaveChanges();
                }
                isSuccess = "Create Custom Section Successful";
            }
            return isSuccess;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="steps"></param>
        /// <returns></returns>
        public string CustomStep(List<StepMasterDTO> steps)
        {
            var isSuccess = "Failed to create Custom Step";
            if (steps?.Count > 0)
            {
                foreach (var step in steps)
                {
                    TblStepMaster stepMaster = new TblStepMaster();
                    Guid stepMasterId = Guid.NewGuid();
                    stepMaster.step_id = stepMasterId.ToString();
                    stepMaster.roadmap_section_id = step.RoadMapSubSectionId;
                    stepMaster.step_body = step.StepBody;



                    _context.TblStepMaster.Add(stepMaster);
                    _context.SaveChanges();
                }
                isSuccess = "create Custom Step Successful";
            }
            return isSuccess;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="subSections"></param>
        /// <returns></returns>
        public string CustomSubSection(List<SubSectionMasterDTO> subSections)
        {
            var isSuccess = "Failed to create Custom SubSection";
            if (subSections?.Count > 0)
            {
                foreach (var subSection in subSections)
                {
                    TblRoadmapSubSectionMster subSectionMster = new TblRoadmapSubSectionMster();
                    Guid roadMapSubSectionId = Guid.NewGuid();
                    subSectionMster.id = roadMapSubSectionId.ToString();
                    subSectionMster.Sub_Section = subSection.SubSectionName;
                    subSectionMster.section_id = subSection.RoadMapSectionId;

                    _context.TblRoadmapSubSectionMster.Add(subSectionMster);
                    _context.SaveChanges();
                }
                isSuccess = "create Custom SubSection Successful";
            }
            return isSuccess;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="listHazard"></param>
        /// <returns></returns>

        public string InitialHazard(List<InitialHazardMasterDTO> listHazard)
        {

            List<TblInitialHazardsMaster> list = new List<TblInitialHazardsMaster>();
            string isSuccess = "Initial Hazard added to the library successfully";
            try
            {
                foreach (var item in listHazard)
                {
                    TblInitialHazardsMaster hazard = new TblInitialHazardsMaster();
                    Guid hazardId = Guid.NewGuid();
                    hazard.id = hazardId.ToString();
                    hazard.value = item.Value;
                    hazard.user_id = item.UserId;
                    hazard.created_at = DateTimeOffset.Now;
                    hazard.modified_at = DateTimeOffset.Now;
                    list.Add(hazard);
                }

                _context.TblInitialHazardsMaster.AddRange(list);
                _context.SaveChanges();
            }
            catch (Exception ex)
            {
                Console.Write(ex);
                return isSuccess = "Create intialhazard failed";
            }

            return isSuccess;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="counterMeasure"></param>
        /// <returns></returns>
        public string CounterMeasure(List<CounterMeasureDTO> counterMeasure)
        {

            List<TblCounterMeasures> list = new List<TblCounterMeasures>();
            string isSuccess = "Control Measure added to the library successfully";
            try
            {
                foreach (var item in counterMeasure)
                {
                    TblCounterMeasures obj = new TblCounterMeasures();
                    Guid counterId = Guid.NewGuid();
                    obj.id = counterId.ToString();
                    obj.value = item.Value;
                    obj.user_id = item.UserId;
                    obj.created_at = DateTimeOffset.Now;
                    obj.modified_at = DateTimeOffset.Now;
                    list.Add(obj);
                }

                _context.TblCounterMeasures.AddRange(list);
                _context.SaveChanges();
            }
            catch (Exception ex)
            {
                Console.Write(ex);
                return isSuccess = "Create counter measeure failed";
            }

            return isSuccess;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public List<InitialHazardMasterDTO> InitialHazard(string userId)
        {
            List<InitialHazardMasterDTO> list = null;
            try
            {
                if (userId != null && userId != string.Empty)
                {
                    list = new List<InitialHazardMasterDTO>();
                    list = (from hazard in _context.TblInitialHazardsMaster
                            where hazard.user_id == userId
                            orderby hazard.created_at descending
                            select new InitialHazardMasterDTO
                            {
                                UserId = hazard.user_id,
                                Id = hazard.id,
                                Value = hazard.value
                            }).ToList();
                }
            }
            catch (Exception)
            {

                throw;
            }
            return list;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public List<CounterMeasureDTO> CounterMeasure(string userId)
        {
            List<CounterMeasureDTO> list = null;
            try
            {
                if (userId != null && userId != string.Empty)
                {
                    list = new List<CounterMeasureDTO>();
                    list = (from measure in _context.TblCounterMeasures
                            where measure.user_id == userId
                            orderby measure.created_at descending
                            select new CounterMeasureDTO
                            {
                                UserId = measure.user_id,
                                Id = measure.id,
                                Value = measure.value
                            }).ToList();
                }
            }
            catch (Exception)
            {

                throw;
            }
            return list;
        }
        #endregion
        /// <summary>
        /// 
        /// </summary>
        /// <param name="HazardMachineId"></param>
        /// <returns></returns>
        public MachineHazardDTO GetHazardMachineById(string HazardMachineId)
        {

            var result = (from hazard in _context.TblMachineHazards
                          where hazard.id == HazardMachineId
                          select new MachineHazardDTO
                          {
                              Id = hazard.id,
                              initial_hazard = hazard.initial_hazard,
                              name = hazard.name,
                              version = hazard.version,
                              counter_measure = hazard.counter_measure,
                              HazardType = (from type in _context.TblHazardType
                                            where type.hazard_id == hazard.id
                                            select new HazardTypeDTO
                                            {
                                                HazardTypeId = type.id,
                                                HazardTypeName = type.type
                                            }).FirstOrDefault(),
                              PerformanceHazardLevel = (from level in _context.TblPerformanceLevelRating
                                                        where level.machine_hazard_id == hazard.id
                                                        select new PerformanceHazardLevelDTO
                                                        {
                                                            PerformanceHazardLevelId = level.id,
                                                            Category = level.category,
                                                            PLR = level.PLR
                                                        }).ToList(),
                              HazardMedia = (from media in _context.TblHazardMedia
                                             where media.machine_hazard_id == hazard.id
                                             select new HazardMediaDTO
                                             {
                                                 URL = media.url,
                                                 Type = media.type
                                             }).ToList(),
                              HRNCalculations = (from hrn in _context.TblHRNCalculations
                                                 where hrn.machine_hazard_id == hazard.id
                                                 select new HRNCalculationsDTO
                                                 {
                                                     PO = hrn.PO,
                                                     NP = hrn.NP,
                                                     SD = hrn.SD,
                                                     FE = hrn.FE,
                                                     Type = hrn.type,
                                                     Version = hrn.version,
                                                     Rating = hrn.rating,
                                                     Modes = (from mode in _context.TblModes
                                                              where mode.id == hrn.modes
                                                              select new ModesDTO
                                                              {
                                                                  Id = mode.id,
                                                                  ModeName = mode.mode_name
                                                              }).ToList()
                                                 }).ToList(),
                              HazardSource = (from source in _context.TblHazardSource
                                              where source.hazard_type_id == hazard.hazard_type_id
                                              select new HazardSourceDTO
                                              {
                                                  Id = source.id,
                                                  Source = source.source
                                              }).ToList(),
                              HazardConsequences = (from source in _context.TblHazardConsequences
                                                    where source.hazard_type_id == hazard.hazard_type_id
                                                    select new HazardConsequenceDTO
                                                    {
                                                        Id = source.id,
                                                        Consequences = source.consequence
                                                    }).ToList()
                          }).FirstOrDefault();
            return result;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="roadmapId"></param>
        /// <returns></returns>
        public bool DeleteRoadmapData(string roadmapId)
        {
            try
            {
                bool isSuccess = false;
                if (roadmapId != null)
                {
                    var sectionList = _context.TblTemplateRoadmapSection.Where(s => s.roadmap_id == roadmapId).ToList();
                    foreach (var sec in sectionList)
                    {
                        var subSecList = _context.TblTemplateRoadmapSubSection.Where(sub => sub.section_id == sec.id).ToList();
                        foreach (var subsec in subSecList)
                        {
                            var stepList = _context.TblTemplateRoadmapStep.Where(stp => stp.roadmap_section_id == subsec.id).ToList();

                            if (stepList != null)
                            {
                                _context.TblTemplateRoadmapStep.RemoveRange(stepList);
                                _context.SaveChanges();
                                isSuccess = true;
                            }
                        }
                        if (subSecList != null)
                        {
                            _context.TblTemplateRoadmapSubSection.RemoveRange(subSecList);
                            _context.SaveChanges();
                            isSuccess = true;
                        }
                    }
                    if (sectionList != null)
                    {
                        _context.TblTemplateRoadmapSection.RemoveRange(sectionList);
                        _context.SaveChanges();
                        isSuccess = true;
                    }
                }
                return isSuccess;
            }
            catch (Exception)
            {

                throw;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="roadmapId"></param>
        /// <returns></returns>
        public async Task<string> DeleteTemplateRoadmap(DeleteRoadmapFile roadmap)
        {
            string isSuccess = "No Records Found";
            try
            {
                if (roadmap.Type.ToLower() == "roadmap")
                {
                    var roadmapData = _context.TblTemplateRoadmapMaster.Where(r => r.roadmap_id == roadmap.Id && r.is_library == true).FirstOrDefault();

                    var sectionList = _context.TblTemplateRoadmapSection.Where(s => s.roadmap_id == roadmap.Id).ToList();
                    foreach (var sec in sectionList)
                    {
                        var subSecList = _context.TblTemplateRoadmapSubSection.Where(sub => sub.section_id == sec.id).ToList();
                        foreach (var subsec in subSecList)
                        {
                            var stepList = _context.TblTemplateRoadmapStep.Where(stp => stp.roadmap_section_id == subsec.id).ToList();

                            if (stepList != null)
                            {
                                _context.TblTemplateRoadmapStep.RemoveRange(stepList);
                                _context.SaveChanges();
                            }
                        }
                        if (subSecList != null)
                        {
                            _context.TblTemplateRoadmapSubSection.RemoveRange(subSecList);
                            _context.SaveChanges();
                        }
                    }
                    if (sectionList != null)
                    {
                        _context.TblTemplateRoadmapSection.RemoveRange(sectionList);
                        _context.SaveChanges();
                    }
                    _context.TblTemplateRoadmapMaster.Remove(roadmapData);
                    _context.SaveChanges();
                    isSuccess = "Roadmap Deleted Successfully";
                }
                if (roadmap.Type.ToLower() == "section")
                {
                    var section = _context.TblTemplateRoadmapSection.Where(s => s.id == roadmap.Id).FirstOrDefault();

                    var subSecList = _context.TblTemplateRoadmapSubSection.Where(sub => sub.section_id == section.id).ToList();
                    foreach (var subsec in subSecList)
                    {

                        var stepList = _context.TblTemplateRoadmapStep.Where(stp => stp.roadmap_section_id == subsec.id).ToList();

                        if (stepList != null)
                        {
                            _context.TblTemplateRoadmapStep.RemoveRange(stepList);
                            _context.SaveChanges();

                        }
                    }
                    if (subSecList != null)
                    {
                        _context.TblTemplateRoadmapSubSection.RemoveRange(subSecList);
                        _context.SaveChanges();
                    }
                    _context.TblTemplateRoadmapSection.Remove(section);
                    _context.SaveChanges();
                    isSuccess = "Roadmap Section Deleted Successfully";
                }
                if (roadmap.Type.ToLower() == "subsection")
                {
                    var subSec = _context.TblTemplateRoadmapSubSection.Where(sub => sub.id == roadmap.Id).FirstOrDefault();
                    if (subSec != null)
                    {
                        var stepList = _context.TblTemplateRoadmapStep.Where(stp => stp.roadmap_section_id == subSec.id).ToList();

                        if (stepList != null)
                        {
                            _context.TblTemplateRoadmapStep.RemoveRange(stepList);
                            _context.SaveChanges();
                            isSuccess = "Deleted";
                        }
                        _context.TblTemplateRoadmapSubSection.Remove(subSec);
                        _context.SaveChanges();
                        isSuccess = "Roadmap SubSection Deleted Successfully";
                    }
                }
                if (roadmap.Type.ToLower() == "step")
                {
                    var step = _context.TblTemplateRoadmapStep.Where(sp => sp.step_id == roadmap.Id).FirstOrDefault();
                    if (step != null)
                    {
                        _context.TblTemplateRoadmapStep.Remove(step);
                        _context.SaveChanges();
                        isSuccess = "Roadmap Step Deleted Successfully";
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }
            return isSuccess;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="tblSiteDetails"></param>
        /// <returns></returns>
        public async Task<string> SaveSiteDetails(TblSiteDetails tblSiteDetails)
        {
            string isSuccess = "Site Details Failed to Save";
            try
            {
                var siteDuplicate = _context.TblSiteDetails.Where(s => s.sitename.ToLower() == tblSiteDetails.sitename.ToLower()).FirstOrDefault();
                if (siteDuplicate == null)
                {
                    TblSiteDetails tblSite = new();
                    tblSite.id = Guid.NewGuid().ToString();
                    tblSite.sitename = tblSiteDetails?.sitename;
                    tblSite.itemid = tblSiteDetails?.sitename;
                    tblSite.siteid = tblSiteDetails?.siteid;
                    tblSite.driveid = tblSiteDetails?.driveid;
                    tblSite.project_id = tblSiteDetails?.project_id;
                    tblSite.erp_project_id = tblSiteDetails?.erp_project_id;
                    tblSite.created_at = DateTimeOffset.UtcNow;
                    tblSite.modified_at = DateTimeOffset.UtcNow;
                    _context.TblSiteDetails.Add(tblSite);
                    _context.SaveChanges();
                    isSuccess = "Site Details Saved";
                }
                return isSuccess;
            }
            catch (Exception ex)
            {
                return isSuccess;
                throw;
            }
        }
        public async Task<List<TblSiteDetails>> GetSiteDetails(string siteName)
        {
            try
            {
                var siteDetails = _context.TblSiteDetails.Where(s => s.sitename.ToLower() == siteName.ToLower()).ToList();
                return siteDetails;
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
