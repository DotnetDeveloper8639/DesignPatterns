﻿using Offer.API.EntityModels;
using Offer.API.Models.OfferDTO;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Offer.API.Services
{
    public interface IOpportunityService : IRepositoryBase<TblOpportunity>
    {
        Task<List<OpportunityDTO>> GetOpportunityByProjectId(string projectId);
        Task<List<OpportunityDTO>> GetOpportunities();
    }
}
