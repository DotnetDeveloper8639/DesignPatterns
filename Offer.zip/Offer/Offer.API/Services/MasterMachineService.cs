﻿using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Offer.API.DbContextClass;
using Offer.API.EntityModels;
using Offer.API.Extensions;
using Offer.API.Helper;
using Offer.API.Models.OfferDTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;

namespace Offer.API.Services
{
    public class MasterMachineService : RepositoryBase<TblMasterMachine>, IMasterMachineService
    {
        private readonly Sch_Context _context;
        private readonly IHttpContextAccessor httpContextAccessor;
        private static object lockObject = new object();
        public MasterMachineService(Sch_Context context
            , IHttpContextAccessor _httpContextAccessor) : base(context)
        {
            _context = context;
            httpContextAccessor = _httpContextAccessor;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="search"></param>
        /// <param name="count"></param>
        /// <param name="increasedCount"></param>
        /// <returns></returns>
        public async Task<List<GetMachineDto>> GetFilteredMasterMachineDetails(SearchMachineDto searchMachineDto)
        {
            var machineDetails = new List<GetMachineDto>();
            try
            {
                //Get all machines as per the filter
                var machines = await (from application1 in _context.TblMachineApplication
                                      join application in _context.TblApplication on application1.application_id equals application.application
                                      join machine in _context.TblMachines on application1.machine_id equals machine.id into machine1
                                      from machine2 in machine1.DefaultIfEmpty()
                                      join cus in _context.TblMachineCustomerAssociation on machine2.id equals cus.machine_id
                                      join machine_images in _context.TblMachineImages on machine2.id equals machine_images.machine_id into machine_images1
                                      from machine_images2 in machine_images1.Where(it => it.is_primary == true).DefaultIfEmpty()
                                      where machine2.id != null && machine2.is_delete == false
                                      select new GetMachineDto
                                      {
                                          Id = machine2.id,
                                          Machine_Name = machine2.machine_name,
                                          Asset_Number = machine2.asset_id,
                                          Serial_Number = machine2.serial_number,
                                          Machine_Type = machine2.machine_type,
                                          Description = machine2.machine_description,
                                          Global_Id = machine2.global_id,
                                          IsDelete = machine2.is_delete,
                                          Application = application.application,
                                          Customer_Id = cus.customer_id,
                                          Thumbnail_Url = string.IsNullOrEmpty(machine_images2.thumbnail_url) ? string.Empty : machine_images2.thumbnail_url
                                      }).ToListAsync();

                if (!string.IsNullOrEmpty(searchMachineDto.Search))
                {
                    machines = machines.Where(it => it.Machine_Name.ToLower().Contains(searchMachineDto.Search.ToLower())).ToList();                    
                }

                machineDetails.AddRange(machines);

                switch (searchMachineDto is not null)
                {
                    case var _ when searchMachineDto.FilterSearch.Count > 0:                    
                        foreach (var item in searchMachineDto.FilterSearch)
                        {
                            if (item is not null && !string.IsNullOrEmpty(item.Field))
                            {                                
                              machineDetails = BuildFilterExpression(machineDetails, item, searchMachineDto.Search).Skip(searchMachineDto.IncreasedCount).Take(searchMachineDto.Count).ToList();
                            }
                        }
                        break;
                    case var _ when searchMachineDto.FilterSearch.Count == 0:
                    default:
                        machineDetails = machineDetails.Skip(searchMachineDto.IncreasedCount).Take(searchMachineDto.Count).ToList();
                        break;              
                }
                return machineDetails;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="search"></param>
        /// <param name="count"></param>
        /// <param name="increasedCount"></param>
        /// <returns></returns>
        public async Task<List<GetMachineDto>> GetMasterMachineDetails(string search, int count, int increasedCount)
        {
            var machineDetails = new List<GetMachineDto>();
            try
            {
                if (!string.IsNullOrEmpty(search))
                {
                    var applications = await (from application1 in _context.TblMachineApplication
                                              join application in _context.TblApplication on application1.application_id equals application.application
                                              join machine in _context.TblMachines on application1.machine_id equals machine.id into machine1
                                              from machine2 in machine1.DefaultIfEmpty()
                                              join cus in _context.TblMachineCustomerAssociation on machine2.id equals cus.machine_id
                                              where machine2.machine_name.Contains(search) || application.application.Contains(search) && machine2.id != null
                                              select new GetMachineDto
                                              {
                                                  Id = machine2.id,
                                                  Machine_Name = machine2.machine_name,
                                                  Asset_Number = machine2.asset_id,
                                                  Serial_Number = machine2.serial_number,
                                                  Machine_Type = machine2.machine_type,
                                                  Description = machine2.machine_description,
                                                  Global_Id = machine2.global_id,
                                                  IsDelete = machine2.is_delete,
                                                  Customer_Id = cus.customer_id
                                              }).Skip(increasedCount).Take(count).ToListAsync();
                    var machineType = await (from machineType1 in _context.TblMachineTypeAssociation
                                             join machinetype in _context.TblMachineType on machineType1.machinetype_id equals machinetype.machine_type
                                             join machine in _context.TblMachines on machineType1.machine_id equals machine.id into machine1
                                             from machine2 in machine1.DefaultIfEmpty()
                                             join cus in _context.TblMachineCustomerAssociation on machine2.id equals cus.machine_id
                                             where machine2.machine_name.Contains(search) || machinetype.machine_type.Contains(search) && machine2.id != null
                                             select new GetMachineDto
                                             {
                                                 Id = machine2.id,
                                                 Machine_Name = machine2.machine_name,
                                                 Asset_Number = machine2.asset_id,
                                                 Serial_Number = machine2.serial_number,
                                                 Machine_Type = machine2.machine_type,
                                                 Description = machine2.machine_description,
                                                 Global_Id = machine2.global_id,
                                                 IsDelete = machine2.is_delete,
                                                 Customer_Id = cus.customer_id
                                             }).Skip(increasedCount).Take(count).ToListAsync();
                    var specificFeature = await (from specificFeature1 in _context.TblMachineSpecificFeature
                                                 join specificfeature in _context.TblSpecificFeature on specificFeature1.specificfeature_id equals specificfeature.specific_feature
                                                 join machine in _context.TblMachines on specificFeature1.machine_id equals machine.id into machine1
                                                 from machine2 in machine1.DefaultIfEmpty()
                                                 join cus in _context.TblMachineCustomerAssociation on machine2.id equals cus.machine_id
                                                 where machine2.machine_name.Contains(search) || specificfeature.specific_feature.Contains(search) && machine2.id != null
                                                 select new GetMachineDto
                                                 {
                                                     Id = machine2.id,
                                                     Machine_Name = machine2.machine_name,
                                                     Asset_Number = machine2.asset_id,
                                                     Serial_Number = machine2.serial_number,
                                                     Machine_Type = machine2.machine_type,
                                                     Description = machine2.machine_description,
                                                     Global_Id = machine2.global_id,
                                                     IsDelete = machine2.is_delete,
                                                     Customer_Id = cus.customer_id
                                                 }).Skip(increasedCount).Take(count).ToListAsync();
                    var controlSystem = await (from controlSystem1 in _context.TblMachineControlSystem
                                               join controlsystem in _context.TblControlSystem on controlSystem1.controlsystem_id equals controlsystem.control_system
                                               join machine in _context.TblMachines on controlSystem1.machine_id equals machine.id into machine1
                                               from machine2 in machine1.DefaultIfEmpty()
                                               join cus in _context.TblMachineCustomerAssociation on machine2.id equals cus.machine_id
                                               where machine2.machine_name.Contains(search) || controlsystem.control_system.Contains(search) && machine2.id != null
                                               select new GetMachineDto
                                               {
                                                   Id = machine2.id,
                                                   Machine_Name = machine2.machine_name,
                                                   Asset_Number = machine2.asset_id,
                                                   Serial_Number = machine2.serial_number,
                                                   Machine_Type = machine2.machine_type,
                                                   Description = machine2.machine_description,
                                                   Global_Id = machine2.global_id,
                                                   IsDelete = machine2.is_delete,
                                                   Customer_Id = cus.customer_id
                                               }).Skip(increasedCount).Take(count).ToListAsync();

                    machineDetails = await (from machine in _context.TblMachines
                                            join cus in _context.TblMachineCustomerAssociation on machine.id equals cus.machine_id
                                            where machine.machine_name.Contains(search)
                                            || machine.machine_type.Contains(search) || machine.asset_id.Contains(search)
                                            || machine.serial_number.Contains(search)
                                            select new GetMachineDto
                                            {
                                                Id = machine.id,
                                                Machine_Name = machine.machine_name,
                                                Asset_Number = machine.asset_id,
                                                Serial_Number = machine.serial_number,
                                                Machine_Type = machine.machine_type,
                                                Description = machine.machine_description,
                                                Global_Id = machine.global_id,
                                                IsDelete = machine.is_delete,
                                                Customer_Id = cus.customer_id
                                            })
                     .Skip(increasedCount).Take(count).ToListAsync();
                    machineDetails.AddRange(specificFeature.Except(machineDetails, new MachineComparer()).ToList());
                    machineDetails.AddRange(applications.Except(machineDetails, new MachineComparer()).ToList());
                    machineDetails.AddRange(controlSystem.Except(machineDetails, new MachineComparer()).ToList());
                    machineDetails.AddRange(machineType.Except(machineDetails, new MachineComparer()).ToList());
                }
                else
                {
                    machineDetails = await (from cus in _context.TblMachineCustomerAssociation
                                            join m in _context.TblMachines on cus.machine_id equals m.id
                                            where m.is_delete == false
                                            select new GetMachineDto
                                            {
                                                Id = m.id,
                                                Machine_Name = m.machine_name,
                                                Asset_Number = m.asset_id,
                                                Serial_Number = m.serial_number,
                                                Machine_Type = m.machine_type,
                                                Description = m.machine_description,
                                                Global_Id = m.global_id,
                                                Customer_Id = cus.customer_id
                                            }).Skip(increasedCount).Take(count).ToListAsync();
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            return machineDetails.Where(m => m.IsDelete == false).Distinct().ToList();
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="machineName"></param>
        /// <param name="count"></param>
        /// <param name="increasedCount"></param>
        /// <returns></returns>
        public async Task<List<CustomerMachineDto>> GetCustomerMachineDetails(string customerId, int count, int increasedCount)
        {
            try
            {
                var machineDetails = await (from cus in _context.TblMachineCustomerAssociation
                                            join machines in _context.TblMachines on cus.machine_id equals machines.id
                                            where cus.customer_id == customerId && machines.is_delete == false
                                            select new CustomerMachineDto
                                            {
                                                Id = machines.id,
                                                Global_Id = machines.global_id,
                                                Machine_Name = machines.machine_name,
                                                Asset_Id = machines.asset_id,
                                                Serial_Number = machines.serial_number,
                                                Machine_Description = machines.machine_description,
                                                Estimated_Hours = machines.estimated_hours,
                                                Machine_Location = machines.machine_location,
                                                Industry_Type = machines.industry_type,
                                                WBSID = machines.WBSID,
                                                Customer_Id = customerId,
                                                Customer_Name = _context.TblCustomers.FirstOrDefault(c => c.id == customerId).customer_name
                                            }).Distinct().Skip(increasedCount).Take(count).ToListAsync();
                return machineDetails;
            }
            catch (Exception)
            {
                throw;
            }

        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public async Task<List<TblMachine>> GetMasterMachineDetails()
        {
            var machineDetails = await _context.TblMachines.
                                  OrderByDescending(x => x.created_at).ToListAsync();
            return machineDetails;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="Machines"></param>
        /// <returns></returns>
        public MachineApiResponse<Dictionary<int, MaterMachineFileUploadDTO>> FileUploadForMasterMachineInJSonFormate(List<MaterMachineFileUploadDTO> Machines)
        {
            string result = string.Empty;
            int rowNumber = 0;
            var apiresponse = new MachineApiResponse<Dictionary<int, MaterMachineFileUploadDTO>>();
            var duplicatemachineList = new Dictionary<int, MaterMachineFileUploadDTO>();
            List<TblMachine> masterMachinesList = new();
            List<TblMachineCustomerAssociation> machineCustomerAssociationList = new();
            List<TblControlSystem> controlSystemList = new();
            List<TblSpecificFeature> specificFeatureList = new();
            List<TblMachineType> machineTypeList = new();
            List<TblApplication> applicationList = new();
            List<TblMachineCustomerAssociationTimeStamp> machineCustomerAssociationTimeStampList = new();
            List<TblControlSystemTimeStamp> controlSystemTimeStampList = new();
            List<TblSpecificFeatureTimeStamp> specificFeatureTimeStampList = new();
            List<TblMachineTypeTimeStamp> machineTypeTimeStampList = new();
            List<TblApplicationTimeStamp> applicationTimeStampList = new();
            List<TblMachineTypeAssociation> machineTypeAssociationList = new();
            List<TblMachineSpecificFeature> machineSpecificFeatureList = new();
            List<TblMachineApplication> machineApplicationList = new();
            List<TblMachineControlSystem> machineControlSystemList = new();
            List<TblMachineMediaMaster> machineMediaMasterList = new();
            try
            {
                foreach (var item in Machines)
                {
                    TblMachine masterMachines = new();
                    TblMachineCustomerAssociation machineCustomerAssociation = new();
                    TblControlSystem controlSystem = new();
                    TblSpecificFeature specificFeature = new();
                    TblMachineType machineType = new();
                    TblApplication application = new();
                    TblMachineCustomerAssociationTimeStamp machineCustomerAssociationTimeStamp = new();
                    TblControlSystemTimeStamp controlSystemTimeStamp = new();
                    TblSpecificFeatureTimeStamp specificFeatureTimeStamp = new();
                    TblMachineTypeTimeStamp machineTypeTimeStamp = new();
                    TblApplicationTimeStamp applicationTimeStamp = new();
                    TblMachineTypeAssociation machineTypeAssociation = new();
                    TblMachineSpecificFeature machineSpecificFeature = new();
                    TblMachineApplication machineApplication = new();
                    TblMachineControlSystem machineControlSystem = new();

                    Guid guid = Guid.NewGuid();
                    GetMachineDto materMachines = new()
                    {
                        Machine_Name = item?.Machine_Name,
                        Machine_Type = item?.Machine_Type,
                        Asset_Number = item?.Asset_Number,
                        Serial_Number = item?.Serial_Number,
                        Model = item?.Model,
                        Manufacturer = item?.Manufacturer,
                        Description = item?.Description,
                        Customer_Id = item?.Customer_Id,
                        IndustrySegment = item?.IndustrySegment,
                        Id = Convert.ToString(guid)
                    };
                    var machineStatus = CreateMasterMachine(materMachines);
                    if (machineStatus.Result)
                    {
                        machineCustomerAssociation.id = Guid.NewGuid().ToString();
                        machineCustomerAssociation.machine_id = Convert.ToString(guid);
                        machineCustomerAssociation.customer_id = item?.Customer_Id;
                        machineCustomerAssociation.segments = item?.IndustrySegment;
                        machineCustomerAssociation.sub_segments = item?.SubIndustrySegment;

                        machineCustomerAssociationTimeStamp.id = Guid.NewGuid().ToString();
                        machineCustomerAssociationTimeStamp.machinecustomerassociation_id = machineCustomerAssociation.id;
                        machineCustomerAssociationTimeStamp.created_at = DateTimeOffset.Now;
                        machineCustomerAssociationTimeStamp.created_by = GetCurrentUserId();
                        machineCustomerAssociationTimeStamp.modified_at = DateTimeOffset.Now;
                        machineCustomerAssociationTimeStamp.modified_by = GetCurrentUserId();
                        machineCustomerAssociationTimeStampList.Add(machineCustomerAssociationTimeStamp);
                        machineCustomerAssociationList.Add(machineCustomerAssociation);

                        for (int i = 0; i < item.MachineMetadata.Count; i++)
                        {
                            for (int con = 0; con < item.MachineMetadata[i].ControlSystem.Count; con++)
                            {
                                controlSystemTimeStamp.id = Guid.NewGuid().ToString();
                                controlSystemTimeStamp.controlsystem_id = item.MachineMetadata[i]?.ControlSystem[con];
                                controlSystemTimeStamp.created_at = DateTimeOffset.Now;
                                controlSystemTimeStamp.created_by = GetCurrentUserId();
                                controlSystemTimeStamp.modified_at = DateTimeOffset.Now;
                                controlSystemTimeStamp.modified_by = GetCurrentUserId();
                                controlSystemTimeStampList.Add(controlSystemTimeStamp);

                                machineControlSystem.id = Guid.NewGuid().ToString();
                                machineControlSystem.machine_id = Convert.ToString(guid);
                                machineControlSystem.controlsystem_id = _context.TblControlSystem.FirstOrDefault(c => c.id == item.MachineMetadata[i].ControlSystem[con])?.control_system;
                                machineControlSystem.created_at = DateTimeOffset.Now;
                                machineControlSystem.created_by = GetCurrentUserId();
                                machineControlSystem.modified_at = DateTimeOffset.Now;
                                machineControlSystem.modified_by = GetCurrentUserId();
                                machineControlSystemList.Add(machineControlSystem);
                            }

                            applicationTimeStamp.id = Guid.NewGuid().ToString();
                            applicationTimeStamp.application_id = item.MachineMetadata[i]?.Application;
                            applicationTimeStamp.created_at = DateTimeOffset.Now;
                            applicationTimeStamp.created_by = GetCurrentUserId();
                            applicationTimeStamp.modified_at = DateTimeOffset.Now;
                            applicationTimeStamp.modified_by = GetCurrentUserId();

                            machineApplication.id = Guid.NewGuid().ToString();
                            machineApplication.machine_id = Convert.ToString(guid);
                            machineApplication.application_id = _context.TblApplication.FirstOrDefault(a => a.id == item.MachineMetadata[i].Application)?.application;
                            machineApplication.created_at = DateTimeOffset.Now;
                            machineApplication.created_by = GetCurrentUserId();
                            machineApplication.modified_at = DateTimeOffset.Now;
                            machineApplication.modified_by = GetCurrentUserId();
                            machineApplicationList.Add(machineApplication);
                            applicationTimeStampList.Add(applicationTimeStamp);

                            for (int spf = 0; spf < item.MachineMetadata[i].SpecificFeature.Count; spf++)
                            {
                                specificFeatureTimeStamp.id = Guid.NewGuid().ToString();
                                specificFeatureTimeStamp.specificfeature_id = item.MachineMetadata[i]?.SpecificFeature[spf];
                                specificFeatureTimeStamp.created_at = DateTimeOffset.Now;
                                specificFeatureTimeStamp.created_by = GetCurrentUserId();
                                specificFeatureTimeStamp.modified_at = DateTimeOffset.Now;
                                specificFeatureTimeStamp.modified_by = GetCurrentUserId();

                                machineSpecificFeature.id = Guid.NewGuid().ToString();
                                machineSpecificFeature.machine_id = Convert.ToString(guid);
                                machineSpecificFeature.specificfeature_id = _context.TblSpecificFeature.FirstOrDefault(s => s.id == item.MachineMetadata[i].SpecificFeature[spf])?.specific_feature;
                                machineSpecificFeature.created_at = DateTimeOffset.Now;
                                machineSpecificFeature.created_by = GetCurrentUserId();
                                machineSpecificFeature.modified_at = DateTimeOffset.Now;
                                machineSpecificFeature.modified_by = GetCurrentUserId();
                                machineSpecificFeatureList.Add(machineSpecificFeature);
                                specificFeatureTimeStampList.Add(specificFeatureTimeStamp);
                            }

                            machineTypeTimeStamp.id = Guid.NewGuid().ToString();
                            machineTypeTimeStamp.machinetype_id = item.MachineMetadata[i]?.MachineType;
                            machineTypeTimeStamp.created_at = DateTimeOffset.Now;
                            machineTypeTimeStamp.created_by = GetCurrentUserId();
                            machineTypeTimeStamp.modified_at = DateTimeOffset.Now;
                            machineTypeTimeStamp.modified_by = GetCurrentUserId();

                            machineTypeAssociation.id = Guid.NewGuid().ToString();
                            machineTypeAssociation.machine_id = Convert.ToString(guid);
                            machineTypeAssociation.machinetype_id = _context.TblMachineType.FirstOrDefault(m => m.id == item.MachineMetadata[i].MachineType)?.machine_type;
                            machineTypeAssociation.created_at = DateTimeOffset.Now;
                            machineTypeAssociation.created_by = GetCurrentUserId();
                            machineTypeAssociation.modified_at = DateTimeOffset.Now;
                            machineTypeAssociation.modified_by = GetCurrentUserId();

                            machineTypeAssociationList.Add(machineTypeAssociation);
                            machineTypeTimeStampList.Add(machineTypeTimeStamp);
                        }
                        for (int media = 0; media < item.MachineImage.Count; media++)
                        {
                            TblMachineMediaMaster tblMachineMedia = new()
                            {
                                id = Guid.NewGuid().ToString(),
                                url = item.MachineImage[media].Url,
                                type = item.MachineImage[media].Content_Type,
                                machine_limits = Convert.ToString(guid),
                                created_by = GetCurrentUserId(),
                                created_at = DateTimeOffset.Now,
                                modified_at = DateTimeOffset.Now,
                                modified_by = GetCurrentUserId(),
                                name = item.MachineImage[media].File_Name,
                                drive_id = item.MachineImage[media].Drive_Id,
                                item_id = item.MachineImage[media].Item_Id,
                                image_size = item.MachineImage[media].Image_Size,
                            };
                            machineMediaMasterList.Add(tblMachineMedia);
                        }
                    }

                }
                //_context.TblMachines.AddRange(masterMachinesList);
                _context.TblMachineCustomerAssociation.AddRange(machineCustomerAssociationList);
                _context.TblMachineCustomerAssociationTimeStamp.AddRange(machineCustomerAssociationTimeStampList);
                _context.TblMachineTypeTimeStamp.AddRange(machineTypeTimeStampList);
                _context.TblSpecificFeatureTimeStamp.AddRange(specificFeatureTimeStampList);
                _context.TblApplicationTimeStamp.AddRange(applicationTimeStampList);
                _context.TblControlSystemTimeStamp.AddRange(controlSystemTimeStampList);
                _context.TblMachineTypeAssociation.AddRange(machineTypeAssociationList);
                _context.TblMachineSpecificFeature.AddRange(machineSpecificFeatureList);
                _context.TblMachineApplication.AddRange(machineApplicationList);
                _context.TblMachineControlSystem.AddRange(machineControlSystemList);
                _context.TblMachineMediaMaster.AddRange(machineMediaMasterList);
                _context.SaveChanges();
                apiresponse.StatusReason = "Machine's created successfully";
            }
            catch (Exception ex)
            {
                result = ex.Message.ToString();
                apiresponse.StatusReason = "Failed to create machine";
            }
            apiresponse.StatusCode = 201;
            return apiresponse;
        }



        public string MachineEdit(MachineEditDTO editMachine)
        {
            string msg = string.Empty;


            try
            {
                TblMachine tblMachine = _context.TblMachines.Where(x => x.id == editMachine.Id).FirstOrDefault();
                if (tblMachine is not null)
                {
                    tblMachine.machine_description = editMachine.Machine_Description;
                    tblMachine.serial_number = editMachine.Serial_Number;
                    tblMachine.asset_id = editMachine.Asset_Number;
                    tblMachine.machine_status = editMachine.Machine_Status;
                    tblMachine.manufacturer = editMachine.Manufacturer;
                    tblMachine.machine_model = editMachine.Machine_Model;
                    _context.SaveChanges();

                    #region Update Machine Application
                    TblMachineApplication tblMachineApplication = _context.TblMachineApplication
                                                                                       .Where(x => x.machine_id == editMachine.Id)
                                                                                       .FirstOrDefault();

                    if (tblMachineApplication is not null)
                    {
                        tblMachineApplication.application_id = _context.TblApplication.FirstOrDefault(c => c.id == editMachine.Application)?.application; ;
                        _context.Entry(tblMachineApplication).State = EntityState.Modified;
                        _context.SaveChanges();
                    }
                    #endregion

                    #region Update Machine Type Association
                    TblMachineTypeAssociation tblMachineTypeAssociation = _context.TblMachineTypeAssociation
                                                                                       .Where(x => x.machine_id == editMachine.Id)
                                                                                       .FirstOrDefault();

                    if (tblMachineTypeAssociation is not null)
                    {
                        tblMachineTypeAssociation.machinetype_id = _context.TblMachineType.FirstOrDefault(c => c.id == editMachine.MachineType)?.machine_type;
                        _context.Entry(tblMachineTypeAssociation).State = EntityState.Modified;
                        _context.SaveChanges();
                    }
                    #endregion

                    #region Update Machine Type Association
                    // Delete 
                    var entitiesToDelete = _context.TblMachineSpecificFeature
                                                   .Where(x => x.machine_id == editMachine.Id)
                                                   .ToList();

                    _context.TblMachineSpecificFeature.RemoveRange(entitiesToDelete);
                    _context.SaveChanges();

                    //Insert
                    foreach (var item in editMachine.SpecificFeature)
                    {
                        TblMachineSpecificFeature tblMachineSpecificFeature = new TblMachineSpecificFeature
                        {
                            id = Guid.NewGuid().ToString(),
                            specificfeature_id = _context.TblSpecificFeature.FirstOrDefault(c => c.id == item)?.specific_feature,
                            machine_id = editMachine?.Id,
                            created_by = GetCurrentUserId(),
                            created_at = DateTimeOffset.Now,
                            modified_at = DateTimeOffset.Now,
                            modified_by = GetCurrentUserId(),
                        };
                        _context.TblMachineSpecificFeature.Add(tblMachineSpecificFeature);
                        _context.SaveChanges();
                    }

                    #endregion

                    #region Update Machine Control System
                    // Delete 
                    List<TblMachineControlSystem> deleteMachineControlSystem = _context.TblMachineControlSystem
                                                                                       .Where(x => x.machine_id == editMachine.Id)
                                                                                       .ToList();

                    _context.TblMachineControlSystem.RemoveRange(deleteMachineControlSystem);
                    _context.SaveChanges();

                    //Insert
                    foreach (var item in editMachine.ControlSystem)
                    {
                        TblMachineControlSystem tblMachineControlSystem = new TblMachineControlSystem
                        {
                            id = Guid.NewGuid().ToString(),
                            controlsystem_id = _context.TblControlSystem.FirstOrDefault(c => c.id == item)?.control_system,
                            machine_id = editMachine?.Id,
                            created_by = GetCurrentUserId(),
                            created_at = DateTimeOffset.Now,
                            modified_at = DateTimeOffset.Now,
                            modified_by = GetCurrentUserId(),
                        };
                        _context.TblMachineControlSystem.Add(tblMachineControlSystem);
                        _context.SaveChanges();

                    }

                    #endregion


                    #region Update Machine Media
                    // Delete 
                    List<TblMachineMediaMaster> deleteMachineMedia = _context.TblMachineMediaMaster
                                                                                       .Where(x => x.machine_limits == editMachine.Id)
                                                                                       .ToList();

                    _context.TblMachineMediaMaster.RemoveRange(deleteMachineMedia);
                    _context.SaveChanges();

                    //Insert
                    foreach (var item in editMachine.MachineFilesList)
                    {
                        TblMachineMediaMaster tblMachineMedia = new TblMachineMediaMaster
                        {
                            id = Guid.NewGuid().ToString(),
                            url = item.Url,
                            type = item.Content_Type,
                            machine_limits = editMachine?.Id,
                            created_by = GetCurrentUserId(),
                            created_at = DateTimeOffset.Now,
                            modified_at = DateTimeOffset.Now,
                            modified_by = GetCurrentUserId(),
                            name = item.File_Name,
                            drive_id = item.Drive_Id,
                            item_id = item.Item_Id,
                            image_size = item.Image_Size,
                        };
                        _context.TblMachineMediaMaster.Add(tblMachineMedia);
                        _context.SaveChanges();

                    }


                    #endregion

                    msg = "Machine updated successfully";
                }
                else
                {
                    msg = "Machine not updated";
                }
            }
            catch (Exception ex)
            {
                msg = "Failed to update";
            }
            return msg;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="customerId"></param>
        /// <param name="segment"></param>
        /// <param name="subSegment"></param>
        /// <returns></returns>
        private async Task<string> GenerateRandomNumber(string customerId, string segment)
        {
            var isDuplicateGMId = _context.TblMachines.OrderByDescending(o => o.global_id != null)
                                                      .ThenByDescending(o => o.created_at)
                                                      .FirstOrDefault()?.global_id;
            string number = isDuplicateGMId?[^4..];
            int randomNumber = int.Parse(number);
            randomNumber = ++randomNumber;
            string globalMachineId = segment != null ? customerId + segment + randomNumber.ToString("D4") : customerId + randomNumber.ToString("D4");

            return globalMachineId;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public async Task<List<TblApplication>> GetAllApplication(string search, int count, int increasedCount)
        {
            try
            {
                var applications = new List<TblApplication>();
                if (!string.IsNullOrEmpty(search))
                {
                    applications = await _context.TblApplication
                    .Where(a => a.application.Contains(search))
                    .Select(a => new TblApplication
                    {
                        id = a.id,
                        application = a.application
                    }).Skip(increasedCount).Take(count).ToListAsync();
                }
                else
                {
                    applications = await _context.TblApplication
                    .Select(a => new TblApplication
                    {
                        id = a.id,
                        application = a.application
                    }).Skip(increasedCount).Take(count).ToListAsync();
                }

                return applications;
            }
            catch (Exception)
            {

                throw;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public async Task<List<TblControlSystem>> GetAllControlSystem(string search, int count, int increasedCount)
        {
            try
            {
                var controlSystems = new List<TblControlSystem>();
                if (!string.IsNullOrEmpty(search))
                {
                    controlSystems = await _context.TblControlSystem
                    .Where(c => c.control_system.Contains(search))
                    .Select(c => new TblControlSystem
                    {
                        id = c.id,
                        control_system = c.control_system
                    }).Skip(increasedCount).Take(count).ToListAsync();
                }
                else
                {
                    controlSystems = await _context.TblControlSystem
                    .Select(c => new TblControlSystem
                    {
                        id = c.id,
                        control_system = c.control_system
                    }).Skip(increasedCount).Take(count).ToListAsync();
                }
                return controlSystems;
            }
            catch (Exception)
            {

                throw;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public async Task<List<TblSpecificFeature>> GetAllSpecificFeature(string search, int count, int increasedCount)
        {
            try
            {
                var specificFeatures = new List<TblSpecificFeature>();
                if (!string.IsNullOrEmpty(search))
                {
                    specificFeatures = await _context.TblSpecificFeature
                   .Where(s => s.specific_feature.Contains(search))
                   .Select(s => new TblSpecificFeature
                   {
                       id = s.id,
                       specific_feature = s.specific_feature
                   }).Skip(increasedCount).Take(count).ToListAsync();
                }
                else
                {
                    specificFeatures = await _context.TblSpecificFeature
                    .Select(s => new TblSpecificFeature
                    {
                        id = s.id,
                        specific_feature = s.specific_feature
                    }).Skip(increasedCount).Take(count).ToListAsync();
                }

                return specificFeatures;
            }
            catch (Exception)
            {

                throw;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public async Task<List<TblMachineType>> GetAllMachineType(string search, int count, int increasedCount)
        {
            try
            {
                var machineTypes = new List<TblMachineType>();
                if (!string.IsNullOrEmpty(search))
                {
                    machineTypes = await _context.TblMachineType
                    .Where(m => m.machine_type.Contains(search))
                    .Select(m => new TblMachineType
                    {
                        id = m.id,
                        machine_type = m.machine_type
                    }).Skip(increasedCount).Take(count).ToListAsync();
                }
                else
                {
                    machineTypes = await _context.TblMachineType
                    .Select(m => new TblMachineType
                    {
                        id = m.id,
                        machine_type = m.machine_type
                    }).Skip(increasedCount).Take(count).ToListAsync();
                }
                return machineTypes;
            }
            catch (Exception)
            {

                throw;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="application"></param>
        /// <returns></returns>
        public async Task<string> CreateApplication(List<ApplicationDto> application)
        {
            try
            {
                string isSuccess = "Failed to created Application";
                List<TblApplication> tblApplicationList = new();
                List<TblMachineApplication> tblMachineApplicationList = new();
                List<TblApplicationTimeStamp> tblApplicationTimeStampList = new();
                for (int i = 0; i < application.Count; i++)
                {
                    TblApplication tblApplication = new();
                    TblMachineApplication tblMachineApplication = new();
                    TblApplicationTimeStamp tblApplicationTimeStamp = new();
                    if (string.IsNullOrEmpty(application[i].Id))
                    {
                        tblApplication.id = Guid.NewGuid().ToString();
                        tblApplication.application = application[i]?.Application;
                        tblMachineApplication.id = Guid.NewGuid().ToString();
                        tblMachineApplication.application_id = tblApplication.id;
                        tblMachineApplication.machine_id = application[i]?.Machine_Id;
                        tblMachineApplication.created_by = GetCurrentUserId();
                        tblMachineApplication.created_at = DateTimeOffset.Now;
                        tblMachineApplication.modified_at = DateTimeOffset.Now;
                        tblMachineApplication.modified_by = GetCurrentUserId();
                        tblApplicationTimeStamp.id = Guid.NewGuid().ToString();
                        tblApplicationTimeStamp.application_id = tblApplication.id;
                        tblApplicationTimeStamp.created_by = GetCurrentUserId();
                        tblApplicationTimeStamp.created_at = DateTimeOffset.Now;
                        tblApplicationTimeStamp.modified_at = DateTimeOffset.Now;
                        tblApplicationTimeStamp.modified_by = GetCurrentUserId();
                        tblApplicationList.Add(tblApplication);
                        tblMachineApplicationList.Add(tblMachineApplication);
                        tblApplicationTimeStampList.Add(tblApplicationTimeStamp);
                    }
                    else
                    {
                        var apllicationUpdate = _context.TblApplication.Where(a => a.id == application[i].Id).FirstOrDefault();
                        var applicationTimeStamp = _context.TblApplicationTimeStamp.Where(a => a.application_id == application[i].Id).FirstOrDefault();
                        if (apllicationUpdate != null)
                        {
                            apllicationUpdate.application = application[i].Application;
                            applicationTimeStamp.modified_at = DateTimeOffset.Now;
                            applicationTimeStamp.modified_by = GetCurrentUserId();
                            _context.TblApplication.Update(apllicationUpdate);
                            _context.TblApplicationTimeStamp.Update(applicationTimeStamp);
                            _context.SaveChanges();
                        }
                    }
                }
                _context.TblApplication.AddRange(tblApplicationList);
                _context.TblMachineApplication.AddRange(tblMachineApplicationList);
                _context.TblApplicationTimeStamp.AddRange(tblApplicationTimeStampList);
                _context.SaveChanges();
                isSuccess = "Application created successfully";
                return isSuccess;
            }
            catch (Exception)
            {

                throw;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="controlSystems"></param>
        /// <returns></returns>
        public async Task<string> CreateControlSystem(List<ControlSystemDto> controlSystems)
        {
            try
            {
                string isSuccess = "Failed to created ControlSystem";
                List<TblControlSystem> controlSystemList = new();
                List<TblMachineControlSystem> tblMachineControlSystemList = new();
                List<TblControlSystemTimeStamp> tblControlSystemTimeStampList = new();
                for (int i = 0; i < controlSystems.Count; i++)
                {
                    TblControlSystem tblControlSystem = new();
                    TblMachineControlSystem tblMachineControlSystem = new();
                    TblControlSystemTimeStamp tblControlSystemTimeStamp = new();
                    if (string.IsNullOrEmpty(controlSystems[i].Id))
                    {
                        tblControlSystem.id = Guid.NewGuid().ToString();
                        tblControlSystem.control_system = controlSystems[i]?.ControlSystem;

                        tblMachineControlSystem.id = Guid.NewGuid().ToString();
                        tblMachineControlSystem.controlsystem_id = tblControlSystem.id;
                        tblMachineControlSystem.machine_id = controlSystems[i]?.Machine_Id;
                        tblMachineControlSystem.created_by = GetCurrentUserId();
                        tblMachineControlSystem.created_at = DateTimeOffset.Now;
                        tblMachineControlSystem.modified_at = DateTimeOffset.Now;
                        tblMachineControlSystem.modified_by = GetCurrentUserId();
                        tblControlSystemTimeStamp.id = Guid.NewGuid().ToString();
                        tblControlSystemTimeStamp.controlsystem_id = tblControlSystem.id;
                        tblControlSystemTimeStamp.created_by = GetCurrentUserId();
                        tblControlSystemTimeStamp.created_at = DateTimeOffset.Now;
                        tblControlSystemTimeStamp.modified_at = DateTimeOffset.Now;
                        tblControlSystemTimeStamp.modified_by = GetCurrentUserId();
                        controlSystemList.Add(tblControlSystem);
                        tblMachineControlSystemList.Add(tblMachineControlSystem);
                        tblControlSystemTimeStampList.Add(tblControlSystemTimeStamp);
                    }
                    else
                    {
                        var controlSystemUpdate = _context.TblControlSystem.Where(a => a.id == controlSystems[i].Id).FirstOrDefault();
                        var controlSystemTimeStamp = _context.TblControlSystemTimeStamp.Where(a => a.controlsystem_id == controlSystems[i].Id).FirstOrDefault();
                        if (controlSystemUpdate != null)
                        {
                            controlSystemUpdate.control_system = controlSystems[i].ControlSystem;
                            controlSystemTimeStamp.modified_at = DateTimeOffset.Now;
                            controlSystemTimeStamp.modified_by = GetCurrentUserId();
                            _context.TblControlSystem.Update(controlSystemUpdate);
                            _context.TblControlSystemTimeStamp.Update(controlSystemTimeStamp);
                            _context.SaveChanges();
                        }
                    }
                }
                _context.TblControlSystem.AddRange(controlSystemList);
                _context.TblMachineControlSystem.AddRange(tblMachineControlSystemList);
                _context.TblControlSystemTimeStamp.AddRange(tblControlSystemTimeStampList);
                _context.SaveChanges();
                isSuccess = "ControlSystem created successfully";
                return isSuccess;
            }
            catch (Exception)
            {

                throw;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="specificFeatures"></param>
        /// <returns></returns>
        public async Task<string> CreateSpecificFeatuere(List<SpecificFeatureDto> specificFeatures)
        {
            try
            {
                string isSuccess = "Failed to created SpecificFeatuere";
                List<TblSpecificFeature> specificFeatureList = new();
                List<TblMachineSpecificFeature> tblMachineSpecificFeatureList = new();
                List<TblSpecificFeatureTimeStamp> tblSpecificFeatureTimeStampList = new();
                for (int i = 0; i < specificFeatures.Count; i++)
                {
                    TblSpecificFeature tblSpecificFeature = new();
                    TblMachineSpecificFeature tblMachineSpecificFeature = new();
                    TblSpecificFeatureTimeStamp tblSpecificFeatureTimeStamp = new();
                    if (string.IsNullOrEmpty(specificFeatures[i].Id))
                    {
                        tblSpecificFeature.id = Guid.NewGuid().ToString();
                        tblSpecificFeature.specific_feature = specificFeatures[i]?.SpecificFeature;
                        tblMachineSpecificFeature.id = Guid.NewGuid().ToString();
                        tblMachineSpecificFeature.specificfeature_id = tblSpecificFeature.id;
                        tblMachineSpecificFeature.machine_id = specificFeatures[i]?.Machine_Id;
                        tblMachineSpecificFeature.created_by = GetCurrentUserId();
                        tblMachineSpecificFeature.created_at = DateTimeOffset.Now;
                        tblMachineSpecificFeature.modified_at = DateTimeOffset.Now;
                        tblMachineSpecificFeature.modified_by = GetCurrentUserId();
                        tblSpecificFeatureTimeStamp.id = Guid.NewGuid().ToString();
                        tblSpecificFeatureTimeStamp.specificfeature_id = tblSpecificFeature.id;
                        tblSpecificFeatureTimeStamp.created_by = GetCurrentUserId();
                        tblSpecificFeatureTimeStamp.created_at = DateTimeOffset.Now;
                        tblSpecificFeatureTimeStamp.modified_at = DateTimeOffset.Now;
                        tblSpecificFeatureTimeStamp.modified_by = GetCurrentUserId();
                        specificFeatureList.Add(tblSpecificFeature);
                        tblMachineSpecificFeatureList.Add(tblMachineSpecificFeature);
                        tblSpecificFeatureTimeStampList.Add(tblSpecificFeatureTimeStamp);
                    }
                    else
                    {
                        var specificFeatureUpdate = _context.TblSpecificFeature.Where(a => a.id == specificFeatures[i].Id).FirstOrDefault();
                        var controlSystemTimeStamp = _context.TblSpecificFeatureTimeStamp.Where(a => a.specificfeature_id == specificFeatures[i].Id).FirstOrDefault();
                        if (specificFeatureUpdate != null)
                        {
                            specificFeatureUpdate.specific_feature = specificFeatures[i]?.SpecificFeature;
                            controlSystemTimeStamp.modified_at = DateTimeOffset.Now;
                            controlSystemTimeStamp.modified_by = GetCurrentUserId();
                            _context.TblSpecificFeature.Update(specificFeatureUpdate);
                            _context.TblSpecificFeatureTimeStamp.Update(controlSystemTimeStamp);
                            _context.SaveChanges();
                        }
                    }
                }
                _context.TblSpecificFeature.AddRange(specificFeatureList);
                _context.TblMachineSpecificFeature.AddRange(tblMachineSpecificFeatureList);
                _context.TblSpecificFeatureTimeStamp.AddRange(tblSpecificFeatureTimeStampList);
                _context.SaveChanges();
                isSuccess = "SpecificFeatuere created successfully";
                return isSuccess;
            }
            catch (Exception)
            {

                throw;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="machineType"></param>
        /// <returns></returns>
        public async Task<string> CreateMachineType(List<MachineTypeDto> machineType)
        {
            try
            {
                string isSuccess = "Failed to created MachineType";
                List<TblMachineType> machineTypeList = new();
                List<TblMachineTypeAssociation> tblMachineTypeAssociationList = new();
                List<TblMachineTypeTimeStamp> tblMachineTypeTimeStampList = new();
                for (int i = 0; i < machineType.Count; i++)
                {
                    TblMachineType tblMachineType = new();
                    TblMachineTypeAssociation tblMachineTypeAssociation = new();
                    TblMachineTypeTimeStamp tblMachineTypeTimeStamp = new();
                    if (string.IsNullOrEmpty(machineType[i].Id))
                    {
                        tblMachineType.id = Guid.NewGuid().ToString();
                        tblMachineType.machine_type = machineType[i]?.MachineType;
                        tblMachineTypeAssociation.id = Guid.NewGuid().ToString();
                        tblMachineTypeAssociation.machinetype_id = tblMachineType.id;
                        tblMachineTypeAssociation.machine_id = machineType[i]?.Machine_Id;
                        tblMachineTypeAssociation.created_by = GetCurrentUserId();
                        tblMachineTypeAssociation.created_at = DateTimeOffset.Now;
                        tblMachineTypeAssociation.modified_at = DateTimeOffset.Now;
                        tblMachineTypeAssociation.modified_by = GetCurrentUserId();
                        tblMachineTypeTimeStamp.id = Guid.NewGuid().ToString();
                        tblMachineTypeTimeStamp.machinetype_id = tblMachineType.id;
                        tblMachineTypeTimeStamp.created_by = GetCurrentUserId();
                        tblMachineTypeTimeStamp.created_at = DateTimeOffset.Now;
                        tblMachineTypeTimeStamp.modified_at = DateTimeOffset.Now;
                        tblMachineTypeTimeStamp.modified_by = GetCurrentUserId();
                        machineTypeList.Add(tblMachineType);
                        tblMachineTypeAssociationList.Add(tblMachineTypeAssociation);
                        tblMachineTypeTimeStampList.Add(tblMachineTypeTimeStamp);
                    }
                    else
                    {
                        var machineTypeUpdate = _context.TblMachineType.Where(a => a.id == machineType[i].Id).FirstOrDefault();
                        var machineTypeTimeStamp = _context.TblMachineTypeTimeStamp.Where(a => a.machinetype_id == machineType[i].Id).FirstOrDefault();
                        if (machineTypeUpdate != null)
                        {
                            machineTypeUpdate.machine_type = machineType[i]?.MachineType;
                            machineTypeTimeStamp.modified_at = DateTimeOffset.Now;
                            machineTypeTimeStamp.modified_by = GetCurrentUserId();
                            _context.TblMachineType.Update(machineTypeUpdate);
                            _context.TblMachineTypeTimeStamp.Update(machineTypeTimeStamp);
                            _context.SaveChanges();
                        }
                    }
                }
                _context.TblMachineType.AddRange(machineTypeList);
                _context.TblMachineTypeAssociation.AddRange(tblMachineTypeAssociationList);
                _context.TblMachineTypeTimeStamp.AddRange(tblMachineTypeTimeStampList);
                _context.SaveChanges();
                isSuccess = "MachineType created successfully";
                return isSuccess;
            }
            catch (Exception)
            {

                throw;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="application"></param>
        /// <returns></returns>
        public async Task<string> DeleteApplication(ApplicationDto application)
        {
            try
            {
                string isSuccess = "Failed to delete Application";
                var deleteApplication = _context.TblApplication.Where(a => a.id == application.Id).FirstOrDefault();
                if (deleteApplication != null)
                {
                    _context.TblApplication.Remove(deleteApplication);
                    _context.SaveChanges();
                    isSuccess = "Application deleted successfully";
                }
                return isSuccess;
            }
            catch (Exception)
            {

                throw;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="specificFeature"></param>
        /// <returns></returns>
        public async Task<string> DeleteSpecificFeature(SpecificFeatureDto specificFeature)
        {
            try
            {
                string isSuccess = "Failed to delete SpecificFeature";
                var deleteSpecificFeature = _context.TblSpecificFeature.Where(a => a.id == specificFeature.Id).FirstOrDefault();
                if (deleteSpecificFeature != null)
                {
                    _context.TblSpecificFeature.Remove(deleteSpecificFeature);
                    _context.SaveChanges();
                    isSuccess = "SpecificFeature deleted successfully";
                }
                return isSuccess;
            }
            catch (Exception)
            {

                throw;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="machineType"></param>
        /// <returns></returns>
        public async Task<string> DeleteMachineType(MachineTypeDto machineType)
        {
            try
            {
                string isSuccess = "Failed to delete MachineType";
                var deleteMachineType = _context.TblMachineType.Where(a => a.id == machineType.Id).FirstOrDefault();
                if (deleteMachineType != null)
                {
                    _context.TblMachineType.Remove(deleteMachineType);
                    _context.SaveChanges();
                    isSuccess = "MachineType deleted successfully";
                }
                return isSuccess;
            }
            catch (Exception)
            {

                throw;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="controlSystem"></param>
        /// <returns></returns>
        public async Task<string> DeleteControlSystem(ControlSystemDto controlSystem)
        {
            try
            {
                string isSuccess = "Failed to delete ControlSystem";
                var deleteControlSystem = _context.TblControlSystem.Where(a => a.id == controlSystem.Id).FirstOrDefault();
                if (deleteControlSystem != null)
                {
                    _context.TblControlSystem.Remove(deleteControlSystem);
                    _context.SaveChanges();
                    isSuccess = "ControlSystem deleted successfully";
                }
                return isSuccess;
            }
            catch (Exception)
            {

                throw;
            }
        }

        private string GetCurrentUserId() => httpContextAccessor.HttpContext.User.Claims.FirstOrDefault(c => c.Type == "Id")?.Value ?? String.Empty;

        public async Task<GetMachineAttributeDto> GetMachineAttribute(string machineId)
        {
            var machineDetails = new GetMachineAttributeDto();
            try
            {
                var machineData = await _context.TblMachines.FirstOrDefaultAsync(x => x.id == machineId);
                var machineCustomerAssociation = await _context.TblMachineCustomerAssociation.FirstOrDefaultAsync(x => x.machine_id == machineId);
                var customerDetails = await _context.TblCustomers.FirstOrDefaultAsync(c => c.customer_id == machineCustomerAssociation.customer_id);

                if (machineData is not null)
                {
                    machineDetails.Asset_Number = machineData.asset_id;
                    machineDetails.Serial_Number = machineData.serial_number;
                    machineDetails.Description = machineData.machine_description;
                    machineDetails.Machine_Model = machineData.machine_model;

                    machineDetails.Manufacturer = machineData.manufacturer;
                    machineDetails.Machine_Status = machineData.machine_status;
                    machineDetails.Customer_Id = machineCustomerAssociation.customer_id;
                    machineDetails.IndustrySegment = machineCustomerAssociation.segments;
                    machineDetails.SubIndustrySegment = machineCustomerAssociation.sub_segments;
                    machineDetails.Customer_Name = customerDetails?.customer_name;
                }

                machineDetails.MachineMetaData.Application = await (from app in _context.TblApplication
                                                                    join machineApplication in _context.TblMachineApplication
                                                                         on app.application equals machineApplication.application_id
                                                                    where machineApplication.machine_id == machineId
                                                                    select new ApplicationDto
                                                                    {
                                                                        Id = app.id,
                                                                        Application = app.application,
                                                                        Machine_Id = machineId
                                                                    }).FirstOrDefaultAsync();



                machineDetails.MachineMetaData.SpecificFeature = await (from specificFeature in _context.TblSpecificFeature
                                                                        join machineSpecificFeature in _context.TblMachineSpecificFeature on
                                                                           specificFeature.specific_feature equals machineSpecificFeature.specificfeature_id
                                                                        where machineSpecificFeature.machine_id == machineId
                                                                        select new SpecificFeatureDto
                                                                        {
                                                                            Id = specificFeature.id,
                                                                            SpecificFeature = specificFeature.specific_feature,
                                                                            Machine_Id = machineId
                                                                        }).ToListAsync();


                machineDetails.MachineMetaData.ControlSystem = await (from controlSystem in _context.TblControlSystem
                                                                      join machineControlSystem in _context.TblMachineControlSystem on
                                                                         controlSystem.control_system equals machineControlSystem.controlsystem_id
                                                                      where machineControlSystem.machine_id == machineId
                                                                      select new ControlSystemDto
                                                                      {
                                                                          Id = controlSystem.id,
                                                                          ControlSystem = controlSystem.control_system,
                                                                          Machine_Id = machineId
                                                                      }).ToListAsync();

                machineDetails.MachineMetaData.MachineType = await (from machineAssociation in _context.TblMachineTypeAssociation
                                                                    join machineType in _context.TblMachineType
                                                                         on machineAssociation.machinetype_id equals machineType.machine_type
                                                                    where machineAssociation.machine_id == machineId
                                                                    select new MachineTypeDto
                                                                    {
                                                                        Id = machineType.id,
                                                                        MachineType = machineType.machine_type,
                                                                        Machine_Id = machineId
                                                                    }).FirstOrDefaultAsync();

                machineDetails.MachineMetaData.MachineImageList = await (from machineMedia in _context.TblMachineMediaMaster
                                                                         where machineMedia.machine_limits == machineId
                                                                         select new MachineEditImageDto
                                                                         {
                                                                             File_Name = machineMedia.name,
                                                                             Content_Type = machineMedia.type,
                                                                             Url = machineMedia.url,
                                                                             Drive_Id = machineMedia.drive_id,
                                                                             Item_Id = machineMedia.item_id,
                                                                             Image_Size = machineMedia.image_size,
                                                                         }).ToListAsync();

            }
            catch (Exception ex)
            {
                throw;
            }


            return machineDetails;
        }
        /// <summary>
        /// Get Machine Reference Data
        /// </summary>
        /// <param name="machineId"></param>
        /// <returns>List<MachineReferenceDto></returns>
        public async Task<List<MachineReferenceDto>> GetMachineReferences(string machineId)
        {
            try
            {
                var referenceData = await (from machine in _context.TblMachines.Where(m => m.id == machineId)
                                           join sm in _context.TblServiceMachines on machine.id equals sm.machine_id into sm1
                                           from sm2 in sm1.DefaultIfEmpty()
                                           join ser in _context.TblServices on sm2.service_id equals ser.id
                                           select new MachineReferenceDto
                                           {
                                               BlueprintProjectID = _context.TblProjects.Where(p => p.id == ser.project_id).FirstOrDefault().erp_project_id ?? null,
                                               ProjectId = ser.project_id ?? null,
                                               OfferId = ser.offer_id ?? null,
                                               Erp_Offer_Id = _context.TblOffers.Where(p => p.id == ser.offer_id).FirstOrDefault().WBSID ?? null,
                                               OrderId = _context.TblOrder.Where(p => p.service_id == ser.id).OrderByDescending(o => o.created_at).FirstOrDefault().id ?? null,
                                               Erp_Order_Id = _context.TblOrder.Where(p => p.service_id == ser.id).OrderByDescending(o => o.created_at).FirstOrDefault().erp_order_id ?? null,
                                               ServiceId = ser.id,
                                               ErpServiceId = ser.erp_wbs_id,
                                               Service_Type = ser.service_type
                                           }).ToListAsync();
                return referenceData;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<MachineReferenceForBulkUploadDto> GetMachineReferencesForBulkUpload()
        {
            try
            {
                MachineReferenceForBulkUploadDto machineReferenceForBulkUpload = new();
                machineReferenceForBulkUpload.Application = await _context.TblApplication.ToListAsync();
                machineReferenceForBulkUpload.SpecificFeature = await _context.TblSpecificFeature.ToListAsync();
                machineReferenceForBulkUpload.MachineType = await _context.TblMachineType.ToListAsync();
                machineReferenceForBulkUpload.ControlSystem = await _context.TblControlSystem.ToListAsync();

                return machineReferenceForBulkUpload;
            }
            catch (Exception ex)
            {

                throw;
            }
        }
        /// <summary>
        /// Soft delete machine
        /// </summary>
        /// <param name="machineId"></param>
        /// <returns>string</returns>
        public async Task<string> RemoveMasterMachine(List<string> list)
        {
            try
            {
                string isSuccess = "No machine found";
                if (list is not null && list.Any())
                {
                    for (int i = 0; i < list.Count; i++)
                    {
                        var machine = await _context.TblMachines.FirstOrDefaultAsync(m => m.id == list[i]);
                        if (machine != null)
                        {
                            machine.is_delete = true;
                            machine.modified_at = DateTimeOffset.UtcNow;
                            machine.deleted_at = DateTimeOffset.UtcNow;
                            machine.deleted_by = GetCurrentUserId();
                            _context.TblMachines.Update(machine);
                            _context.SaveChanges();
                            isSuccess = "Machine's deleted successfully";
                        }
                    }
                }
                return isSuccess;
            }
            catch (Exception ex)
            {
                return "Machine's failed to delete";
            }
        }
        /// <summary>
        /// Create machine
        /// </summary>
        /// <param name="machineDto"></param>
        /// <returns></returns>
        public async Task<bool> CreateMasterMachine(GetMachineDto machineDto)
        {
            bool isSuccess = false;
            try
            {
                lock (lockObject)
                {
                    TblMachine masterMachines = new();
                    GenerateGlobalMachineCode generateGlobalMachineCode = new(_context);
                    var isDuplicateGMId = generateGlobalMachineCode.GetRecentMachineCode();
                    string number = isDuplicateGMId.Result?[^6..];
                    int randomNumber = int.Parse(number);
                    randomNumber = ++randomNumber;
                    string globalMachineId = machineDto?.IndustrySegment != null ? machineDto?.Customer_Id + machineDto?.IndustrySegment + randomNumber.ToString("D6") : machineDto?.Customer_Id + randomNumber.ToString("D6");

                    masterMachines.id = machineDto.Id;
                    masterMachines.global_id = globalMachineId;
                    masterMachines.machine_name = machineDto?.Machine_Name;
                    masterMachines.machine_type = machineDto?.Machine_Type;
                    masterMachines.manufacturer = machineDto?.Manufacturer;
                    masterMachines.machine_model = machineDto?.Model;
                    masterMachines.asset_id = machineDto?.Asset_Number;
                    masterMachines.serial_number = machineDto?.Serial_Number;
                    masterMachines.machine_description = machineDto?.Description;
                    masterMachines.created_at = DateTimeOffset.Now;
                    masterMachines.created_by = GetCurrentUserId();
                    masterMachines.modified_at = DateTimeOffset.Now;
                    masterMachines.modified_by = GetCurrentUserId();
                    _context.TblMachines.Add(masterMachines);
                    _context.SaveChanges();
                    isSuccess = true;
                }
                return isSuccess;
            }
            catch (Exception)
            {

                throw;
            }
        }
        /// <summary>
        /// Validate the Machine Upload
        /// </summary>
        /// <param name="materMachines"></param>
        /// <returns></returns>
        public async Task<MachineApiResponse<Dictionary<int, MaterMachineFileUploadDTO>>> MachineValidation(List<MaterMachineFileUploadDTO> materMachines)
        {
            try
            {
                string result = "No duplicate machines found";
                int code = 404;
                int rowNumber = 0;
                var apiresponse = new MachineApiResponse<Dictionary<int, MaterMachineFileUploadDTO>>();
                var duplicatemachineList = new Dictionary<int, MaterMachineFileUploadDTO>();
                for (int mac = 0; mac < materMachines.Count; mac++)
                {
                    var duplicateMachines = await _context.TblMachines.Where(m => m.machine_name.ToLower() == materMachines[mac].Machine_Name.ToLower()).FirstOrDefaultAsync();
                    var duplicateCustMachines = await _context.TblMachineCustomerAssociation
                        .Where(m => duplicateMachines != null && m.machine_id == duplicateMachines.id && m.customer_id == materMachines[mac].Customer_Id).FirstOrDefaultAsync();
                    if (duplicateMachines != null && duplicateCustMachines != null)
                    {
                        rowNumber = ++rowNumber;
                        duplicatemachineList.Add(rowNumber, materMachines[mac]);
                        result = "Machine name already existed";
                        code = 409;
                    }
                }
                apiresponse.DuplicateMachines = duplicatemachineList;
                apiresponse.StatusReason = result;
                apiresponse.StatusCode = code;
                return apiresponse;
            }
            catch (Exception ex)
            {
                return null;
                throw;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="searchMachineDto"></param>
        /// <returns></returns>
        private List<GetMachineDto> BuildFilterExpression(List<GetMachineDto> machineDetails, FilterDto searchMachineDto, string search)
        {
            try
            {
                var filteredMachines = new List<GetMachineDto>();
                switch (searchMachineDto.Field.ToLower())
                {
                    case "application":
                        {
                            filteredMachines = searchMachineDto.Operator.ToLower() switch
                            {
                                "equals" => machineDetails.Where(s => s. Application.ToLower() == searchMachineDto.Value.ToLower()).ToList(),
                                "notequals" => machineDetails.Where(s => s.Application.ToLower() != searchMachineDto.Value.ToLower()).ToList(),
                                "contains" => machineDetails.Where(s => s.Application.ToLower().Contains(searchMachineDto.Value.ToLower())).ToList(),
                                "startswith" => machineDetails.Where(s => s.Application.ToLower().StartsWith(searchMachineDto.Value.ToLower())).ToList(),
                                "endswith" => machineDetails.Where(s => s.Application.ToLower().EndsWith(searchMachineDto.Value.ToLower())).ToList(),
                                "doesn'tcontain" => machineDetails.Where(s => !s.Application.ToLower().Contains(searchMachineDto.Value.ToLower())).ToList(),
                                "doesn'tstartwith" => machineDetails.Where(s => !s.Application.ToLower().StartsWith(searchMachineDto.Value.ToLower())).ToList(),
                                "doesn'tendwith" => machineDetails.Where(s => !s.Application.ToLower().EndsWith(searchMachineDto.Value.ToLower())).ToList(),
                                _ => throw new NotSupportedException($"Operator '{searchMachineDto.Operator}' is not supported."),// Handle other operators as needed
                            };
                        }
                        break;
                    case "specificfeature":
                        {
                            filteredMachines = searchMachineDto.Operator.ToLower() switch
                            {

                                "equals" => machineDetails.Where(s => s.SpecificFeature.ToLower() == searchMachineDto.Value.ToLower()).ToList(),
                                "notequals" => machineDetails.Where(s => s.SpecificFeature.ToLower() != searchMachineDto.Value.ToLower()).ToList(),
                                "contains" => machineDetails.Where(s => s.SpecificFeature.ToLower().Contains(searchMachineDto.Value.ToLower())).ToList(),
                                "startswith" => machineDetails.Where(s => s.SpecificFeature.ToLower().StartsWith(searchMachineDto.Value.ToLower())).ToList(),
                                "endswith" => machineDetails.Where(s => s.SpecificFeature.ToLower().EndsWith(searchMachineDto.Value.ToLower())).ToList(),
                                "doesn'tcontain" => machineDetails.Where(s => !s.SpecificFeature.ToLower().Contains(searchMachineDto.Value.ToLower())).ToList(),
                                "doesn'tstartwith" => machineDetails.Where(s => !s.SpecificFeature.ToLower().StartsWith(searchMachineDto.Value.ToLower())).ToList(),
                                "doesn'tendwith" => machineDetails.Where(s => !s.SpecificFeature.ToLower().EndsWith(searchMachineDto.Value.ToLower())).ToList(),
                                _ => throw new NotSupportedException($"Operator '{searchMachineDto.Operator}' is not supported."),// Handle other operators as needed
                            };
                        } 
                        break;
                    case "controlsystem":
                        {
                            filteredMachines = searchMachineDto.Operator.ToLower() switch
                            {

                                "equals" => machineDetails.Where(s => s.ControlSystem.ToLower() == searchMachineDto.Value.ToLower()).ToList(),
                                "notequals" => machineDetails.Where(s => s.ControlSystem.ToLower() != searchMachineDto.Value.ToLower()).ToList(),
                                "contains" => machineDetails.Where(s => s.ControlSystem.ToLower().Contains(searchMachineDto.Value.ToLower())).ToList(),
                                "startswith" => machineDetails.Where(s => s.ControlSystem.ToLower().StartsWith(searchMachineDto.Value.ToLower())).ToList(),
                                "endswith" => machineDetails.Where(s => s.ControlSystem.ToLower().EndsWith(searchMachineDto.Value.ToLower())).ToList(),
                                "doesn'tcontain" => machineDetails.Where(s => !s.ControlSystem.ToLower().Contains(searchMachineDto.Value.ToLower())).ToList(),
                                "doesn'tstartwith" => machineDetails.Where(s => !s.ControlSystem.ToLower().StartsWith(searchMachineDto.Value.ToLower())).ToList(),
                                "doesn'tendwith" => machineDetails.Where(s => !s.ControlSystem.ToLower().EndsWith(searchMachineDto.Value.ToLower())).ToList(),
                                _ => throw new NotSupportedException($"Operator '{searchMachineDto.Operator}' is not supported."),// Handle other operators as needed
                            };
                        }
                        break;
                    case "machinetype":
                        {
                            filteredMachines = searchMachineDto.Operator.ToLower() switch
                            {

                                "equals" => machineDetails.Where(s => s.MachineType.ToLower() == searchMachineDto.Value.ToLower()).ToList(),
                                "notequals" => machineDetails.Where(s => s.MachineType.ToLower() != searchMachineDto.Value.ToLower()).ToList(),
                                "contains" => machineDetails.Where(s => s.MachineType.ToLower().Contains(searchMachineDto.Value.ToLower())).ToList(),
                                "startswith" => machineDetails.Where(s => s.MachineType.ToLower().StartsWith(searchMachineDto.Value.ToLower())).ToList(),
                                "endswith" => machineDetails.Where(s => s.MachineType.ToLower().EndsWith(searchMachineDto.Value.ToLower())).ToList(),
                                "doesn'tcontain" => machineDetails.Where(s => !s.MachineType.ToLower().Contains(searchMachineDto.Value.ToLower())).ToList(),
                                "doesn'tstartwith" => machineDetails.Where(s => !s.MachineType.ToLower().StartsWith(searchMachineDto.Value.ToLower())).ToList(),
                                "doesn'tendwith" => machineDetails.Where(s => !s.MachineType.ToLower().EndsWith(searchMachineDto.Value.ToLower())).ToList(),
                                _ => throw new NotSupportedException($"Operator '{searchMachineDto.Operator}' is not supported."),// Handle other operators as needed
                            };
                        }
                        break;
                }
                return filteredMachines;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        
        #region Machine Images
        public async Task<ResponseVM> AddUpdateMachineImages(List<MachineImagesUploadDTO> masterMachineImages)
        {
            try
            {
                foreach (var item in masterMachineImages)
                {
                    if (string.IsNullOrEmpty(item.Id))
                    {
                        var machineImages = new TblMachineImages()
                        {
                            id = Guid.NewGuid().ToString(),
                            machine_id = item.Machine_Id,
                            url = item.Url,
                            thumbnail_url = string.IsNullOrEmpty(item.Thumbnail_Url) ? string.Empty : item.Thumbnail_Url,
                            item_id = item.Item_Id,
                            file_name = item.file_name,
                            drive_id = item.Drive_Id,
                            image_size = item.Image_Size,
                            is_primary = item.Is_Primary,
                            is_active = item.Is_Active,
                            created_by = item.Modified_By,
                            deleted_by = string.Empty,
                            created_at = DateTimeOffset.Now                             
                        };
                        _context.TblMachineImages.Add(machineImages);
                    }
                    else
                    {
                        var machineImageData = await _context.TblMachineImages.FirstOrDefaultAsync(x => x.id == item.Id);
                        if (machineImageData is not null)
                        {
                            machineImageData.thumbnail_url = string.IsNullOrEmpty(item.Thumbnail_Url) ? string.Empty : item.Thumbnail_Url;
                            machineImageData.is_primary = item.Is_Primary;
                            machineImageData.is_active = item.Is_Active;
                            machineImageData.deleted_by = item.Modified_By;
                            machineImageData.deleted_at = DateTimeOffset.Now;
                            _context.Entry(machineImageData).State = EntityState.Modified;
                        }
                    }
                }

                await _context.SaveChangesAsync(); // Save changes once outside the loop

                return new ResponseVM(true, MessageConstants.SUCCESS, StatusCodes.Status200OK, MessageConstants.SUCCESS);
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        public async Task<ResponseVM> GetMachineImages(string machineId)
        {
            try
            {
                var machineImages = await _context.TblMachineImages
                                .Where(x => x.is_active == true && x.machine_id== machineId)
                                .Select(m => new GetMachineImagesDTO
                                {
                                    Id = m.id,
                                    Url = m.url,
                                    Thumbnail_Url = m.thumbnail_url,
                                    Drive_Id = m.drive_id,
                                    Item_Id = m.item_id,
                                    file_name = m.file_name,
                                    Image_Size = m.image_size,
                                    created_at = m.created_at,
                                    deleted_at = m.deleted_at,
                                    is_primary = m.is_primary,
                                    is_active = m.is_active
                                }).ToListAsync();

                return new ResponseVM(true, MessageConstants.SUCCESS, StatusCodes.Status200OK, JsonSerializer.Serialize(machineImages));

            }
            catch (System.Exception ex)
            {

                throw;
            }
        } 
        #endregion

    }
}
