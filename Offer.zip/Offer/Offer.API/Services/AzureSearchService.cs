﻿using Azure;
using Azure.Search.Documents;
using Azure.Search.Documents.Indexes;
using Azure.Search.Documents.Indexes.Models;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Offer.API.Models.OfferDTO;
using System;
using System.Net;
using System.Threading.Tasks;
using SearchIndexClient = Azure.Search.Documents.Indexes.SearchIndexClient;

namespace Offer.API.Services
{
    public class AzureSearchService : IAzureSearchService
    {
        private IConfiguration Configuration;
        private string EndPoint { get; }
        private string AdminKey { get; }
        private string ConnectionString { get; }
        private string AzureSearchURL { get; }
        private string AzureIndex { get; }
        private string AzureIndexer { get; }
        private string AzureDataSource { get; }
        private string AzureSearchView { get; }
        public AzureSearchService(IConfiguration configuration)
        {
            Configuration = configuration;
            AzureIndex = Configuration.GetSection("AzureConfigurations").GetSection("AzureIndex").Value;
            AzureIndexer = Configuration.GetSection("AzureConfigurations").GetSection("AzureIndexer").Value;
            AzureDataSource = Configuration.GetSection("AzureConfigurations").GetSection("AzureDataSource").Value;
            AzureSearchView = Configuration.GetSection("AzureConfigurations").GetSection("AzureSearchView").Value;
            EndPoint = Configuration.GetSection("AzureConfigurations").GetSection("AzureEndpoint").Value;
            AdminKey = Configuration.GetSection("AzureConfigurations").GetSection("AdminKey").Value;
            AzureSearchURL = Configuration.GetSection("AzureConfigurations").GetSection("AzureSearchURL").Value;
            ConnectionString = Configuration.GetConnectionString("AzureConnection");
        }
        private void CreateIndexAndIndexer()
        {

            SearchIndexClient indexClient = new SearchIndexClient(new Uri(EndPoint), new AzureKeyCredential(AdminKey));
            SearchIndexerClient indexerClient = new SearchIndexerClient(new Uri(EndPoint), new AzureKeyCredential(AdminKey));

            //Create Index
            Azure.Search.Documents.Indexes.FieldBuilder fieldBuilder = new Azure.Search.Documents.Indexes.FieldBuilder();
            var searchFields = fieldBuilder.Build(typeof(AzureProject));
            var searchIndex = new SearchIndex(AzureIndex, searchFields);


            try
            {
                //delete if already index exists
                CleanupSearchIndexClientResources(indexClient, searchIndex);
                indexClient.CreateOrUpdateIndex(searchIndex);

                //load the index documents
                Uri serviceEndpoint = new Uri(EndPoint);
                AzureKeyCredential credential = new AzureKeyCredential(AdminKey);
                SearchIndexClient adminClient = new SearchIndexClient(serviceEndpoint, credential);

                // Create a SearchClient to load and query documents
                SearchClient srchclient = new SearchClient(serviceEndpoint, searchIndex.Name, credential);


                //Create new data-source and map view or table from azure sql
                var dataSource =
                    new SearchIndexerDataSourceConnection(
                        AzureDataSource,
                        SearchIndexerDataSourceType.AzureSql,
                        ConnectionString,
                        new SearchIndexerDataContainer(AzureSearchView));

                indexerClient.CreateOrUpdateDataSourceConnection(dataSource);



                var schedule = new IndexingSchedule(TimeSpan.FromMinutes(30))
                {
                    StartTime = DateTimeOffset.Now
                };
                var parameters = new IndexingParameters()
                {
                    BatchSize = 100,
                    MaxFailedItems = 0,
                    MaxFailedItemsPerBatch = 0
                };
                var indexer = new SearchIndexer(AzureIndexer, AzureDataSource, AzureIndex)
                {
                    Description = "Data indexer",
                    Schedule = schedule,
                    Parameters = parameters,
                    FieldMappings =
                  {
                      new FieldMapping("project_Id") {TargetFieldName = "project_id"},
                      new FieldMapping("erp_Id") {TargetFieldName = "product_id"},
                      new FieldMapping("product_id") {TargetFieldName = "product_id"},
                       new FieldMapping("customer_name") {TargetFieldName = "customer_name"},
                       new FieldMapping("manager_name") {TargetFieldName = "manager_name"},
                      new FieldMapping("machine_name") {TargetFieldName = "machine_name"},
                      new FieldMapping("machine_type") {TargetFieldName = "machine_type"},
                  }
                };
                var suggester = new SearchSuggester("sg", new[] { "project_id", "customer_name", "product_id", "manager_name", "machine_name", "machine_type" });
                searchIndex.Suggesters.Add(suggester);
                //CleanupSearchIndexerClientResources(indexerClient, indexer);
                indexerClient.CreateOrUpdateIndexerAsync(indexer);

                try
                {
                    indexerClient.RunIndexerAsync(indexer.Name);
                }
                catch (Exception ex)
                {

                }
                //catch (CloudException e) when (e.Response.StatusCode == (HttpStatusCode)429)
                //{
                //    Console.WriteLine("Failed to run indexer: {0}", e.Response.Content);
                //}

            }
            catch (Exception ex)
            {

                throw ex;
            }

        }
        private static void CleanupSearchIndexClientResources(SearchIndexClient indexClient, SearchIndex index)
        {
            try
            {
                if (indexClient.GetIndex(index.Name) != null)
                {
                    indexClient.DeleteIndex(index.Name);
                }
            }
            catch (RequestFailedException e) when (e.Status == 404)
            {
                //if exception occurred and status is "Not Found", this is working as expected
                Console.WriteLine("Failed to find index and this is because it doesn't exist.");
            }
        }
        private static void CleanupSearchIndexerClientResources(SearchIndexerClient indexerClient, SearchIndexer indexer)
        {
            try
            {
                if (indexerClient.GetIndexer(indexer.Name) != null)
                {
                    indexerClient.ResetIndexer(indexer.Name);
                }
            }
            catch (RequestFailedException e) when (e.Status == 404)
            {
                //if exception occurred and status is "Not Found", this is working as expected
                Console.WriteLine("Failed to find indexer and this is because it doesn't exist.");
            }
        }

        public AzureGlobalSearchResponseDTO AzureGlobalSearch()
        {
            CreateIndexAndIndexer();
            var response = new AzureGlobalSearchResponseDTO()
            {
                Headers = new System.Collections.Generic.Dictionary<string, string>()
                {
                    { "Content-Type", "application/json" },
                    { "api-key", AdminKey }
                },

                RequestUrl = "https://slsearch.search.windows.net/indexes/" + $"{AzureIndex}/docs/search?api-version=2020-06-30",
                RequestAutocompleUrl = "https://slsearch.search.windows.net/indexes/" + $"{AzureIndex}/docs/autocomplete?search&api-version=2020-06-30",
                RequestBody = new System.Collections.Generic.Dictionary<string, string>()
                {
                    {"search","searchvalue"},
                    {"searchMode", "any"},
                     {"count","true"},
                    {"top", "100"}
                },
            };
            return response;
        }

    }
    public partial class AzureOffer
    {
        [SearchableField(IsFacetable = true, IsFilterable = true)]
        public string offer_id { get; set; }
        [SearchableField(IsFacetable = true, IsFilterable = true)]
        public string quote_type { get; set; }
        [SearchableField(IsFacetable = true, IsFilterable = true)]
        public string notes { get; set; }
        [SearchableField(IsFacetable = true, IsFilterable = true)]
        public string project_id { get; set; }
        [SearchableField(IsFacetable = true, IsFilterable = true)]
        public string status { get; set; }
        [SearchableField(IsFacetable = true, IsFilterable = true)]
        public string quote_template_type { get; set; }
        [SearchableField(IsFilterable = true)]
        public AzureService[] offerservice { get; set; }

    }
    public partial class AzureService
    {
        [SearchableField(IsFacetable = true, IsFilterable = true)]
        public string product_id { get; set; }
        //[SearchableField(IsFacetable = true, IsFilterable = true)]
        //public string service_id { get; set; }
        //[SearchableField(IsFacetable = true, IsFilterable = true)]
        //public string project_id { get; set; }
        //[SearchableField(IsFacetable = true, IsFilterable = true)]
        //public string offer_id { get; set; }
        //[SearchableField(IsFacetable = true, IsFilterable = true)]
        //public string service_type { get; set; }
        //[SearchableField(IsFacetable = true, IsFilterable = true)]
        //public string service_description { get; set; }
        //[SearchableField(IsFacetable = true, IsFilterable = true)]
        //public string service_location { get; set; }
        //[SearchableField(IsFacetable = true, IsFilterable = true)]
        //public string actual_hours { get; set; }
        //[SearchableField(IsFacetable = true, IsFilterable = true)]
        //public string is_active { get; set; }

        //[SearchableField(IsFacetable = true, IsFilterable = true)]
        //public string service_region { get; set; }
        //[SearchableField(IsFacetable = true, IsFilterable = true)]
        //public string start_date { get; set; }
        //[SearchableField(IsFacetable = true, IsFilterable = true)]
        //public string end_date { get; set; }
        //[SearchableField(IsFilterable =true)]
        public AzureMachine[] machine { get; set; }
    }
    public partial class AzureMachine
    {
        [SearchableField(IsFilterable = true, IsFacetable = true)]
        public string machine_name { get; set; }
        [SearchableField(IsFilterable = true, IsFacetable = true)]
        public string machine_type { get; set; }
        //[SearchableField(IsFacetable = true, IsFilterable = true)]
        //public string asset_id { get; set; }
        //[SearchableField(IsFacetable = true, IsFilterable = true)]
        //public string serial_number { get; set; }
        //[SearchableField(IsFacetable = true, IsFilterable = true)]
        //public string machine_description { get; set; }
        //[SearchableField(IsFacetable = true, IsFilterable = true)]
        //public string estimated_hours { get; set; }
        //[SearchableField(IsFacetable = true, IsFilterable = true)]
        //public string industry_type { get; set; }
        //[SearchableField(IsFacetable = true, IsFilterable = true)]
        //public string machine_location { get; set; }

    }
    public partial class AzureCustomer
    {
        [SearchableField(IsFilterable = true)]
        public string customer_name { get; set; }

        [SearchableField(IsFilterable = true, IsFacetable = true)]
        public string country_code { get; set; }

        [SearchableField(IsFilterable = true, IsFacetable = true)]
        public string city { get; set; }

        [SearchableField(IsFilterable = true, IsFacetable = true)]
        public string zipcode { get; set; }

        [SearchableField(IsFilterable = true, IsFacetable = true)]
        public string street { get; set; }
        [SearchableField(IsFilterable = true, IsFacetable = true)]
        public string phone_number { get; set; }
        [SearchableField(IsFilterable = true, IsFacetable = true)]
        public string language { get; set; }
    }
    public partial class AzureContact
    {
        [SearchableField(IsFilterable = true)]
        public string contact_id { get; set; }

        [SearchableField(IsFilterable = true, IsFacetable = true)]
        public string first_name { get; set; }

        [SearchableField(IsFilterable = true, IsFacetable = true)]
        public string last_name { get; set; }

        [SearchableField(IsFilterable = true, IsFacetable = true)]
        public string display_name { get; set; }

        [SearchableField(IsFilterable = true, IsFacetable = true)]
        public string title { get; set; }
        [SearchableField(IsFilterable = true, IsFacetable = true)]
        public string phone_number { get; set; }
        [SearchableField(IsFilterable = true, IsFacetable = true)]
        public string language { get; set; }
        [SearchableField(IsFilterable = true, IsFacetable = true)]
        public string department { get; set; }
    }
    public partial class AzureOrder
    {
        [SearchableField(IsFilterable = true)]
        public string order_id { get; set; }

        [SearchableField(IsFilterable = true)]
        public string status { get; set; }
    }
    public partial class AzureProject
    {
        [SearchableField(IsKey = true, IsFilterable = true, IsFacetable = true)]
        public string project_Id { get; set; }
        [SearchableField(IsFilterable = true, IsFacetable = true, IsSortable = true)]
        public string project_manager { get; set; }
        [SearchableField(IsFilterable = true, IsFacetable = true, IsSortable = true)]
        public string customer_name { get; set; }
        public AzureService[] service { get; set; }
    }
}
