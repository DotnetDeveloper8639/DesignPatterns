﻿using EventBus.Abstractions;
using EventBus.Events;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Identity.Web;
using Offer.API.DbContextClass;
using Offer.API.EntityModels;
using Offer.API.Helper;
using Offer.API.IntegrationEvents.Events;
using Offer.API.Models.OfferDTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace Offer.API.Services
{
    public class Service : RepositoryBase<TblService>, IService
    {
        private readonly Sch_Context _context;
        private readonly IHttpContextAccessor httpContextAccessor;
        private readonly IEventBus _messageBus;
        public IMasterMachineService _masterMachines;

        public Service(Sch_Context context
           , IHttpContextAccessor httpContextAccessor
           , IEventBus messageBus
           , IMasterMachineService masterMachines) : base(context)
        {
            _context = context;
            this.httpContextAccessor = httpContextAccessor;
            this._messageBus = messageBus;
            _masterMachines = masterMachines;
        }

        public async Task<string> CreateService(List<ServiceDTO> serviceDTO)
        {
            string Result = string.Empty;
            Dictionary<string,List<string>> newServicesAndMachinesId = new Dictionary<string,List<string>>();
            try
            {
                List<TblMachineCustomerAssociation> machineCustomerAssociationList = new();
                List<TblControlSystem> controlSystemList = new();
                List<TblSpecificFeature> specificFeatureList = new();
                List<TblMachineType> machineTypeList = new();
                List<TblApplication> applicationList = new();
                List<TblMachineCustomerAssociationTimeStamp> machineCustomerAssociationTimeStampList = new();
                List<TblControlSystemTimeStamp> controlSystemTimeStampList = new();
                List<TblSpecificFeatureTimeStamp> specificFeatureTimeStampList = new();
                List<TblMachineTypeTimeStamp> machineTypeTimeStampList = new();
                List<TblApplicationTimeStamp> applicationTimeStampList = new();
                List<TblMachineTypeAssociation> machineTypeAssociationList = new();
                List<TblMachineSpecificFeature> machineSpecificFeatureList = new();
                List<TblMachineApplication> machineApplicationList = new();
                List<TblMachineControlSystem> machineControlSystemList = new();
                List<TblMachineMediaMaster> machineMediaMasterList = new();
                string serviceId = string.Empty;
                for (var i = 0; i < serviceDTO.Count; i++)
                {
                    TblService tblService = new TblService();
                    if (i == 0)
                    {
                        serviceId = GenerateServiceId();
                    }
                    else
                    {
                        serviceId = GenerateServiceId(serviceId);
                    }

                    tblService.id = serviceId.ToString();
                    tblService.erp_wbs_id = serviceDTO[i].erp_wbs_id;
                    tblService.project_id = serviceDTO[i].project_id;
                    tblService.offer_id = serviceDTO[i].offer_id;
                    tblService.contact_id = serviceDTO[i].contact_id;
                    tblService.service_type = serviceDTO[i].service_type;
                    tblService.service_location = serviceDTO[i].service_location;
                    tblService.is_active = serviceDTO[i].is_active;
                    tblService.created_by = GetCurrentUserId();
                    tblService.modified_by = GetCurrentUserId();
                    tblService.actual_hours = serviceDTO[i].actual_hours;
                    tblService.total_estimated_hours = serviceDTO[i].total_estimated_hours;
                    tblService.start_date = serviceDTO[i].start_date;
                    tblService.end_date = serviceDTO[i].end_date;
                    tblService.service_description = serviceDTO[i].service_description;
                    tblService.service_region = serviceDTO[i].service_region;
                    tblService.is_ra_external = serviceDTO[i].is_ra_external;
                    tblService.external_ra_notes = serviceDTO[i].external_ra_notes;
                    tblService.service_kpi_id = _context.TblServiceKPI.FirstOrDefault()?.id ?? string.Empty;
                    tblService.created_at = DateTimeOffset.Now;
                    tblService.modified_at = DateTimeOffset.Now;
                    tblService.status = MachineStatus.NOT_STARTED;
                    _context.TblServices.Add(tblService);

                    #region Log Service AuditEntry
                    var projectId = _context.TblServices.Where(s => s.project_id == serviceDTO[i].project_id && s.offer_id == serviceDTO[i].offer_id).FirstOrDefault()?.project_id;
                    var offerId = _context.TblServices.Where(s => s.project_id == serviceDTO[i].project_id && s.offer_id == serviceDTO[i].offer_id).FirstOrDefault()?.offer_id;
                    TblAuditEntry tblServiceAuditEntry = new();
                    tblServiceAuditEntry.id = Guid.NewGuid().ToString();
                    tblServiceAuditEntry.project_id = projectId;
                    tblServiceAuditEntry.erp_project_id = _context.TblProjects.FirstOrDefault(p => p.id == projectId)?.erp_project_id ?? null;
                    tblServiceAuditEntry.offer_id = offerId;
                    tblServiceAuditEntry.service_id = serviceId.ToString();
                    tblServiceAuditEntry.action = "Create";
                    tblServiceAuditEntry.scope = "New Service " + serviceId.ToString() + " has been added";
                    tblServiceAuditEntry.created_at = DateTimeOffset.UtcNow;
                    tblServiceAuditEntry.user_id = _context.TblUser.FirstOrDefault(p => p.id == GetCurrentUserId())?.email_address ?? null;
                    tblServiceAuditEntry.affected_table = "TblService";
                    _context.TblAuditEntry.Add(tblServiceAuditEntry);
                    #endregion

                    // tblServiceList.Add(tblService);
                    _context.SaveChanges();
                    List<string> newMachines = new();
                    if (serviceDTO[i].Machine.Count != 0)
                    {
                        for (var j = 0; j < serviceDTO[i].Machine.Count; j++)
                        {
                            if (!string.IsNullOrEmpty(serviceDTO[i].Machine[j].id))
                            {
                                TblServiceMachine tblServiceMachine = new();
                                Guid guid = Guid.NewGuid();
                                tblServiceMachine.id = Convert.ToString(guid);
                                tblServiceMachine.service_id = serviceId.ToString();
                                tblServiceMachine.machine_id = serviceDTO[i].Machine[j].id;
                                tblServiceMachine.estimated_hours = serviceDTO[i].Machine[j].estimated_hours;
                                tblServiceMachine.created_at = DateTimeOffset.Now;
                                tblServiceMachine.modified_at = DateTimeOffset.Now;

                                _context.TblServiceMachines.Add(tblServiceMachine);
                                _context.SaveChanges();
                                newMachines.Add(Convert.ToString(guid));
                                #region Add Roadmap and Hazard details to machine
                                if (serviceDTO[i].is_risk_assessment == true)
                                {
                                    if (serviceDTO[i].Machine[j].roadmap_details != null)
                                    {
                                        var smId = _context.TblServiceMachines.Where(sm => sm.machine_id == serviceDTO[i].Machine[j].id && sm.service_id == tblService.id).FirstOrDefault();
                                        await CreateRoadmap(serviceDTO[i].Machine[j].roadmap_details, guid.ToString());
                                    }
                                }
                                if (serviceDTO[i].is_risk_reassessment == true)
                                {
                                    var smId = _context.TblServiceMachines.Where(sm => sm.machine_id == serviceDTO[i].Machine[j].id && sm.service_id == tblService.id).FirstOrDefault();
                                    var roadmaps = await GetAllMachineRoadmaps(serviceDTO[i].Machine[j].id);
                                    if (roadmaps.Any())
                                    {
                                        await RiskReAssessmentRoadmap(roadmaps, guid.ToString());
                                    }
                                }
                                #endregion
                                #region Log AuditEntry
                                TblAuditEntry tblAuditEntry = new();
                                tblAuditEntry.id = Guid.NewGuid().ToString();
                                tblAuditEntry.project_id = projectId;
                                tblAuditEntry.erp_project_id = _context.TblProjects.FirstOrDefault(p => p.id == projectId)?.erp_project_id ?? null;
                                tblAuditEntry.offer_id = offerId;
                                tblAuditEntry.service_id = serviceId.ToString();
                                tblAuditEntry.action = "Create";
                                tblAuditEntry.scope = "New Machine " + serviceDTO[i].Machine[j].machine_name + " has been added";
                                tblAuditEntry.created_at = DateTimeOffset.UtcNow;
                                tblAuditEntry.user_id = _context.TblUser.FirstOrDefault(p => p.id == GetCurrentUserId())?.email_address ?? null;
                                tblAuditEntry.affected_table = "TblMachine";
                                _context.TblAuditEntry.Add(tblAuditEntry);
                                _context.SaveChanges();
                                #endregion
                            }
                            else
                            {
                                TblMachine tblMachine = new();
                                TblMachineCustomerAssociation machineCustomerAssociation = new();
                                TblMachineCustomerAssociationTimeStamp machineCustomerAssociationTimeStamp = new();
                                TblControlSystemTimeStamp controlSystemTimeStamp = new();
                                TblSpecificFeatureTimeStamp specificFeatureTimeStamp = new();
                                TblMachineTypeTimeStamp machineTypeTimeStamp = new();
                                TblApplicationTimeStamp applicationTimeStamp = new();
                                TblMachineTypeAssociation machineTypeAssociation = new();
                                TblMachineSpecificFeature machineSpecificFeature = new();
                                TblMachineApplication machineApplication = new();
                                TblMachineControlSystem machineControlSystem = new();
                                var duplicateMachine = _context.TblMachines.Where(m => m.machine_name.ToLower() == serviceDTO[i].Machine[j].machine_name.ToLower()).FirstOrDefault();
                                if (duplicateMachine == null)
                                {
                                    Guid guidMachineId = Guid.NewGuid();
                                    GetMachineDto getMachine = new()
                                    {
                                        Id = Convert.ToString(guidMachineId),
                                        Asset_Number = serviceDTO[i].Machine[j].asset_id,
                                        Machine_Name = serviceDTO[i].Machine[j].machine_name,
                                        Serial_Number = serviceDTO[i].Machine[j].serial_number,
                                        Machine_Type = serviceDTO[i].Machine[j].machine_type,
                                        Description = serviceDTO[i].Machine[j].machine_description,
                                        Manufacturer = serviceDTO[i].Machine[j].Manufacturer,
                                        Model = serviceDTO[i].Machine[j].Model_Number
                                    };

                                    var machineStatus = await _masterMachines.CreateMasterMachine(getMachine);

                                    if (machineStatus)
                                    {
                                        TblServiceMachine tblServiceMachine = new();
                                        Guid guid = Guid.NewGuid();
                                        tblServiceMachine.id = Convert.ToString(guid);
                                        tblServiceMachine.service_id = serviceId.ToString();
                                        tblServiceMachine.machine_id = guidMachineId.ToString();
                                        tblServiceMachine.estimated_hours = tblMachine.estimated_hours;
                                        tblServiceMachine.created_at = DateTimeOffset.Now;
                                        tblServiceMachine.modified_at = DateTimeOffset.Now;

                                        //_context.TblMachines.Add(tblMachine);
                                        _context.TblServiceMachines.Add(tblServiceMachine);

                                        machineCustomerAssociation.id = Guid.NewGuid().ToString();
                                        machineCustomerAssociation.machine_id = Convert.ToString(guidMachineId);
                                        machineCustomerAssociation.customer_id = serviceDTO[i].Machine[j]?.Customer_Id;
                                        machineCustomerAssociation.segments = serviceDTO[i].Machine[j]?.IndustrySegment;

                                        machineCustomerAssociationTimeStamp.id = Guid.NewGuid().ToString();
                                        machineCustomerAssociationTimeStamp.machinecustomerassociation_id = machineCustomerAssociation.id;
                                        machineCustomerAssociationTimeStamp.created_at = DateTimeOffset.Now;
                                        machineCustomerAssociationTimeStamp.created_by = GetCurrentUserId();
                                        machineCustomerAssociationTimeStamp.modified_at = DateTimeOffset.Now;
                                        machineCustomerAssociationTimeStamp.modified_by = GetCurrentUserId();
                                        machineCustomerAssociationTimeStampList.Add(machineCustomerAssociationTimeStamp);
                                        machineCustomerAssociationList.Add(machineCustomerAssociation);

                                        for (int m = 0; m < serviceDTO[i].Machine[j].MachineMetadata.Count; m++)
                                        {
                                            for (int con = 0; con < serviceDTO[i].Machine[j].MachineMetadata[m].ControlSystem.Count; con++)
                                            {
                                                controlSystemTimeStamp.id = Guid.NewGuid().ToString();
                                                controlSystemTimeStamp.controlsystem_id = serviceDTO[i].Machine[j].MachineMetadata[m]?.ControlSystem[con];
                                                controlSystemTimeStamp.created_at = DateTimeOffset.Now;
                                                controlSystemTimeStamp.created_by = GetCurrentUserId();
                                                controlSystemTimeStamp.modified_at = DateTimeOffset.Now;
                                                controlSystemTimeStamp.modified_by = GetCurrentUserId();
                                                controlSystemTimeStampList.Add(controlSystemTimeStamp);

                                                machineControlSystem.id = Guid.NewGuid().ToString();
                                                machineControlSystem.machine_id = Convert.ToString(guidMachineId);
                                                machineControlSystem.controlsystem_id = serviceDTO[i].Machine[j].MachineMetadata[m]?.ControlSystem[con];
                                                machineControlSystem.created_at = DateTimeOffset.Now;
                                                machineControlSystem.created_by = GetCurrentUserId();
                                                machineControlSystem.modified_at = DateTimeOffset.Now;
                                                machineControlSystem.modified_by = GetCurrentUserId();
                                                machineControlSystemList.Add(machineControlSystem);
                                            }

                                            applicationTimeStamp.id = Guid.NewGuid().ToString();
                                            applicationTimeStamp.application_id = serviceDTO[i].Machine[j].MachineMetadata[m]?.Application;
                                            applicationTimeStamp.created_at = DateTimeOffset.Now;
                                            applicationTimeStamp.created_by = GetCurrentUserId();
                                            applicationTimeStamp.modified_at = DateTimeOffset.Now;
                                            applicationTimeStamp.modified_by = GetCurrentUserId();

                                            machineApplication.id = Guid.NewGuid().ToString();
                                            machineApplication.machine_id = Convert.ToString(guidMachineId);
                                            machineApplication.application_id = serviceDTO[i].Machine[j].MachineMetadata[m]?.Application;
                                            machineApplication.created_at = DateTimeOffset.Now;
                                            machineApplication.created_by = GetCurrentUserId();
                                            machineApplication.modified_at = DateTimeOffset.Now;
                                            machineApplication.modified_by = GetCurrentUserId();
                                            machineApplicationList.Add(machineApplication);
                                            applicationTimeStampList.Add(applicationTimeStamp);

                                            for (int spf = 0; spf < serviceDTO[i].Machine[j].MachineMetadata[m].SpecificFeature.Count; spf++)
                                            {
                                                specificFeatureTimeStamp.id = Guid.NewGuid().ToString();
                                                specificFeatureTimeStamp.specificfeature_id = serviceDTO[i].Machine[j].MachineMetadata[m]?.SpecificFeature[spf];
                                                specificFeatureTimeStamp.created_at = DateTimeOffset.Now;
                                                specificFeatureTimeStamp.created_by = GetCurrentUserId();
                                                specificFeatureTimeStamp.modified_at = DateTimeOffset.Now;
                                                specificFeatureTimeStamp.modified_by = GetCurrentUserId();

                                                machineSpecificFeature.id = Guid.NewGuid().ToString();
                                                machineSpecificFeature.machine_id = Convert.ToString(guidMachineId);
                                                machineSpecificFeature.specificfeature_id = serviceDTO[i].Machine[j].MachineMetadata[m]?.SpecificFeature[spf];
                                                machineSpecificFeature.created_at = DateTimeOffset.Now;
                                                machineSpecificFeature.created_by = GetCurrentUserId();
                                                machineSpecificFeature.modified_at = DateTimeOffset.Now;
                                                machineSpecificFeature.modified_by = GetCurrentUserId();
                                                machineSpecificFeatureList.Add(machineSpecificFeature);
                                                specificFeatureTimeStampList.Add(specificFeatureTimeStamp);
                                            }

                                            machineTypeTimeStamp.id = Guid.NewGuid().ToString();
                                            machineTypeTimeStamp.machinetype_id = serviceDTO[i].Machine[j].MachineMetadata[m]?.MachineType;
                                            machineTypeTimeStamp.created_at = DateTimeOffset.Now;
                                            machineTypeTimeStamp.created_by = GetCurrentUserId();
                                            machineTypeTimeStamp.modified_at = DateTimeOffset.Now;
                                            machineTypeTimeStamp.modified_by = GetCurrentUserId();

                                            machineTypeAssociation.id = Guid.NewGuid().ToString();
                                            machineTypeAssociation.machine_id = Convert.ToString(guidMachineId);
                                            machineTypeAssociation.machinetype_id = serviceDTO[i].Machine[j].MachineMetadata[m]?.MachineType;
                                            machineTypeAssociation.created_at = DateTimeOffset.Now;
                                            machineTypeAssociation.created_by = GetCurrentUserId();
                                            machineTypeAssociation.modified_at = DateTimeOffset.Now;
                                            machineTypeAssociation.modified_by = GetCurrentUserId();

                                            machineTypeAssociationList.Add(machineTypeAssociation);
                                            machineTypeTimeStampList.Add(machineTypeTimeStamp);
                                        }

                                        _context.TblMachineCustomerAssociation.AddRange(machineCustomerAssociationList);
                                        _context.TblMachineCustomerAssociationTimeStamp.AddRange(machineCustomerAssociationTimeStampList);
                                        _context.TblMachineTypeTimeStamp.AddRange(machineTypeTimeStampList);
                                        _context.TblSpecificFeatureTimeStamp.AddRange(specificFeatureTimeStampList);
                                        _context.TblApplicationTimeStamp.AddRange(applicationTimeStampList);
                                        _context.TblControlSystemTimeStamp.AddRange(controlSystemTimeStampList);
                                        _context.TblMachineTypeAssociation.AddRange(machineTypeAssociationList);
                                        _context.TblMachineSpecificFeature.AddRange(machineSpecificFeatureList);
                                        _context.TblMachineApplication.AddRange(machineApplicationList);
                                        _context.TblMachineControlSystem.AddRange(machineControlSystemList);
                                        _context.SaveChanges();
                                        newMachines.Add(Convert.ToString(guid));
                                        #region Add Roadmap and Hazard details to machine
                                        if (serviceDTO[i].is_risk_assessment == true)
                                        {
                                            if (serviceDTO[i].Machine[j].roadmap_details != null)
                                            {
                                                var smId = _context.TblServiceMachines.Where(sm => sm.machine_id == Convert.ToString(guidMachineId) && sm.service_id == tblService.id).FirstOrDefault();
                                                await CreateRoadmap(serviceDTO[i].Machine[j].roadmap_details, smId.id);
                                            }
                                        }
                                        if (serviceDTO[i].is_risk_reassessment == true)
                                        {
                                            var smId = _context.TblServiceMachines.Where(sm => sm.machine_id == Convert.ToString(guidMachineId) && sm.service_id == tblService.id).FirstOrDefault();
                                            var roadmaps = await GetAllMachineRoadmaps(serviceDTO[i].Machine[j].id);
                                            if (roadmaps.Any())
                                            {
                                                await RiskReAssessmentRoadmap(roadmaps, smId.id);
                                            }
                                        }
                                        #endregion
                                        #region Log AuditEntry
                                        TblAuditEntry tblAuditEntry = new();
                                        tblAuditEntry.id = Guid.NewGuid().ToString();
                                        tblAuditEntry.project_id = projectId;
                                        tblAuditEntry.erp_project_id = _context.TblProjects.FirstOrDefault(p => p.id == projectId)?.erp_project_id ?? null;
                                        tblAuditEntry.offer_id = offerId;
                                        tblAuditEntry.service_id = serviceId.ToString();
                                        tblAuditEntry.action = "Create";
                                        tblAuditEntry.scope = "New Machine " + serviceDTO[i].Machine[j].machine_name + " has been added";
                                        tblAuditEntry.created_at = DateTimeOffset.UtcNow;
                                        tblAuditEntry.user_id = _context.TblUser.FirstOrDefault(p => p.id == GetCurrentUserId())?.email_address ?? null;
                                        tblAuditEntry.affected_table = "TblMachine";
                                        _context.TblAuditEntry.Add(tblAuditEntry);
                                        _context.SaveChanges();
                                        #endregion
                                    }
                                }
                            }
                        }
                        newServicesAndMachinesId.Add(serviceId, newMachines);
                    }
                    else
                    {
                        TblServiceMachine tblServiceMachine = new();
                        tblServiceMachine.id = Guid.NewGuid().ToString();
                        tblServiceMachine.service_id = serviceId.ToString();
                        tblServiceMachine.machine_id = "00000000-0000-0000-0000-000000000000";
                        tblServiceMachine.created_at = DateTimeOffset.Now;
                        tblServiceMachine.modified_at = DateTimeOffset.Now;

                        _context.TblServiceMachines.Add(tblServiceMachine);
                        _context.SaveChanges();

                        newServicesAndMachinesId.Add(serviceId, null);
                    }
                }

                Result = "Service Created Successfully";

                #region Add Machine request to ERP

                var offer = (from offr in _context.TblOffers
                             join project in _context.TblProjects on offr.project_id equals project.id
                             join svc in _context.TblServices on offr.id equals svc.offer_id
                             join cust in _context.TblCustomers on project.customer_id equals cust.id
                             join offrContact in _context.TblContacts on offr.contact_id equals offrContact.contact_id
                             join projectContact in _context.TblContacts on project.contact_id equals projectContact.contact_id
                             //join serviceContact in _context.TblContacts on service.contact_id equals serviceContact.contact_id
                             where offr.id == serviceDTO.FirstOrDefault().offer_id
                             select new
                             {
                                 offerId = offr.id,
                                 projectId = offr.project_id,
                                 offer_contact_person = offrContact.display_name,
                                 offer_wbs_id = offr.WBSID,
                                 erp_project_id = project.erp_project_id,
                                 offer_status = offr.status,
                                 offer_contact_email = offrContact.email_address,
                                 offer_contact_number = offrContact.phone_number,
                                 offer_quote_type = offr.quote_type,
                                 offer_contact_id = offr.contact_id,
                                 project_contact_id = project.contact_id,
                                 companyCode = project.company_id
                             }).FirstOrDefault();

                var wbsDeleteObject = new WbsUpdateRequestEvent();
                if (offer is not null)
                {
                    wbsDeleteObject.Offer = new WbsUpdateRequestOffer();
                    wbsDeleteObject.Offer.ContactPerson = offer.offer_contact_person;
                    wbsDeleteObject.Offer.ERPProjectID = offer.erp_project_id;
                    wbsDeleteObject.Offer.Status = offer.offer_status;
                    wbsDeleteObject.Offer.ContactEmail = offer.offer_contact_email;
                    wbsDeleteObject.Offer.ContactNumber = offer.offer_contact_number;
                    wbsDeleteObject.Offer.OfferID = offer.offerId;
                    wbsDeleteObject.Offer.ProjectID = offer.projectId;
                    wbsDeleteObject.Offer.QuoteType = offer.offer_quote_type;
                    wbsDeleteObject.Offer.WBSID = offer.offer_wbs_id;

                    wbsDeleteObject.Offer.Services = new List<WbsUpdateRequestService>();

                    var serviceIds = newServicesAndMachinesId.Keys.ToList();

                    var serviceDetails = (from svc in _context.TblServices
                                          //join contact in _context.TblContacts on svc.contact_id equals contact.contact_id
                                          where serviceIds.Contains(svc.id)
                                          select new
                                          {
                                              contactEmail = string.Empty,//contact.email_address,
                                              region = svc.service_region,
                                              endDate = svc.end_date,
                                              startDate = svc.start_date,
                                              contactNumber = string.Empty,//contact.phone_number,
                                              contactPerson = string.Empty,//contact.display_name,
                                              description = svc.service_description,
                                              location = svc.service_location,
                                              serviceId = svc.id,
                                              serviceProductId = svc.service_type
                                          }).ToList();

                    foreach (var svc in serviceDetails)
                    {

                        var wbsService = new WbsUpdateRequestService();
                        var totalSumInHour = 0m;
                        var serviceProduct = svc.serviceProductId?.Split('-') ?? new List<string>().ToArray();

                        wbsService.Action = "ADD";
                        wbsService.ContactEmail = svc.contactEmail;
                        wbsService.Region = svc.region;
                        wbsService.EndDate = svc.endDate.Value;
                        wbsService.ContactNumber = svc.contactNumber;
                        wbsService.ContactPerson = svc.contactPerson;
                        wbsService.Description = svc.description;
                        wbsService.Location = svc.location;
                        wbsService.ServiceID = svc.serviceId;
                        wbsService.ServiceProductID = serviceProduct.Count() > 0 ? serviceProduct[0].Trim() : String.Empty;
                        wbsService.StartDate = svc.startDate.Value;
                        wbsService.Type = serviceProduct.Count() > 1 ? serviceProduct[1].Trim() : String.Empty;

                        var machineIdsToAdd = newServicesAndMachinesId[svc.serviceId];
                        var machineDetail = new WbsUpdateRequestMachineDetails();
                        machineDetail.Machines = new List<WbsUpdateMachine>();
                        if (machineIdsToAdd != null)
                        {
                            var machines = (from machine in _context.TblMachines
                                        join serviceMachine in _context.TblServiceMachines on machine.id equals serviceMachine.machine_id
                                        where machineIdsToAdd.Contains(serviceMachine.id)
                                        select new
                                        {
                                            machineName = machine.machine_name,
                                            assetNumber = machine.asset_id,
                                            description = machine.machine_description,
                                            estimatedHour = serviceMachine.estimated_hours,
                                            machineId = serviceMachine.id,
                                            serialNumber = machine.serial_number,
                                            type = machine.machine_type,
                                            wbsId = serviceMachine.erp_wbs_id
                                        }).ToList();
                            foreach (var machine in machines)
                            {
                                var wbsMachine = new WbsUpdateMachine();

                                totalSumInHour = machine.estimatedHour + totalSumInHour;

                                wbsMachine.MachineName = machine.machineName;
                                wbsMachine.Action = "ADD";
                                wbsMachine.AssetNumber = machine.assetNumber;
                                wbsMachine.Description = machine.description;
                                wbsMachine.EstimatedHours = machine.estimatedHour;
                                wbsMachine.MachineID = machine.machineId;
                                wbsMachine.Manufacturer = String.Empty;
                                wbsMachine.SerialNumber = machine.serialNumber;
                                wbsMachine.Type = machine.type;
                                wbsMachine.WBSID = machine.wbsId;

                                machineDetail.Machines.Add(wbsMachine);
                            }
                        }
                        wbsService.MachineDetails = machineDetail;
                        wbsService.TotalSumInHours = totalSumInHour;

                        wbsDeleteObject.Offer.Services.Add(wbsService);
                    }

                    var techincalHeader = new RequestTechnicalHeader()
                    {
                        TenantID = httpContextAccessor.HttpContext?.User?.GetTenantId() ?? String.Empty,
                        CompanyCode = offer.companyCode,
                        EmailAddress = httpContextAccessor.HttpContext?.User?.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Email)?.Value ?? String.Empty,
                        RequestID = Guid.NewGuid().ToString(),
                        Timestamp = DateTime.UtcNow
                    };


                    wbsDeleteObject.TopicName = "wbsrequest";
                    wbsDeleteObject.TechnicalHeader = techincalHeader;

                    _messageBus.PublishToQueue(wbsDeleteObject, true);
                }

                #endregion

            }
            catch (Exception ex)
            {
                Result = "Service Creation Failed";
            }

            return Result;
        }
        public async Task<string> AddMachines(List<MachineDTO> machineDTO)
        {
            string Result = string.Empty;

            var tblServiceMachinesList = new List<string>();
            List<TblMachineCustomerAssociation> machineCustomerAssociationList = new();
            List<TblControlSystem> controlSystemList = new();
            List<TblSpecificFeature> specificFeatureList = new();
            List<TblMachineType> machineTypeList = new();
            List<TblApplication> applicationList = new();
            List<TblMachineCustomerAssociationTimeStamp> machineCustomerAssociationTimeStampList = new();
            List<TblControlSystemTimeStamp> controlSystemTimeStampList = new();
            List<TblSpecificFeatureTimeStamp> specificFeatureTimeStampList = new();
            List<TblMachineTypeTimeStamp> machineTypeTimeStampList = new();
            List<TblApplicationTimeStamp> applicationTimeStampList = new();
            List<TblMachineTypeAssociation> machineTypeAssociationList = new();
            List<TblMachineSpecificFeature> machineSpecificFeatureList = new();
            List<TblMachineApplication> machineApplicationList = new();
            List<TblMachineControlSystem> machineControlSystemList = new();
            List<TblMachineMediaMaster> machineMediaMasterList = new();
            try
            {
                for (var i = 0; i < machineDTO.Count; i++)
                {
                    if (!string.IsNullOrEmpty(machineDTO[i].id))
                    {
                        TblServiceMachine tblServiceMachine = new TblServiceMachine();
                        Guid guid = Guid.NewGuid();
                        tblServiceMachine.id = Convert.ToString(guid);
                        tblServiceMachine.service_id = machineDTO[i].service_id;
                        tblServiceMachine.machine_id = machineDTO[i].id;
                        tblServiceMachine.estimated_hours = machineDTO[i].estimated_hours;
                        tblServiceMachine.created_at = DateTimeOffset.Now;
                        tblServiceMachine.modified_at = DateTimeOffset.Now;

                        tblServiceMachinesList.Add(Convert.ToString(guid));

                        _context.TblServiceMachines.Add(tblServiceMachine);
                        _context.SaveChanges();
                        #region Add Roadmap and Hazard details to machine
                        if (machineDTO[i].roadmap_details != null)
                        {
                            var smId = _context.TblServiceMachines.Where(sm => sm.machine_id == machineDTO[i].id && sm.service_id == machineDTO[i].service_id).FirstOrDefault();
                            await CreateRoadmap(machineDTO[i].roadmap_details, guid.ToString());
                        }
                        #endregion
                        #region Log AuditEntry
                        var projectId = _context.TblServices.Where(s => s.id == machineDTO[i].service_id).FirstOrDefault()?.project_id;
                        var offerId = _context.TblServices.Where(s => s.id == machineDTO[i].service_id).FirstOrDefault()?.offer_id;
                        TblAuditEntry tblAuditEntry = new();
                        tblAuditEntry.id = Guid.NewGuid().ToString();
                        tblAuditEntry.project_id = projectId;
                        tblAuditEntry.erp_project_id = _context.TblProjects.FirstOrDefault(p => p.id == projectId)?.erp_project_id ?? null;
                        tblAuditEntry.offer_id = offerId;
                        tblAuditEntry.service_id = machineDTO[i].service_id;
                        tblAuditEntry.action = "Create";
                        tblAuditEntry.scope = "New Machine " + machineDTO[i].machine_name + " has been added";
                        tblAuditEntry.created_at = DateTimeOffset.UtcNow;
                        tblAuditEntry.user_id = _context.TblUser.FirstOrDefault(p => p.id == GetCurrentUserId())?.email_address ?? null;
                        tblAuditEntry.affected_table = "TblMachine";
                        _context.TblAuditEntry.Add(tblAuditEntry);
                        _context.SaveChanges();
                        #endregion
                    }
                    else
                    {
                        TblMachine tblMachine = new TblMachine();
                        TblMachineCustomerAssociation machineCustomerAssociation = new();
                        TblMachineCustomerAssociationTimeStamp machineCustomerAssociationTimeStamp = new();
                        TblControlSystemTimeStamp controlSystemTimeStamp = new();
                        TblSpecificFeatureTimeStamp specificFeatureTimeStamp = new();
                        TblMachineTypeTimeStamp machineTypeTimeStamp = new();
                        TblApplicationTimeStamp applicationTimeStamp = new();
                        TblMachineTypeAssociation machineTypeAssociation = new();
                        TblMachineSpecificFeature machineSpecificFeature = new();
                        TblMachineApplication machineApplication = new();
                        TblMachineControlSystem machineControlSystem = new();

                        var duplicateMachine = _context.TblMachines.Where(m => m.machine_name.ToLower() == machineDTO[i].machine_name.ToLower()).FirstOrDefault();
                        if (duplicateMachine == null)
                        {
                            Guid guidMachineId = Guid.NewGuid();
                            GetMachineDto getMachine = new()
                            {
                                Id = Convert.ToString(guidMachineId),
                                Asset_Number = machineDTO[i].asset_id,
                                Machine_Name = machineDTO[i].machine_name,
                                Serial_Number = machineDTO[i].serial_number,
                                Machine_Type = machineDTO[i].machine_type,
                                Description = machineDTO[i].machine_description,
                                Manufacturer = machineDTO[i].Manufacturer,
                                Model = machineDTO[i].Model_Number
                            };

                            var machineStatus = await _masterMachines.CreateMasterMachine(getMachine);

                            if (machineStatus)
                            {

                                TblServiceMachine tblServiceMachine = new TblServiceMachine();
                                Guid guid = Guid.NewGuid();
                                tblServiceMachine.id = Convert.ToString(guid);
                                tblServiceMachine.service_id = machineDTO[i].service_id;
                                tblServiceMachine.machine_id = Convert.ToString(guidMachineId);
                                tblServiceMachine.estimated_hours = tblMachine.estimated_hours;
                                tblServiceMachine.created_at = DateTimeOffset.Now;
                                tblServiceMachine.modified_at = DateTimeOffset.Now;

                                tblServiceMachinesList.Add(Convert.ToString(guid));

                                //_context.TblMachines.Add(tblMachine);
                                _context.TblServiceMachines.Add(tblServiceMachine);

                                machineCustomerAssociation.id = Guid.NewGuid().ToString();
                                machineCustomerAssociation.machine_id = Convert.ToString(guidMachineId);
                                machineCustomerAssociation.customer_id = machineDTO[i]?.Customer_Id;
                                machineCustomerAssociation.segments = machineDTO[i]?.IndustrySegment;

                                machineCustomerAssociationTimeStamp.id = Guid.NewGuid().ToString();
                                machineCustomerAssociationTimeStamp.machinecustomerassociation_id = machineCustomerAssociation.id;
                                machineCustomerAssociationTimeStamp.created_at = DateTimeOffset.Now;
                                machineCustomerAssociationTimeStamp.created_by = GetCurrentUserId();
                                machineCustomerAssociationTimeStamp.modified_at = DateTimeOffset.Now;
                                machineCustomerAssociationTimeStamp.modified_by = GetCurrentUserId();
                                machineCustomerAssociationTimeStampList.Add(machineCustomerAssociationTimeStamp);
                                machineCustomerAssociationList.Add(machineCustomerAssociation);

                                for (int m = 0; m < machineDTO[i].MachineMetadata.Count; m++)
                                {
                                    for (int con = 0; con < machineDTO[i].MachineMetadata[m].ControlSystem.Count; con++)
                                    {
                                        controlSystemTimeStamp.id = Guid.NewGuid().ToString();
                                        controlSystemTimeStamp.controlsystem_id = machineDTO[i].MachineMetadata[m]?.ControlSystem[con];
                                        controlSystemTimeStamp.created_at = DateTimeOffset.Now;
                                        controlSystemTimeStamp.created_by = GetCurrentUserId();
                                        controlSystemTimeStamp.modified_at = DateTimeOffset.Now;
                                        controlSystemTimeStamp.modified_by = GetCurrentUserId();
                                        controlSystemTimeStampList.Add(controlSystemTimeStamp);

                                        machineControlSystem.id = Guid.NewGuid().ToString();
                                        machineControlSystem.machine_id = Convert.ToString(guid);
                                        machineControlSystem.controlsystem_id = machineDTO[i].MachineMetadata[m]?.ControlSystem[con];
                                        machineControlSystem.created_at = DateTimeOffset.Now;
                                        machineControlSystem.created_by = GetCurrentUserId();
                                        machineControlSystem.modified_at = DateTimeOffset.Now;
                                        machineControlSystem.modified_by = GetCurrentUserId();
                                        machineControlSystemList.Add(machineControlSystem);
                                    }

                                    applicationTimeStamp.id = Guid.NewGuid().ToString();
                                    applicationTimeStamp.application_id = machineDTO[i].MachineMetadata[m]?.Application;
                                    applicationTimeStamp.created_at = DateTimeOffset.Now;
                                    applicationTimeStamp.created_by = GetCurrentUserId();
                                    applicationTimeStamp.modified_at = DateTimeOffset.Now;
                                    applicationTimeStamp.modified_by = GetCurrentUserId();

                                    machineApplication.id = Guid.NewGuid().ToString();
                                    machineApplication.machine_id = Convert.ToString(guidMachineId);
                                    machineApplication.application_id = machineDTO[i].MachineMetadata[m]?.Application;
                                    machineApplication.created_at = DateTimeOffset.Now;
                                    machineApplication.created_by = GetCurrentUserId();
                                    machineApplication.modified_at = DateTimeOffset.Now;
                                    machineApplication.modified_by = GetCurrentUserId();
                                    machineApplicationList.Add(machineApplication);
                                    applicationTimeStampList.Add(applicationTimeStamp);

                                    for (int spf = 0; spf < machineDTO[i].MachineMetadata[m].SpecificFeature.Count; spf++)
                                    {
                                        specificFeatureTimeStamp.id = Guid.NewGuid().ToString();
                                        specificFeatureTimeStamp.specificfeature_id = machineDTO[i].MachineMetadata[m]?.SpecificFeature[spf];
                                        specificFeatureTimeStamp.created_at = DateTimeOffset.Now;
                                        specificFeatureTimeStamp.created_by = GetCurrentUserId();
                                        specificFeatureTimeStamp.modified_at = DateTimeOffset.Now;
                                        specificFeatureTimeStamp.modified_by = GetCurrentUserId();

                                        machineSpecificFeature.id = Guid.NewGuid().ToString();
                                        machineSpecificFeature.machine_id = Convert.ToString(guidMachineId);
                                        machineSpecificFeature.specificfeature_id = machineDTO[i].MachineMetadata[m]?.SpecificFeature[spf];
                                        machineSpecificFeature.created_at = DateTimeOffset.Now;
                                        machineSpecificFeature.created_by = GetCurrentUserId();
                                        machineSpecificFeature.modified_at = DateTimeOffset.Now;
                                        machineSpecificFeature.modified_by = GetCurrentUserId();
                                        machineSpecificFeatureList.Add(machineSpecificFeature);
                                        specificFeatureTimeStampList.Add(specificFeatureTimeStamp);
                                    }

                                    machineTypeTimeStamp.id = Guid.NewGuid().ToString();
                                    machineTypeTimeStamp.machinetype_id = machineDTO[i].MachineMetadata[m]?.MachineType;
                                    machineTypeTimeStamp.created_at = DateTimeOffset.Now;
                                    machineTypeTimeStamp.created_by = GetCurrentUserId();
                                    machineTypeTimeStamp.modified_at = DateTimeOffset.Now;
                                    machineTypeTimeStamp.modified_by = GetCurrentUserId();

                                    machineTypeAssociation.id = Guid.NewGuid().ToString();
                                    machineTypeAssociation.machine_id = Convert.ToString(guidMachineId);
                                    machineTypeAssociation.machinetype_id = machineDTO[i].MachineMetadata[m]?.MachineType;
                                    machineTypeAssociation.created_at = DateTimeOffset.Now;
                                    machineTypeAssociation.created_by = GetCurrentUserId();
                                    machineTypeAssociation.modified_at = DateTimeOffset.Now;
                                    machineTypeAssociation.modified_by = GetCurrentUserId();

                                    machineTypeAssociationList.Add(machineTypeAssociation);
                                    machineTypeTimeStampList.Add(machineTypeTimeStamp);
                                }
                                _context.TblMachineCustomerAssociation.AddRange(machineCustomerAssociationList);
                                _context.TblMachineCustomerAssociationTimeStamp.AddRange(machineCustomerAssociationTimeStampList);
                                _context.TblMachineTypeTimeStamp.AddRange(machineTypeTimeStampList);
                                _context.TblSpecificFeatureTimeStamp.AddRange(specificFeatureTimeStampList);
                                _context.TblApplicationTimeStamp.AddRange(applicationTimeStampList);
                                _context.TblControlSystemTimeStamp.AddRange(controlSystemTimeStampList);
                                _context.TblMachineTypeAssociation.AddRange(machineTypeAssociationList);
                                _context.TblMachineSpecificFeature.AddRange(machineSpecificFeatureList);
                                _context.TblMachineApplication.AddRange(machineApplicationList);
                                _context.TblMachineControlSystem.AddRange(machineControlSystemList);
                                _context.SaveChanges();
                                #region Add Roadmap and Hazard details to machine
                                if (machineDTO[i].roadmap_details != null)
                                {
                                    var smId = _context.TblServiceMachines.Where(sm => sm.machine_id == tblMachine.id && sm.service_id == machineDTO[i].service_id).FirstOrDefault();
                                    await CreateRoadmap(machineDTO[i].roadmap_details, guid.ToString());
                                }
                                #endregion
                                #region Log AuditEntry
                                var projectId = _context.TblServices.Where(s => s.id == machineDTO[i].service_id).FirstOrDefault()?.project_id;
                                var offerId = _context.TblServices.Where(s => s.id == machineDTO[i].service_id).FirstOrDefault()?.offer_id;
                                TblAuditEntry tblAuditEntry = new();
                                tblAuditEntry.id = Guid.NewGuid().ToString();
                                tblAuditEntry.project_id = projectId;
                                tblAuditEntry.erp_project_id = _context.TblProjects.FirstOrDefault(p => p.id == projectId)?.erp_project_id ?? null;
                                tblAuditEntry.offer_id = offerId;
                                tblAuditEntry.service_id = machineDTO[i].service_id;
                                tblAuditEntry.action = "Create";
                                tblAuditEntry.scope = "New Machine " + machineDTO[i].machine_name + " has been added";
                                tblAuditEntry.created_at = DateTimeOffset.UtcNow;
                                tblAuditEntry.user_id = _context.TblUser.FirstOrDefault(p => p.id == GetCurrentUserId())?.email_address ?? null;
                                tblAuditEntry.affected_table = "TblMachine";
                                _context.TblAuditEntry.Add(tblAuditEntry);
                                _context.SaveChanges();
                                #endregion
                            }
                        }
                    }

                }
                Result = "Machine added successfully";

                #region Add Machine request to ERP

                var offer = (from offr in _context.TblOffers
                             join project in _context.TblProjects on offr.project_id equals project.id
                             join svc in _context.TblServices on offr.id equals svc.offer_id
                             join cust in _context.TblCustomers on project.customer_id equals cust.id
                             join offrContact in _context.TblContacts on offr.contact_id equals offrContact.contact_id
                             join projectContact in _context.TblContacts on project.contact_id equals projectContact.contact_id
                             //join serviceContact in _context.TblContacts on service.contact_id equals serviceContact.contact_id
                             where svc.id == machineDTO.FirstOrDefault().service_id
                             select new
                             {
                                 offerId = offr.id,
                                 projectId = offr.project_id,
                                 offer_contact_person = offrContact.display_name,
                                 offer_wbs_id = offr.WBSID,
                                 erp_project_id = project.erp_project_id,
                                 offer_status = offr.status,
                                 offer_contact_email = offrContact.email_address,
                                 offer_contact_number = offrContact.phone_number,
                                 offer_quote_type = offr.quote_type,
                                 offer_contact_id = offr.contact_id,
                                 project_contact_id = project.contact_id,
                                 companyCode = project.company_id
                             }).FirstOrDefault();

                var wbsDeleteObject = new WbsUpdateRequestEvent();
                if (offer is not null)
                {
                    wbsDeleteObject.Offer = new WbsUpdateRequestOffer();
                    wbsDeleteObject.Offer.ContactPerson = offer.offer_contact_person;
                    wbsDeleteObject.Offer.ERPProjectID = offer.erp_project_id;
                    wbsDeleteObject.Offer.Status = offer.offer_status;
                    wbsDeleteObject.Offer.ContactEmail = offer.offer_contact_email;
                    wbsDeleteObject.Offer.ContactNumber = offer.offer_contact_number;
                    wbsDeleteObject.Offer.OfferID = offer.offerId;
                    wbsDeleteObject.Offer.ProjectID = offer.projectId;
                    wbsDeleteObject.Offer.QuoteType = offer.offer_quote_type;
                    wbsDeleteObject.Offer.WBSID = offer.offer_wbs_id;

                    wbsDeleteObject.Offer.Services = new List<WbsUpdateRequestService>();

                    var serviceIds = machineDTO.Select(m => m.service_id).Distinct().ToList();

                    var serviceDetails = (from svc in _context.TblServices
                                              //join contact in _context.TblContacts on svc.contact_id equals contact.contact_id
                                          where serviceIds.Contains(svc.id)
                                          select new
                                          {
                                              contactEmail = string.Empty,//contact.email_address,
                                              region = svc.service_region,
                                              endDate = svc.end_date,
                                              startDate = svc.start_date,
                                              contactNumber = string.Empty,//contact.phone_number,
                                              contactPerson = string.Empty,//contact.display_name,
                                              description = svc.service_description,
                                              location = svc.service_location,
                                              serviceId = svc.id,
                                              serviceProductId = svc.service_type
                                          }).ToList();

                    foreach (var svc in serviceDetails)
                    {

                        var wbsService = new WbsUpdateRequestService();
                        var totalSumInHour = 0m;
                        var serviceProduct = svc.serviceProductId?.Split('-') ?? new List<string>().ToArray();

                        wbsService.Action = "NONE";
                        wbsService.ContactEmail = svc.contactEmail;
                        wbsService.Region = svc.region;
                        wbsService.EndDate = svc.endDate.Value;
                        wbsService.ContactNumber = svc.contactNumber;
                        wbsService.ContactPerson = svc.contactPerson;
                        wbsService.Description = svc.description;
                        wbsService.Location = svc.location;
                        wbsService.ServiceID = svc.serviceId;
                        wbsService.ServiceProductID = serviceProduct.Count() > 0 ? serviceProduct[0].Trim() : String.Empty;
                        wbsService.StartDate = svc.startDate.Value;
                        wbsService.Type = serviceProduct.Count() > 1 ? serviceProduct[1].Trim() : String.Empty;

                        //var machineIdsToAdd = tblServiceMachinesList.Select(sm => sm.id).ToList();

                        var machines = (from machine in _context.TblMachines
                                        join serviceMachine in _context.TblServiceMachines on machine.id equals serviceMachine.machine_id
                                        where tblServiceMachinesList.Contains(serviceMachine.id)
                                        select new
                                        {
                                            machineName = machine.machine_name,
                                            assetNumber = machine.asset_id,
                                            description = machine.machine_description,
                                            estimatedHour = serviceMachine.estimated_hours,
                                            machineId = serviceMachine.id,
                                            serialNumber = machine.serial_number,
                                            type = machine.machine_type,
                                            wbsId = serviceMachine.erp_wbs_id
                                        }).ToList();

                        var machineDetail = new WbsUpdateRequestMachineDetails();
                        machineDetail.Machines = new List<WbsUpdateMachine>();

                        foreach (var machine in machines)
                        {
                            var wbsMachine = new WbsUpdateMachine();

                            totalSumInHour = machine.estimatedHour + totalSumInHour;

                            wbsMachine.MachineName = machine.machineName;
                            wbsMachine.Action = "ADD";
                            wbsMachine.AssetNumber = machine.assetNumber;
                            wbsMachine.Description = machine.description;
                            wbsMachine.EstimatedHours = machine.estimatedHour;
                            wbsMachine.MachineID = machine.machineId;
                            wbsMachine.Manufacturer = String.Empty;
                            wbsMachine.SerialNumber = machine.serialNumber;
                            wbsMachine.Type = machine.type;
                            wbsMachine.WBSID = machine.wbsId;

                            machineDetail.Machines.Add(wbsMachine);
                        }

                        wbsService.MachineDetails = machineDetail;
                        wbsService.TotalSumInHours = totalSumInHour;

                        wbsDeleteObject.Offer.Services.Add(wbsService);
                    }

                    var techincalHeader = new RequestTechnicalHeader()
                    {
                        TenantID = httpContextAccessor.HttpContext?.User?.GetTenantId() ?? String.Empty,
                        CompanyCode = offer.companyCode,
                        EmailAddress = httpContextAccessor.HttpContext?.User?.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Email)?.Value ?? String.Empty,
                        RequestID = Guid.NewGuid().ToString(),
                        Timestamp = DateTime.UtcNow
                    };


                    wbsDeleteObject.TopicName = "wbsrequest";
                    wbsDeleteObject.TechnicalHeader = techincalHeader;

                    _messageBus.PublishToQueue(wbsDeleteObject, true);
                }

                #endregion

            }
            catch (Exception ex)
            {
                Result = "Failed to add machines";
            }

            return Result;
        }
        public async Task<bool> CreateRoadmap(List<RoadMapMasterDTO> roadmapList, string servicemachineId)
        {
            var totalSteps = 0;
            var answeredSteps = 0;
            var roadmapProgress = 0;
            try
            {
                for (int raodmaps = 0; raodmaps < roadmapList.Count; raodmaps++)
                {
                    var roadmapData = await GetRoadmapDetailsById(roadmapList[raodmaps].RoadMapMasterId);
                    if (roadmapData != null)
                    {
                        TblRoadmapMaster rm = new();
                        rm.roadmap_id = Guid.NewGuid().ToString();
                        rm.roadmap_name = roadmapData.RoadMapName;
                        rm.iscustom = true;
                        rm.user_id = GetCurrentUserId();
                        rm.created_at = DateTimeOffset.UtcNow;
                        rm.created_by = GetCurrentUserId();
                        rm.modified_at = DateTimeOffset.UtcNow;
                        rm.modified_by = GetCurrentUserId();

                        TblMachineRoadmap machineRoadmap = new();
                        machineRoadmap.id = Guid.NewGuid().ToString();
                        machineRoadmap.service_machine_id = servicemachineId;
                        machineRoadmap.roadmap_id = rm.roadmap_id;
                        machineRoadmap.istype = "RRA";
                        machineRoadmap.created_at = DateTimeOffset.UtcNow;
                        machineRoadmap.created_by = GetCurrentUserId();
                        machineRoadmap.modified_at = DateTimeOffset.UtcNow;
                        machineRoadmap.modified_by = GetCurrentUserId();

                        TblProjectRoadmapAssociation roadmapAssociation = new();
                        roadmapAssociation.id = Guid.NewGuid().ToString();
                        roadmapAssociation.project_id = roadmapData.Project_Id;
                        roadmapAssociation.roadmap_id = rm.roadmap_id;
                        roadmapAssociation.created_at = DateTimeOffset.UtcNow;
                        #region Log AuditEntry
                        TblAuditEntry tblAuditEntry = new();
                        tblAuditEntry.id = Guid.NewGuid().ToString();
                        tblAuditEntry.project_id = roadmapData.Project_Id;
                        tblAuditEntry.erp_project_id = _context.TblProjects.FirstOrDefault(p => p.id == roadmapData.Project_Id)?.erp_project_id ?? null;
                        tblAuditEntry.action = "Create";
                        tblAuditEntry.scope = "New Roadmap " + roadmapData.RoadMapName + " has been added";
                        tblAuditEntry.created_at = DateTimeOffset.UtcNow;
                        tblAuditEntry.user_id = _context.TblUser.FirstOrDefault(p => p.id == GetCurrentUserId())?.email_address ?? null;
                        tblAuditEntry.affected_table = "TblRoadmapMaster";
                        _context.TblAuditEntry.Add(tblAuditEntry);
                        #endregion
                        _context.TblRoadmapMaster.Add(rm);
                        _context.TblMachineRoadmap.Add(machineRoadmap);
                        _context.TblProjectRoadmapAssociation.Add(roadmapAssociation);
                        _context.SaveChanges();
                        
                        for (int s = 0; s < roadmapData.RoadMapSections.Count; s++)
                        {
                            TblRoadmapSection rs = new();
                            rs.roadmap_id = rm.roadmap_id;
                            rs.id = Guid.NewGuid().ToString();
                            rs.section = roadmapData.RoadMapSections[s].SectionName;
                            rs.created_at = DateTimeOffset.UtcNow;
                            rs.created_by = GetCurrentUserId();
                            rs.modified_at = DateTimeOffset.UtcNow;
                            rs.modified_by = GetCurrentUserId();

                            _context.TblRoadmapSection.Add(rs);
                            _context.SaveChanges();
                            for (int sb = 0; sb < roadmapData.RoadMapSections[s].RoadMapSubSection.Count; sb++)
                            {
                                TblRoadmapSubSectionMster submaster = new();

                                submaster.id = Guid.NewGuid().ToString();
                                submaster.Sub_Section = roadmapData.RoadMapSections[s].RoadMapSubSection[sb].SubSectionName;
                                submaster.section_id = rs.id;
                                submaster.created_at = DateTimeOffset.UtcNow;
                                submaster.created_by = GetCurrentUserId();
                                submaster.modified_at = DateTimeOffset.UtcNow;
                                submaster.modified_by = GetCurrentUserId();

                                _context.TblRoadmapSubSectionMster.Add(submaster);
                                _context.SaveChanges();
                                for (int stm = 0; stm < roadmapData.RoadMapSections[s].RoadMapSubSection[sb].StepMaster.Count; stm++)
                                {
                                    TblStepMaster sm = new();
                                    TblServiceMachineSteps servicemsteps = new();
                                    TblStepMachineAssociation stepMachineAssociation = new();
                                    #region Creating new step and Adding answers to the step
                                    sm.step_id = Guid.NewGuid().ToString();
                                    sm.roadmap_section_id = submaster.id;
                                    sm.step_body = roadmapData.RoadMapSections[s].RoadMapSubSection[sb].StepMaster[stm].StepBody;
                                    sm.step_notes = roadmapData.RoadMapSections[s].RoadMapSubSection[sb].StepMaster[stm].Notes;
                                    sm.padlock = false;
                                    sm.created_at = DateTimeOffset.UtcNow;
                                    sm.created_by = GetCurrentUserId();
                                    sm.modified_at = DateTimeOffset.UtcNow;
                                    sm.modified_by = GetCurrentUserId();

                                    stepMachineAssociation.id = Guid.NewGuid().ToString();
                                    stepMachineAssociation.servicemachine_id = servicemachineId;
                                    stepMachineAssociation.step_id = sm.step_id;
                                    stepMachineAssociation.created_at = DateTimeOffset.UtcNow;

                                    _context.TblStepMaster.Add(sm);
                                    _context.TblStepMachineAssociation.Add(stepMachineAssociation);
                                    _context.SaveChanges();

                                    ///Count total steps for Roadmap
                                    totalSteps++;
                                    if (roadmapData.IsSelected == true)
                                    {
                                        for (int ans = 0; ans < roadmapData.RoadMapSections[s].RoadMapSubSection[sb].StepMaster[stm].Answers.Count; ans++)
                                        {
                                            if (roadmapData.RoadMapSections[s].RoadMapSubSection[sb].StepMaster[stm].Answers[ans].HazardDetails.Any())
                                            {
                                                servicemsteps.service_machine_steps_id = Guid.NewGuid().ToString();
                                                servicemsteps.step_id = sm.step_id;
                                                servicemsteps.not_applicable = false;
                                                servicemsteps.compliant = false;
                                                servicemsteps.hazard = true;
                                                servicemsteps.servicemachine_id = servicemachineId;
                                                servicemsteps.user_id = GetCurrentUserId();
                                                servicemsteps.ispreferred = true;
                                                servicemsteps.created_at = DateTimeOffset.UtcNow;
                                                servicemsteps.created_by = GetCurrentUserId();
                                                servicemsteps.modified_at = DateTimeOffset.UtcNow;
                                                servicemsteps.modified_by = GetCurrentUserId();

                                                _context.TblServiceMachineSteps.Add(servicemsteps);
                                                _context.SaveChanges();
                                                answeredSteps++;
                                                if (roadmapData.RoadMapSections[s].RoadMapSubSection[sb].StepMaster[stm].Answers[ans].HazardDetails != null)
                                                {
                                                    foreach (var hazards in roadmapData.RoadMapSections[s].RoadMapSubSection[sb].StepMaster[stm].Answers[ans].HazardDetails)
                                                    {
                                                        TblMachineHazards machineHazards = new();
                                                        TblHazardType hazardTypes = new();
                                                        List<TblHazardSource> hazardSourceList = new();
                                                        List<TblHazardConsequences> hazardConsequencesList = new();
                                                        var hazardDetails = await GethazardDetailsById(hazards.Id);
                                                        if (hazardDetails != null)
                                                        {
                                                            machineHazards.id = Guid.NewGuid().ToString();
                                                            machineHazards.name = hazardDetails.Name;
                                                            machineHazards.initial_hazard = hazardDetails.Initial_hazard;
                                                            machineHazards.counter_measure = hazardDetails.Counter_measure;
                                                            machineHazards.service_machine_steps_id = servicemsteps.service_machine_steps_id;
                                                            machineHazards.hazard_status = "Yet to Start";
                                                            machineHazards.created_at = DateTimeOffset.UtcNow;
                                                            machineHazards.created_by = GetCurrentUserId();
                                                            machineHazards.modified_at = DateTimeOffset.UtcNow;
                                                            machineHazards.modified_by = GetCurrentUserId();

                                                            _context.TblMachineHazards.Add(machineHazards);
                                                            _context.SaveChanges();

                                                            TblPerformanceLevelRating levelRating = new();
                                                            levelRating.id = Guid.NewGuid().ToString();
                                                            levelRating.PLR = hazardDetails.PLR;
                                                            levelRating.machine_hazard_id = machineHazards.id;
                                                            levelRating.category = hazardDetails.Category;
                                                            levelRating.created_at = DateTimeOffset.UtcNow;
                                                            levelRating.created_by = GetCurrentUserId();
                                                            levelRating.modified_at = DateTimeOffset.UtcNow;
                                                            levelRating.modified_by = GetCurrentUserId();

                                                            _context.TblPerformanceLevelRating.Add(levelRating);
                                                            _context.SaveChanges();

                                                            if (hazardDetails.HazardMedia != null)
                                                            {
                                                                for (int hazmed = 0; hazmed < hazardDetails.HazardMedia.Count; hazmed++)
                                                                {
                                                                    TblHazardMedia media = new();
                                                                    media.id = Guid.NewGuid().ToString();
                                                                    media.machine_hazard_id = machineHazards.id;
                                                                    media.type = hazardDetails.HazardMedia[hazmed].Type;
                                                                    media.url = hazardDetails.HazardMedia[hazmed].URL;
                                                                    media.name = hazardDetails.HazardMedia[hazmed].FileName;
                                                                    media.drive_id = hazardDetails.HazardMedia[hazmed].DriveId != null ? hazardDetails.HazardMedia[hazmed].DriveId.Trim() : null;
                                                                    media.item_id = hazardDetails.HazardMedia[hazmed].ItemId != null ? hazardDetails.HazardMedia[hazmed].ItemId.Trim() : null;
                                                                    media.image_size = hazardDetails.HazardMedia[hazmed].Image_Size;
                                                                    media.created_at = DateTimeOffset.UtcNow;
                                                                    media.created_by = GetCurrentUserId();
                                                                    media.modified_at = DateTimeOffset.UtcNow;
                                                                    media.modified_by = GetCurrentUserId();

                                                                    _context.TblHazardMedia.Add(media);
                                                                    _context.SaveChanges();
                                                                }
                                                            }

                                                            if (hazardDetails.HazardType != null)
                                                            {
                                                                for (int haztyp = 0; haztyp < hazardDetails.HazardType.Count; haztyp++)
                                                                {
                                                                    hazardTypes.id = Guid.NewGuid().ToString();
                                                                    hazardTypes.type = hazardDetails.HazardType[haztyp].HazardTypeName;
                                                                    hazardTypes.hazard_id = machineHazards.id;
                                                                    hazardTypes.created_at = DateTimeOffset.UtcNow;
                                                                    hazardTypes.created_by = GetCurrentUserId();
                                                                    hazardTypes.modified_at = DateTimeOffset.UtcNow;
                                                                    hazardTypes.modified_by = GetCurrentUserId();

                                                                    _context.TblHazardType.Add(hazardTypes);
                                                                    _context.SaveChanges();

                                                                    if (hazardDetails.HazardType[haztyp].HazardSources != null)
                                                                    {
                                                                        for (int hazsor = 0; hazsor < hazardDetails.HazardType[haztyp].HazardSources.Count; hazsor++)
                                                                        {
                                                                            TblHazardSource hazardSource = new();
                                                                            hazardSource.id = Guid.NewGuid().ToString();
                                                                            hazardSource.source = hazardDetails.HazardType[haztyp].HazardSources[hazsor].Source;
                                                                            hazardSource.hazard_type_id = hazardTypes.id;
                                                                            hazardSource.created_at = DateTimeOffset.UtcNow;
                                                                            hazardSource.created_by = GetCurrentUserId();
                                                                            hazardSource.modified_at = DateTimeOffset.UtcNow;
                                                                            hazardSource.modified_by = GetCurrentUserId();

                                                                            hazardSourceList.Add(hazardSource);
                                                                        }
                                                                    }
                                                                    if (hazardDetails.HazardType[haztyp].HazardConsequences != null)
                                                                    {
                                                                        for (int hazcon = 0; hazcon < hazardDetails.HazardType[haztyp].HazardConsequences.Count; hazcon++)
                                                                        {
                                                                            TblHazardConsequences hazardConsequences = new();
                                                                            hazardConsequences.id = Guid.NewGuid().ToString();
                                                                            hazardConsequences.consequence = hazardDetails.HazardType[haztyp].HazardConsequences[hazcon].Consequences;
                                                                            hazardConsequences.hazard_type_id = hazardTypes.id;
                                                                            hazardConsequences.created_at = DateTimeOffset.UtcNow;
                                                                            hazardConsequences.created_by = GetCurrentUserId();
                                                                            hazardConsequences.modified_at = DateTimeOffset.UtcNow;
                                                                            hazardConsequences.modified_by = GetCurrentUserId();

                                                                            hazardConsequencesList.Add(hazardConsequences);
                                                                        }
                                                                    }

                                                                }
                                                            }

                                                            _context.TblHazardSource.AddRange(hazardSourceList);
                                                            _context.TblHazardConsequences.AddRange(hazardConsequencesList);
                                                            _context.SaveChanges();
                                                            if (hazardDetails.HRNCalculations != null)
                                                            {
                                                                for (int hazcal = 0; hazcal < hazardDetails.HRNCalculations.Count; hazcal++)
                                                                {
                                                                    TblHRNCalculations hRNCalculations = new();
                                                                    hRNCalculations.id = Guid.NewGuid().ToString();
                                                                    hRNCalculations.PO = hazardDetails.HRNCalculations[hazcal].PO;
                                                                    hRNCalculations.SD = hazardDetails.HRNCalculations[hazcal].SD;
                                                                    hRNCalculations.NP = hazardDetails.HRNCalculations[hazcal].NP;
                                                                    hRNCalculations.FE = hazardDetails.HRNCalculations[hazcal].FE;
                                                                    hRNCalculations.rating = hazardDetails.HRNCalculations[hazcal].Rating;
                                                                    hRNCalculations.type = hazardDetails.HRNCalculations[hazcal].Type;
                                                                    hRNCalculations.modes = GetModeId(hazardDetails.HRNCalculations[hazcal].Mode);
                                                                    hRNCalculations.version = hazardDetails.HRNCalculations[hazcal].Version;
                                                                    hRNCalculations.machine_hazard_id = machineHazards.id;
                                                                    hRNCalculations.created_at = DateTimeOffset.UtcNow;
                                                                    hRNCalculations.created_by = GetCurrentUserId();
                                                                    hRNCalculations.modified_at = DateTimeOffset.UtcNow;
                                                                    hRNCalculations.modified_by = GetCurrentUserId();

                                                                    _context.TblHRNCalculations.Add(hRNCalculations);
                                                                    _context.SaveChanges();
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                            if (roadmapData.RoadMapSections[s].RoadMapSubSection[sb].StepMaster[stm].Answers[ans].YesComplaint)
                                            {
                                                servicemsteps.service_machine_steps_id = Guid.NewGuid().ToString();
                                                servicemsteps.step_id = sm.step_id;
                                                servicemsteps.not_applicable = false;
                                                servicemsteps.compliant = true;
                                                servicemsteps.hazard = false;
                                                servicemsteps.servicemachine_id = servicemachineId;
                                                servicemsteps.user_id = GetCurrentUserId();
                                                servicemsteps.ispreferred = true;
                                                servicemsteps.created_at = DateTimeOffset.UtcNow;
                                                servicemsteps.created_by = GetCurrentUserId();
                                                servicemsteps.modified_at = DateTimeOffset.UtcNow;
                                                servicemsteps.modified_by = GetCurrentUserId();

                                                _context.TblServiceMachineSteps.Add(servicemsteps);
                                                _context.SaveChanges();
                                                answeredSteps++;
                                            }
                                            if (roadmapData.RoadMapSections[s].RoadMapSubSection[sb].StepMaster[stm].Answers[ans].NotApplicable)
                                            {
                                                servicemsteps.service_machine_steps_id = Guid.NewGuid().ToString();
                                                servicemsteps.step_id = sm.step_id;
                                                servicemsteps.not_applicable = true;
                                                servicemsteps.compliant = false;
                                                servicemsteps.hazard = false;
                                                servicemsteps.servicemachine_id = servicemachineId;
                                                servicemsteps.user_id = GetCurrentUserId();
                                                servicemsteps.ispreferred = true;
                                                servicemsteps.created_at = DateTimeOffset.UtcNow;
                                                servicemsteps.created_by = GetCurrentUserId();
                                                servicemsteps.modified_at = DateTimeOffset.UtcNow;
                                                servicemsteps.modified_by = GetCurrentUserId();

                                                _context.TblServiceMachineSteps.Add(servicemsteps);
                                                _context.SaveChanges();
                                                answeredSteps++;
                                            }
                                        }
                                    }
                                    #endregion
                                }
                            }
                        }

                        /// Update Roadmap Status when MarkAsComplete true and calculate Roadmap Progress
                        roadmapProgress = answeredSteps != 0 ? (int)100 * answeredSteps / totalSteps : 0;
                        var roadMap = _context.TblMachineRoadmap.FirstOrDefault(r => r.roadmap_id == rm.roadmap_id && r.service_machine_id == servicemachineId);
                        if (roadMap != null)
                        {
                            roadMap.roadmap_status = "In-Progress";
                            roadMap.roadmap_progress = roadmapProgress;
                            _context.TblMachineRoadmap.Update(roadMap);
                            _context.SaveChanges();
                        }
                    }
                }

                return true;
            }
            catch (Exception)
            {

                throw;
            }
        }
        public async Task<bool> RiskReAssessmentRoadmap(List<RoadMapMasterDTO> roadmapList, string servicemachineId)
        {
            var totalSteps = 0;
            var answeredSteps = 0;
            var roadmapProgress = 0;
            try
            {
                for (int raodmaps = 0; raodmaps < roadmapList.Count; raodmaps++)
                {
                    //Get Roadmap details by Roadmap Id
                    var roadmapData = await GetRoadmapDetailsById(roadmapList[raodmaps].RoadMapMasterId);
                    if (roadmapData != null)
                    {
                        TblRoadmapMaster rm = new();
                        rm.roadmap_id = Guid.NewGuid().ToString();
                        rm.roadmap_name = roadmapData.RoadMapName;
                        rm.iscustom = true;
                        rm.is_risk_reassessment = true;
                        rm.user_id = GetCurrentUserId();
                        rm.created_at = DateTimeOffset.UtcNow;
                        rm.created_by = GetCurrentUserId();
                        rm.modified_at = DateTimeOffset.UtcNow;
                        rm.modified_by = GetCurrentUserId();

                        TblMachineRoadmap machineRoadmap = new();
                        machineRoadmap.id = Guid.NewGuid().ToString();
                        machineRoadmap.service_machine_id = servicemachineId;
                        machineRoadmap.roadmap_id = rm.roadmap_id;
                        machineRoadmap.istype = "RA";
                        machineRoadmap.created_at = DateTimeOffset.UtcNow;
                        machineRoadmap.created_by = GetCurrentUserId();
                        machineRoadmap.modified_at = DateTimeOffset.UtcNow;
                        machineRoadmap.modified_by = GetCurrentUserId();

                        TblProjectRoadmapAssociation roadmapAssociation = new();
                        roadmapAssociation.id = Guid.NewGuid().ToString();
                        roadmapAssociation.project_id = roadmapData.Project_Id;
                        roadmapAssociation.roadmap_id = rm.roadmap_id;
                        roadmapAssociation.created_at = DateTimeOffset.UtcNow;

                        _context.TblRoadmapMaster.Add(rm);
                        _context.TblMachineRoadmap.Add(machineRoadmap);
                        _context.TblProjectRoadmapAssociation.Add(roadmapAssociation);
                        _context.SaveChanges();
                        #region Log AuditEntry
                        TblAuditEntry tblAuditEntry = new();
                        tblAuditEntry.id = Guid.NewGuid().ToString();
                        tblAuditEntry.project_id = roadmapData.Project_Id;
                        tblAuditEntry.erp_project_id = _context.TblProjects.FirstOrDefault(p => p.id == roadmapData.Project_Id)?.erp_project_id ?? null;
                        tblAuditEntry.action = "Create";
                        tblAuditEntry.scope = "New Roadmap " + roadmapData.RoadMapName + " has been added";
                        tblAuditEntry.created_at = DateTimeOffset.UtcNow;
                        tblAuditEntry.user_id = _context.TblUser.FirstOrDefault(p => p.id == GetCurrentUserId())?.email_address ?? null;
                        tblAuditEntry.affected_table = "TblRoadmapMaster";
                        _context.TblAuditEntry.Add(tblAuditEntry);
                        #endregion
                        for (int s = 0; s < roadmapData.RoadMapSections.Count; s++)
                        {
                            TblRoadmapSection rs = new();
                            rs.roadmap_id = rm.roadmap_id;
                            rs.id = Guid.NewGuid().ToString();
                            rs.section = roadmapData.RoadMapSections[s].SectionName;
                            rs.created_at = DateTimeOffset.UtcNow;
                            rs.created_by = GetCurrentUserId();
                            rs.modified_at = DateTimeOffset.UtcNow;
                            rs.modified_by = GetCurrentUserId();

                            _context.TblRoadmapSection.Add(rs);
                            _context.SaveChanges();
                            for (int sb = 0; sb < roadmapData.RoadMapSections[s].RoadMapSubSection.Count; sb++)
                            {
                                TblRoadmapSubSectionMster submaster = new();

                                submaster.id = Guid.NewGuid().ToString();
                                submaster.Sub_Section = roadmapData.RoadMapSections[s].RoadMapSubSection[sb].SubSectionName;
                                submaster.section_id = rs.id;
                                submaster.created_at = DateTimeOffset.UtcNow;
                                submaster.created_by = GetCurrentUserId();
                                submaster.modified_at = DateTimeOffset.UtcNow;
                                submaster.modified_by = GetCurrentUserId();

                                _context.TblRoadmapSubSectionMster.Add(submaster);
                                _context.SaveChanges();
                                for (int stm = 0; stm < roadmapData.RoadMapSections[s].RoadMapSubSection[sb].StepMaster.Count; stm++)
                                {
                                    TblStepMaster sm = new();
                                    TblServiceMachineSteps servicemsteps = new();
                                    TblStepMachineAssociation stepMachineAssociation = new();
                                    #region Creating new step and Adding answers to the step
                                    sm.step_id = Guid.NewGuid().ToString();
                                    sm.roadmap_section_id = submaster.id;
                                    sm.step_body = roadmapData.RoadMapSections[s].RoadMapSubSection[sb].StepMaster[stm].StepBody;
                                    sm.step_notes = roadmapData.RoadMapSections[s].RoadMapSubSection[sb].StepMaster[stm].Notes;
                                    sm.padlock = false;
                                    sm.created_at = DateTimeOffset.UtcNow;
                                    sm.created_by = GetCurrentUserId();
                                    sm.modified_at = DateTimeOffset.UtcNow;
                                    sm.modified_by = GetCurrentUserId();

                                    stepMachineAssociation.id = Guid.NewGuid().ToString();
                                    stepMachineAssociation.servicemachine_id = servicemachineId;
                                    stepMachineAssociation.step_id = sm.step_id;
                                    stepMachineAssociation.created_at = DateTimeOffset.UtcNow;

                                    _context.TblStepMaster.Add(sm);
                                    _context.TblStepMachineAssociation.Add(stepMachineAssociation);
                                    _context.SaveChanges();

                                    ///Count total steps for Roadmap
                                    totalSteps++;
                                    for (int ans = 0; ans < roadmapData.RoadMapSections[s].RoadMapSubSection[sb].StepMaster[stm].Answers.Count; ans++)
                                        {
                                            if (roadmapData.RoadMapSections[s].RoadMapSubSection[sb].StepMaster[stm].Answers[ans].HazardDetails.Any())
                                            {
                                                servicemsteps.service_machine_steps_id = Guid.NewGuid().ToString();
                                                servicemsteps.step_id = sm.step_id;
                                                servicemsteps.not_applicable = false;
                                                servicemsteps.compliant = false;
                                                servicemsteps.hazard = true;
                                                servicemsteps.servicemachine_id = servicemachineId;
                                                servicemsteps.user_id = GetCurrentUserId();
                                                servicemsteps.ispreferred = true;
                                                servicemsteps.created_at = DateTimeOffset.UtcNow;
                                                servicemsteps.created_by = GetCurrentUserId();
                                                servicemsteps.modified_at = DateTimeOffset.UtcNow;
                                                servicemsteps.modified_by = GetCurrentUserId();

                                                _context.TblServiceMachineSteps.Add(servicemsteps);
                                                _context.SaveChanges();
                                                answeredSteps++;
                                                if (roadmapData.RoadMapSections[s].RoadMapSubSection[sb].StepMaster[stm].Answers[ans].HazardDetails != null)
                                                {
                                                    foreach (var hazards in roadmapData.RoadMapSections[s].RoadMapSubSection[sb].StepMaster[stm].Answers[ans].HazardDetails)
                                                    {
                                                        TblMachineHazards machineHazards = new();
                                                        TblHazardType hazardTypes = new();
                                                        List<TblHazardSource> hazardSourceList = new();
                                                        List<TblHazardConsequences> hazardConsequencesList = new();
                                                        var hazardDetails = await GethazardDetailsById(hazards.Id);
                                                        if (hazardDetails != null)
                                                        {
                                                            machineHazards.id = Guid.NewGuid().ToString();
                                                            machineHazards.name = hazardDetails.Name;
                                                            machineHazards.initial_hazard = hazardDetails.Initial_hazard;
                                                            machineHazards.counter_measure = hazardDetails.Counter_measure;
                                                            machineHazards.service_machine_steps_id = servicemsteps.service_machine_steps_id;
                                                            machineHazards.hazard_status = "Yet to Start";
                                                            machineHazards.created_at = DateTimeOffset.UtcNow;
                                                            machineHazards.created_by = GetCurrentUserId();
                                                            machineHazards.modified_at = DateTimeOffset.UtcNow;
                                                            machineHazards.modified_by = GetCurrentUserId();

                                                            _context.TblMachineHazards.Add(machineHazards);
                                                            _context.SaveChanges();

                                                            TblPerformanceLevelRating levelRating = new();
                                                            levelRating.id = Guid.NewGuid().ToString();
                                                            levelRating.PLR = hazardDetails.PLR;
                                                            levelRating.machine_hazard_id = machineHazards.id;
                                                            levelRating.category = hazardDetails.Category;
                                                            levelRating.created_at = DateTimeOffset.UtcNow;
                                                            levelRating.created_by = GetCurrentUserId();
                                                            levelRating.modified_at = DateTimeOffset.UtcNow;
                                                            levelRating.modified_by = GetCurrentUserId();

                                                            _context.TblPerformanceLevelRating.Add(levelRating);
                                                            _context.SaveChanges();

                                                            if (hazardDetails.HazardMedia != null)
                                                            {
                                                                for (int hazmed = 0; hazmed < hazardDetails.HazardMedia.Count; hazmed++)
                                                                {
                                                                    TblHazardMedia media = new();
                                                                    media.id = Guid.NewGuid().ToString();
                                                                    media.machine_hazard_id = machineHazards.id;
                                                                    media.type = hazardDetails.HazardMedia[hazmed].Type;
                                                                    media.url = hazardDetails.HazardMedia[hazmed].URL;
                                                                    media.name = hazardDetails.HazardMedia[hazmed].FileName;
                                                                    media.drive_id = hazardDetails.HazardMedia[hazmed].DriveId != null ? hazardDetails.HazardMedia[hazmed].DriveId.Trim() : null;
                                                                    media.item_id = hazardDetails.HazardMedia[hazmed].ItemId != null ? hazardDetails.HazardMedia[hazmed].ItemId.Trim() : null;
                                                                    media.image_size = hazardDetails.HazardMedia[hazmed].Image_Size;
                                                                    media.created_at = DateTimeOffset.UtcNow;
                                                                    media.created_by = GetCurrentUserId();
                                                                    media.modified_at = DateTimeOffset.UtcNow;
                                                                    media.modified_by = GetCurrentUserId();

                                                                    _context.TblHazardMedia.Add(media);
                                                                    _context.SaveChanges();
                                                                }
                                                            }

                                                            if (hazardDetails.HazardType != null)
                                                            {
                                                                for (int haztyp = 0; haztyp < hazardDetails.HazardType.Count; haztyp++)
                                                                {
                                                                    hazardTypes.id = Guid.NewGuid().ToString();
                                                                    hazardTypes.type = hazardDetails.HazardType[haztyp].HazardTypeName;
                                                                    hazardTypes.hazard_id = machineHazards.id;
                                                                    hazardTypes.created_at = DateTimeOffset.UtcNow;
                                                                    hazardTypes.created_by = GetCurrentUserId();
                                                                    hazardTypes.modified_at = DateTimeOffset.UtcNow;
                                                                    hazardTypes.modified_by = GetCurrentUserId();

                                                                    _context.TblHazardType.Add(hazardTypes);
                                                                    _context.SaveChanges();

                                                                    if (hazardDetails.HazardType[haztyp].HazardSources != null)
                                                                    {
                                                                        for (int hazsor = 0; hazsor < hazardDetails.HazardType[haztyp].HazardSources.Count; hazsor++)
                                                                        {
                                                                            TblHazardSource hazardSource = new();
                                                                            hazardSource.id = Guid.NewGuid().ToString();
                                                                            hazardSource.source = hazardDetails.HazardType[haztyp].HazardSources[hazsor].Source;
                                                                            hazardSource.hazard_type_id = hazardTypes.id;
                                                                            hazardSource.created_at = DateTimeOffset.UtcNow;
                                                                            hazardSource.created_by = GetCurrentUserId();
                                                                            hazardSource.modified_at = DateTimeOffset.UtcNow;
                                                                            hazardSource.modified_by = GetCurrentUserId();

                                                                            hazardSourceList.Add(hazardSource);
                                                                        }
                                                                    }
                                                                    if (hazardDetails.HazardType[haztyp].HazardConsequences != null)
                                                                    {
                                                                        for (int hazcon = 0; hazcon < hazardDetails.HazardType[haztyp].HazardConsequences.Count; hazcon++)
                                                                        {
                                                                            TblHazardConsequences hazardConsequences = new();
                                                                            hazardConsequences.id = Guid.NewGuid().ToString();
                                                                            hazardConsequences.consequence = hazardDetails.HazardType[haztyp].HazardConsequences[hazcon].Consequences;
                                                                            hazardConsequences.hazard_type_id = hazardTypes.id;
                                                                            hazardConsequences.created_at = DateTimeOffset.UtcNow;
                                                                            hazardConsequences.created_by = GetCurrentUserId();
                                                                            hazardConsequences.modified_at = DateTimeOffset.UtcNow;
                                                                            hazardConsequences.modified_by = GetCurrentUserId();

                                                                            hazardConsequencesList.Add(hazardConsequences);
                                                                        }
                                                                    }
                                                                }
                                                            }

                                                            _context.TblHazardSource.AddRange(hazardSourceList);
                                                            _context.TblHazardConsequences.AddRange(hazardConsequencesList);
                                                            _context.SaveChanges();
                                                            if (hazardDetails.HRNCalculations != null)
                                                            {
                                                                for (int hazcal = 0; hazcal < hazardDetails.HRNCalculations.Count; hazcal++)
                                                                {
                                                                    TblHRNCalculations hRNCalculations = new();
                                                                    hRNCalculations.id = Guid.NewGuid().ToString();
                                                                    hRNCalculations.PO = hazardDetails.HRNCalculations[hazcal].PO;
                                                                    hRNCalculations.SD = hazardDetails.HRNCalculations[hazcal].SD;
                                                                    hRNCalculations.NP = hazardDetails.HRNCalculations[hazcal].NP;
                                                                    hRNCalculations.FE = hazardDetails.HRNCalculations[hazcal].FE;
                                                                    hRNCalculations.rating = hazardDetails.HRNCalculations[hazcal].Rating;
                                                                    hRNCalculations.type = hazardDetails.HRNCalculations[hazcal].Type;
                                                                    hRNCalculations.modes = GetModeId(hazardDetails.HRNCalculations[hazcal].Mode);
                                                                    hRNCalculations.version = hazardDetails.HRNCalculations[hazcal].Version;
                                                                    hRNCalculations.machine_hazard_id = machineHazards.id;
                                                                    hRNCalculations.created_at = DateTimeOffset.UtcNow;
                                                                    hRNCalculations.created_by = GetCurrentUserId();
                                                                    hRNCalculations.modified_at = DateTimeOffset.UtcNow;
                                                                    hRNCalculations.modified_by = GetCurrentUserId();

                                                                    _context.TblHRNCalculations.Add(hRNCalculations);
                                                                    _context.SaveChanges();
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                            if (roadmapData.RoadMapSections[s].RoadMapSubSection[sb].StepMaster[stm].Answers[ans].YesComplaint)
                                            {
                                                servicemsteps.service_machine_steps_id = Guid.NewGuid().ToString();
                                                servicemsteps.step_id = sm.step_id;
                                                servicemsteps.not_applicable = false;
                                                servicemsteps.compliant = true;
                                                servicemsteps.hazard = false;
                                                servicemsteps.servicemachine_id = servicemachineId;
                                                servicemsteps.user_id = GetCurrentUserId();
                                                servicemsteps.ispreferred = true;
                                                servicemsteps.created_at = DateTimeOffset.UtcNow;
                                                servicemsteps.created_by = GetCurrentUserId();
                                                servicemsteps.modified_at = DateTimeOffset.UtcNow;
                                                servicemsteps.modified_by = GetCurrentUserId();

                                                _context.TblServiceMachineSteps.Add(servicemsteps);
                                                _context.SaveChanges();
                                                answeredSteps++;
                                            }
                                            if (roadmapData.RoadMapSections[s].RoadMapSubSection[sb].StepMaster[stm].Answers[ans].NotApplicable)
                                            {
                                                servicemsteps.service_machine_steps_id = Guid.NewGuid().ToString();
                                                servicemsteps.step_id = sm.step_id;
                                                servicemsteps.not_applicable = true;
                                                servicemsteps.compliant = false;
                                                servicemsteps.hazard = false;
                                                servicemsteps.servicemachine_id = servicemachineId;
                                                servicemsteps.user_id = GetCurrentUserId();
                                                servicemsteps.ispreferred = true;
                                                servicemsteps.created_at = DateTimeOffset.UtcNow;
                                                servicemsteps.created_by = GetCurrentUserId();
                                                servicemsteps.modified_at = DateTimeOffset.UtcNow;
                                                servicemsteps.modified_by = GetCurrentUserId();

                                                _context.TblServiceMachineSteps.Add(servicemsteps);
                                                _context.SaveChanges();
                                                answeredSteps++;
                                            }
                                        }
                                    
                                    #endregion
                                }
                            }
                        }

                        /// Update Roadmap Status when MarkAsComplete true and calculate Roadmap Progress
                        roadmapProgress = answeredSteps != 0 ? (int)100 * answeredSteps / totalSteps : 0;
                        var roadMap = _context.TblMachineRoadmap.FirstOrDefault(r => r.roadmap_id == rm.roadmap_id && r.service_machine_id == servicemachineId);
                        if (roadMap != null)
                        {
                            roadMap.roadmap_status = "In-Progress";
                            roadMap.roadmap_progress = roadmapProgress;
                            _context.TblMachineRoadmap.Update(roadMap);
                            _context.SaveChanges();
                        }
                    }
                }

                return true;
            }
            catch (Exception)
            {

                throw;
            }
        }
        private string GetModeId(string modeName)
        {
            try
            {
                if (modeName != null)
                {
                    var Id = _context.TblModes.FirstOrDefault(m => m.mode_name.ToLower().Trim() == modeName.ToLower().Trim()) != null ? _context.TblModes.FirstOrDefault(m => m.mode_name.ToLower().Trim() == modeName.ToLower().Trim()).id : null;
                    return Id;
                }
                else
                {
                    return null;
                }

            }
            catch (Exception ex)
            {
                return null;
            }
        }
        private string GenerateServiceId(string value)
        {

            Task.Delay(100);
            var Id = Convert.ToInt32(value.Substring(3));
            Id++;

            string serviceId = $"{Id:0000000000}";
            string newServiceId = "SRV" + serviceId;

            return newServiceId;
        }
        private string GenerateServiceId()
        {
            Task.Delay(100);

            var lastRecord = _context.TblServices.OrderBy(sr => sr.created_at)?.LastOrDefault()?.id ?? string.Empty;

            var Id = string.IsNullOrEmpty(lastRecord) || lastRecord.Contains("-") ? 0 : Convert.ToInt32(lastRecord.Substring(3)); //Convert.ToInt32(lastRecord.id.Substring(3));
            Id++;

            string serviceId = $"{Id:0000000000}";
            string newServiceId = "SRV" + serviceId;

            return newServiceId;
        }
        public string UpdateServiceAndMachine(ServiceDTO service)
        {
            string result = string.Empty;
            try
            {
                if (!string.IsNullOrEmpty(service.id))
                {
                    List<TblMachine> tblMachineList = new List<TblMachine>();
                    List<TblServiceMachine> tblServiceMachinesList = new List<TblServiceMachine>();

                    TblService serviceObj = _context.TblServices.Where(x => x.id == service.id).FirstOrDefault();
                    if (serviceObj != null)
                    {
                        serviceObj.contact_id = service.contact_id;
                        serviceObj.service_region = service.service_region;
                        serviceObj.service_type = service.service_type;
                        serviceObj.service_location = service.service_location;
                        serviceObj.service_description = service.service_description;
                        serviceObj.actual_hours = service.actual_hours;
                        serviceObj.is_active = service.is_active;
                        serviceObj.total_estimated_hours = service.total_estimated_hours;

                        _context.TblServices.Update(serviceObj);
                    }


                    for (int i = 0; i < service.Machine.Count; i++)
                    {
                       // TblMachine machine = _context.TblMachines.Where(m => m.serial_number == service.Machine[i].serial_number && m.asset_id == service.Machine[i].asset_id).FirstOrDefault();
                        TblMachine machine = _context.TblMachines.Where(m =>  m.id == service.Machine[i].id).FirstOrDefault();
                        TblServiceMachine serviceMachine = _context.TblServiceMachines.Where(sm => sm.service_id == service.id && sm.machine_id == service.Machine[i].id).FirstOrDefault();
                        if (machine != null)
                        {
                           machine.asset_id = service.Machine[i].asset_id;
                           //machine.estimated_hours = service.Machine[i].estimated_hours;
                           machine.machine_name = service.Machine[i].machine_name;
                           machine.serial_number = service.Machine[i].serial_number;
                           machine.machine_type = service.Machine[i].machine_type;
                           machine.machine_location = service.Machine[i].machine_location;
                           machine.industry_type = service.Machine[i].industry_type;
                           machine.machine_description = service.Machine[i].machine_description;
                           machine.modified_at = DateTimeOffset.Now;
                           machine.modified_by = service.Machine[i].modified_by;
                           serviceMachine.estimated_hours = service.Machine[i].estimated_hours;

                           tblMachineList.Add(machine);

                            _context.TblServiceMachines.Update(serviceMachine);
                            _context.TblMachines.Update(machine);
                            _context.SaveChanges();
                        }

                    }

                    if (tblMachineList.Count > 0)
                    {
                        #region Add Machine request to ERP

                        var offer = (from offr in _context.TblOffers
                                     join project in _context.TblProjects on offr.project_id equals project.id
                                     join svc in _context.TblServices on offr.id equals svc.offer_id
                                     join cust in _context.TblCustomers on project.customer_id equals cust.id
                                     join offrContact in _context.TblContacts on offr.contact_id equals offrContact.contact_id
                                     join projectContact in _context.TblContacts on project.contact_id equals projectContact.contact_id
                                     //join serviceContact in _context.TblContacts on service.contact_id equals serviceContact.contact_id
                                     where svc.id == service.id
                                     select new
                                     {
                                         offerId = offr.id,
                                         projectId = offr.project_id,
                                         offer_contact_person = offrContact.display_name,
                                         offer_wbs_id = offr.WBSID,
                                         erp_project_id = project.erp_project_id,
                                         offer_status = offr.status,
                                         offer_contact_email = offrContact.email_address,
                                         offer_contact_number = offrContact.phone_number,
                                         offer_quote_type = offr.quote_type,
                                         offer_contact_id = offr.contact_id,
                                         project_contact_id = project.contact_id,
                                         companyCode = project.company_id
                                     }).FirstOrDefault();

                        var wbsDeleteObject = new WbsUpdateRequestEvent();
                        if (offer is not null)
                        {
                            wbsDeleteObject.Offer = new WbsUpdateRequestOffer();
                            wbsDeleteObject.Offer.ContactPerson = offer.offer_contact_person;
                            wbsDeleteObject.Offer.ERPProjectID = offer.erp_project_id;
                            wbsDeleteObject.Offer.Status = offer.offer_status;
                            wbsDeleteObject.Offer.ContactEmail = offer.offer_contact_email;
                            wbsDeleteObject.Offer.ContactNumber = offer.offer_contact_number;
                            wbsDeleteObject.Offer.OfferID = offer.offerId;
                            wbsDeleteObject.Offer.ProjectID = offer.projectId;
                            wbsDeleteObject.Offer.QuoteType = offer.offer_quote_type;
                            wbsDeleteObject.Offer.WBSID = offer.offer_wbs_id;
                            wbsDeleteObject.Offer.Services = new List<WbsUpdateRequestService>();

                            var serviceDetails = (from svc in _context.TblServices
                                                      //join contact in _context.TblContacts on svc.contact_id equals contact.contact_id
                                                  where svc.id == service.id
                                                  select new
                                                  {
                                                      contactEmail = string.Empty,//contact.email_address,
                                                      region = string.Empty,//svc.service_region,
                                                      endDate = svc.end_date,
                                                      startDate = svc.start_date,
                                                      contactNumber = string.Empty,//contact.phone_number,
                                                      contactPerson = string.Empty,//contact.display_name,
                                                      description = svc.service_description,
                                                      location = svc.service_location,
                                                      serviceId = svc.id,
                                                      serviceProductId = svc.service_type
                                                  }).ToList();

                            foreach (var svc in serviceDetails)
                            {

                                var wbsService = new WbsUpdateRequestService();
                                var totalSumInHour = 0m;
                                var serviceProduct = svc.serviceProductId?.Split('-') ?? new List<string>().ToArray();

                                wbsService.Action = "UPDATE";
                                wbsService.ContactEmail = svc.contactEmail;
                                wbsService.Region = svc.region;
                                wbsService.EndDate = svc.endDate.Value;
                                wbsService.ContactNumber = svc.contactNumber;
                                wbsService.ContactPerson = svc.contactPerson;
                                wbsService.Description = svc.description;
                                wbsService.Location = svc.location;
                                wbsService.ServiceID = svc.serviceId;
                                wbsService.ServiceProductID = serviceProduct.Count() > 0 ? serviceProduct[0].Trim() : String.Empty;
                                wbsService.StartDate = svc.startDate.Value;
                                wbsService.Type = serviceProduct.Count() > 1 ? serviceProduct[1].Trim() : String.Empty;

                                var machineIdsToAdd = tblServiceMachinesList.Select(sm => sm.id).ToList();

                                var machines = (from machine in _context.TblMachines
                                                join serviceMachine in _context.TblServiceMachines on machine.id equals serviceMachine.machine_id
                                                where machineIdsToAdd.Contains(serviceMachine.id)
                                                select new
                                                {
                                                    machineName = machine.machine_name,
                                                    assetNumber = machine.asset_id,
                                                    description = machine.machine_description,
                                                    estimatedHour = serviceMachine.estimated_hours,
                                                    machineId = serviceMachine.id,
                                                    serialNumber = machine.serial_number,
                                                    type = machine.machine_type,
                                                    wbsId = serviceMachine.erp_wbs_id
                                                }).ToList();

                                var machineDetail = new WbsUpdateRequestMachineDetails();
                                machineDetail.Machines = new List<WbsUpdateMachine>();

                                foreach (var machine in machines)
                                {
                                    var wbsMachine = new WbsUpdateMachine();

                                    totalSumInHour = machine.estimatedHour + totalSumInHour;

                                    wbsMachine.MachineName = machine.machineName;
                                    wbsMachine.Action = "ADD";
                                    wbsMachine.AssetNumber = machine.assetNumber;
                                    wbsMachine.Description = machine.description;
                                    wbsMachine.EstimatedHours = machine.estimatedHour;
                                    wbsMachine.MachineID = machine.machineId;
                                    wbsMachine.Manufacturer = String.Empty;
                                    wbsMachine.SerialNumber = machine.serialNumber;
                                    wbsMachine.Type = machine.type;
                                    wbsMachine.WBSID = machine.wbsId;

                                    machineDetail.Machines.Add(wbsMachine);
                                }

                                wbsService.MachineDetails = machineDetail;
                                wbsService.TotalSumInHours = totalSumInHour;

                                wbsDeleteObject.Offer.Services.Add(wbsService);
                            }

                            var techincalHeader = new RequestTechnicalHeader()
                            {
                                TenantID = httpContextAccessor.HttpContext?.User?.GetTenantId() ?? String.Empty,
                                CompanyCode = offer.companyCode,
                                EmailAddress = httpContextAccessor.HttpContext?.User?.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Email)?.Value ?? String.Empty,
                                RequestID = Guid.NewGuid().ToString(),
                                Timestamp = DateTime.UtcNow
                            };


                            wbsDeleteObject.TopicName = "wbsrequest";
                            wbsDeleteObject.TechnicalHeader = techincalHeader;

                            _messageBus.PublishToQueue(wbsDeleteObject, true);
                        }

                        #endregion
                    }

                    return result = "Service updated successfully";
                }
                else
                {
                    return result = "ServiceId should not be empty";
                }
            }
            catch (Exception ex)
            {

                return result = ex.InnerException.Message;
            }


        }
        public string UpdateService(EditServiceDTO service)
        {
            string result = string.Empty;
            try
            {
                if (!string.IsNullOrEmpty(service.ServiceId))
                {

                    TblService serviceObj = _context.TblServices.Where(x => x.id == service.ServiceId).FirstOrDefault();
                    if (serviceObj != null)
                    {

                        serviceObj.contact_id = service.ContactId;
                        serviceObj.start_date = service.StartDate;
                        serviceObj.end_date = service.EndDate;
                        serviceObj.service_description = service.Description;
                        serviceObj.is_ra_external = service.is_ra_external;
                        serviceObj.external_ra_notes = service.is_ra_external_notes;

                        _context.TblServices.Update(serviceObj);
                        _context.SaveChanges();

                        return result = "Service updated successfully";
                    }
                    else
                    {
                        return result = "ServiceId not existed ";
                    }
                }
                else
                {
                    return result = "ServiceId should not be empty";
                }
            }
            catch (Exception ex)
            {

                return result = ex.InnerException.Message;
            }

        }
        public string UpdateMachine(MachineDTO machine)
        {
            string result = string.Empty;
            try
            {
                if (!string.IsNullOrEmpty(machine.id))
                {

                    TblMachine machineObj = _context.TblMachines.Where(x => x.id == machine.id).FirstOrDefault();
                    TblServiceMachine serviceMachineObj = _context.TblServiceMachines.Where(x => x.machine_id == machine.id && x.service_id == machine.service_id).FirstOrDefault();
                    if (machineObj != null)
                    {
                        //machineObj.estimated_hours = machine.estimated_hours;
                        machineObj.asset_id = machine.asset_id;
                        machineObj.industry_type = machine.industry_type;
                        machineObj.machine_type = machine.machine_type;
                        machineObj.machine_description = machine.machine_description;
                        machineObj.machine_location = machine.machine_location;
                        machineObj.machine_name = machine.machine_name;
                        machineObj.serial_number = machine.serial_number;
                        machineObj.modified_at = DateTimeOffset.Now;
                        machineObj.modified_by = GetCurrentUserId();
                        serviceMachineObj.estimated_hours = machine.estimated_hours;

                        _context.TblServiceMachines.Update(serviceMachineObj);
                        _context.TblMachines.Update(machineObj);
                        _context.SaveChanges();

                        return result = "Machine updated successfully";
                    }
                    else
                    {
                        return result = "MachineId not existed ";
                    }
                }
                else
                {
                    return result = "MachineId should not be empty";
                }
            }
            catch (Exception ex)
            {

                return result = ex.InnerException.Message;
            }

        }

        public async Task<ActualHoursRequest> AddActualHours(ActualHoursDto actualHours)
        {
            try
            {
                List<TblActualHours> hoursList = new();
                TblMachineKPI machineKPI = new();
                
                var serviceAsctualHours = 0;
                string action = string.Empty;
                foreach (var item in actualHours.MachineActualHours)
                {
                    TblActualHours hours = new();
                    if (!string.IsNullOrEmpty(item.Action) && item.Action.ToLower() == ActionStatusConstants.ADD.ToLower())
                    {
                        var serviceHours = _context.TblServices.Where(s => s.id == actualHours.Service_Id).FirstOrDefault();
                        action = ActionStatusConstants.ADD;
                        hours.id = Guid.NewGuid().ToString();
                        hours.service_machine_id = item.ServiceMachine_Id;
                        hours.user_id = actualHours.User_Id;
                        hours.actualhours = item.ActualHours;
                        hours.comments = item.Comments;
                        hours.created_at = DateTimeOffset.UtcNow;
                        hours.created_by = actualHours.User_Name;
                        hours.modified_at = DateTimeOffset.UtcNow;
                        hours.modified_by = actualHours.User_Name;
                        _context.TblActualHours.Add(hours);

                        //Saving to ServiceLevel
                        serviceHours.actual_hours += Convert.ToInt32(item.ActualHours);
                        _context.TblServices.Update(serviceHours);

                        var kpi = _context.TblMachineKPI.Where(m => m.service_machine_id == item.ServiceMachine_Id).FirstOrDefault();
                        if (kpi == null)
                        {
                            machineKPI.id = Guid.NewGuid().ToString();
                            machineKPI.actualaggregatedhours = item.ActualHours;
                            machineKPI.service_machine_id = item.ServiceMachine_Id;
                            machineKPI.created_at = DateTimeOffset.UtcNow;
                            machineKPI.created_by = actualHours.User_Name;
                            machineKPI.modified_at = DateTimeOffset.UtcNow;
                            machineKPI.modified_by = actualHours.User_Name;
                            _context.TblMachineKPI.Add(machineKPI);
                        }
                        else
                        {
                            kpi.actualaggregatedhours += item.ActualHours;
                            _context.TblMachineKPI.Update(kpi);
                        }
                        await _context.SaveChangesAsync();
                    }
                    if (!string.IsNullOrEmpty(item.Action) && item.Action.ToLower() == ActionStatusConstants.UPDATE.ToLower())
                    {
                        var updateActlHours = _context.TblActualHours.Where(a => a.id == item.Id).FirstOrDefault();
                        action = ActionStatusConstants.UPDATE;
                        updateActlHours.actualhours = item.ActualHours;
                        updateActlHours.comments = item.Comments;
                        _context.TblActualHours.Update(updateActlHours);

                        //Update Service Actual hours
                        var status = UpdateServiceActualHours(actualHours.Service_Id, updateActlHours.actualhours);

                        var serviceHours = _context.TblServices.Where(s => s.id == actualHours.Service_Id).FirstOrDefault();
                        serviceHours.actual_hours -= Convert.ToInt32(updateActlHours.actualhours);
                        _context.TblServices.Update(serviceHours);

                        var kpi = _context.TblMachineKPI.Where(m => m.service_machine_id == item.ServiceMachine_Id).FirstOrDefault();
                        if (kpi == null)
                        {
                            machineKPI.id = Guid.NewGuid().ToString();
                            machineKPI.actualaggregatedhours = item.ActualHours;
                            machineKPI.service_machine_id = item.ServiceMachine_Id;
                            machineKPI.created_at = DateTimeOffset.UtcNow;
                            machineKPI.created_by = actualHours.User_Name;
                            machineKPI.modified_at = DateTimeOffset.UtcNow;
                            machineKPI.modified_by = actualHours.User_Name;
                            _context.TblMachineKPI.Add(machineKPI);
                        }
                        else
                        {
                            kpi.actualaggregatedhours += item.ActualHours;
                            _context.TblMachineKPI.Update(kpi);
                        }

                        await _context.SaveChangesAsync();

                    }
                    if (!string.IsNullOrEmpty(item.Action) && item.Action.ToLower() == ActionStatusConstants.DELETE.ToLower())
                    {
                        if (!string.IsNullOrEmpty(item.Id))
                        {
                            action = ActionStatusConstants.DELETE;
                            var deleteActlhours = _context.TblActualHours.Where(a => a.id == item.Id).FirstOrDefault();
                            _context.TblActualHours.Remove(deleteActlhours);

                            var kpi = _context.TblMachineKPI.Where(m => m.service_machine_id == item.ServiceMachine_Id).FirstOrDefault();
                            kpi.actualaggregatedhours -= deleteActlhours.actualhours;
                            _context.TblMachineKPI.Update(kpi);

                            var serviceHours = UpdateServiceActualHours(actualHours?.Service_Id, deleteActlhours.actualhours);

                            await _context.SaveChangesAsync();
                        }
                    }
                }

                var orderDetails = _context.TblOrder.Where(a => a.erp_order_id == actualHours.Order_Id && a.service_id == actualHours.Service_Id).FirstOrDefault();
                var project = _context.TblProjects.Where(p => p.id == actualHours.Project_Id).FirstOrDefault();
                List<Machine> machineDetailsList = new();
                List<ServiceRequest> ServiceList = new();
                foreach (var item in actualHours.MachineActualHours)
                {
                    var machine = _context.TblMachines.Where(m => m.id == item.Machine_Id).FirstOrDefault();
                    serviceAsctualHours = item.Machine_Id == "00000000-0000-0000-0000-000000000000" ? Convert.ToInt32(item.ActualHours) : 0;
                    if (machine != null && item.Machine_Id != "00000000-0000-0000-0000-000000000000")
                    {
                        var serviceMachne = _context.TblServiceMachines.Where(s => s.service_id == actualHours.Service_Id && s.machine_id == machine.id).FirstOrDefault();
                        Machine machines = new();
                        machines.MachineID = serviceMachne.id;
                        machines.WBSID = serviceMachne.erp_wbs_id;
                        machines.ActualHours = item.ActualHours;
                        machines.Action = action;
                        machineDetailsList.Add(machines);
                    }
                }

                var machineDetails = new MachineDetails(machineDetailsList);
                var serviceDetails = _context.TblServices.Where(s => s.id == actualHours.Service_Id).FirstOrDefault();
                var service = new ServiceRequest(serviceDetails.id, serviceDetails.erp_wbs_id, serviceAsctualHours, machineDetails);
                ServiceList.Add(service);
                var order = new Order(orderDetails?.id, orderDetails?.erp_order_id, project?.erp_project_id, project?.id, ServiceList);


                var techincalHeader = new RequestTechnicalHeader()
                {
                    TenantID = httpContextAccessor.HttpContext?.User?.GetTenantId() ?? String.Empty,
                    CompanyCode = project.company_id,
                    EmailAddress = httpContextAccessor
                    .HttpContext?
                    .User?
                    .Claims
                    .FirstOrDefault(c => c.Type == ClaimTypes.Email)?
                    .Value ?? String.Empty,
                    RequestID = Guid.NewGuid().ToString(),
                    Timestamp = DateTime.UtcNow
                };

                var actualHoursRequest = new ActualHoursRequest()
                {
                    TechnicalHeader = techincalHeader,
                    Order = order,
                    TopicName = "actualhoursrequest"
                };
                return actualHoursRequest;
            }
            catch (Exception ex)
            {
                return null;
            }

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="serviceMaterial"></param>
        /// <returns></returns>
        public async Task<List<string>> GetServiceMaterialByCompanyCode(ServiceMaterialResponseDTO serviceMaterial)
        {
            List<string> serviceMaterials = new();

            try
            {
                serviceMaterials = await _context.TblServiceMaterials
                    .Where(sm => sm.company_code == serviceMaterial.Companycode && sm.language.ToUpper() == serviceMaterial.Language.ToUpper())
                    .Select(sm => $"{sm.service_product_id} - {sm.value} - {sm.value_type}")
                    .Distinct()
                    .ToListAsync();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return serviceMaterials;
        }

        /// <summary>
        /// Get Added User ActualHours
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public async Task<List<GetMachineActualHours>> GetRecentLogActualHours(string serviceMachineId, string userId)
        {
            try
            {
                var result = new List<GetMachineActualHours>();
                if (IsUserProjectManager())
                {
                    result = await _context.TblActualHours.Where(a => a.service_machine_id == serviceMachineId)
                    .Select(actl => new GetMachineActualHours
                    {
                        Id = actl.id,
                        ActualHours = actl.actualhours,
                        ServiceMachine_Id = actl.service_machine_id,
                        Comments = actl.comments,
                        CreatedAt = actl.created_at
                    }).OrderByDescending(s => s.CreatedAt).ToListAsync();
                }
                else
                {
                    result = await _context.TblActualHours.Where(a => a.service_machine_id == serviceMachineId && a.user_id == userId)
                    .Select(actl => new GetMachineActualHours
                    {
                        Id = actl.id,
                        ActualHours = actl.actualhours,
                        ServiceMachine_Id = actl.service_machine_id,
                        Comments = actl.comments,
                        CreatedAt = actl.created_at
                    }).OrderByDescending(s => s.CreatedAt).ToListAsync();
                }
                

                return result;
            }
            catch(Exception ex)
            {
                return null;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="machineId"></param>
        /// <returns></returns>
        public async Task<List<RoadMapMasterDTO>> GetAllMachineRoadmaps(string machineId)
        {
            try
            {
                var result = await (from machine in _context.TblMachines.Where(m => m.id == machineId)
                                    join ser in _context.TblServiceMachines on machine.id equals ser.machine_id into ser1
                                    from servicemachine in ser1.DefaultIfEmpty()
                                    join mr in _context.TblMachineRoadmap on servicemachine.id equals mr.service_machine_id into mr1
                                    from machineroadmap in mr1.DefaultIfEmpty()
                                    join roadMap in _context.TblRoadmapMaster on machineroadmap.roadmap_id equals roadMap.roadmap_id
                                    select new RoadMapMasterDTO
                                    {
                                        RoadMapMasterId = roadMap.roadmap_id,
                                        RoadMapName = roadMap.roadmap_name,
                                        //RoadMapSections = _context.TblRoadmapSection.Where(s => s.roadmap_id == roadMap.roadmap_id).Select(rm => new RoadMapSectionDTO
                                        //{
                                        //    SectionName = rm.section,
                                        //    RoadMapSectionId = rm.id,
                                        //    RoadMapSubSection = _context.TblRoadmapSubSectionMster.Where(sub => sub.section_id == rm.id).Select(sub => new RoadMapSubSectionDTO
                                        //    {
                                        //        RoadMapSubSectionId = sub.id,
                                        //        SubSectionName = sub.Sub_Section,
                                        //        StepMaster = _context.TblStepMachineAssociation.Where(sma => sma.servicemachine_id == servicemachine.id).Join(_context.TblStepMaster.Where(s => s.roadmap_section_id == sub.id), sm => sm.step_id, stp => stp.step_id, (sm, stp) => new StepMasterDTO
                                        //        {
                                        //            StepMasterId = stp.step_id,
                                        //            StepBody = stp.step_body,
                                        //            Notes = stp.step_notes,
                                        //            Answers = _context.TblServiceMachineSteps.Where(s => s.step_id == stp.step_id && s.servicemachine_id == servicemachine.id && s.ispreferred == true).Select(answr => new Answers
                                        //            {
                                        //                ServiceMachineStepId = answr.service_machine_steps_id,
                                        //                YesComplaint = answr.compliant,
                                        //                NotApplicable = answr.not_applicable,
                                        //                Hazard = answr.hazard,
                                        //                ReportedBy = answr.created_by,
                                        //                HazardDetails = _context.TblMachineHazards.Where(s => s.service_machine_steps_id == answr.service_machine_steps_id).Select(h => new MachineHazardDto
                                        //                {
                                        //                    Id = h.id,
                                        //                    //Initial_hazard = h.initial_hazard,
                                        //                    //Name = h.name,
                                        //                    //Version = h.version,
                                        //                    //Counter_measure = h.counter_measure,
                                        //                    //Category = _context.TblPerformanceLevelRating.Where(p => p.machine_hazard_id == h.id).FirstOrDefault().category ?? null,
                                        //                    //PLR = _context.TblPerformanceLevelRating.Where(p => p.machine_hazard_id == h.id).FirstOrDefault().PLR ?? null,
                                        //                    ////Notes = _context.TblFourEyesQualityCheck.FirstOrDefault(h => h.hazard_id == hazard.id).notes ?? "NA",
                                        //                    //HazardType = (from type in _context.TblHazardType
                                        //                    //              where type.hazard_id == h.id
                                        //                    //              select new HazardType
                                        //                    //              {
                                        //                    //                  HazardTypeId = type.id,
                                        //                    //                  HazardTypeName = type.type ?? "NA",
                                        //                    //                  HazardSources = _context.TblHazardSource.Where(h => h.hazard_type_id == type.id).Select(s => new HazardSource
                                        //                    //                  {
                                        //                    //                      Id = s.id,
                                        //                    //                      Source = s.source ?? "NA"
                                        //                    //                  }).ToList(),
                                        //                    //                  HazardConsequences = _context.TblHazardConsequences.Where(h => h.hazard_type_id == type.id).Select(s => new HazardConsequence
                                        //                    //                  {
                                        //                    //                      Id = s.id,
                                        //                    //                      Consequences = s.consequence ?? "NA"
                                        //                    //                  }).ToList()
                                        //                    //              }).ToList(),
                                        //                    //HazardMedia = (from media in _context.TblHazardMedia
                                        //                    //               where media.machine_hazard_id == h.id
                                        //                    //               select new HazardMedia
                                        //                    //               {
                                        //                    //                   URL = media.url,
                                        //                    //                   Type = media.type,
                                        //                    //                   Image_Size = media.image_size
                                        //                    //               }).ToList(),
                                        //                    //HRNCalculations = _context.TblHRNCalculations.Where(hrn => hrn.machine_hazard_id == h.id).Select(s => new HRNCalculations
                                        //                    //{
                                        //                    //    Mode = s.modes != null ? _context.TblModes.FirstOrDefault(m => m.id == s.modes).mode_name : null,
                                        //                    //    Id = s.id,
                                        //                    //    PO = s.PO,
                                        //                    //    FE = s.FE,
                                        //                    //    SD = s.SD,
                                        //                    //    NP = s.NP,
                                        //                    //    Rating = s.rating,
                                        //                    //    Version = s.version,
                                        //                    //    Type = s.type
                                        //                    //}).ToList()
                                        //                }).ToList(),
                                        //                ComplaintMedia = answr.compliant == true ? _context.TblComplaintMedia.Where(s => s.service_machinestep_id == answr.service_machine_steps_id).Select(s => new FileDto
                                        //                {
                                        //                    FileName = s.name,
                                        //                    ContentType = s.type,
                                        //                    URL = s.url,
                                        //                    Id = s.id,
                                        //                    ItemId = s.item_id,
                                        //                    DriveId = s.drive_id,
                                        //                    Image_Size = s.image_size
                                        //                }).ToList() : null,
                                        //            }).ToList(),
                                        //        }).ToList()
                                        //    }).ToList()
                                        //}).ToList()
                                    }).ToListAsync();
                return result;

            }
            catch (Exception)
            {

                throw;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="companycode"></param>
        /// <returns></returns>
        public async Task<string> GetRegionByCompanyCode(string companycode)
        {
            try
            {
                var region = _context.TblCompanies.Where(c => c.company_code == companycode).FirstOrDefault()?.region;
                return region;
            }
            catch (Exception)
            {

                throw;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="hazardId"></param>
        /// <returns></returns>
        public async Task<MachineHazardDto> GethazardDetailsById(string hazardId)
        {
            try
            {
                var result = await (from hazard in _context.TblMachineHazards
                                    join level in _context.TblPerformanceLevelRating on hazard.id equals level.machine_hazard_id
                                    where hazard.id == hazardId
                                    select new MachineHazardDto
                                    {
                                        Id = hazard.id,
                                        Initial_hazard = hazard.initial_hazard ?? "NA",
                                        Name = hazard.name ?? "NA",
                                        Version = hazard.version ?? "NA",
                                        Counter_measure = hazard.counter_measure ?? "NA",
                                        PLR = level.PLR != "" ? level.PLR : "NA",
                                        Category = level.category != "" ? level.category : "NA",
                                        //Notes = _context.TblFourEyesQualityCheck.FirstOrDefault(h => h.hazard_id == hazard.id).notes ?? "NA",
                                        HazardType = (from type in _context.TblHazardType
                                                      where type.hazard_id == hazard.id
                                                      select new HazardType
                                                      {
                                                          HazardTypeId = type.id,
                                                          HazardTypeName = type.type ?? "NA",
                                                          HazardSources = _context.TblHazardSource.Where(h => h.hazard_type_id == type.id).Select(s => new HazardSource
                                                          {
                                                              Id = s.id,
                                                              Source = s.source ?? "NA"
                                                          }).ToList(),
                                                          HazardConsequences = _context.TblHazardConsequences.Where(h => h.hazard_type_id == type.id).Select(s => new HazardConsequence
                                                          {
                                                              Id = s.id,
                                                              Consequences = s.consequence ?? "NA"
                                                          }).ToList()
                                                      }).ToList(),
                                        HazardMedia = (from media in _context.TblHazardMedia
                                                       where media.machine_hazard_id == hazard.id
                                                       select new HazardMedia
                                                       {
                                                           Id = media.id,
                                                           URL = media.url,
                                                           Type = media.type,
                                                           FileName = media.name,
                                                           DriveId = media.drive_id.Trim(),
                                                           ItemId = media.item_id.Trim(),
                                                           Image_Size = media.image_size
                                                       }).ToList(),
                                        HRNCalculations = _context.TblHRNCalculations.Where(hrn => hrn.machine_hazard_id == hazard.id).Select(s => new HRNCalculations
                                        {
                                            Mode = s.modes != null ? _context.TblModes.FirstOrDefault(m => m.id == s.modes).mode_name : null,
                                            Id = s.id,
                                            PO = s.PO,
                                            FE = s.FE,
                                            SD = s.SD,
                                            NP = s.NP,
                                            Rating = s.rating,
                                            Version = s.version,
                                            Type = s.type
                                        }).ToList()
                                    }).FirstOrDefaultAsync();
                return result;
            }
            catch (Exception)
            {

                throw;
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="roadmapId"></param>
        /// <returns></returns>
        public async Task<RoadMapMasterDTO> GetRoadmapDetailsById(string roadmapId)
        {
            try
            {
                var result = await (from  roadMap in _context.TblRoadmapMaster.Where(r =>r.roadmap_id == roadmapId) 
                                    select new RoadMapMasterDTO
                                    {
                                        RoadMapMasterId = roadMap.roadmap_id,
                                        RoadMapName = roadMap.roadmap_name,
                                        RoadMapSections = _context.TblRoadmapSection.Where(s => s.roadmap_id == roadMap.roadmap_id).Select(rm => new RoadMapSectionDTO
                                        {
                                            SectionName = rm.section,
                                            RoadMapSectionId = rm.id,
                                            RoadMapSubSection = _context.TblRoadmapSubSectionMster.Where(sub => sub.section_id == rm.id).Select(sub => new RoadMapSubSectionDTO
                                            {
                                                RoadMapSubSectionId = sub.id,
                                                SubSectionName = sub.Sub_Section,
                                                StepMaster = _context.TblStepMaster.Where(s => s.roadmap_section_id == sub.id)
                                                .Select(stp => new StepMasterDTO
                                                {
                                                    StepMasterId = stp.step_id,
                                                    StepBody = stp.step_body,
                                                    Notes = stp.step_notes,
                                                    Answers = _context.TblServiceMachineSteps.Where(s => s.step_id == stp.step_id && s.ispreferred == true).Select(answr => new Answers
                                                    {
                                                        ServiceMachineStepId = answr.service_machine_steps_id,
                                                        YesComplaint = answr.compliant,
                                                        NotApplicable = answr.not_applicable,
                                                        Hazard = answr.hazard,
                                                        ReportedBy = answr.created_by,
                                                        HazardDetails = _context.TblMachineHazards.Where(s => s.service_machine_steps_id == answr.service_machine_steps_id).Select(h => new MachineHazardDto
                                                        {
                                                            Id = h.id,
                                                            Name = h.name,
                                                        }).ToList(),
                                                        //ComplaintMedia = answr.compliant == true ? _context.TblComplaintMedia.Where(s => s.service_machinestep_id == answr.service_machine_steps_id).Select(s => new FileDto
                                                        //{
                                                        //    FileName = s.name,
                                                        //    ContentType = s.type,
                                                        //    URL = s.url,
                                                        //    Id = s.id,
                                                        //    ItemId = s.item_id,
                                                        //    DriveId = s.drive_id,
                                                        //    Image_Size = s.image_size
                                                        //}).ToList() : null,
                                                    }).ToList(),
                                                }).ToList()
                                            }).ToList()
                                        }).ToList()
                                    }).FirstOrDefaultAsync();
                return result;
            }
            catch (Exception)
            {

                throw;
            }
        }
        /// <summary>
        /// Get RRA Machines
        /// </summary>
        /// <param name="serviceId"></param>
        /// <returns></returns>
        public async Task<List<RiskReAssessmentMachinesDto>> GetMachinesByService(string serviceId)
        {
            try
            {
                var result = await (from ser in _context.TblServices
                              join sm in _context.TblServiceMachines on ser.id equals sm.service_id into sm1
                              from sm2 in sm1.DefaultIfEmpty()
                              join mach in _context.TblMachines on sm2.machine_id equals mach.id
                              join mr in _context.TblMachineRoadmap on sm2.id equals mr.service_machine_id
                              where ser.id == serviceId && mr.roadmap_status == "Completed"
                              select new RiskReAssessmentMachinesDto
                              {
                                  MachineId = mach.id,
                                  machine_name = mach.machine_name,
                                  machine_description = mach.machine_description,
                                  machine_type = mach.machine_type
                              }).Distinct().ToListAsync();
                return result;
            }
            catch (Exception)
            {

                throw;
            }
        }
        /// <summary>
        /// Create RiskReAssessment
        /// </summary>
        /// <param name="serviceDTO"></param>
        /// <returns></returns>
        public async Task<string> CreateRiskReAssessmentService(List<ServiceDTO> serviceDTO)
        {
            string Result = string.Empty;
            Dictionary<string, List<string>> newServicesAndMachinesId = new();
            try
            {

                string serviceId = string.Empty;
                for (var i = 0; i < serviceDTO.Count; i++)
                {
                    TblService tblService = new();
                    if (i == 0)
                    {
                        serviceId = GenerateServiceId();
                    }
                    else
                    {
                        serviceId = GenerateServiceId(serviceId);
                    }

                    tblService.id = serviceId.ToString();
                    tblService.erp_wbs_id = serviceDTO[i].erp_wbs_id;
                    tblService.project_id = serviceDTO[i].project_id;
                    tblService.offer_id = serviceDTO[i].offer_id;
                    tblService.contact_id = serviceDTO[i].contact_id;
                    tblService.service_type = serviceDTO[i].service_type;
                    tblService.service_location = serviceDTO[i].service_location;
                    tblService.is_active = serviceDTO[i].is_active;
                    tblService.created_by = GetCurrentUserId();
                    tblService.modified_by = GetCurrentUserId();
                    tblService.actual_hours = serviceDTO[i].actual_hours;
                    tblService.total_estimated_hours = serviceDTO[i].total_estimated_hours;
                    tblService.start_date = serviceDTO[i].start_date;
                    tblService.end_date = serviceDTO[i].end_date;
                    tblService.service_description = serviceDTO[i].service_description;
                    tblService.service_region = serviceDTO[i].service_region;
                    tblService.is_ra_external = serviceDTO[i].is_ra_external;
                    tblService.external_ra_notes = serviceDTO[i].external_ra_notes;
                    tblService.service_kpi_id = _context.TblServiceKPI.FirstOrDefault()?.id ?? string.Empty;
                    tblService.created_at = DateTimeOffset.Now;
                    tblService.modified_at = DateTimeOffset.Now;

                    // tblServiceList.Add(tblService);
                    _context.TblServices.Add(tblService);
                    _context.SaveChanges();
                    List<string> newMachines = new();
                    if (serviceDTO[i].Machine.Count != 0)
                    {
                        for (var j = 0; j < serviceDTO[i].Machine.Count; j++)
                        {
                            TblMachine tblMachine = new();
                            Guid guidMachineId = Guid.NewGuid();
                            tblMachine.id = Convert.ToString(guidMachineId);
                            tblMachine.asset_id = serviceDTO[i].Machine[j].asset_id;
                            tblMachine.estimated_hours = serviceDTO[i].Machine[j].estimated_hours;
                            tblMachine.machine_name = serviceDTO[i].Machine[j].machine_name;
                            tblMachine.serial_number = serviceDTO[i].Machine[j].serial_number;
                            tblMachine.machine_type = serviceDTO[i].Machine[j].machine_type;
                            tblMachine.machine_location = serviceDTO[i].Machine[j].machine_location;
                            tblMachine.industry_type = serviceDTO[i].Machine[j].industry_type;
                            tblMachine.machine_description = serviceDTO[i].Machine[j].machine_description;
                            tblMachine.created_by = GetCurrentUserId();
                            tblMachine.created_at = DateTimeOffset.Now;
                            tblMachine.modified_at = DateTimeOffset.Now;
                            tblMachine.modified_by = String.Empty;


                            TblServiceMachine tblServiceMachine = new();
                            Guid guid = Guid.NewGuid();
                            tblServiceMachine.id = Convert.ToString(guid);
                            tblServiceMachine.service_id = serviceId.ToString();
                            tblServiceMachine.machine_id = tblMachine.id;
                            tblServiceMachine.created_at = DateTimeOffset.Now;
                            tblServiceMachine.modified_at = DateTimeOffset.Now;

                            _context.TblMachines.Add(tblMachine);
                            _context.TblServiceMachines.Add(tblServiceMachine);
                            _context.SaveChanges();
                            newMachines.Add(Convert.ToString(guid));
                            #region Add Roadmap and Hazard details to machine
                            if (serviceDTO[i].Machine[j].roadmap_details != null)
                            {
                                var smId = _context.TblServiceMachines.Where(sm => sm.machine_id == tblMachine.id && sm.service_id == serviceDTO[i].Machine[j].service_id).FirstOrDefault();
                                await RiskReAssessmentRoadmap(serviceDTO[i].Machine[j].roadmap_details, smId.id);
                            }
                            #endregion
                        }

                        newServicesAndMachinesId.Add(serviceId, newMachines);
                    }
                    else
                    {
                        TblServiceMachine tblServiceMachine = new();
                        tblServiceMachine.id = Guid.NewGuid().ToString();
                        tblServiceMachine.service_id = serviceId.ToString();
                        tblServiceMachine.machine_id = "00000000-0000-0000-0000-000000000000";
                        tblServiceMachine.created_at = DateTimeOffset.Now;
                        tblServiceMachine.modified_at = DateTimeOffset.Now;

                        _context.TblServiceMachines.Add(tblServiceMachine);
                        _context.SaveChanges();

                        newServicesAndMachinesId.Add(serviceId, null);
                    }

                }


                Result = "Service Created Successfully";

                #region Add Machine request to ERP

                var offer = (from offr in _context.TblOffers
                             join project in _context.TblProjects on offr.project_id equals project.id
                             join svc in _context.TblServices on offr.id equals svc.offer_id
                             join cust in _context.TblCustomers on project.customer_id equals cust.id
                             join offrContact in _context.TblContacts on offr.contact_id equals offrContact.contact_id
                             join projectContact in _context.TblContacts on project.contact_id equals projectContact.contact_id
                             //join serviceContact in _context.TblContacts on service.contact_id equals serviceContact.contact_id
                             where offr.id == serviceDTO.FirstOrDefault().offer_id
                             select new
                             {
                                 offerId = offr.id,
                                 projectId = offr.project_id,
                                 offer_contact_person = offrContact.display_name,
                                 offer_wbs_id = offr.WBSID,
                                 erp_project_id = project.erp_project_id,
                                 offer_status = offr.status,
                                 offer_contact_email = offrContact.email_address,
                                 offer_contact_number = offrContact.phone_number,
                                 offer_quote_type = offr.quote_type,
                                 offer_contact_id = offr.contact_id,
                                 project_contact_id = project.contact_id,
                                 companyCode = project.company_id
                             }).FirstOrDefault();

                var wbsDeleteObject = new WbsUpdateRequestEvent();
                if (offer is not null)
                {
                    wbsDeleteObject.Offer = new WbsUpdateRequestOffer();
                    wbsDeleteObject.Offer.ContactPerson = offer.offer_contact_person;
                    wbsDeleteObject.Offer.ERPProjectID = offer.erp_project_id;
                    wbsDeleteObject.Offer.Status = offer.offer_status;
                    wbsDeleteObject.Offer.ContactEmail = offer.offer_contact_email;
                    wbsDeleteObject.Offer.ContactNumber = offer.offer_contact_number;
                    wbsDeleteObject.Offer.OfferID = offer.offerId;
                    wbsDeleteObject.Offer.ProjectID = offer.projectId;
                    wbsDeleteObject.Offer.QuoteType = offer.offer_quote_type;
                    wbsDeleteObject.Offer.WBSID = offer.offer_wbs_id;

                    wbsDeleteObject.Offer.Services = new List<WbsUpdateRequestService>();

                    var serviceIds = newServicesAndMachinesId.Keys.ToList();

                    var serviceDetails = (from svc in _context.TblServices
                                              //join contact in _context.TblContacts on svc.contact_id equals contact.contact_id
                                          where serviceIds.Contains(svc.id)
                                          select new
                                          {
                                              contactEmail = string.Empty,//contact.email_address,
                                              region = svc.service_region,
                                              endDate = svc.end_date,
                                              startDate = svc.start_date,
                                              contactNumber = string.Empty,//contact.phone_number,
                                              contactPerson = string.Empty,//contact.display_name,
                                              description = svc.service_description,
                                              location = svc.service_location,
                                              serviceId = svc.id,
                                              serviceProductId = svc.service_type
                                          }).ToList();

                    foreach (var svc in serviceDetails)
                    {

                        var wbsService = new WbsUpdateRequestService();
                        var totalSumInHour = 0m;
                        var serviceProduct = svc.serviceProductId?.Split('-') ?? new List<string>().ToArray();

                        wbsService.Action = "ADD";
                        wbsService.ContactEmail = svc.contactEmail;
                        wbsService.Region = svc.region;
                        wbsService.EndDate = svc.endDate.Value;
                        wbsService.ContactNumber = svc.contactNumber;
                        wbsService.ContactPerson = svc.contactPerson;
                        wbsService.Description = svc.description;
                        wbsService.Location = svc.location;
                        wbsService.ServiceID = svc.serviceId;
                        wbsService.ServiceProductID = serviceProduct.Count() > 0 ? serviceProduct[0].Trim() : String.Empty;
                        wbsService.StartDate = svc.startDate.Value;
                        wbsService.Type = serviceProduct.Count() > 1 ? serviceProduct[1].Trim() : String.Empty;

                        var machineIdsToAdd = newServicesAndMachinesId[svc.serviceId];
                        var machineDetail = new WbsUpdateRequestMachineDetails
                        {
                            Machines = new List<WbsUpdateMachine>()
                        };
                        if (machineIdsToAdd != null)
                        {
                            var machines = (from machine in _context.TblMachines
                                            join serviceMachine in _context.TblServiceMachines on machine.id equals serviceMachine.machine_id
                                            where machineIdsToAdd.Contains(serviceMachine.id)
                                            select new
                                            {
                                                machineName = machine.machine_name,
                                                assetNumber = machine.asset_id,
                                                description = machine.machine_description,
                                                estimatedHour = machine.estimated_hours,
                                                machineId = serviceMachine.id,
                                                serialNumber = machine.serial_number,
                                                type = machine.machine_type,
                                                wbsId = serviceMachine.erp_wbs_id
                                            }).ToList();
                            foreach (var machine in machines)
                            {
                                var wbsMachine = new WbsUpdateMachine();

                                totalSumInHour = machine.estimatedHour + totalSumInHour;

                                wbsMachine.MachineName = machine.machineName;
                                wbsMachine.Action = "ADD";
                                wbsMachine.AssetNumber = machine.assetNumber;
                                wbsMachine.Description = machine.description;
                                wbsMachine.EstimatedHours = machine.estimatedHour;
                                wbsMachine.MachineID = machine.machineId;
                                wbsMachine.Manufacturer = String.Empty;
                                wbsMachine.SerialNumber = machine.serialNumber;
                                wbsMachine.Type = machine.type;
                                wbsMachine.WBSID = machine.wbsId;

                                machineDetail.Machines.Add(wbsMachine);
                            }
                        }
                        wbsService.MachineDetails = machineDetail;
                        wbsService.TotalSumInHours = totalSumInHour;

                        wbsDeleteObject.Offer.Services.Add(wbsService);
                    }

                    var techincalHeader = new RequestTechnicalHeader()
                    {
                        TenantID = httpContextAccessor.HttpContext?.User?.GetTenantId() ?? String.Empty,
                        CompanyCode = offer.companyCode,
                        EmailAddress = httpContextAccessor.HttpContext?.User?.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Email)?.Value ?? String.Empty,
                        RequestID = Guid.NewGuid().ToString(),
                        Timestamp = DateTime.UtcNow
                    };


                    wbsDeleteObject.TopicName = "wbsrequest";
                    wbsDeleteObject.TechnicalHeader = techincalHeader;

                    _messageBus.PublishToQueue(wbsDeleteObject, true);
                }

                #endregion

            }
            catch (Exception ex)
            {
                Result = "Service Creation Failed";
            }

            return Result;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="auditLogEntryEvent"></param>
        /// <returns></returns>
        private static async Task LogAuditEntry(AuditLogEntryEvent auditLogEntryEvent)
        {
            try
            {
                using var context = new Sch_Context();
                TblAuditEntry tblAuditEntry = new();
                tblAuditEntry.id = Guid.NewGuid().ToString();
                tblAuditEntry.project_id = auditLogEntryEvent?.Project_Id;
                tblAuditEntry.action = auditLogEntryEvent?.Action;
                tblAuditEntry.scope = auditLogEntryEvent?.Scope;
                tblAuditEntry.created_at = DateTimeOffset.UtcNow;
                tblAuditEntry.user_id = auditLogEntryEvent?.User_Id;
                tblAuditEntry.old_value = auditLogEntryEvent?.Old_Value;
                tblAuditEntry.new_value = auditLogEntryEvent?.New_Value;
                tblAuditEntry.affected_table = auditLogEntryEvent?.Affected_Table;
                tblAuditEntry.offer_id = auditLogEntryEvent?.Offer_Id;
                tblAuditEntry.service_id = auditLogEntryEvent?.Service_Id;
                context.TblAuditEntry.Add(tblAuditEntry);
                await context.SaveChangesAsync();
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        private string UpdateServiceActualHours(string serviceId, decimal actlHours)
        {
            try
            {
                string isSuccess = string.Empty;
                var serviceHours = _context.TblServices.Where(s => s.id == serviceId).FirstOrDefault();
                if (serviceHours != null)
                {
                    serviceHours.actual_hours -= Convert.ToInt32(actlHours);
                    _context.TblServices.Update(serviceHours);
                    _context.SaveChanges();
                    isSuccess = "Service hours updated";
                }
                return isSuccess;
            }
            catch (Exception)
            {

                throw;
            }
        }

        private string GetCurrentUserId() => httpContextAccessor.HttpContext.User.Claims.FirstOrDefault(c => c.Type == "Id")?.Value ?? String.Empty;
        private bool IsUserProjectManager() => httpContextAccessor.HttpContext.User.Claims.Where(c => c.Type == ClaimTypes.Role).Any(c => c.Value == "Global Admin");
    }
}
