﻿using Offer.API.EntityModels;
using Offer.API.Models.OfferDTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Offer.API.Services
{
    public interface IRoadMapService : IRepositoryBase<TblRoadmapMaster>
    {
        public ApiResponse<Dictionary<string, string>> SaveRoadMap(UploadRoadmapDTO list);
        public List<RoadMapMasterDTO> GetRoadMap();
        public List<TblLibrary> GetLibrary(string userId);
        public string CreateLibrary(List<LibraryDTO> list, string userId);
        public string DeleteBookMark(string[] libraryId);
        #region CustomRoadMap
        public string CustomRoadmap(List<RoadmapDTO> roadmaps);
        public string CustomSection(List<SectionMasterDTO> sections);
        public string CustomStep(List<StepMasterDTO> steps);
        public string CustomSubSection(List<SubSectionMasterDTO> subSections);
        #endregion
        #region InitialHazard
        public string InitialHazard(List<InitialHazardMasterDTO> initialHazardMaster);
        public string CounterMeasure(List<CounterMeasureDTO> counterMeasure);
        public List<InitialHazardMasterDTO> InitialHazard(string userId);
        public List<CounterMeasureDTO> CounterMeasure(string userid);
        #endregion
        public MachineHazardDTO GetHazardMachineById(string HazardMachineId);
        string SaveTemplateRoadMap(List<TemplateRoadmapDto> roadMaps);
        List<RoadMapMasterDTO> GetCustomTemplateRoadMap();
        Task<List<RoadMapMasterDTO>> GetRoadMap(string roadmapId);
        Task<string> DeleteTemplateRoadmap(DeleteRoadmapFile roadmap);
        Task<string> UpdateLibraryRoadmap(EditPredefinedRoadmapDto roadmap);
        List<RoadMapMasterDTO> GetPredefinedTemplateRoadMap();
        Task<string> SaveSiteDetails(TblSiteDetails tblSiteDetails);
        Task<List<TblSiteDetails>> GetSiteDetails(string siteName);
    }

}
