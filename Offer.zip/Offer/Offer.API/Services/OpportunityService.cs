﻿using Offer.API.DbContextClass;
using Offer.API.EntityModels;
using Offer.API.Models.OfferDTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using Microsoft.AspNetCore.Http;

namespace Offer.API.Services
{
    public class OpportunityService : RepositoryBase<TblOpportunity>, IOpportunityService
    {
        private readonly Sch_Context _context;
        private readonly IHttpContextAccessor httpContextAccessor;

        public OpportunityService(Sch_Context context
            , IHttpContextAccessor httpContextAccessor) : base(context)
        {
            _context = context;
            this.httpContextAccessor = httpContextAccessor;
        }

        public async Task<List<OpportunityDTO>> GetOpportunityByProjectId(string projectId)
        {
            var result = new List<OpportunityDTO>();
            try
            {
                if (IsUserOfferManager())
                    result = await (from opp in _context.TblOpportunity
                                    join project in _context.TblProjects on opp.project_id equals project.id
                                    join customer in _context.TblCustomers on project.customer_id equals customer.id
                                    where opp.project_id == projectId
                                    select new OpportunityDTO
                                    {
                                        OpportunityId = opp.id,
                                        ProjectId = opp.project_id,
                                        Status = opp.status,
                                        Customer_Name = customer.customer_name,
                                        Erp_Project_Id = project.erp_project_id
                                    }).OrderByDescending(x => x.Created_At).ToListAsync();
                else
                    result = await (from opp in _context.TblOpportunity
                                    join project in _context.TblProjects on opp.project_id equals project.id
                                    join prjstaff in _context.TblProjectStaffs on new { userId = GetCurrentUserId(), projectId = project.id } equals new { userId = prjstaff.user_id, projectId = prjstaff.project_id }
                                    join customer in _context.TblCustomers on project.customer_id equals customer.id
                                    where opp.project_id == projectId
                                    select new OpportunityDTO
                                    {
                                        OpportunityId = opp.id,
                                        ProjectId = opp.project_id,
                                        Status = opp.status,
                                        Customer_Name = customer.customer_name,
                                        Erp_Project_Id = project.erp_project_id
                                    }).OrderByDescending(x => x.Created_At).ToListAsync();

                //var result = await (from opp in _context.TblOpportunity
                //                    where opp.project_id == projectId
                //                    select new OpportunityDTO
                //                    {
                //                        OpportunityId = opp.id,
                //                        ProjectId = opp.project_id,
                //                        Status = opp.status,
                //                        Customer_Name = opp.customer_name,
                //                    }).ToListAsync();
                return result;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }
        public async Task<List<OpportunityDTO>> GetOpportunities()
        {
            var result = new List<OpportunityDTO>();
            try
            {
                if (IsUserOfferManager())
                    result = await (from opp in _context.TblOpportunity
                                    join project in _context.TblProjects on opp.project_id equals project.id
                                    join customer in _context.TblCustomers on project.customer_id equals customer.id
                                    select new OpportunityDTO
                                    {
                                        OpportunityId = opp.id,
                                        ProjectId = opp.project_id,
                                        Status = opp.status,
                                        Customer_Name = customer.customer_name,
                                        Erp_Project_Id = project.erp_project_id,
                                        Created_At = opp.created_at
                                    }).OrderByDescending(x => x.Created_At).ToListAsync();
                else
                    result = await (from opp in _context.TblOpportunity
                                    join project in _context.TblProjects on opp.project_id equals project.id
                                    join prjstaff in _context.TblProjectStaffs on new { userId = GetCurrentUserId(), projectId = project.id } equals new { userId = prjstaff.user_id, projectId = prjstaff.project_id }
                                    join customer in _context.TblCustomers on project.customer_id equals customer.id
                                    select new OpportunityDTO
                                    {
                                        OpportunityId = opp.id,
                                        ProjectId = opp.project_id,
                                        Status = opp.status,
                                        Customer_Name = customer.customer_name,
                                        Erp_Project_Id = project.erp_project_id,
                                        Created_At = opp.created_at
                                    }).OrderByDescending(x => x.Created_At).ToListAsync();
                return result;
            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        private string GetCurrentUserId() => httpContextAccessor.HttpContext.User.Claims.FirstOrDefault(c => c.Type == "Id")?.Value ?? String.Empty;

        private bool IsUserOfferManager() => httpContextAccessor.HttpContext.User.Claims.Where(c => c.Type == ClaimTypes.Role).Any(c => c.Value == "Global Admin");
    }
}
