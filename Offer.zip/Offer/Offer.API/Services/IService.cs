﻿using Offer.API.IntegrationEvents.Events;
using Offer.API.Models.OfferDTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Offer.API.Services
{
    public interface IService
    {
        public Task<string> CreateService(List<ServiceDTO> service);
        Task<string> AddMachines(List<MachineDTO> machineDTO);
        public string UpdateServiceAndMachine(ServiceDTO service);
        public string UpdateService(EditServiceDTO service);
        public string UpdateMachine(MachineDTO machine);
        Task<ActualHoursRequest> AddActualHours(ActualHoursDto actualHours);
        Task<List<string>> GetServiceMaterialByCompanyCode(ServiceMaterialResponseDTO serviceMaterial);
        Task<List<GetMachineActualHours>> GetRecentLogActualHours(string serviceMachineId, string userId);
        Task<List<RoadMapMasterDTO>> GetAllMachineRoadmaps(string machineId);
        Task<string> GetRegionByCompanyCode(string companycode);
        Task<List<RiskReAssessmentMachinesDto>> GetMachinesByService(string serviceId);
        Task<MachineHazardDto> GethazardDetailsById(string hazardId);
        Task<RoadMapMasterDTO> GetRoadmapDetailsById(string roadmapId);
        Task<string> CreateRiskReAssessmentService(List<ServiceDTO> serviceDTO);
        Task<bool> RiskReAssessmentRoadmap(List<RoadMapMasterDTO> roadmapList, string servicemachineId);
    }
}
