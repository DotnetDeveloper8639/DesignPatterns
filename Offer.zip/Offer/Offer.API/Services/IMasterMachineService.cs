﻿using Offer.API.EntityModels;
using Offer.API.Helper;
using Offer.API.Models.OfferDTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Offer.API.Services
{
    public interface IMasterMachineService : IRepositoryBase<TblMasterMachine>
    {
        Task<List<GetMachineDto>> GetMasterMachineDetails(string MachineName, int count, int increasedCount);
        Task<List<GetMachineDto>> GetFilteredMasterMachineDetails(SearchMachineDto searchMachineDto);
        Task<GetMachineAttributeDto> GetMachineAttribute(string machineId);
        MachineApiResponse<Dictionary<int, MaterMachineFileUploadDTO>> FileUploadForMasterMachineInJSonFormate(List<MaterMachineFileUploadDTO> Machines);

        string MachineEdit(MachineEditDTO editMachine);

        Task<List<TblMachine>> GetMasterMachineDetails();
        Task<List<CustomerMachineDto>> GetCustomerMachineDetails(string customerId, int count, int increasedCount);
        Task<List<TblApplication>> GetAllApplication(string search, int count, int increasedCount);
        Task<List<TblControlSystem>> GetAllControlSystem(string search, int count, int increasedCount);
        Task<List<TblSpecificFeature>> GetAllSpecificFeature(string search, int count, int increasedCount);
        Task<List<TblMachineType>> GetAllMachineType(string search, int count, int increasedCount);
        Task<string> CreateApplication(List<ApplicationDto> application);
        Task<string> CreateControlSystem(List<ControlSystemDto> controlSystems);
        Task<string> CreateSpecificFeatuere(List<SpecificFeatureDto> specificFeatures);
        Task<string> CreateMachineType(List<MachineTypeDto> machineType);
        Task<string> DeleteApplication(ApplicationDto application);
        Task<string> DeleteSpecificFeature(SpecificFeatureDto specificFeature);
        Task<string> DeleteMachineType(MachineTypeDto machineType);
        Task<string> DeleteControlSystem(ControlSystemDto controlSystem);
        Task<List<MachineReferenceDto>> GetMachineReferences(string machineId);
        Task<MachineReferenceForBulkUploadDto> GetMachineReferencesForBulkUpload();
        Task<string> RemoveMasterMachine(List<string> list);
        Task<bool> CreateMasterMachine(GetMachineDto machineDto);
        Task<MachineApiResponse<Dictionary<int, MaterMachineFileUploadDTO>>> MachineValidation(List<MaterMachineFileUploadDTO> materMachines);

        #region Machine Images
        Task<ResponseVM> AddUpdateMachineImages(List<MachineImagesUploadDTO> masterMachineImages);
        Task<ResponseVM> GetMachineImages(string machineId);
        #endregion
    }
}
