﻿using Offer.API.EntityModels;
using Offer.API.IntegrationEvents.Events;
using Offer.API.Models.OfferDTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Offer.API.Services
{
    public interface IOfferStatusService : IRepositoryBase<TblOffer>
    {
        Task<List<FinalQuotationsDTO>> GetFinalQuotationVersions(string offerId);
        Task<bool> AddFinalQuotation(AddFinalQuotationDTO addFinalQuotationDTO);
        string GenerateLayoutQuotationByCommercialQuotationNumber(AddEditLayoutQuotationDTO addEditLayoutQuotationDTO);
        Task<List<OfferStatusDTO>> GetOfferStatusDetailsById(string projectid, string offerId);
        Task<OfferStatusDTO> GetOfferServiceDetails(string serviceId);
        Task<List<OfferStatusDTO>> GetOfferMachineDetails(string projectid, string offerId, string serviceId);
        Task<List<OfferStatusDTO>> GetOfferManagementDeatails();
        Task<GetOfferOpportunityDTO> GetOfferByOpportunityId(string opportunityId);
        Task<string> CreateOffer(CreateOfferDTO offerStatus);
        string UpdateOffer(EditOfferDTO offerStatus);
        string DeleteOfferById(List<string> list);
        string DeleteOfferServiceById(List<string> list);

        string DeleteMachineById(List<string> list);
        Dictionary<string, int> GetOffertMetrics();
        // List<string> GetProjectId(string email);
        List<ResponseProjectDTO> GetProjectsByCustomerId(string customerId);
        List<string> GetMachineName();
        public string GetOfferId();
        Task<List<CustomerDTO>> GetCustomerName(string customerName);
        List<LoginUserDTO> GetLoginUsers(string user);
        string CreateServiceProduct(ServiceMaterialRequestEvent serviceMaterial);

        Task WbsResponseProcess(WbsResponseEvent wbsResponse);

        Task UpdatePlannedCost(ErpPlannedCostResponseEvent wbsResponse);

        Task UpdateActualCost(ErpActualCostResponseEvent wbsResponse);
        Task UpdateCalculatedHour(ErpCalculatedHourResponseEvent erpCalculatedHour);
        Task UpdateActualSales(ErpActualSaleResponseEvent actualSaleResponse);
        Task UpdatePlannedSales(ErpPlannedSalesResponseEvent plannedSaleResponse);
        Task AddCommercialQuotation(CommercialQuotationResponseEvent commercialQuotation);
        Task AddCommercialQuotationV1(CommercialQuotationResponseEventV1 commercialQuotation);
        Task<bool> DeleteOpprtunity(DeleteOpportunityDTO deleteOpportunity);
        Task<CommercialQuotation> GetCommercialQuotation(string offerId);
        Task<List<CommercialQuotation>> GetCommercialQuotationVersion(string offerId);
        Task<string> AssignOffer(EditOfferDTO editOffer);
        Task<Dictionary<string, List<OfferEffortMetricsDto>>> GetOfferDailyEffortMetrics(string range);

    }
}
