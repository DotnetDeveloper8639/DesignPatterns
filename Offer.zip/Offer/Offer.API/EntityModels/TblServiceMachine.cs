﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Offer.API.EntityModels
{
    [Table("tblServiceMachine")]
    public class TblServiceMachine
    {
        [Key]
        [Column(TypeName = "nvarchar(50)")]
        public string id { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        [ForeignKey("TblService")]
        public string service_id { get; set; }
        [Column(TypeName = "datetimeoffset(7)")]
        public DateTimeOffset created_at { get; set; }
        [Column(TypeName = "datetimeoffset(7)")]
        public DateTimeOffset modified_at { get; set; }
        [Column(TypeName = "nvarchar(80)")]
        [ForeignKey("TblMachine")]
        public string machine_id { get; set; }

        [Column("erp_wbs_id", TypeName = "nvarchar(100)")]
        public string erp_wbs_id { get; set; }
        [Column(TypeName = "decimal(18,4)")]
        public decimal estimated_hours { get; set; }
        [Column(TypeName = "bit")]
        public bool isactive { get; set; }
        public virtual TblService TblService { get; set; }
        public virtual TblMachine TblMachine { get; set; }
    }
}
