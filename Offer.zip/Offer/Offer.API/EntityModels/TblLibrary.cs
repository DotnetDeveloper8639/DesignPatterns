﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Offer.API.EntityModels
{
    [Table("tblLibrary")]
    public class TblLibrary
    {
        [Key]
        [Column(TypeName = "varchar(50)")]
        public string id { get; set; }
        [Column(TypeName = "nvarchar(1000)")]
        public string name { get; set; }
        [Column(TypeName = "nvarchar(100)")]
        public string type { get; set; }
        [Column(TypeName = "nvarchar(MAX)")]
        public string url { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string content_type { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string version { get; set; }
        [Column(TypeName = "nvarchar(MAX)")]
        public string preview_image_url { get; set; }
        [Column(TypeName = "nvarchar(100)")]
        public string drive_id { get; set; }
        [Column(TypeName = "nvarchar(100)")]
        public string item_id { get; set; }
        [Column(TypeName = "datetimeoffset(7)")]
        public DateTimeOffset created_at { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string created_by { get; set; }
        [Column(TypeName = "datetimeoffset(7)")]
        public DateTimeOffset modified_at { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string modified_by { get; set; }
    }
}
