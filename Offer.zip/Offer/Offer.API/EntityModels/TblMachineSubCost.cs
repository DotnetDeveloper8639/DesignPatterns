﻿namespace Offer.API.EntityModels
{
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;

    [Table("TblMachineSubCost")]
    public class TblMachineSubCost
    {
        [Key]
        [Column(TypeName = "nvarchar(50)")]
        public string id { get; set; }

        [Column(TypeName = "nvarchar(50)")]
        [ForeignKey("TblServiceMachine")]
        public string service_machine_id { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal quantity { get; set; }
        [Column(TypeName = "nvarchar(10)")]
        public string unit { get; set; }

        [Column(TypeName = "money")]
        public decimal cost { get; set; }

        [Column(TypeName = "nvarchar(500)")]
        public string description { get; set; }
    }
}
