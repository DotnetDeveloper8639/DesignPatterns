﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Offer.API.EntityModels
{
    [Table("tblOrder")]
    public class TblOrder
    {
        [Key]
        [Column(TypeName = "nvarchar(50)")]
        public string id { get; set; }

        [Column(TypeName = "nvarchar(50)")]
        public string erp_order_id { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string erp_project_id { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string erp_wbs_id { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string service_product_id { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        [ForeignKey("TblService")]
        public string service_id { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string status { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        [ForeignKey("TblOrderKPI")]
        public string order_kpi_id { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        [ForeignKey("TblOffer")]
        public string offer_id { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        [ForeignKey("TblCustomer")]
        public string customer_id { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        [ForeignKey("TblProject")]
        public string project_id { get; set; }
        [Column(TypeName = "datetimeoffset(7)")]
        public DateTimeOffset created_at { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string created_by { get; set; }
        [Column(TypeName = "datetimeoffset(7)")]
        public DateTimeOffset modified_at { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string modified_by { get; set; }

        public virtual TblService TblService { get; set; }
        public virtual TblOrderKPI TblOrderKPI { get; set; }
        public virtual TblOffer TblOffer { get; set; }
        public virtual TblCustomer TblCustomer { get; set; }
        public virtual TblProject TblProject { get; set; }
    }
}
