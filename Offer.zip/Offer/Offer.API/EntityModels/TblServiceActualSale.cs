﻿namespace Offer.API.EntityModels
{
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;

    [Table("tblServiceActualSale")]
    public class TblServiceActualSale
    {
        [Key]
        [Column(TypeName = "nvarchar(50)")]
        public string id { get; set; }

        [Column(TypeName = "nvarchar(50)")]
        [ForeignKey("TblService")]
        public string service_id { get; set; }

        [Column(TypeName = "nvarchar(50)")]
        public string cost_type { get; set; }
        [Column(TypeName = "nvarchar(10)")]
        public string currency { get; set; }

        [Column(TypeName = "money")]
        public decimal actual_sale_value { get; set; }
    }
}
