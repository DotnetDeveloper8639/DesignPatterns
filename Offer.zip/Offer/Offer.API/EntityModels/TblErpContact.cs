﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Offer.API.EntityModels
{
    [Table("tblErpContact")]
    public class TblErpContact
    {
        [Key]
        [Column(TypeName = "nvarchar(50)")]
        public string erp_contact_id { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string first_name { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string customer_id { get; set; }
        [Column(TypeName = "nvarchar(150)")]
        public string last_name { get; set; }
        [Column(TypeName = "nvarchar(150)")]
        public string display_name { get; set; }
        [Column(TypeName = "nvarchar(150)")]
        public string email_address { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string title { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string language { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string phone_number { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string department { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string modified_by { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string created_by { get; set; }
    }
}
