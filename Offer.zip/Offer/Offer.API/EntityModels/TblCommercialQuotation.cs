﻿namespace Offer.API.EntityModels
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;

    [Table("tblCommercialQuotation")]
    public class TblCommercialQuotation
    {
        [Key]
        [Column(TypeName = "nvarchar(50)")]
        public string id { get; set; }

        [Column(TypeName = "nvarchar(50)")]
        public string project_id { get; set; }

        [Column(TypeName = "nvarchar(50)")]
        public string erp_project_id { get; set; }

        [Column(TypeName = "nvarchar(50)")]
        [ForeignKey("TblOffer")]
        public string offer_id { get; set; }
        [Column(TypeName = "nvarchar(100)")]
        public string quotationnumber { get; set; }

        [Column(TypeName = "nvarchar(25)")]
        public string content_type { get; set; }

        [Column(TypeName = "nvarchar(25)")]
        public string encoding_format { get; set; }

        [Column(TypeName = "varbinary(MAX)")]
        public byte[] data { get; set; }
        [Column(TypeName = "nvarchar(20)")]
        public string version { get; set; }
        [Column(TypeName = "datetimeoffset(7)")]
        public DateTimeOffset created_at { get; set; }
        [Column(TypeName = "nvarchar(max)")]
        public string layout_quotation_details { get; set; }

    }
}
