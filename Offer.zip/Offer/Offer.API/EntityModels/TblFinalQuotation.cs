﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Offer.API.EntityModels
{
    [Table("tblFinalQuotation")]
    public class TblFinalQuotation
    {
        [Key]
        [Column(TypeName = "nvarchar(50)")]
        public string id { get; set; }
        [Column(TypeName = "nvarchar(100)")]
        [ForeignKey("TblOffer")]
        public string offerId { get; set; }
        [Column(TypeName = "nvarchar(100)")]
        public string driveId { get; set; }
        [Column(TypeName = "nvarchar(100)")]
        public string itemId { get; set; }
        [Column(TypeName = "nvarchar(MAX)")]
        public string url { get; set; }
        [Column(TypeName = "nvarchar(150)")]
        public string name { get; set; }
        [Column(TypeName = "decimal(18,2)")]
        public decimal? version { get; set; }
        [Column(TypeName = "datetimeoffset(7)")]
        public DateTimeOffset created_date { get; set; }
        [Column(TypeName = "nvarchar(100)")]
        public string created_by { get; set; }
    }
}
