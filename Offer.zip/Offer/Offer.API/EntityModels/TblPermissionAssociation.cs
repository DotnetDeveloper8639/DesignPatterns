﻿
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Offer.API.EntityModels
{
    [Table("tblPermissionAssociation")]
    public class TblPermissionAssociation
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column(TypeName = "nvarchar(50)")]
        public string id { get; set; }

        [Column(TypeName = "nvarchar(50)")]
        [ForeignKey("tblRoles")]
        public string role_id { get; set; }

        [Column(TypeName = "nvarchar(50)")]
        [ForeignKey("tblPermissions")]
        public int permission_id { get; set; }
    }
}
