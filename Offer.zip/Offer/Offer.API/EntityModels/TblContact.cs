﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Offer.API.EntityModels
{
    [Table("tblContact")]
    public class TblContact
    {
        [Key]
        [Column(TypeName = "nvarchar(50)")]
        public string contact_id { get; set; }
        [Column(TypeName = "nvarchar(80)")]
        public string first_name { get; set; }
        [Column(TypeName = "nvarchar(80)")]
        public string last_name { get; set; }
        [Column(TypeName = "nvarchar(160)")]
        public string display_name { get; set; }
        [Column(TypeName = "nvarchar(150)")]
        public string email_address { get; set; }
        [Column(TypeName = "nvarchar(10)")]
        public string title { get; set; }
        [Column(TypeName = "nvarchar(10)")]
        public string language { get; set; }
        [Column(TypeName = "nvarchar(80)")]
        public string phone_number { get; set; }
        [Column(TypeName = "nvarchar(80)")]
        public string department { get; set; }
        [Column(TypeName = "datetimeoffset(7)")]
        public DateTimeOffset created_at { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string created_by { get; set; }
        [Column(TypeName = "datetimeoffset(7)")]
        public DateTimeOffset modified_at { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string modified_by { get; set; }
    }
}
