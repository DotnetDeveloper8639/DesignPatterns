﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Offer.API.EntityModels
{
    [Table("tblHazardMedia")]
    public class TblHazardMedia
    {
        [Key]
        [Column(TypeName = "nvarchar(50)")]
        public string id { get; set; }
        [Column(TypeName = "nvarchar(MAX)")]
        public string url { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string type { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        [ForeignKey("MachineHazards")]
        public string machine_hazard_id { get; set; }
        [Column(TypeName = "nvarchar(100)")]
        public string name { get; set; }
        [Column(TypeName = "nvarchar(100)")]
        public string drive_id { get; set; }
        [Column(TypeName = "nvarchar(100)")]
        public string item_id { get; set; }
        [Column(TypeName = "int")]
        public int? image_size { get; set; }
        public DateTimeOffset created_at { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string created_by { get; set; }
        [Column(TypeName = "datetimeoffset(7)")]
        public DateTimeOffset modified_at { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string modified_by { get; set; }

        public virtual TblMachineHazards MachineHazards { get; set; }
    }
}
