﻿namespace Offer.API.EntityModels
{
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;

    [Table("tblServiceMaterials")]
    public class TblServiceMaterial
    {
        [Key]
        [Column(TypeName = "nvarchar(50)")]
        public string id { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string service_product_id { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string company_code { get; set; }

        [Column(TypeName = "nvarchar(50)")]
        public string language { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string value { get; set; }
        [Column(TypeName = "nvarchar(MAX)")]
        public string sales_text { get; set; }
        [Column(TypeName = "nvarchar(MAX)")]
        public string value_type { get; set; }
    }
}
