﻿namespace Offer.API.EntityModels
{
    using System;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;

    [Table("tblCommercialQuotationChunk")]
    public class TblCommercialQuotationChunk
    {
        [Key]
        [Column(TypeName = "nvarchar(50)")]
        public string id { get; set; }

        [Column(TypeName = "nvarchar(80)")]
        public string project_id { get; set; }

        [Column(TypeName = "nvarchar(80)")]
        public string erp_project_id { get; set; }

        [Column(TypeName = "nvarchar(80)")]
        [ForeignKey("TblOffer")]
        public string offer_id { get; set; }

        [Column(TypeName = "nvarchar(80)")]
        public string quotation_number { get; set; }

        [Column(TypeName = "nvarchar(80)")]
        public string content_type { get; set; }

        [Column(TypeName = "nvarchar(100)")]
        public string encoding_format { get; set; }

        [Column(TypeName = "varbinary(MAX)")]
        public byte[] data { get; set; }
   
        [Column(TypeName = "datetimeoffset(7)")]
        public DateTimeOffset created_at { get; set; }

        [Column(TypeName = "int")]
        public int current_chunk_number { get; set; }

        [Column(TypeName = "int")]
        public int next_chunk_number { get; set; }

        [Column(TypeName = "int")]
        public int total_chunk { get; set; }
    }
}
