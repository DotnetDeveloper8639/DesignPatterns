﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Offer.API.EntityModels
{
    [Table("tblTenantCatalog")]
    public class TblTenantCatalog
    {
        [Key]
        [Column(TypeName = "nvarchar(50)")]
        public string id { get; set; }
        [Column(TypeName = "nvarchar(80)")]
        public string client_name { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string region { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string country { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string language { get; set; }
    }
}
