﻿namespace Offer.API.EntityModels
{
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;

    [Table("tblServiceCost")]
    public class TblServiceCost
    {
        [Key]
        [Column(TypeName = "nvarchar(50)")]
        public string id { get; set; }

        [Column(TypeName = "nvarchar(50)")]
        [ForeignKey("TblService")]
        public string service_id { get; set; }

        [Column(TypeName = "money")]
        public decimal total_calculated_cost { get; set; }
    }
}
