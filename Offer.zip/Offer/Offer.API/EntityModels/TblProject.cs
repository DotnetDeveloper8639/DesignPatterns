﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Offer.API.EntityModels
{
    [Table("tblProject")]
    public class TblProject
    {
        [Key]
        [Column(TypeName = "nvarchar(50)")]
        public string id { get; set; }
        [Column(TypeName = "nvarchar(80)")]
        public string erp_project_id { get; set; }
        [Column(TypeName = "nvarchar(80)")]
        public string project_name { get; set; }
        [Column(TypeName = "nvarchar(160)")]
        public string description { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? start_date { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? end_date { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string status { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        [ForeignKey("TblControllingArea")]
        public string controlling_id { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        [ForeignKey("TblTenantCatalog")]
        public string tenant_id { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        [ForeignKey("TblCompany")]
        public string company_id { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        [ForeignKey("TblCustomer")]
        public string customer_id { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        [ForeignKey("TblProjectStaff")]
        public string staff_id { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        [ForeignKey("TblOrder")]
        public string order_id { get; set; }
        [Column(TypeName = "nvarchar(1000)")]
        public string notes { get; set; }
        [Column(TypeName = "int")]
        public int estimatedhours { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        [ForeignKey("TblProjectKPI")]
        public string project_kpi_id { get; set; }
        [Column(TypeName = "nvarchar(80)")]
        public string contact_id { get; set; }
        [Column(TypeName = "datetimeoffset(7)")]
        public DateTimeOffset created_at { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string created_by { get; set; }
        [Column(TypeName = "datetimeoffset(7)")]
        public DateTimeOffset modified_at { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string modified_by { get; set; }
        public virtual TblCustomer TblCustomer { get; set; }
        public virtual TblTenantCatalog TblTenantCatalog { get; set; }
        public virtual TblControllingArea TblControllingArea { get; set; }
        public virtual TblCompany TblCompany { get; set; }
        public virtual TblProjectStaff TblProjectStaff { get; set; }
        public virtual TblOrder TblOrder { get; set; }
        public virtual TblProjectKPI TblProjectKPI { get; set; }

    }
}
