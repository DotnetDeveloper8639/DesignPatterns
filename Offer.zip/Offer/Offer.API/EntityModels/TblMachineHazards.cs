﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Offer.API.EntityModels
{
    [Table("tblMachineHazards")]
    public class TblMachineHazards
    {
        [Key]
        [Column(TypeName = "nvarchar(50)")]
        public string id { get; set; }
        [Column(TypeName = "nvarchar(100)")]
        public string name { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        [ForeignKey("HazardType")]
        public string hazard_type_id { get; set; }
        [Column(TypeName = "nvarchar(MAX)")]
        public string initial_hazard { get; set; }
        [Column(TypeName = "nvarchar(MAX)")]
        public string counter_measure { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        [ForeignKey("TblServiceMachineSteps")]
        public string service_machine_steps_id { get; set; }
        [Column(TypeName = "nvarchar(255)")]
        public string version { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string hazard_status { get; set; }
        [Column(TypeName = "datetimeoffset(7)")]
        public DateTimeOffset created_at { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string created_by { get; set; }
        [Column(TypeName = "datetimeoffset(7)")]
        public DateTimeOffset modified_at { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string modified_by { get; set; }

        public virtual TblHazardType HazardType { get; set; }
        public virtual TblServiceMachineSteps TblServiceMachineSteps { get; set; }
    }
}
