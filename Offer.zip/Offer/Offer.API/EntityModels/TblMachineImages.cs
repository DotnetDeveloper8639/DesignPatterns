﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Offer.API.EntityModels
{
    [Table("tblMachineImages")]
    public class TblMachineImages
    {
        [Key]
        [Column(TypeName = "nvarchar(80)")]
        public string id { get; set; }

        [Column(TypeName = "nvarchar(80)")]
        public string machine_id { get; set; }


        [Column(TypeName = "datetimeoffset(7)")]
        public DateTimeOffset? created_at { get; set; }

        [Column(TypeName = "nvarchar(50)")]
        public string created_by { get; set; }

        [Column(TypeName = "datetimeoffset(7)")]
        public DateTimeOffset? deleted_at { get; set; }

        [Column(TypeName = "nvarchar(50)")]
        public string deleted_by { get; set; }

        [Column(TypeName = "bit")]
        public bool is_primary { get; set; }

        [Column(TypeName = "bit")]
        public bool is_active { get; set; }

        [Column(TypeName = "nvarchar(MAX)")]
        public string url { get; set; }

        [Column(TypeName = "nvarchar(MAX)")]
        public string thumbnail_url { get; set; }

        [Column(TypeName = "nvarchar(100)")]
        public string file_name { get; set; }

        [Column(TypeName = "nvarchar(100)")]
        public string drive_id { get; set; }

        [Column(TypeName = "nvarchar(100)")]
        public string item_id { get; set; }

        [Column(TypeName = "int")]
        public int? image_size { get; set; }


    }
}
