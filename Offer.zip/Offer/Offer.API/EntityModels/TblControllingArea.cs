﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Offer.API.EntityModels
{
    [Table("tblControllingArea")]
    public class TblControllingArea
    {
        [Key]
        [Column(TypeName = "nvarchar(50)")]
        public string id { get; set; }
        [Column(TypeName = "nvarchar(80)")]
        public string controlling_area { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string controlling_area_code { get; set; }
    }
}
