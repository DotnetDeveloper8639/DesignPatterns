﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Offer.API.EntityModels
{
    [Table("tblGroups")]
    public class TblGroups
    {
        [Key]
        [Column(TypeName = "nvarchar(50)")]
        public string id { get; set; }
        [Column(TypeName = "nvarchar(160)")]
        public string group_name { get; set; }
        [Column(TypeName = "nvarchar(255)")]
        public string group_email_address { get; set; }
    }
}
