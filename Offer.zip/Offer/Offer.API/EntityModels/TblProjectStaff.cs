﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Offer.API.EntityModels
{
    [Table("tblProjectStaff")]
    public class TblProjectStaff
    {
        [Key]
        [Column(TypeName = "nvarchar(50)")]
        public string id { get; set; }
        [Column(TypeName = "nvarchar(80)")]
        public string project_id { get; set; }
        [Column(TypeName = "nvarchar(80)")]
        public string user_id { get; set; }
        [Column(TypeName = "nvarchar(80)")]
        public string group_id { get; set; }
        [Column(TypeName = "datetimeoffset(7)")]
        public DateTimeOffset created_at { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string created_by { get; set; }
        [Column(TypeName = "datetimeoffset(7)")]
        public DateTimeOffset modified_at { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string modified_by { get; set; }

    }
}
