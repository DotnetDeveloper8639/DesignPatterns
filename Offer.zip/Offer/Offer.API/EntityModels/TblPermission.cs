﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Offer.API.EntityModels
{
    [Table("tblPermissions")]
    public class TblPermission
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column(TypeName = "int")]
        public int id { get; set; }

        [Required]
        [Column(TypeName = "nvarchar(160)")]
        public string name { get; set; }

        [Required]
        [Column(TypeName = "nvarchar(160)")]
        public string display_name { get; set; }
        [Column(TypeName = "bit")]
        public bool is_active { get; set; }
        [Column(TypeName = "int")]
        public int serial_number { get; set; }
    }
}
