﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Offer.API.EntityModels
{
    [Table("tblRoles")]
    public class TblRoles
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column(TypeName = "nvarchar(50)")]
        public string id { get; set; }

        [Column(TypeName = "nvarchar(160)")]
        public string role_name { get; set; }

        [Column("is_default", TypeName = "bit")]
        public bool IsDefault { get; set; }
        [Column("is_global_admin_role", TypeName = "bit")]
        public bool IsGlobalAdminRole { get; set; }
    }
}
