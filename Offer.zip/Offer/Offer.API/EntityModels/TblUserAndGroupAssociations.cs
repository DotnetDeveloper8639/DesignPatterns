﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Offer.API.EntityModels
{
    [Table("tblUserAndGroupAssociation")]
    public class TblUserAndGroupAssociations
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        [Column(TypeName = "nvarchar(50)")]
        public string id { get; set; }

        [Column(TypeName = "nvarchar(50)")]
        [ForeignKey("TblUsers")]
        public string members { get; set; }

        [Column(TypeName = "nvarchar(50)")]
        [ForeignKey("TblGroups")]
        public string group_id { get; set; }
    }
}
