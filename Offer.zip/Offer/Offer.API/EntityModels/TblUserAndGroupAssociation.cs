﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Offer.API.EntityModels
{
    [Table("tblUserAndGroupAssociation")]
    public class TblUserAndGroupAssociation
    {
        [Key]
        [Column(TypeName = "nvarchar(50)")]
        public string id { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string owners { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        public string members { get; set; }
        [Column(TypeName = "nvarchar(50)")]
        [ForeignKey("TblGroups")]
        public string group_id { get; set; }

        public virtual TblGroups TblGroups { get; set; }
    }
}
