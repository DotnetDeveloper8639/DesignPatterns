﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Offer.API.Models.OfferDTO
{
    public class ResponseProjectDTO
    {
        public string Project_Id { get; set; }
        public string Erp_Project_Id { get; set; }
    }
}
