﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Offer.API.Models.OfferDTO
{
    public class MaterMachineFileUploadDTO
    {
        public int Row_Number { get; set; }
        public string Machine_Name { get; set; }
        public string Machine_Type { get; set; }
        public string Manufacturer { get; set; }
        public string Model { get; set; }
        public string Serial_Number { get; set; }
        public string Asset_Number { get; set; }
        public string Description { get; set; }
        public string Customer_Id { get; set; }
        public string IndustrySegment { get; set; }
        public string SubIndustrySegment { get; set; }
        public List<MachineMetadataDto> MachineMetadata { get; set; }
        public List<MachineImageDto> MachineImage { get; set; }
    }

    public class MachineImagesUploadDTO
    {
        public string Id { get; set; }

        public string Machine_Id { get; set; }
        public bool Is_Primary { get; set; }
        public string Url { get; set; }
        public string Thumbnail_Url { get; set; }
        public string file_name { get; set; }
        public string Drive_Id { get; set; }
        public string Item_Id { get; set; }
        public string Modified_By { get; set; }
        public bool Is_Active { get; set; }
        public int? Image_Size { get; set; }

    }
    public class GetMachineImagesDTO
    {
        public string Id { get; set; }
        public string Machine_Id { get; set; }
        public bool Is_Primary { get; set; }
        public string Url { get; set; }
        public string Thumbnail_Url { get; set; }
        public string file_name { get; set; }
        public string Drive_Id { get; set; }
        public string Item_Id { get; set; }
        public int? Image_Size { get; set; }

        public DateTimeOffset? created_at { get; set; }

        public string created_by { get; set; }
        public bool is_primary { get; set; }
        public bool is_active { get; set; }


        public DateTimeOffset? deleted_at { get; set; }
    }
    public class MachineEditDTO
    {
        public string Id { get; set; }
        public string Machine_Description { get; set; }
        public string Serial_Number { get; set; }
        public string Asset_Number { get; set; }
        public string Machine_Status { get; set; }
        public string Manufacturer { get; set; }
        public string Machine_Model { get; set; }
        public string Application { get; set; }
        public string MachineType { get; set; }
        public List<string> SpecificFeature { get; set; }
        public List<string> ControlSystem { get; set; }
        public List<MachineEditImageDto> MachineFilesList { get; set; }

    }
    public class MachineEditImageDto
    {
        public string File_Name { get; set; }
        public string Content_Type { get; set; }
        public string Url { get; set; }
        public string Drive_Id { get; set; }
        public string Item_Id { get; set; }
        public int Image_Size { get; set; }
    }
    public class MachineMetadataDto
    {
        public string Application { get; set; }
        public string MachineType { get; set; }
        public List<string> SpecificFeature { get; set; }
        public List<string> ControlSystem { get; set; }
    }
    public class GetMachineDto
    {
        public string Id { get; set; } = string.Empty;
        public string Machine_Name { get; set; } = string.Empty;
        public string Machine_Type { get; set; } = string.Empty;
        public string Manufacturer { get; set; } = string.Empty;
        public string Model { get; set; } = string.Empty;
        public string Serial_Number { get; set; } = string.Empty;
        public string Asset_Number { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public string Customer_Id { get; set; } = string.Empty;
        public string Global_Id { get; set; } = string.Empty;
        public string IndustrySegment { get; set; } = string.Empty;
        public string SubIndustrySegment { get; set; } = string.Empty;
        public string SpecificFeature { get; set; } = string.Empty;
        public string Application { get; set; } = string.Empty;
        public string ControlSystem { get; set; } = string.Empty;
        public string MachineType { get; set; } = string.Empty;
        public bool IsDelete { get; set; }
        public string Thumbnail_Url { get; set; }
    }

    public class GetMachineAttributeDto
    {
        public string Machine_Model { get; set; }
        public string Serial_Number { get; set; }
        public string Asset_Number { get; set; }
        public string Description { get; set; }
        public string Manufacturer { get; set; }
        public string Machine_Status { get; set; }
        public string Customer_Id { get; set; }
        public string IndustrySegment { get; set; }
        public string SubIndustrySegment { get; set; }
        public string Customer_Name { get; set; }
        public GetMetaDataDto MachineMetaData { get; set; }
        public GetMachineAttributeDto()
        {
            MachineMetaData = new GetMetaDataDto();
        }
    }
    public class GetMetaDataDto
    {
        public ApplicationDto Application { get; set; }
        public List<ControlSystemDto> ControlSystem { get; set; }
        public List<SpecificFeatureDto> SpecificFeature { get; set; }
        public MachineTypeDto MachineType { get; set; }

        public List<MachineEditImageDto> MachineImageList { get; set; }
    }
    public class MetaDataDto
    {
        public List<ApplicationDto> Application { get; set; }
        public List<ControlSystemDto> ControlSystem { get; set; }
        public List<SpecificFeatureDto> SpecificFeature { get; set; }
        public List<MachineTypeDto> MachineType { get; set; }

        public List<MachineEditImageDto> MachineImageList { get; set; }
    }
    public class ApplicationDto
    {
        public string Id { get; set; }
        public string Machine_Id { get; set; }
        public string Application { get; set; }
    }
    public class ControlSystemDto
    {
        public string Id { get; set; }
        public string Machine_Id { get; set; }
        public string ControlSystem { get; set; }
    }
    public class MachineTypeDto
    {
        public string Id { get; set; }
        public string Machine_Id { get; set; }
        public string MachineType { get; set; }
    }
    public class SpecificFeatureDto
    {
        public string Id { get; set; }
        public string Machine_Id { get; set; }
        public string SpecificFeature { get; set; }
    }
    public class MachineImageDto
    {
        public string Id { get; set; }
        public string File_Name { get; set; }
        public string Content_Type { get; set; }
        public string Url { get; set; }
        public string Drive_Id { get; set; }
        public string Item_Id { get; set; }
        public int Image_Size { get; set; }
    }
    public class CustomerMachineDto
    {
        [JsonPropertyName("id")]
        public string Id { get; set; }
        [JsonPropertyName("machine_name")]
        public string Machine_Name { get; set; }
        [JsonPropertyName("asset_id")]
        public string Asset_Id { get; set; }
        [JsonPropertyName("serial_number")]
        public string Serial_Number { get; set; }
        [JsonPropertyName("machine_description")]
        public string Machine_Description { get; set; }
        [JsonPropertyName("estimated_hours")]
        public decimal Estimated_Hours { get; set; }
        [JsonPropertyName("machine_location")]
        public string Machine_Location { get; set; }
        [JsonPropertyName("industry_type")]
        public string Industry_Type { get; set; }
        public string WBSID { get; set; }
        [JsonPropertyName("customer_id")]
        public string Customer_Id { get; set; }
        [JsonPropertyName("customer_name")]
        public string Customer_Name { get; set; }
        [JsonPropertyName("global_id")]
        public string Global_Id { get; set; } = string.Empty;

    }
}
