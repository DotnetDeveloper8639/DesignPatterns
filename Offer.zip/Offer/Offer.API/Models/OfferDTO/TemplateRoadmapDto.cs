﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Offer.API.Models.OfferDTO
{
    public class TemplateRoadmapDto
    {
        public string RoadMapMasterId { get; set; }
        [Required(ErrorMessage = "ProjectRoadMap Id should not be empty")]
        public string ProjectRoadMapId { get; set; }
        public string ServiceMachineId { get; set; }
        public string RoadMapName { get; set; }
        public string RoadMapVersion { get; set; }
        public string Description { get; set; }
        public DateTimeOffset CreatedAt { get; set; }
        public List<RoadMapSectionDTO> RoadMapSections { get; set; }
    }
    public class DeleteTemplateRoadmap
    {
        [Required(ErrorMessage = "RoadMap Id should not be empty")]
        public string RoadMapMasterId { get; set; }
        public string RoadMapName { get; set; }
        public string RoadMapVersion { get; set; }
        public string Description { get; set; }
        public bool IsDelete { get; set; }
        public List<DeleteRoadMapSectionDTO> RoadMapSections { get; set; }
    }
    public class DeleteRoadMapSectionDTO
    {
        public string RoadMapSectionId { get; set; }
        public string RoadMapMasterId { get; set; }
        public string SectionName { get; set; }
        public bool IsDelete { get; set; }
        public List<DeleteRoadMapSubSectionDTO> RoadMapSubSection { get; set; }
    }
    public class DeleteRoadMapSubSectionDTO
    {
        public string RoadMapSubSectionId { get; set; }
        public string RoadMapSectionId { get; set; }
        public string SubSectionName { get; set; }
        public bool IsDelete { get; set; }
        public List<DeleteStepMasterDTO> StepMaster { get; set; }
    }
    public class DeleteStepMasterDTO
    {
        public string RoadMapSubSectionId { get; set; }
        public string StepMasterId { get; set; }
        public string StepBody { get; set; }
        public bool IsDelete { get; set; }
    }
}
