﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Offer.API.Models.OfferDTO
{
    public class ActualHoursDto
    {
        [Required(ErrorMessage = "Prject Id should not be empty")]
        public string Project_Id { get; set; }
        [Required(ErrorMessage = "Order Id should not be empty")]
        public string Order_Id { get; set; }
        [Required(ErrorMessage = "Service Id should not be empty")]
        public string Service_Id { get; set; }
        [Required(ErrorMessage = "User Id should not be empty")]
        public string User_Id { get; set; }
        public string User_Name { get; set; }
        public string Action { get; set; }
        public List<MachineActualHours> MachineActualHours { get; set; }

    }
    public class MachineActualHours
    {
        public string Id { get; set; }
        public string ServiceMachine_Id { get; set; }
        public string Machine_Id { get; set; }
        public decimal ActualHours { get; set; }
        public string Comments { get; set; }
        public string Action { get; set; }
    }
    public class GetActualHoursDto
    {
        public List<GetMachineActualHours> MachineActualHours { get; set; }
    }
    public class GetMachineActualHours
    {
        public string Id { get; set; }
        public string ServiceMachine_Id { get; set; }
        public decimal ActualHours { get; set; }
        public string Comments { get; set; }
        public DateTimeOffset CreatedAt { get; set; }
    }
}
