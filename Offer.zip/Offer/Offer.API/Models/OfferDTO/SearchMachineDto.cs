﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Offer.API.Models.OfferDTO
{
    public class SearchMachineDto
    {
        public string Search { get; set; }
        public List<FilterDto> FilterSearch { get; set; }
        public int Count { get; set; }
        public int IncreasedCount { get; set; }
    }
    public class FilterDto
    {
        public string Field { get; set; }
        public string Operator { get; set; }
        public string Value { get; set; }
    }
}
