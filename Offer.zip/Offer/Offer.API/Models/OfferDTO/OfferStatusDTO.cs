﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Offer.API.Models.OfferDTO
{
    public class OfferStatusDTO
    {
        public string quote_type { get; set; }
        public string notes { get; set; }
        public string quote_template_type { get; set; }
        public string offer_id { get; set; }
        public string opportunity_id { get; set; }
        public string project_id { get; set; }
        public string job_Order_id { get; set; }
        public string encrypted_project_id { get; set; }
        public string contact_id { get; set; }
        public string contact_email { get; set; }
        public string contact_name { get; set; }
        public string contact_address { get; set; }
        public string contact_number { get; set; }
        public string customer_id { get; set; }
        public string erp_customer_id { get; set; }
        public string customer_name { get; set; }
        public string city { get; set; }
        public string street { get; set; }
        public string zipcode { get; set; }
        public string customer_phonenumber { get; set; }
        public string country_code { get; set; }
        public string company_name { get; set; }
        public string company_code { get; set; }
        public int roadmap_progress { get; set; }
        public int hours_progress { get; set; }
        public string assigned_to { get; set; }
        //public string po_status { get; set; }
        public DateTime? opportunity_date { get; set; }
        public string assignee { get; set; }
        public string service_type { get; set; }
        public string service_id { get; set; }
        public string service_location { get; set; }
        public string service_description { get; set; }
        public string service_region { get; set; }
        public string customer_address { get; set; }
        public string serial_number { get; set; }
        public string asset_id { get; set; }
        public string machine_id { get; set; }
        public string machine_name { get; set; }
        public string machine_description { get; set; }
        public string machine_type { get; set; }
        public string global_id { get; set; }
        public string project_description { get; set; }
        public string Status { get; set; }
        public string region { get; set; }
        public int actual_hours { get; set; }
        public string is_ra_external { get; set; }
        public string external_ra_notes { get; set; }
        public string total_estimated_hours { get; set; }
        public string offer_date { get; set; }
        public string Start_Date { get; set; }
        public string End_Date { get; set; }
        public string service_wbs_id { get; set; }
        public string erp_wbs_id { get; set; }
        public string erp_project_id { get; set; }
        public string erp_service_wbs_id { get; set; }
        public string erp_machine_wbs_id { get; set; }
        public bool is_commercial_quote { get; set; }
        public string IndustrySegment { get; set; }
        public string Project_Start_Date { get; set; }
        public string Project_End_Date { get; set; }
    }
    public class CreateOfferDTO
    {
        public OfferDTO Offer { get; set; }
        public CustomerDTO Customer { get; set; }
        public ContactDTO Contact { get; set; }
       // public List<ServiceDTO> ServiceModels { get; set; }
    }
    public class GetOfferOpportunityDTO
    {
        public OpportunityOfferDTO Offer { get; set; }
        public CustomerDTO Customer { get; set; }
        public ContactDTO Contact { get; set; }
    }
    public class OpportunityOfferDTO
    {
        public string offer_id { get; set; }
        public string project_id { get; set; }
        public string contact_id { get; set; }
        public string status { get; set; }
        public string assignee { get; set; }
        public string notes { get; set; }
        public string quote_template_type { get; set; }
        public string quote_type { get; set; }
        public List<OpportunityServiceDTO> Service { get; set; }
        public DateTimeOffset created_at { get; set; }
        public string created_by { get; set; }
        public DateTimeOffset modified_at { get; set; }
        public string modified_by { get; set; }
        public string erp_wbs_id { get; set; }
        public string erp_project_id { get; set; }
        public bool is_commercial_quote { get; set; }
    }
    public class OfferDTO
    {
        public string offer_id { get; set; }
        [Required(ErrorMessage ="Project Id should not be empty")]
        public string project_id { get; set; }
        public string contact_id { get; set; }
        public string status { get; set; }
        public string assignee { get; set; }
        public string notes { get; set; }
        public string quote_template_type { get; set; }
        public string quote_type { get; set; }
        public List<ServiceDTO> Service { get; set; }
        public DateTimeOffset created_at { get; set; }
        public string created_by { get; set; }
        public DateTimeOffset modified_at { get; set; }
        public string modified_by { get; set; }
    }
    public class EditOfferDTO
    {
        [Required(ErrorMessage = "Offer Id should not be empty")]
        public string OfferId { get; set; }
        public string AdditionalNotes { get; set; }
        public string ContactId { get; set; }
        public string Status { get; set; }
        public string Assignee { get; set; }
    }
    public class OpportunityServiceDTO
    {

        public string id { get; set; }
        public string erp_wbs_id { get; set; }
        public string project_id { get; set; }
        public string offer_id { get; set; }
        public string contact_id { get; set; }
        public string service_type { get; set; }
        public string service_location { get; set; }
        public DateTime? start_date { get; set; }
        public DateTime? end_date { get; set; }
        public int actual_hours { get; set; }
        public string is_active { get; set; }
        public string service_description { get; set; }
        public string service_region { get; set; }
        public string is_ra_external { get; set; }
        public string external_ra_notes { get; set; }
        public string total_estimated_hours { get; set; }
        public DateTimeOffset created_at { get; set; }
        public string created_by { get; set; }
        public DateTimeOffset modified_at { get; set; }
        public string modified_by { get; set; }
        public List<MachineDTO> Machine { get; set; }
        public List<CustomerDTO> Customer { get; set; }
        public List<ContactDTO> Contact { get; set; }
    }
    public class ServiceDTO
    {
        public string id { get; set; }
        public string erp_wbs_id { get; set; }
        public string project_id { get; set; }
        public string offer_id { get; set; }
        public string contact_id { get; set; }
        public string service_type { get; set; }
        public string service_location { get; set; }
        public DateTime? start_date { get; set; }
        public DateTime? end_date { get; set; }
        public int actual_hours { get; set; }
        public string is_active { get; set; }
        public string service_description { get; set; }
        public string service_region { get; set; }
        public string is_ra_external { get; set; }
        public string external_ra_notes { get; set; }
        public string total_estimated_hours { get; set; }
        public bool is_risk_assessment { get; set; }
        public bool is_risk_reassessment { get; set; }
        public DateTimeOffset created_at { get; set; }
        public string created_by { get; set; }
        public DateTimeOffset modified_at { get; set; }
        public string modified_by { get; set; }
        public List<MachineDTO> Machine { get; set; }
       
    }

    public class MachineDTO
    {
        public string id { get; set; }
        public string service_id { get; set; }
        public string machine_description { get; set; }
        public string master_machine_id { get; set; }
        public string machine_name { get; set; }
        public string asset_id { get; set; }
        public string serial_number { get; set; }
        public decimal estimated_hours { get; set; }
        public string machine_type { get; set; }
        public string machine_location { get; set; }
        public string industry_type { get; set; }
        public string Manufacturer { get; set; }
        public string Model_Number { get; set; }
        public DateTimeOffset created_at { get; set; }
        public string created_by { get; set; }
        public DateTimeOffset modified_at { get; set; }
        public string modified_by { get; set; }
        public string erp_wbs_id { get; set; }
        public string Customer_Id { get; set; }
        public string IndustrySegment { get; set; }
        public List<RoadMapMasterDTO> roadmap_details { get; set; }
        public List<MachineMetadataDto> MachineMetadata { get; set; }
        public List<MachineImageDto> MachineImage { get; set; }
    }
    public class ContactDTO
    {

        public string contact_id { get; set; }
        //public string title {get;set;}
        public string first_name { get; set; }
        public string last_name { get; set; }
        //public string department { get; set; }
        //public string language { get; set; }
        public string display_name { get; set; }
        public string email_address { get; set; }
        public string phone_number { get; set; }
        public DateTimeOffset created_at { get; set; }
        public string created_by { get; set; }
        public DateTimeOffset modified_at { get; set; }
        public string modified_by { get; set; }
    }
    public class CustomerDTO
    {

        public string id { get; set; }
        public string customer_name { get; set; }
        public string erp_customer_id { get; set; }
        public string contact_id { get; set; }
        public string project_id { get; set; }
        public string customer_id { get; set; }
        public string country_code { get; set; }
        public string city { get; set; }
        public string zipcode { get; set; }
        public string street { get; set; }
        public string phone_number { get; set; }
        public string language { get; set; }
        public DateTimeOffset created_at { get; set; }
        public string created_by { get; set; }
        public DateTimeOffset modified_at { get; set; }
        public string modified_by { get; set; }
    }
    public class EditServiceDTO
    {
        [Required(ErrorMessage = "Service Id should not be empty")]
        public string ServiceId { get; set; }
        public string ContactId { get; set; }
        public string Description { get; set; }
        public string is_ra_external { get; set; }
        public string is_ra_external_notes { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
    }
   public class OpportunityDTO
    {
        public string OpportunityId { get; set; }
        public string Customer_Name { get; set; }
        public string ProjectId { get; set; }
        public string Status { get; set; }
        public DateTimeOffset Created_At { get; set; }
        public string Created_By { get; set; }
        public string Modified_By { get; set; }
        public DateTimeOffset Modified_At { get; set; }
        public string Erp_Project_Id { get; set; }
    }
    public class LoginUserDTO
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
    }
    public class DeleteOpportunityDTO
    {
        [Required(ErrorMessage = "Offer Id should not be empty")]
        public string Offer_Id { get; set; }
        [Required(ErrorMessage = "Project Id should not be empty")]
        public string Project_Id { get; set; }
        [Required(ErrorMessage = "Opportunity Id should not be empty")]
        public string Opportunity_Id { get; set; }

    }

    public class AddEditLayoutQuotationDTO
    {
        [Required(ErrorMessage = "Quotation Number should not be empty")]
        public string QuotationNumber { get; set; }
        public string LayoutQuotationDetails { get; set; }        
    }
}
