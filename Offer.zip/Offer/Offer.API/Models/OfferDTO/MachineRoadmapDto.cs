﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Offer.API.Models.OfferDTO
{
    public class MachineRoadmapDto
    {
        public string MachineId { get; set; }
        public List<RoadMapMasterDTO> RoadMaps { get; set; }
    }
}
