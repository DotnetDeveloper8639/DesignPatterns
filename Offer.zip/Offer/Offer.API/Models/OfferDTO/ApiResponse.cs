﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace Offer.API.Models.OfferDTO
{
    public class ApiResponse<T>
    {
        public ApiResponse()
        {
            this.StatusCode = (int)HttpStatusCode.OK;
        }
        public T Data { get; set; }
        public int StatusCode { get; set; }
        public string StatusReason { get; set; }
    }
    public class MachineApiResponse<T>
    {
        public MachineApiResponse()
        {
            this.StatusCode = (int)HttpStatusCode.OK;
        }
        public T DuplicateMachines { get; set; }
        public int StatusCode { get; set; }
        public string StatusReason { get; set; }
    }
}
