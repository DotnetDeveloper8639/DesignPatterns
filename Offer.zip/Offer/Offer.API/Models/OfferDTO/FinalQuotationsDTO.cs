﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Offer.API.Models.OfferDTO
{
    public class FinalQuotationsDTO
    {
        public string Id { get; set; }
        public string FileName { get; set; }
        public string Url { get; set; }
        public string DriveId { get; set; }
        public string ItemId { get; set; }  
        public string OfferId { get; set; }
        public decimal? VersionNumber { get; set; }
        public string GenerateBy { get; set; }
        public DateTimeOffset CreatedDate { get; set; }
    }
}
