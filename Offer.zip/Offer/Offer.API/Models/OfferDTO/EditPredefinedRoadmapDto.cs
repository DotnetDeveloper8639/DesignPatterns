﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Offer.API.Models.OfferDTO
{
    public class EditPredefinedRoadmapDto
    {
        [Required(ErrorMessage = "RoadMapMaster Id should not be empty")]
        public string RoadMapMasterId { get; set; }
        public string RoadMapName { get; set; }
        public List<EditPredefinedRoadmapSectionDto> RoadMapSection { get; set; }
    }
    public class EditPredefinedRoadmapSectionDto
    {
        public string RoadMapSectionId { get; set; }
        public string RoadMapMasterId { get; set; }
        public string SectionName { get; set; }
        public bool IsEdit { get; set; }
        public List<EditPredefinedRoadmapSubSectionDto> RoadMapSubSection { get; set; }

    }
    public class EditPredefinedRoadmapSubSectionDto
    {
        public string RoadMapSubSectionId { get; set; }
        public string RoadMapSectionId { get; set; }
        public string SubSectionName { get; set; }
        public bool IsEdit { get; set; }
        public List<EditPredefinedRoadmapStepMasterDto> StepMaster { get; set; }
    }
    public class EditPredefinedRoadmapStepMasterDto
    {
        public string RoadMapSubSectionId { get; set; }
        public string StepMasterId { get; set; }
        public string StepBody { get; set; }
        public bool IsEdit { get; set; }
    }
}
