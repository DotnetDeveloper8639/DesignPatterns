﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Offer.API.Models.OfferDTO
{
    public class ServiceMaterialResponseDTO
    {
        public string Companycode { get; set; }
        public string Language { get; set; }
    }
}
