﻿using Offer.API.EntityModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Offer.API.Models.OfferDTO
{
    public class MachineReferenceDto
    {
        public string ProjectId { get; set; }
        public string BlueprintProjectID { get; set; }
        public string OfferId { get; set; }
        public string Erp_Offer_Id { get; set; }
        public string Erp_Order_Id { get; set; }
        public string OrderId { get; set; }
        public string ServiceId { get; set; }
        public string ErpServiceId { get; set; }
        public string Service_Type { get; set; }
    }
    public class MachineReferenceForBulkUploadDto
    {
        public List<TblApplication> Application { get; set; }  
        public List<TblControlSystem> ControlSystem { get; set; }
        public List<TblMachineType> MachineType { get; set; }
        public List<TblSpecificFeature> SpecificFeature { get; set; }
        public MachineReferenceForBulkUploadDto()
        {
            Application = new List<TblApplication>();
            ControlSystem = new List<TblControlSystem>();
            SpecificFeature = new List<TblSpecificFeature>();
            MachineType = new List<TblMachineType>();
        }
    }
    public class ApplicationForBulkUploadDto
    {
        public string Id { get; set; }
        public string Application { get; set; }
    }
    public class ControlSystemForBulkUploadDto
    {
        public string Id { get; set; }
        public string ControlSystem { get; set; }
    }
    public class MachineTypeForBulkUploadDto
    {
        public string Id { get; set; }
        public string MachineType { get; set; }
    }
    public class SpecificFeatureForBulkUploadDto
    {
        public string Id { get; set; }
        public string SpecificFeature { get; set; }
    }
}
