﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Offer.API.Models.OfferDTO
{
    public class MachineHazardDTO
    {
        public string Id { get; set; }
        public string name { get; set; }
        public string hazard_type_id { get; set; }
        public string initial_hazard { get; set; }
        public string counter_measure { get; set; }
        public string service_machine_steps_id { get; set; }
        public string version { get; set; }
        public HazardTypeDTO HazardType { get; set; }
        public List<PerformanceHazardLevelDTO> PerformanceHazardLevel { get; set; }
        public List<HazardMediaDTO> HazardMedia { get; set; }
        public List<HRNCalculationsDTO> HRNCalculations { get; set; }
        public List<HazardSourceDTO> HazardSource { get; set; }
        public List<HazardConsequenceDTO> HazardConsequences { get; set; }
    }
   
    public class HRNCalculationsDTO
    {
        public string Id { get; set; }
        public string PO { get; set; }
        public string SD { get; set; }
        public string FE { get; set; }
        public string NP { get; set; }
        public string Rating { get; set; }
        public string Type { get; set; }
        public string Version { get; set; }
        public List<ModesDTO> Modes { get; set; }
    }
    public class HazardTypeDTO
    {
        public string HazardTypeId { get; set; }
        public string HazardTypeName { get; set; }
    }
    public class HazardSourceDTO
    {
        public string Id { get; set; }
        public string Source { get; set; }
    }
    public class HazardConsequenceDTO
    {
        public string Id { get; set; }
        public string Consequences { get; set; }
    }
    public class ModesDTO
    {
        public string Id { get; set; }
        public string ModeName { get; set; }
    }
    public class HazardMediaDTO
    {
        public string Type { get; set; }
        public string URL { get; set; }
    }
    public class PerformanceHazardLevelDTO
    {
        public string PerformanceHazardLevelId { get; set; }
        public string PLR { get; set; }
        public string Category { get; set; }
    }
    public class LibraryDTO
    {
        public string LibraryId { get; set; }
        public string Name { get; set; }
        public string Type { get; set; }
        public string Url { get; set; }
        public string Version { get; set; }
        public string ContentType { get; set; }
        public string PreviewImageUrl { get; set; }
        public string ItemId { get; set; }
        public string DriveId { get; set; }

    }
    public class UploadRoadmapDTO
    {
        public LegislationsMediaDTO Legislations { get; set; }
        public List<RoadMapMasterDTO> RoadMap { get; set; }
    }
    public class RoadMapMasterDTO
    {
        public string RoadMapMasterId { get; set; }
        public string RoadMapName { get; set; }
        public string RoadMapVersion { get; set; }
        public string Description { get; set; }
        public string UserId { get; set; }
        public string Project_Id { get; set; }
        public string ServiceId { get; set; }
        public string MachineId { get; set; }
        public bool IsSelected { get; set; }
        public DateTimeOffset CreatedAt { get; set; }
        public List<RoadMapSectionDTO> RoadMapSections { get; set; }
    }
    public class RoadMapSectionDTO
    {
        public string RoadMapSectionId { get; set; }
        public string RoadMapMasterId { get; set; }
        public string SectionName { get; set; }
        public DateTimeOffset Created_At { get; set; }
        public List<RoadMapSubSectionDTO> RoadMapSubSection { get; set; }

    }
    public class RoadMapSubSectionDTO
    {
        public string RoadMapSubSectionId { get; set; }
        public string RoadMapSectionId { get; set; }
        public string SubSectionName { get; set; }
        public DateTimeOffset Created_At { get; set; }
        public List<StepMasterDTO> StepMaster { get; set; }

    }
   

    public class InitialHazardMasterDTO
    {
        public string Id { get; set; }
        public string Value { get; set; }
        public string UserId { get; set; }
    }
    public class CounterMeasureDTO
    {
        public string Id { get; set; }
        public string Value { get; set; }
        public string UserId { get; set; }
    }
    
    public class StepMasterDTO
    {
        public string RoadMapSubSectionId { get; set; }
        public string StepMasterId { get; set; }
        public string StepBody { get; set; }
        public string Notes { get; set; }
        public DateTimeOffset Created_At { get; set; }
        public List<Answers> Answers { get; set; }
        public List<MachineHazardDto> Hazards { get; set; }
    }
    public class Answers
    {
        public string Id { get; set; }
        public string ServiceMachineStepId { get; set; }
        public bool YesComplaint { get; set; }
        public bool NotApplicable { get; set; }
        public bool Hazard { get; set; }
        public string ReportedBy { get; set; }
        public bool IsPreferred { get; set; }
        public List<MachineHazardDto> HazardDetails { get; set; }
        public List<FileDto> ComplaintMedia { get; set; }
    }
    public class FileDto
    {
        public string Id { get; set; }
        public string FileName { get; set; }
        public string ContentType { get; set; }
        public string URL { get; set; }
        public string DriveId { get; set; }
        public string ItemId { get; set; }
        public int? Image_Size { get; set; }
    }
    public class MachineHazardDto
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string Hazard_type_id { get; set; }
        public string Initial_hazard { get; set; }
        public string Counter_measure { get; set; }
        public string Service_machine_steps_id { get; set; }
        public string Notes { get; set; }
        public string Version { get; set; }
        public string PLR { get; set; }
        public string Category { get; set; }
        public List<HazardType> HazardType { get; set; }
        public List<HazardMedia> HazardMedia { get; set; }
        public List<HRNCalculations> HRNCalculations { get; set; }
    }
    public class HazardType
    {
        public string HazardTypeId { get; set; }
        public string HazardTypeName { get; set; }
        public List<HazardSource> HazardSources { get; set; }
        public List<HazardConsequence> HazardConsequences { get; set; }
    }
    public class HazardMedia
    {
        public string Id { get; set; }
        public string Type { get; set; }
        public string URL { get; set; }
        public string FileName { get; set; }
        public string DriveId { get; set; }
        public string ItemId { get; set; }
        public int? Image_Size { get; set; }
    }
    public class HRNCalculations
    {
        public string Type { get; set; }
        public string Id { get; set; }
        public string PO { get; set; }
        public string SD { get; set; }
        public string FE { get; set; }
        public string NP { get; set; }
        public string Rating { get; set; }
        public string Version { get; set; }
        public string Mode { get; set; }
    }
    public class HazardSource
    {
        public string Id { get; set; }
        public string Source { get; set; }
    }
    public class HazardConsequence
    {
        public string Id { get; set; }
        public string Consequences { get; set; }
    }
    public class RoadmapDTO
    {
        public string RoadMapName { get; set; }
        public string RoadMapVersion { get; set; }
        public string Description { get; set; }
        public bool IsCustom { get; set; }
    }
    public class SectionMasterDTO
    {
        public string RoadMapMasterId { get; set; }
        public string SectionName { get; set; }
    }

    public class SubSectionMasterDTO
    {
        public string RoadMapSectionId { get; set; }
        public string SubSectionName { get; set; }
    }
    public class DeleteRoadmapFile
    {
        public string Id { get; set; }
        public string Type { get; set; }
    }
    public class CopyRoadmapDto
    {
        public string ServiceId { get; set; }
        public List<CopyRoadmapMachinesDto> Machines { get; set; }
    }
    public class CopyRoadmapMachinesDto
    {
        public string MachineId { get; set; }
        public List<RoadMapMasterDTO> Roadmaps { get; set; }
    }
    public class RiskReAssessmentMachinesDto
    {
        public string MachineId { get; set; }
        public string machine_name { get; set; }
        public string machine_description { get; set; }
        public string machine_type { get; set; }
    }
}
