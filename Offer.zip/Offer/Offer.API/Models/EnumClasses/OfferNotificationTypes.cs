﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Threading.Tasks;

namespace Offer.API.Models.EnumClasses
{
    public enum OfferNotificationTypes
    {
        [EnumMember(Value = "Quotation Sent to Client")]
        QuotationSenttoClient,
        [EnumMember(Value = "Quotation Approved")]
        QuotationApproved,
        [EnumMember(Value = "Offer Deleted")]
        OfferDeleted,
        [EnumMember(Value = "Offer Created")]
        OfferCreated,
        [EnumMember(Value = "Offer Updated")]
        OfferUpdated,
        [EnumMember(Value = "Machine Added")]
        MachineAdded,
        [EnumMember(Value = "Machine(s) Uploaded")]
        MachinesUploaded,
        [EnumMember(Value = "Machine Deleted")]
        MachineDeleted
    }
}
