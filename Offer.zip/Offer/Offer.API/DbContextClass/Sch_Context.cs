﻿using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Offer.API.EntityModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Tenant.Service;
using Microsoft.Identity.Web;

namespace Offer.API.DbContextClass
{
    public class Sch_Context : DbContext
    {
        private readonly IConfiguration _configuration;
        private readonly IHttpContextAccessor httpContextAccessor;
        private readonly ITenantService tenantService;

        public Sch_Context()
        {
        }

        public Sch_Context(DbContextOptions<Sch_Context> options
            , IConfiguration configuration
            , IHttpContextAccessor httpContextAccessor
            , ITenantService tenantService)
                     : base(options)
        {
            _configuration = configuration;
            this.httpContextAccessor = httpContextAccessor;
            this.tenantService = tenantService;
        }


        public virtual DbSet<TblCompany> TblCompanies { get; set; }
        public virtual DbSet<TblContact> TblContacts { get; set; }
        public virtual DbSet<TblControllingArea> TblControllingAreas { get; set; }
        public virtual DbSet<TblCustomer> TblCustomers { get; set; }
        public virtual DbSet<TblErpContact> TblErpContacts { get; set; }
        public virtual DbSet<TblErpCustomer> TblErpCustomers { get; set; }
        public virtual DbSet<TblMachine> TblMachines { get; set; }
        public virtual DbSet<TblMasterMachine> TblMasterMachines { get; set; }
        public virtual DbSet<TblOffer> TblOffers { get; set; }
        public virtual DbSet<TblProject> TblProjects { get; set; }
        public virtual DbSet<TblProjectStaff> TblProjectStaffs { get; set; }
        public virtual DbSet<TblQuotation> TblQuotations { get; set; }
        public virtual DbSet<TblService> TblServices { get; set; }
        public virtual DbSet<TblServiceMachine> TblServiceMachines { get; set; }
        public virtual DbSet<TblTenantCatalog> TblTenantCatalogs { get; set; }
        public virtual DbSet<TblUser> TblUsers { get; set; }
        public virtual DbSet<TblTaskManager> TblTasks { get; set; }
        public virtual DbSet<TblOrder> TblOrder { get; set; }
        public virtual DbSet<TblOrderKPI> TblOrderKPI { get; set; }
        public virtual DbSet<TblServiceKPI> TblServiceKPI { get; set; }
        public virtual DbSet<TblOfferKPI> TblOfferKPI { get; set; }
        public virtual DbSet<TblProjectKPI> TblProjectKPI { get; set; }
        public virtual DbSet<TblSchNotification> TblNotiications { get; set; }
        public virtual DbSet<TblCounterMeasures> TblCounterMeasures { get; set; }
        public virtual DbSet<TblHazardConsequences> TblHazardConsequences { get; set; }
        public virtual DbSet<TblHazardMedia> TblHazardMedia { get; set; }
        public virtual DbSet<TblHazardSource> TblHazardSource { get; set; }
        public virtual DbSet<TblHazardType> TblHazardType { get; set; }
        public virtual DbSet<TblHRNCalculations> TblHRNCalculations { get; set; }
        public virtual DbSet<TblInitialHazardsMaster> TblInitialHazardsMaster { get; set; }
        public virtual DbSet<TblLifecyclePhaseMaster> TblLifecyclePhaseMaster { get; set; }
        public virtual DbSet<TblModes> TblModes { get; set; }
        public virtual DbSet<TblMachineHazards> TblMachineHazards { get; set; }
        public virtual DbSet<TblMachineLimits> TblMachineLimits { get; set; }
        public virtual DbSet<TblMachineMediaMaster> TblMachineMediaMaster { get; set; }
        public virtual DbSet<TblMachineModeMaster> TblMachineModeMaster { get; set; }
        public virtual DbSet<TblMachineRoadmapAssociation> TblMachineRoadmapAssociation { get; set; }
        public virtual DbSet<TblPerformanceLevelRating> TblPerformanceLevelRating { get; set; }
        public virtual DbSet<TblRoadmapMaster> TblRoadmapMaster { get; set; }
        public virtual DbSet<TblRoadmapSubSectionMster> TblRoadmapSubSectionMster { get; set; }
        public virtual DbSet<TblRoadmapSection> TblRoadmapSection { get; set; }
        public virtual DbSet<TblStepMaster> TblStepMaster { get; set; }
        public virtual DbSet<TblUser> TblUser { get; set; }
        public virtual DbSet<TblUserAndGroupAssociation> TblUserAndGroupAssociation { get; set; }
        public virtual DbSet<TblGroups> TblGroups { get; set; }
        public virtual DbSet<TblRoleAndModuleAssociation> TblRoleAndModuleAssociation { get; set; }
        public virtual DbSet<TblRoles> TblRoles { get; set; }
        public virtual DbSet<TblMachineRoadmap> TblMachineRoadmap { get; set; }
        public virtual DbSet<TblBookmarks> TblBookmarks { get; set; }
        public virtual DbSet<TblLibrary> TblLibrary { get; set; }
        public virtual DbSet<TblServiceMaterial> TblServiceMaterials { get; set; }
        public virtual DbSet<TblServiceHour> TblServiceHours { get; set; }
        public virtual DbSet<TblServiceCost> TblServiceCosts { get; set; }
        public virtual DbSet<TblServiceActualCost> TblServiceActualCosts { get; set; }
        public virtual DbSet<TblServicePlannedCost> TblServicePlannedCosts { get; set; }
        public virtual DbSet<TblServiceActualSale> TblServiceActualSales { get; set; }
        public virtual DbSet<TblServicePlannedSale> TblServicePlannedSales { get; set; }
        public virtual DbSet<TblMachineHour> TblMachineHours { get; set; }
        public virtual DbSet<TblMachineCost> TblMachineCosts { get; set; }
        public virtual DbSet<TblMachineActualCost> TblMachineActualCosts { get; set; }
        public virtual DbSet<TblMachinePlannedCost> TblMachinePlannedCosts { get; set; }
        public virtual DbSet<TblMachineActualSale> TblMachineActualSales { get; set; }
        public virtual DbSet<TblMachinePlannedSale> TblMachinePlannedSales { get; set; }
        public virtual DbSet<TblMachineSubCost> TblMachineSubCosts { get; set; }
        public virtual DbSet<TblOpportunity> TblOpportunity { get; set; }
        public virtual DbSet<TblCommercialQuotation> TblCommercialQuotations { get; set; }
        public virtual DbSet<TblPermission> TblPermission { get; set; }
        public virtual DbSet<TblPermissionAssociation> TblPermissionAssociation { get; set; }
        public virtual DbSet<TblUserRoleAssignment> TblUserRoleAssignment { get; set; }
        public virtual DbSet<TblTemplateRoadmapMaster> TblTemplateRoadmapMaster { get; set; }
        public virtual DbSet<TblTemplateRoadmapSection> TblTemplateRoadmapSection { get; set; }
        public virtual DbSet<TblTemplateRoadmapSubSection> TblTemplateRoadmapSubSection { get; set; }
        public virtual DbSet<TblTemplateRoadmapStep> TblTemplateRoadmapStep { get; set; }
        public virtual DbSet<TblLegislationsMedia> TblLegislationsMedia { get; set; }
        public virtual DbSet<TblServiceMachineSteps> TblServiceMachineSteps { get; set; }
        public virtual DbSet<TblStepMachineAssociation> TblStepMachineAssociation { get; set; }
        public virtual DbSet<TblComplaintMedia> TblComplaintMedia { get; set; }
        public virtual DbSet<TblProjectRoadmapAssociation> TblProjectRoadmapAssociation { get; set; }
        public virtual DbSet<TblAuditEntry> TblAuditEntry { get; set; }
        public virtual DbSet<TblSubIndustrySegments> TblSubIndustrySegments { get; set; }
        public virtual DbSet<TblMachineCustomerAssociation> TblMachineCustomerAssociation { get; set; }
        public virtual DbSet<TblMachineCustomerAssociationTimeStamp> TblMachineCustomerAssociationTimeStamp { get; set; }
        public virtual DbSet<TblControlSystem> TblControlSystem { get; set; }
        public virtual DbSet<TblControlSystemTimeStamp> TblControlSystemTimeStamp { get; set; }
        public virtual DbSet<TblSpecificFeature> TblSpecificFeature { get; set; }
        public virtual DbSet<TblSpecificFeatureTimeStamp> TblSpecificFeatureTimeStamp { get; set; }
        public virtual DbSet<TblMachineType> TblMachineType { get; set; }
        public virtual DbSet<TblIndustrySegments> TblIndustrySegments { get; set; }
        public virtual DbSet<TblApplication> TblApplication { get; set; }
        public virtual DbSet<TblApplicationTimeStamp> TblApplicationTimeStamp { get; set; }
        public virtual DbSet<TblMachineKPI> TblMachineKPI { get; set; }
        public virtual DbSet<TblActualHours> TblActualHours { get; set; }
        public virtual DbSet<TblSiteDetails> TblSiteDetails { get; set; }
        public virtual DbSet<TblMachineTypeTimeStamp> TblMachineTypeTimeStamp { get; set; }
        public virtual DbSet<TblMachineControlSystem> TblMachineControlSystem { get; set; }
        public virtual DbSet<TblMachineApplication> TblMachineApplication { get; set; }
        public virtual DbSet<TblMachineSpecificFeature> TblMachineSpecificFeature { get; set; }
        public virtual DbSet<TblMachineTypeAssociation> TblMachineTypeAssociation { get; set; }
        public virtual DbSet<TblFinalQuotation> TblFinalQuotations { get; set; }
        public virtual DbSet<TblCommercialQuotationChunk> TblCommercialQuotationChunks { get; set; }
        public virtual DbSet<TblMachineImages> TblMachineImages { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {

                string tid = string.Empty;
                var currentTenantId = httpContextAccessor.HttpContext.Items["CurrentTenantId"];
                if (currentTenantId != null)
                    tid = Convert.ToString(currentTenantId);
                else
                    tid = httpContextAccessor.HttpContext.User.GetTenantId();

                var tenantInfo = tenantService.GetTenantInfo(tid);

                optionsBuilder.UseSqlServer(tenantInfo.Connectionstring);

                base.OnConfiguring(optionsBuilder);
            }
        }
    }
}
