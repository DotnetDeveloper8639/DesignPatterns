﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Offer.API.Services;
using System;


namespace Offer.API.Controllers
{
    [Route("/api/offersvc/opportunitysvc")]
    [ApiController]
    public class OpportunityController : ControllerBase
    {
        public readonly IOpportunityService OpportunityService;

        public OpportunityController(IOpportunityService opportunityService)
        {
            OpportunityService = opportunityService;
        }
        [Route("")]
        [HttpGet]
        public IActionResult Get()
        {
            try
            {
                var result = OpportunityService.GetOpportunities();
                return Ok(new JsonResult(result.Result));
            }
            catch (Exception)
            {

                return StatusCode(StatusCodes.Status500InternalServerError, "Internal Server Error");
            }

        }

        [Route("{projectId}")]
        [HttpGet]
        public IActionResult GetOpportunityByProjectId(string projectId)
        {
            try
            {
                var result = OpportunityService.GetOpportunityByProjectId(projectId);
                return Ok(new JsonResult(result.Result));
            }
            catch (Exception)
            {

                return StatusCode(StatusCodes.Status500InternalServerError, "Internal Server Error");
            }

        }

    }
}
