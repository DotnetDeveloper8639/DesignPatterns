﻿using EventBus.Abstractions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Offer.API.Models.OfferDTO;
using Offer.API.Services;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Offer.API.Controllers
{
    [Route("/api/offersvc/service")]
    [Authorize]
    [ApiController]
    public class ServiceController : ControllerBase
    {
        public IService _serviceContext { get; }
        private const string DAPR_PUBSUB_NAME = "pubsub";
        private readonly IEventBus eventBus;

        public ServiceController(IService service, IEventBus _eventBus)
        {
            _serviceContext = service;
            eventBus = _eventBus;
        }

        [Route("create")]
        [Authorize(Roles = "Offer.Write,Offer.Read")]
        [HttpPost]
        public IActionResult CreateService([FromBody] List<ServiceDTO> service)
        {
            try
            {
                var result = _serviceContext.CreateService(service);
                return Ok(new JsonResult(result.Result));
            }
            catch (Exception ex)
            {

                return StatusCode(StatusCodes.Status500InternalServerError, "Error occured while creating the service");
            }
        }

        [Route("addmachines")]
        [Authorize(Roles = "Offer.Write,Offer.Read")]
        [HttpPost]
        public IActionResult AddMachines([FromBody] List<MachineDTO> machine)
        {
            try
            {
                var result = _serviceContext.AddMachines(machine);
                return Ok(new JsonResult(result.Result));
            }
            catch (Exception ex)
            {

                return StatusCode(StatusCodes.Status500InternalServerError, "Error occured while adding machines");
            }
        }


        //using in library
        [Route("update")]
        [Authorize(Roles = "Offer.Write,Offer.Read")]
        [HttpPost]
        public IActionResult UpdateSeviceAndMachine([FromBody] ServiceDTO service)
        {
            try
            {
                var result = _serviceContext.UpdateServiceAndMachine(service);
                return Ok(new JsonResult(result));
            }
            catch (Exception ex)
            {

                return StatusCode(StatusCodes.Status500InternalServerError, "Error occured while updating the service");
            }
        }

        [Route("edit")]
        [Authorize(Roles = "Offer.Write,Offer.Read")]
        [HttpPut]
        public IActionResult UpdateService([FromBody] EditServiceDTO service)
        {
            try
            {
                var result = _serviceContext.UpdateService(service);
                return Ok(new JsonResult(result));
            }
            catch (Exception ex)
            {

                return StatusCode(StatusCodes.Status500InternalServerError, "Error occured while updating the service");
            }
        }
        [Route("updatemachine")]
        [Authorize(Roles = "Offer.Write,Offer.Read")]
        [HttpPut]
        public IActionResult UpdateMachine([FromBody] MachineDTO machine)
        {
            try
            {
                var result = _serviceContext.UpdateMachine(machine);
                return Ok(new JsonResult(result));
            }
            catch (Exception ex)
            {

                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }
        }
        [HttpPost]
        [Authorize(Roles = "Offer.Write,Offer.Read")]
        [Route("addactualhours")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Produces("application/json")]
        public async Task<IActionResult> AddActualHours(ActualHoursDto actualHours)
        {
            var result = _serviceContext.AddActualHours(actualHours);
            await eventBus.PublishToQueue(result.Result, true);
            if (result.Result == null)
            {
                return new JsonResult("Actual Hours Not Added")
                {
                    StatusCode = StatusCodes.Status500InternalServerError
                };
            }
            return new JsonResult("Actual Hours Added")
            {
                
            StatusCode = StatusCodes.Status200OK
            };
        }

        [Route("servicematerial")]
        [HttpPost]
        [Authorize(Roles = "Offer.Write,Offer.Read")]
        public async Task<ActionResult> GetServiceMaterialByCompanyCode([FromBody] ServiceMaterialResponseDTO serviceMaterial)
        {
            try
            {
                var result = await _serviceContext.GetServiceMaterialByCompanyCode(serviceMaterial);
                if (result.Count == 0)
                {
                    return NotFound("No Records Found");
                }
                return Ok(new JsonResult(result));
            }
            catch (Exception ex)
            {

                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);

            }

        }

        [Route("{serviceMachineId}/{userId}/logactualhours")]
        [HttpGet]
        [Authorize(Roles = "Offer.Write,Offer.Read")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [Produces("application/json")]
        public async Task<ActionResult> GetRecentLogActualHours(string serviceMachineId, string userId)
        {
            try
            {
                var result = await _serviceContext.GetRecentLogActualHours(serviceMachineId, userId);

                if(result != null)
                {
                    return Ok(result);
                }
                else
                {
                    return StatusCode(404, "No Records Found");
                }
                
            }
            catch (Exception ex)
            {

                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);

            }

        }
        [Route("{machineId}/machineroadmaps")]
        [HttpGet]
        [Authorize(Roles = "Offer.Write,Offer.Read")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [Produces("application/json")]
        public async Task<IActionResult> GetMachineRoadmaps(string machineId)
        {
            try
            {
                var result = await _serviceContext.GetAllMachineRoadmaps(machineId);
                return Ok(result);
            }
            catch (Exception ex)
            {

                return StatusCode(404, "No Records Found");
            }
        }
        [HttpGet]
        [Route("{companycode}/regionbycompanycode")]
        [Authorize(Roles = "Offer.Write,Offer.Read")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [Produces("application/json")]
        public async Task<IActionResult> GetServiceRegion(string companycode)
        {
            try
            {
                var result = await _serviceContext.GetRegionByCompanyCode(companycode);
                return Ok(result);
            }
            catch (Exception)
            {
                throw;
            }
        }
        [HttpGet]
        [Route("{serviceId}/rramachines")]
        [Authorize(Roles = "Offer.Write,Offer.Read")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [Produces("application/json")]
        public async Task<IActionResult> GetRRAMachines(string serviceId)
        {
            try
            {
                var result = await _serviceContext.GetMachinesByService(serviceId);
                return Ok(result);
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
