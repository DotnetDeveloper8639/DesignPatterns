﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Offer.API.Helper;
using Offer.API.Models.OfferDTO;
using Offer.API.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Offer.API.Controllers
{
    [Authorize]
    [Route("/api/offersvc/mastermachinesvc")]
    [ApiController]
    public class MasterMachineController : ControllerBase
    {


        public readonly IMasterMachineService _repositoryService;
        public MasterMachineController(IMasterMachineService masterMachineService)
        {
            _repositoryService = masterMachineService;
        }
        [Route("GetMasterMachineDetails")]
        [HttpGet]
        [Authorize(Roles = "Library.Read,Offer.Write,Offer.Read")]
        public async Task<IActionResult> GetMasterMachineDetails()
        {
            var result = await _repositoryService.GetMasterMachineDetails();
            if (!result.Any())
            {
                return NotFound("No Records Found");
            }
            return Ok(new JsonResult(result));
        }
        [Route("{customerId}/{count}/{increasedCount}/searchcustomermachines")]
        [HttpGet]
        [Authorize(Roles = "Library.Read,Offer.Write,Offer.Read")]
        public async Task<IActionResult> GetCustomerMachineDetails(string customerId, int count, int increasedCount)
        {
            try
            {
                var result = await _repositoryService.GetCustomerMachineDetails(customerId, count, increasedCount);
                if (!result.Any())
                {
                    var data = new
                    {
                        statusCode = "404",
                        returnText = "No data found"
                    };
                    return StatusCode(StatusCodes.Status200OK, data);
                }
                return Ok(new JsonResult(result));
            }
            catch (Exception)
            {

                return StatusCode(StatusCodes.Status500InternalServerError, "Error occured while fetching the data");
            }
        }
        [Route("SearchMasterMachines/{MachineName}/{count}/{increasedCount}")]
        [Authorize(Roles = "Library.Read,Offer.Write,Offer.Read")]
        [HttpGet]
        public async Task<IActionResult> GetMasterMachineDetailsByName(string MachineName, int count, int increasedCount)
        {
            try
            {
                var result = await _repositoryService.GetMasterMachineDetails(MachineName, count, increasedCount);
                if (!result.Any())
                {
                    var data = new
                    {
                        statusCode = "404",
                        returnText = "No data found"
                    };
                    return StatusCode(StatusCodes.Status200OK, data);
                }
                return Ok(new JsonResult(result));
            }
            catch (Exception)
            {

                return StatusCode(StatusCodes.Status500InternalServerError, "Error occured while fetching the data");
            }

        }
        [Route("filteredmachines")]
        [Authorize(Roles = "Library.Read,Offer.Write,Offer.Read")]
        [HttpPost]
        public async Task<IActionResult> GetFilteredMasterMachineDetails(SearchMachineDto searchMachineDto)
        {
            try
            {
                var result = await _repositoryService.GetFilteredMasterMachineDetails(searchMachineDto);
                if (!result.Any())
                {
                    var data = new
                    {
                        statusCode = "404",
                        returnText = "No data found"
                    };
                    return StatusCode(StatusCodes.Status200OK, data);
                }
                return Ok(new JsonResult(result));
            }
            catch (Exception)
            {

                return StatusCode(StatusCodes.Status500InternalServerError, "Error occured while fetching the data");
            }

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="masterMachines"></param>
        /// <returns></returns>
        [Route("MasterMachineFileUploadJson")]
        [Authorize(Roles = "Library.Write,Library.Read")]
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [Produces("application/json")]
        public ActionResult FileUploadForMasterMachineInJSonFormate([FromBody] List<MaterMachineFileUploadDTO> masterMachines)
        {
            try
            {
                if (masterMachines == null)
                {
                    return BadRequest();
                }
                var result = _repositoryService.FileUploadForMasterMachineInJSonFormate(masterMachines);
                return Ok(new JsonResult(result));
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Error occured while uploading the file");
            }

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="count"></param>
        /// <param name="increasedCount"></param>
        /// <returns></returns>
        [Route("{search}/{count}/{increasedCount}/applications")]
        [Authorize(Roles = "Library.Read,Offer.Write,Offer.Read")]
        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [Produces("application/json")]
        public async Task<IActionResult> GetAllApplication(string search, int count, int increasedCount)
        {
            try
            {
                var result = await _repositoryService.GetAllApplication(search, count, increasedCount);
                if (!result.Any())
                {
                    var data = new
                    {
                        statusCode = "404",
                        returnText = "No data found"
                    };
                    return StatusCode(StatusCodes.Status200OK, data);
                }
                return Ok(new JsonResult(result));
            }
            catch (Exception)
            {

                return StatusCode(StatusCodes.Status500InternalServerError, "Error occured while fetching the data");
            }

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="count"></param>
        /// <param name="increasedCount"></param>
        /// <returns></returns>
        [Route("{search}/{count}/{increasedCount}/controlsystems")]
        [Authorize(Roles = "Library.Read,Offer.Write,Offer.Read")]
        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [Produces("application/json")]
        public async Task<IActionResult> GetAllControlSystem(string search, int count, int increasedCount)
        {
            try
            {
                var result = await _repositoryService.GetAllControlSystem(search, count, increasedCount);
                if (!result.Any())
                {
                    var data = new
                    {
                        statusCode = "404",
                        returnText = "No data found"
                    };
                    return StatusCode(StatusCodes.Status200OK, data);
                }
                return Ok(new JsonResult(result));
            }
            catch (Exception)
            {

                return StatusCode(StatusCodes.Status500InternalServerError, "Error occured while fetching the data");
            }

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="count"></param>
        /// <param name="increasedCount"></param>
        /// <returns></returns>
        [Route("{search}/{count}/{increasedCount}/machinetypes")]
        [Authorize(Roles = "Library.Read,Offer.Write,Offer.Read")]
        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [Produces("application/json")]
        public async Task<IActionResult> GetAllMachineType(string search, int count, int increasedCount)
        {
            try
            {
                var result = await _repositoryService.GetAllMachineType(search, count, increasedCount);
                if (!result.Any())
                {
                    var data = new
                    {
                        statusCode = "404",
                        returnText = "No data found"
                    };
                    return StatusCode(StatusCodes.Status200OK, data);
                }
                return Ok(new JsonResult(result));
            }
            catch (Exception)
            {

                return StatusCode(StatusCodes.Status500InternalServerError, "Error occured while fetching the data");
            }

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="count"></param>
        /// <param name="increasedCount"></param>
        /// <returns></returns>
        [Route("{search}/{count}/{increasedCount}/specificfeatures")]
        [Authorize(Roles = "Library.Read,Offer.Write,Offer.Read")]
        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [Produces("application/json")]
        public async Task<IActionResult> GetAllSpecificFeature(string search, int count, int increasedCount)
        {
            try
            {
                var result = await _repositoryService.GetAllSpecificFeature(search, count, increasedCount);
                if (!result.Any())
                {
                    var data = new
                    {
                        statusCode = "404",
                        returnText = "No data found"
                    };
                    return StatusCode(StatusCodes.Status200OK, data);
                }
                return Ok(new JsonResult(result));
            }
            catch (Exception)
            {

                return StatusCode(StatusCodes.Status500InternalServerError, "Error occured while fetching the data");
            }

        }
        [Route("application")]
        [Authorize(Roles = "Library.Read,Offer.Write,Offer.Read")]
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [Produces("application/json")]
        public async Task<IActionResult> CreateApplication(List<ApplicationDto> application)
        {
            try
            {
                if (application == null)
                {
                    return BadRequest();
                }
                var result = await _repositoryService.CreateApplication(application);
                return Ok(result);

            }
            catch (Exception)
            {

                throw;
            }
        }
        [Route("controlsystem")]
        [Authorize(Roles = "Library.Read,Offer.Write,Offer.Read")]
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [Produces("application/json")]
        public async Task<IActionResult> CreateControlSystem(List<ControlSystemDto> controlSystems)
        {
            try
            {
                if (controlSystems == null)
                {
                    return BadRequest();
                }
                var result = await _repositoryService.CreateControlSystem(controlSystems);
                return Ok(result);

            }
            catch (Exception)
            {

                throw;
            }
        }
        [Route("specificfeature")]
        [Authorize(Roles = "Library.Read,Offer.Write,Offer.Read")]
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [Produces("application/json")]
        public async Task<IActionResult> CreateSpecificFeature(List<SpecificFeatureDto> specificFeatures)
        {
            try
            {
                if (specificFeatures == null)
                {
                    return BadRequest();
                }
                var result = await _repositoryService.CreateSpecificFeatuere(specificFeatures);
                return Ok(result);

            }
            catch (Exception)
            {

                throw;
            }
        }
        [Route("machinetype")]
        [Authorize(Roles = "Library.Read,Offer.Write,Offer.Read")]
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [Produces("application/json")]
        public async Task<IActionResult> CreateMachineType(List<MachineTypeDto> machineTypes)
        {
            try
            {
                if (machineTypes == null)
                {
                    return BadRequest();
                }
                var result = await _repositoryService.CreateMachineType(machineTypes);
                return Ok(result);

            }
            catch (Exception)
            {

                throw;
            }
        }
        [Route("deletemachinetype")]
        [Authorize(Roles = "Library.Read,Offer.Write,Offer.Read")]
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [Produces("application/json")]
        public async Task<IActionResult> DeleteMachineType(MachineTypeDto machineTypes)
        {
            try
            {
                if (machineTypes == null)
                {
                    return BadRequest();
                }
                var result = await _repositoryService.DeleteMachineType(machineTypes);
                return Ok(result);

            }
            catch (Exception)
            {

                throw;
            }
        }
        [Route("deleteapplication")]
        [Authorize(Roles = "Library.Read,Offer.Write,Offer.Read")]
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [Produces("application/json")]
        public async Task<IActionResult> DeleteApplication(ApplicationDto application)
        {
            try
            {
                if (application == null)
                {
                    return BadRequest();
                }
                var result = await _repositoryService.DeleteApplication(application);
                return Ok(result);

            }
            catch (Exception)
            {

                throw;
            }
        }
        [Route("deletespecificfeature")]
        [Authorize(Roles = "Library.Read,Offer.Write,Offer.Read")]
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [Produces("application/json")]
        public async Task<IActionResult> DeleteSpecificFeature(SpecificFeatureDto specificFeature)
        {
            try
            {
                if (specificFeature == null)
                {
                    return BadRequest();
                }
                var result = await _repositoryService.DeleteSpecificFeature(specificFeature);
                return Ok(result);

            }
            catch (Exception)
            {

                throw;
            }
        }
        [Route("deletecontrolsystem")]
        [Authorize(Roles = "Library.Read,Offer.Write,Offer.Read")]
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [Produces("application/json")]
        public async Task<IActionResult> DeleteControlSystem(ControlSystemDto controlSystem)
        {
            try
            {
                if (controlSystem == null)
                {
                    return BadRequest();
                }
                var result = await _repositoryService.DeleteControlSystem(controlSystem);
                return Ok(result);

            }
            catch (Exception)
            {

                throw;
            }
        }


        #region
        [Route("MachineAttribute/{machineId}")]
        [Authorize(Roles = "Library.Read,Offer.Write,Offer.Read")]
        [HttpGet]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Produces("application/json")]
        public async Task<IActionResult> GetMachineAttribute(string machineId)
        {
            try
            {
                if (string.IsNullOrEmpty(machineId))
                    return BadRequest();

                return Ok(new JsonResult(await _repositoryService.GetMachineAttribute(machineId)));
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, MessageConstants.ErrorMessage);
            }

        }
        #endregion


        [Route("MachineEdit")]
        [Authorize(Roles = "Machine.Edit")]
        [HttpPut]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Produces("application/json")]
        public ActionResult MachineEdit([FromBody] MachineEditDTO machineEdit)
        {
            try
            {
                if (machineEdit == null)
                {
                    return BadRequest();
                }

                return Ok(new JsonResult(_repositoryService.MachineEdit(machineEdit)));
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, MessageConstants.EditErrorMessage);
            }

        }
        [Route("machinereferences/{machineId}")]
        [Authorize(Roles = "Library.Read,Offer.Write,Offer.Read")]
        [HttpGet]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Produces("application/json")]
        public async Task<IActionResult> GetMachineReferences(string machineId)
        {
            try
            {
                if (string.IsNullOrEmpty(machineId))
                    return BadRequest();

                return Ok(new JsonResult(await _repositoryService.GetMachineReferences(machineId)));
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, MessageConstants.ErrorMessage);
            }
        }

        [Route("GetMachineReferencesForBulkUpload")]
        [Authorize(Roles = "Library.Read,Offer.Write,Offer.Read")]
        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Produces("application/json")]
        public async Task<IActionResult> GetMachineReferencesForBulkUpload()
        {
            try
            {
                return Ok(new JsonResult(await _repositoryService.GetMachineReferencesForBulkUpload()));
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, MessageConstants.ErrorMessage);
            }
        }
        [Route("mastermachine")]
        [Authorize(Roles = "Library.Read,Offer.Write,Offer.Read")]
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Produces("application/json")]
        public async Task<IActionResult> RemoveMasterMachine([FromBody] List<string> list)
        {
            try
            {
                return Ok(await _repositoryService.RemoveMasterMachine(list));
            }
            catch (Exception)
            {

                return StatusCode(StatusCodes.Status500InternalServerError, MessageConstants.ErrorMessage);
            }
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="masterMachines"></param>
        /// <returns></returns>
        [Route("validatemastermachine")]
        [Authorize(Roles = "Library.Write,Library.Read")]
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status409Conflict)]
        [Produces("application/json")]
        public ActionResult ValidateMasterMachineInJSonFormate([FromBody] List<MaterMachineFileUploadDTO> masterMachines)
        {
            try
            {
                if (masterMachines == null)
                {
                    return BadRequest();
                }
                var result = _repositoryService.MachineValidation(masterMachines);
                return Ok(new JsonResult(result));
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Error occured while uploading the file");
            }

        }


        #region Machine Images Upload
        [Route("AddUpdateMachineImages")]
        [Authorize(Roles = "Library.Write,Library.Read")]
        //[AllowAnonymous]
        [HttpPost]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [Produces("application/json")]
        public async Task<IActionResult> AddUpdateMachineImages([FromBody] List<MachineImagesUploadDTO> masterMachineImages)
        {
            try
            {
                if (masterMachineImages.Count == 0)
                    return BadRequest(new ResponseVM(true, MessageConstants.LIST_CAN_NOT_BE_EMPTY, StatusCodes.Status200OK, MessageConstants.ERROR));

                return Ok(await _repositoryService.AddUpdateMachineImages(masterMachineImages));
            }
            catch (Exception)
            {

                return Ok(new ResponseVM(true, MessageConstants.ERROR, StatusCodes.Status500InternalServerError, MessageConstants.ERROR));

            }

        }

        [HttpGet]
       [Authorize(Roles = "Library.Write,Library.Read")]
        [Route("GetMachineImages/{machineId}")]
        //[AllowAnonymous]
        public async Task<IActionResult> GetMachineImages(string machineId)
        {
            try
            {
                return Ok(await _repositoryService.GetMachineImages(machineId));
            }
            catch (Exception ex)
            {
                return Ok(new ResponseVM(true, MessageConstants.ERROR, StatusCodes.Status500InternalServerError, MessageConstants.ERROR));
            }

        }

        #endregion
    }
}
