﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Offer.API.EntityModels;
using Offer.API.Models.OfferDTO;
using Offer.API.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Offer.API.Controllers
{
    [Route("/api/offersvc/librarysvc")]
    [ApiController]
    public class RoadMapController : ControllerBase
    {
        public readonly IRoadMapService _repositoryService;
        public RoadMapController(IRoadMapService roadMapService)
        {
            _repositoryService = roadMapService;
        }

        [Route("RoadMap")]
        [HttpGet]
        public IActionResult SaveRoadMap()
        {
            try
            {
                var result = _repositoryService.GetRoadMap();
                return Ok(new JsonResult(result));
            }
            catch (Exception)
            {

                return StatusCode(StatusCodes.Status500InternalServerError, "Error occured while fetching the data");
            }

        }
        [Route("CustomTemplateRoadMap")]
        [HttpGet]
        public IActionResult CustomTemplateRoadMap()
        {
            try
            {
                var result = _repositoryService.GetCustomTemplateRoadMap();
                return Ok(new JsonResult(result));
            }
            catch (Exception)
            {

                return StatusCode(StatusCodes.Status500InternalServerError, "Error occured while fetching the data");
            }

        }
        [Route("PredefinedTemplateRoadMap")]
        [HttpGet]
        public IActionResult PredefinedTemplateRoadMap()
        {
            try
            {
                var result = _repositoryService.GetPredefinedTemplateRoadMap();
                return Ok(new JsonResult(result));
            }
            catch (Exception)
            {

                return StatusCode(StatusCodes.Status500InternalServerError, "Error occured while fetching the data");
            }

        }
        [Route("{roadmapId}/CustomTemplateRoadMap")]
        [HttpGet]
        public async Task<IActionResult> CustomTemplateRoadMap(string roadmapId)
        {
            try
            {
                var result = await _repositoryService.GetRoadMap(roadmapId);
                return Ok(new JsonResult(result));
            }
            catch (Exception)
            {

                return StatusCode(StatusCodes.Status500InternalServerError, "Error occured while fetching the data");
            }

        }
        [Route("RoadMap")]
        [HttpPost]
        public IActionResult SaveRoadMap([FromBody] UploadRoadmapDTO list)
        {
            try
            {
                var result = _repositoryService.SaveRoadMap(list);
                return Ok(new JsonResult(result));
            }
            catch (Exception)
            {

                return StatusCode(StatusCodes.Status500InternalServerError, "Error occured while saving the data");
            }

        }
        [Authorize]
        [Authorize(Roles = "TemplateRoadmap.Write")]
        [Route("TemplateRoadMap")]
        [HttpPost]
        public IActionResult SaveTemplateRoadmap([FromBody] List<TemplateRoadmapDto> list)
        {
            try
            {
                var result = _repositoryService.SaveTemplateRoadMap(list);
                return Ok(new JsonResult(result));
            }
            catch (Exception)
            {

                return StatusCode(StatusCodes.Status500InternalServerError, "Error occured while saving the data");
            }

        }

        [Route("DeleteTemplateRoadmap")]
        [HttpPost]
        public IActionResult DeleteTemplateRoadmap(DeleteRoadmapFile legislation)
        {
            try
            {
                var result = _repositoryService.DeleteTemplateRoadmap(legislation);
                return Ok(new JsonResult(result.Result));
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Error occured while saving the data");
            }
        }
        [Route("TemplateRoadmap")]
        [HttpPut]
        public IActionResult UpdateTemplateRoadmap(EditPredefinedRoadmapDto legislation)
        {
            try
            {
                var result = _repositoryService.UpdateLibraryRoadmap(legislation);
                return Ok(new JsonResult(result.Result));
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Error occured while saving the data");
            }
        }
        #region LibraryRegion
        [Route("library/{userId}")]
        [HttpGet]
        public IActionResult GetLibrary(string userId)
        {
            try
            {
                var result = _repositoryService.GetLibrary(userId);
                return Ok(new JsonResult(result));
            }
            catch (Exception)
            {

                return StatusCode(StatusCodes.Status500InternalServerError, "Error occured while fetching the data");
            }
        }

        [Route("library/{userId}")]
        [HttpPost]
        public IActionResult CreateLibrary([FromBody] List<LibraryDTO> list, string userId)
        {
            try
            {
                var result = _repositoryService.CreateLibrary(list, userId);
                return Ok(new JsonResult(result));
            }
            catch (Exception Ex)
            {

                return StatusCode(StatusCodes.Status500InternalServerError, "Error occured while saving the data");
            }
        }

        [Route("deletebookmark")]
        [HttpPost]
        public IActionResult DeleteBookMark([FromBody] string[] libraryId)
        {
            try
            {
                var result = _repositoryService.DeleteBookMark(libraryId);
                return Ok(new JsonResult(result));
            }
            catch (Exception Ex)
            {

                return StatusCode(StatusCodes.Status500InternalServerError, "Error occured while deleting bookmark");
            }
        }
        #endregion

        #region Custom_Roadmap
        [Route("customroadmap")]
        [HttpPost]
        public IActionResult CustomRoadmap([FromBody] List<RoadmapDTO> list)
        {
            try
            {
                var result = _repositoryService.CustomRoadmap(list);
                return Ok(new JsonResult(result));
            }
            catch (Exception ex)
            {



                return StatusCode(StatusCodes.Status500InternalServerError, "Error occured while saving the data");
            }



        }

        [Route("customsection")]
        [HttpPost]
        public IActionResult CustomSection([FromBody] List<SectionMasterDTO> list)
        {
            try
            {
                var result = _repositoryService.CustomSection(list);
                return Ok(new JsonResult(result));
            }
            catch (Exception)
            {



                return StatusCode(StatusCodes.Status500InternalServerError, "Error occured while saving the data");
            }



        }

        [Route("customstep")]
        [HttpPost]
        public IActionResult CustomStep([FromBody] List<StepMasterDTO> list)
        {
            try
            {
                var result = _repositoryService.CustomStep(list);
                return Ok(new JsonResult(result));
            }
            catch (Exception)
            {



                return StatusCode(StatusCodes.Status500InternalServerError, "Error occured while saving the data");
            }


        }

        [Route("CustomSubSection")]
        [HttpPost]
        public IActionResult CustomSubSection([FromBody] List<SubSectionMasterDTO> list)
        {
            try
            {
                var result = _repositoryService.CustomSubSection(list);
                return Ok(new JsonResult(result));
            }
            catch (Exception)
            {

                return StatusCode(StatusCodes.Status500InternalServerError, "Error occured while saving the data");
            }



        }
        #endregion

        #region InitialHazard
        [Route("InitialHazard")]
        [HttpPost]
        public IActionResult InitialHazard([FromBody] List<InitialHazardMasterDTO> initialHazardMaster)
        {
            try
            {
                var result = _repositoryService.InitialHazard(initialHazardMaster);
                return Ok(new JsonResult(result));
            }
            catch (Exception)
            {

                return StatusCode(StatusCodes.Status500InternalServerError, "Error occured while saving the data");
            }

        }
        [Route("CounterMeasure")]
        [HttpPost]
        public IActionResult CounterMeasure([FromBody] List<CounterMeasureDTO> counterMeasure)
        {
            try
            {
                var result = _repositoryService.CounterMeasure(counterMeasure);
                return Ok(new JsonResult(result));
            }
            catch (Exception)
            {

                return StatusCode(StatusCodes.Status500InternalServerError, "Error occured while saving the data");
            }

        }
        [Route("InitialHazard/{userId}")]
        [HttpGet]
        public IActionResult InitialHazard(string userId)
        {
            try
            {
                var result = _repositoryService.InitialHazard(userId);
                return Ok(new JsonResult(result));
            }
            catch (Exception)
            {

                return StatusCode(StatusCodes.Status500InternalServerError, "Error occured while fetching the data");
            }
        }
        [Route("CounterMeasure/{userId}")]
        [HttpGet]
        public IActionResult CounterMeasure(string userId)
        {
            try
            {
                var result = _repositoryService.CounterMeasure(userId);
                return Ok(new JsonResult(result));
            }
            catch (Exception)
            {

                return StatusCode(StatusCodes.Status500InternalServerError, "Error occured while fetching the data");
            }
        }
        #endregion

        [Route("HazardMachine/{hazardMachineId}")]
        [HttpGet]
        public IActionResult GetHazardMachineById(string hazardMachineId)
        {
            try
            {
                var result = _repositoryService.GetHazardMachineById(hazardMachineId);
                return Ok(new JsonResult(result));
            }
            catch (Exception)
            {

                return StatusCode(StatusCodes.Status500InternalServerError, "Error occured while fetching the data");
            }
        }
        [HttpPost]
        [Route("sitedetails")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public IActionResult SaveSiteDetails(TblSiteDetails siteDetails)
        {
            try
            {
                var result = _repositoryService.SaveSiteDetails(siteDetails);
                return Ok(result.Result);
            }
            catch (Exception)
            {

                throw;
            }
        }
        [HttpGet]
        [Route("{siteName}/sitedetails")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        public IActionResult GetSiteDetails(string siteName)
        {
            try
            {
                var result = _repositoryService.GetSiteDetails(siteName);
                return Ok(result.Result);
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
