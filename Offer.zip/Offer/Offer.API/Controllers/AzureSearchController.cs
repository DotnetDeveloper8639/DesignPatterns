﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Offer.API.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Offer.API.Controllers
{
    [Route("/api/offersvc/search")]
    [ApiController]
    public class AzureSearchController : ControllerBase
    {
        public readonly IAzureSearchService _AzureSearchService;

        public AzureSearchController(IAzureSearchService azureSearchService)
        {
            _AzureSearchService = azureSearchService;
        }

        [Route("")]
        [HttpGet]
        public ActionResult Get()
        {
            try
            {
                var result = _AzureSearchService.AzureGlobalSearch();

                return Ok(new JsonResult(result));
            }
            catch (Exception ex)
            {

                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }

        }
    }
}
