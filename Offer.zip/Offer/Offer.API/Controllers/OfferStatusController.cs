﻿using EventBus.Abstractions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Offer.API.Helper;
using Offer.API.IntegrationEvents.Events;
using Offer.API.Models.OfferDTO;
using Offer.API.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Offer.API.Controllers
{
    [Authorize]
    [Route("/api/offersvc")]
    [ApiController]
    public class OfferStatusController : ControllerBase
    {

        public readonly IOfferStatusService _repositoryService;
        private readonly IEventBus eventBus;
        public IDataProtector _protection;
        public readonly string offerSecurityString = "InpupOffeRR!@!$oTe*&*cti&onS%ch*em#aRsal!";
        public OfferStatusController(IOfferStatusService offerStatusService
            , IEventBus eventBus)
        {
            _repositoryService = offerStatusService;
            this.eventBus = eventBus;
        }

        /// <summary>
        /// Get All offers
        /// </summary>
        /// <returns></returns>
        [Route("")]
        [HttpGet]
        [Authorize(Roles = "Offer.Read,Offer.Write")]
        public async Task<ActionResult> Get()
        {

            var result = await _repositoryService.GetOfferManagementDeatails();
            if (!result.Any())
            {
                return NotFound("No Records Found");
            }
            return Ok(new JsonResult(result));
        }
        [Route("{opportunityId}")]
        [HttpGet]
        [Authorize(Roles = "Offer.Read,Offer.Write")]
        public async Task<ActionResult> GetOfferByOpportunityId(string opportunityId)
        {
            try
            {
                var result = await _repositoryService.GetOfferByOpportunityId(opportunityId);
                if (result == null)
                {
                    return NotFound("No Records Found");
                }
                return Ok(new JsonResult(result));
            }
            catch (Exception)
            {

                return StatusCode(StatusCodes.Status500InternalServerError, "Internal Server Error");

            }

        }


        /// <summary>
        /// Get offer by projectId and OfferId
        /// </summary>
        /// <param name="projectId"></param>
        /// <param name="offerId"></param>
        /// <returns></returns>
        [Route("offerdetails/{offerId},{projectId}")]
        [HttpGet]
        [Authorize(Roles = "Offer.Read,Offer.Write")]
        public async Task<ActionResult> GetOfferDetailsById(string projectId, string offerId)
        {
            //var decryptedProjectId = _protection.Unprotect(projectId);
            //var decryptedOfferId = _protection.Unprotect(offerId);
            var result = await _repositoryService.GetOfferStatusDetailsById(projectId, offerId);
            if (result == null)
            {
                return NotFound("No Records Found");
            }
            return Ok(new JsonResult(result));
        }

        /// <summary>
        /// Get Service of ProjectId, OfferId and ServiceType
        /// </summary>
        /// <param name="projectId"></param>
        /// <param name="offerId"></param>
        /// <param name="serviceType"></param>
        /// <returns></returns>
        [Route("offerservicedetails/{serviceId}")]
        [HttpGet]
        //[Authorize(Roles = "Service.List,Service.Manage")]
        [Authorize(Roles = "Offer.Read,Offer.Write")]
        public async Task<ActionResult> GetOfferServiceDetails(string serviceId)
        {

            var result = await _repositoryService.GetOfferServiceDetails(serviceId);
            if (result == null)
            {
                return NotFound("No Records Found");
            }
            return Ok(new JsonResult(result));
        }

        /// <summary>
        /// Get Machine of ProjectId, OfferId and ServiceId
        /// </summary>
        /// <param name="projectId"></param>
        /// <param name="offerId"></param>
        /// <param name="serviceId"></param>
        /// <returns></returns>
        [Route("offermachinedetails/{projectId},{offerId},{serviceId}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [Produces("application/json")]
        [HttpGet]
        //[Authorize(Roles = "Service.List,Service.Manage")]
        [Authorize(Roles = "Offer.Read,Offer.Write")]
        public async Task<ActionResult> GetOfferMachineDetails(string projectId, string offerId, string serviceId)
        {

            var result = await _repositoryService.GetOfferMachineDetails(projectId, offerId, serviceId);
            if (result == null)
            {
                return NotFound("No Records Found");
            }
            return Ok(new JsonResult(result));
        }

        /// <summary>
        /// Create new offer
        /// </summary>
        /// <param name="createOfferDTO"></param>
        /// <returns></returns>
        [Route("create")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [Produces("application/json")]
        [HttpPost]
        [Authorize(Roles = "Offer.Write")]
        public ActionResult CreateOffer([FromBody] CreateOfferDTO createOfferDTO)
        {

            var result = _repositoryService.CreateOffer(createOfferDTO);
            if (result == null)
            {
                return NotFound("No Records Found");
            }
            return Ok(new JsonResult(result));
        }


        [Route("deletemachine")]
        [HttpPost]
        //[Authorize(Roles = "Machine.Delete,Machine.Manage")]
        [Authorize(Roles = "Offer.Delete, Offer.Write")]
        public ActionResult DeleteMachineById([FromBody] List<string> list)
        {
            var result = _repositoryService.DeleteMachineById(list);
            if (!result.Any())
            {
                return NotFound("No Records Found");
            }
            return Ok(new JsonResult(result));
        }

        [Route("deleteofferservice")]
        [HttpPost]
        //[Authorize(Roles = "Service.Delete,Service.Manage")]
        [Authorize(Roles = "Offer.Write,Offer.Delete")]
        public ActionResult DeleteOfferServiceById([FromBody] List<string> list)
        {
            var result = _repositoryService.DeleteOfferServiceById(list);
            if (!result.Any())
            {
                return NotFound("No Records Found");
            }
            return Ok(new JsonResult(result));
        }


        /// <summary>
        /// Delete offer or List of Offers
        /// </summary>
        /// <param name="list"></param>
        /// <returns></returns>
        [Route("deleteoffer")]
        [HttpPost]
        [Authorize(Roles = "Offer.Delete,Offer.Write")]
        public ActionResult DeleteOfferById([FromBody] List<string> list)
        {
            var result = _repositoryService.DeleteOfferById(list);
            if (!result.Any())
            {
                return NotFound("No Records Found");
            }
            return Ok(new JsonResult(result));
        }

        [Route("effortmetrics")]
        [HttpGet]
        [Authorize(Roles = "Offer.Read,Offer.Write")]
        public ActionResult OfferStatusEffortMetrics()
        {
            var result = _repositoryService.GetOffertMetrics();
            if (!result.Any())
            {
                return NotFound("No Metrics Found");
            }
            return Ok(new JsonResult(result));
        }

        [Route("getmachines")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [Produces("application/json")]
        [HttpGet]
        //[Authorize(Roles = "Machine.List,Machine.Manage")]
        [Authorize(Roles = "Library.Read,Offer.Write,Offer.Read")]
        public ActionResult GetMachineName()
        {
            var result = _repositoryService.GetMachineName();
            if (!result.Any())
            {
                return NotFound("No machine Found");
            }
            return Ok(new JsonResult(result));
        }
        [Route("Get")]
        [HttpGet]
        [Authorize(Roles = "Offer.Read,Offer.Write")]
        public ActionResult GetOfferId()
        {
            var result = _repositoryService.GetOfferId();
            if (!result.Any())
            {
                return NotFound("No Projects Found");
            }
            return Ok(new JsonResult(result));
        }
        [Route("GetCustomerName")]
        [HttpGet]
        [Authorize(Roles = "Offer.Read,Offer.Write,Customer.Read")]
        public async Task<ActionResult> GetCustomerName(string customerName)
        {
            var result = await _repositoryService.GetCustomerName(customerName);
            if (result == null)
            {
                return NotFound("No Customer Found");
            }
            return Ok(new JsonResult(result));
        }

        [Route("getprojectsbycustomerid/{customerName}")]
        [HttpGet]
        //[Authorize(Roles = "Offer.Get,Offer.Manage")]
        [Authorize(Roles = "Offer.Read,Offer.Write, Offer.Edit")]
        public ActionResult GetProjectsByCustomerId(string customerName)
        {
            try
            {
                var result = _repositoryService.GetProjectsByCustomerId(customerName);
                return Ok(new JsonResult(result));
            }
            catch (Exception)
            {

                return StatusCode(StatusCodes.Status500InternalServerError, "Internal Issue");
            }

        }
        [Route("update")]
        [Authorize(Roles = "Offer.Write,Offer.Edit")]
        [HttpPut]
        public ActionResult UpdateOffer([FromBody] EditOfferDTO update)
        {
            try
            {
                var result = _repositoryService.UpdateOffer(update);
                //if (string.IsNullOrEmpty(result))
                //{
                //    return NotFound(result);
                //}
                return Ok(new JsonResult(result));
            }
            catch (Exception)
            {

                return BadRequest("Internal Server Error");
            }

        }

        [Route("GenerateLayoutQuotationByCommercialQuotationNumber")]
        //[AllowAnonymous]
        [Authorize(Roles = "Offer.Write,Offer.Edit")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [Produces("application/json")]
        [HttpPost]
        public ActionResult GenerateLayoutQuotationByCommercialQuotationNumber([FromBody] AddEditLayoutQuotationDTO addEditLayoutQuotationDTO)
        {
            try
            {
                var result = _repositoryService.GenerateLayoutQuotationByCommercialQuotationNumber(addEditLayoutQuotationDTO);
                return Ok(new JsonResult(result));
            }
            catch (Exception)
            {

                return BadRequest("Internal Server Error");
            }

        }

        [Route("AddFinalQuotation")]
        //[AllowAnonymous]
        [Authorize(Roles = "Offer.Write,Offer.Edit")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [Produces("application/json")]
        [HttpPost]
        public ActionResult AddFinalQuotation([FromBody] AddFinalQuotationDTO addFinalQuotationDTO)
        {
            try
            {
                var result = _repositoryService.AddFinalQuotation(addFinalQuotationDTO);
                if (result.Result == true)
                {
                    return StatusCode(200, "Final Quotation Added");
                }
                else
                {
                    return StatusCode(500, "Final Quotation Failed to Save");
                }
            }
            catch (Exception)
            {

                return BadRequest("Internal Server Error");
            }

        }

        [Route("getloginusers/{user}")]
        [HttpGet]
        [Authorize(Roles = "Offer.Read,Offer.Write")]
        public ActionResult GetLoginUsers(string user)
        {
            try
            {
                var result = _repositoryService.GetLoginUsers(user);
                return Ok(new JsonResult(result));
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Internal Server Error");
            }


        }

        [Route("{offerId}/getcommercialquote")]
        [HttpGet]
        [Authorize(Roles = "Offer.Read,Offer.Manage")]
        public async Task<ActionResult> GetCommercialQuotation(string offerId)
        {
            try
            {
                var result = await _repositoryService.GetCommercialQuotation(offerId);
                return Ok(result);
            }
            catch (Exception ex)
            {

                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message);
            }


        }
        [Route("{offerId}/commercialquoteversions")]
        [HttpGet]
        [Authorize(Roles = "Offer.Read,Offer.Manage")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [Produces("application/json")]
        public async Task<ActionResult> GetCommercialQuotationVersions(string offerId)
        {
            try
            {
                var result = await _repositoryService.GetCommercialQuotationVersion(offerId);
                return Ok(result);
            }
            catch (Exception ex)
            {

                return StatusCode(StatusCodes.Status404NotFound, ex.Message);
            }


        }

        [Route("{offerId}/finalquoteversions")]
        [HttpGet]
        [Authorize(Roles = "Offer.Read,Offer.Manage")]
        //[AllowAnonymous]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [Produces("application/json")]
        public async Task<ActionResult> GetFinalQuotationVersions(string offerId)
        {
            try
            {
                var result = await _repositoryService.GetFinalQuotationVersions(offerId);
                return Ok(result);
            }
            catch (Exception ex)
            {

                return StatusCode(StatusCodes.Status404NotFound, ex.Message);
            }


        }


        [AllowAnonymous]
        [Route("servicematerialrequest")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Produces("application/json")]
        [HttpPost]
        public IActionResult ServiceMaterialRequest(ServiceMaterialRequestEvent serviceMaterial)
        {
            eventBus.StoreState("servicematerial_erp", serviceMaterial);

            HttpContext.Items["CurrentTenantId"] = serviceMaterial.TechnicalHeader.TenantID;
            var result = _repositoryService.CreateServiceProduct(serviceMaterial);
            return Ok(result);
        }

        [AllowAnonymous]
        [Route("wbsresponse")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Produces("application/json")]
        [HttpPost]
        public async Task<IActionResult> WBSResponseProcessing(WbsResponseEvent wbsResponse)
        {
            eventBus.StoreState("wbs_erp", wbsResponse);

            HttpContext.Items["CurrentTenantId"] = wbsResponse.TechnicalHeader.TenantID;
            _repositoryService.WbsResponseProcess(wbsResponse);
            return Ok();
        }

        [AllowAnonymous]
        [Route("ProcessActualCost")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Produces("application/json")]
        [HttpPost]
        public async Task<IActionResult> ProcessActualCost(ErpActualCostResponseEvent erpActualCost)
        {
            eventBus.StoreState("actual_costs_erp", erpActualCost);

            HttpContext.Items["CurrentTenantId"] = erpActualCost.TechnicalHeader.TenantID;
            _repositoryService.UpdateActualCost(erpActualCost);
            return Ok();
        }

        [AllowAnonymous]
        [Route("ProcessPlannedCost")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Produces("application/json")]
        [HttpPost]
        public async Task<IActionResult> ProcessPlannedCost(ErpPlannedCostResponseEvent erpPlannedCost)
        {
            eventBus.StoreState("planned_cost_erp", erpPlannedCost);

            HttpContext.Items["CurrentTenantId"] = erpPlannedCost.TechnicalHeader.TenantID;
            _repositoryService.UpdatePlannedCost(erpPlannedCost);
            return Ok();
        }

        [AllowAnonymous]
        [Route("ProcessCalculatedHour")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Produces("application/json")]
        [HttpPost]
        public async Task<IActionResult> ProcessCalculatedHour(ErpCalculatedHourResponseEvent erpCalculatedHour)
        {
            eventBus.StoreState("calculated_hours_erp", erpCalculatedHour);

            HttpContext.Items["CurrentTenantId"] = erpCalculatedHour.TechnicalHeader.TenantID;
            _repositoryService.UpdateCalculatedHour(erpCalculatedHour);
            return Ok();
        }

        [AllowAnonymous]
        [Route("ProcessActualSales")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Produces("application/json")]
        [HttpPost]
        public async Task<IActionResult> ProcessActualSales(ErpActualSaleResponseEvent erpActualSale)
        {
            eventBus.StoreState("actual_sales_erp", erpActualSale);

            HttpContext.Items["CurrentTenantId"] = erpActualSale.TechnicalHeader.TenantID;
            _repositoryService.UpdateActualSales(erpActualSale);
            return Ok();
        }

        [AllowAnonymous]
        [Route("ProcessPlannedSales")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Produces("application/json")]
        [HttpPost]
        public async Task<IActionResult> ProcessPlannedSales(ErpPlannedSalesResponseEvent erpPlannedSales)
        {
            eventBus.StoreState("planned_sales_erp", erpPlannedSales);

            HttpContext.Items["CurrentTenantId"] = erpPlannedSales.TechnicalHeader.TenantID;
            _repositoryService.UpdatePlannedSales(erpPlannedSales);
            return Ok();
        }

        [AllowAnonymous]
        [Route("ProcessCommercialQuotation")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Produces("application/json")]
        [HttpPost]
        public async Task<IActionResult> ProcessCommercialQuotation(CommercialQuotationResponseEventV1 commercialQuotation)
        {
          //  await eventBus.StoreState("commercial_quote_erp", commercialQuotation);

            HttpContext.Items["CurrentTenantId"] = commercialQuotation.TechnicalHeader.TenantID;

            //Without Chunk
            if (commercialQuotation.CommercialQuotation.Data.Length < QuotationConstants.FileLength)
            {
                CommercialQuotationResponseEvent obj = new CommercialQuotationResponseEvent()
                {
                    TechnicalHeader =new RequestTechnicalHeader {
                        TenantID=commercialQuotation.TechnicalHeader.TenantID,
                        CompanyCode = commercialQuotation.TechnicalHeader.CompanyCode,
                        EmailAddress = commercialQuotation.TechnicalHeader.EmailAddress,
                        RequestID = commercialQuotation.TechnicalHeader.RequestID,
                        Timestamp = commercialQuotation.TechnicalHeader.Timestamp,
                    },
                    CommercialQuotation = new CommercialQuotation()
                    {
                        ProjectID = commercialQuotation.CommercialQuotation.ProjectID,
                        ERPProjectID = commercialQuotation.CommercialQuotation.ERPProjectID,
                        OfferID = commercialQuotation.CommercialQuotation.OfferID,
                        ERPOfferID = commercialQuotation.CommercialQuotation.ERPOfferID,
                        QuotationNumber = commercialQuotation.CommercialQuotation.QuotationNumber,
                        ContentType = commercialQuotation.CommercialQuotation.ContentType,
                        EncodingFormat = commercialQuotation.CommercialQuotation.EncodingFormat,
                        Data = commercialQuotation.CommercialQuotation.Data,
                        verion = commercialQuotation.CommercialQuotation.verion,
                        LayoutQuotationDetails = commercialQuotation.CommercialQuotation.LayoutQuotationDetails
                    }
                };
                await _repositoryService.AddCommercialQuotation(obj);
            }
            else
                //With Chunk
                await _repositoryService.AddCommercialQuotationV1(commercialQuotation);

            return Ok();
        }

        [AllowAnonymous]
        [Route("ProcessCommercialQuotationV1")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Produces("application/json")]
        [HttpPost]
        public async Task<IActionResult> ProcessCommercialQuotationV1(CommercialQuotationResponseEventV1 commercialQuotation)
        {
            await eventBus.StoreState("commercial_quote_erp", commercialQuotation);

            HttpContext.Items["CurrentTenantId"] = commercialQuotation.TechnicalHeader.TenantID;

            await _repositoryService.AddCommercialQuotationV1(commercialQuotation);
            return Ok();
        }

        [Route("deleteopportunity")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [Authorize(Roles = "Offer.Delete")]
        [HttpPost]
        public ActionResult DeleteOpportunity([FromBody] DeleteOpportunityDTO deleteOpportunity)
        {
            var result = _repositoryService.DeleteOpprtunity(deleteOpportunity);
            if (result.Result == true)
            {
                return Ok(new JsonResult("Opportunity Deleted Successfully"));
            }
            else
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Failed to delete Opportunity");

            }
        }
        [Route("offerassign")]
        [Authorize(Roles = "Offer.Write,Offer.Edit")]
        [HttpPost]
        public ActionResult AssignOffer([FromBody] EditOfferDTO update)
        {
            try
            {
                var result = _repositoryService.AssignOffer(update);
                return Ok(new JsonResult(result.Result));
            }
            catch (Exception)
            {

                return BadRequest("Internal Server Error");
            }
        }
        /// <summary>
        /// Project effort metrics
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("{dataRange}/dailymetrics")]
        [Authorize(Roles = "Offer.Write,Offer.Edit")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [Produces("application/json")]
        public IActionResult GetOfferDailyMetrics(string dataRange)
        {
            try
            {
                var result = _repositoryService.GetOfferDailyEffortMetrics(dataRange);
                if (result == null)
                {
                    return new JsonResult("No Data Found") { StatusCode = StatusCodes.Status404NotFound };
                }
                return new JsonResult(result) { StatusCode = StatusCodes.Status200OK };
            }
            catch (Exception ex)
            {
                return null;
            }
        }
    }
}
