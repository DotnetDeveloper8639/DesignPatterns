﻿using EventBus.Abstractions;

namespace Offer.API.IntegrationEvents.Events
{
    public class ErpCalculatedHourResponseEvent
    {
        public RequestTechnicalHeader TechnicalHeader { get; set; }
        public ErpCalculatedOffer Offer { get; set; }
    }
}
