﻿using EventBus.Abstractions;
using System.Collections.Generic;

namespace Offer.API.IntegrationEvents.Events
{
    public class WbsResponseEvent
    {
        public RequestTechnicalHeader TechnicalHeader { get; set; }
        public WbsResponseOffer Offer { get; set; }
    }

    public class WbsResponseMachine
    {
        public string MachineID { get; set; }
        public string WBSID { get; set; }
    }

    public class WbsResponseMachinesDetails
    {
        public List<WbsResponseMachine> Machines { get; set; } = new List<WbsResponseMachine>();
    }

    public class WbsResponseService
    {
        public string ServiceID { get; set; }
        public string WBSID { get; set; }
        public WbsResponseMachinesDetails MachineDetails { get; set; } = new WbsResponseMachinesDetails();
    }

    public class WbsResponseOffer
    {
        public string OpportunityID { get; set; }
        public string OfferID { get; set; }
        public string WBSID { get; set; }
        public string ProjectID { get; set; }
        public string ERPProjectID { get; set; }
        public string ValidityDate { get; set; }
        public List<WbsResponseService> Services { get; set; } = new List<WbsResponseService>();
    }
}
