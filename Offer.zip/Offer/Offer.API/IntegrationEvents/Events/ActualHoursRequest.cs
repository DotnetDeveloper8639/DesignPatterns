﻿using EventBus.Abstractions;
using EventBus.Events;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json.Serialization;
using System.Threading.Tasks;

namespace Offer.API.IntegrationEvents.Events
{
    public class ActualHoursRequest : IntegrationEvent
    {
        [JsonPropertyName("TechnicalHeader")]
        public RequestTechnicalHeader TechnicalHeader { get; set; }
        [JsonPropertyName("Order")]
        public Order Order { get; set; }
    }

    public class Order
    {
        [JsonPropertyName("OrderID")]
        public string OrderID { get; set; }
        [JsonPropertyName("ERPOrderID")]
        public string ERPOrderID { get; set; }
        [JsonPropertyName("ProjectID")]
        public string ProjectID { get; set; }
        [JsonPropertyName("ERP_Project_ID")]
        public string ERP_Project_ID { get; set; }
        [JsonPropertyName("Services")]
        public List<ServiceRequest> Services { get; set; }

        public Order(string orderID, string erpOrderID, string projectID, string erp_Project_ID, List<ServiceRequest> services)
        {
            OrderID = orderID;
            ERPOrderID = erpOrderID;
            ProjectID = projectID;
            ERP_Project_ID = erp_Project_ID;
            Services = services;
        }
    }
    public class Machine
    {
        [JsonPropertyName("MachineID")]
        public string MachineID { get; set; }
        [JsonPropertyName("WBSID")]
        public string WBSID { get; set; }
        [JsonPropertyName("ActualHours")]
        public decimal ActualHours { get; set; }
        [JsonPropertyName("Action")]
        public string Action { get; set; }
    }
    public class MachineDetails
    {
        [JsonPropertyName("Machines")]
        public List<Machine> Machines { get; set; }

        public MachineDetails(List<Machine> machines)
        {
            Machines = machines;
        }
    }
    public class ServiceRequest
    {
        [JsonPropertyName("ServiceID")]
        public string ServiceID { get; set; }
        [JsonPropertyName("WBSID")]
        public string WBSID { get; set; }
        [JsonPropertyName("ActualHours")]
        public int ActualHours { get; set; }
        [JsonPropertyName("MachineDetails")]
        public MachineDetails MachineDetails { get; set; }

        public ServiceRequest(string serviceID, string wbsid, int actualHours, MachineDetails machinesDetails)
        {
            ServiceID = serviceID;
            WBSID = wbsid;
            ActualHours = actualHours;
            MachineDetails = machinesDetails;
        }
    }
}
