﻿using EventBus.Abstractions;
using EventBus.Events;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Offer.API.IntegrationEvents.Events
{
    public class ServiceMaterialRequestEvent
    {
        public RequestTechnicalHeader TechnicalHeader { get; set; }
        public List<Material> Materials { get; set; }
    }
    public class TechnicalHeader
    {
        public string TenantID { get; set; }
        public string CompanyCode { get; set; }
        public string EmailAddress { get; set; }
        public string RequestID { get; set; }
        public DateTime Timestamp { get; set; }
    }

    public class Description
    {
        public string LanguageCode { get; set; }
        public string Value { get; set; }
        public string SalesText { get; set; }
    }

    public class Material
    {
        public string ServiceProductID { get; set; }
        public List<Description> Descriptions { get; set; }
    }
}
