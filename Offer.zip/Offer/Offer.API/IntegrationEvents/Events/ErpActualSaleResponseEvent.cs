﻿using EventBus.Abstractions;
using System.Collections.Generic;

namespace Offer.API.IntegrationEvents.Events
{
    public class ErpActualSaleResponseEvent
    {
        public RequestTechnicalHeader TechnicalHeader { get; set; }
        public ErpActualSales ActualSales { get; set; }
    }

    public class ErpActualSaleMachine
    {
        public string MachineID { get; set; }
        public string WBSID { get; set; }
        public string CostType { get; set; }
        public string Currency { get; set; }
        public string ActualSaleValue { get; set; }
    }

    public class ErpActualSaleMachineDetails
    {
        public List<ErpActualSaleMachine> Machines { get; set; }
    }

    public class ErpActualSaleService
    {
        public string ServiceID { get; set; }
        public string WBSID { get; set; }
        public string CostType { get; set; }
        public string Currency { get; set; }
        public string ActualSaleValue { get; set; }
        public ErpActualSaleMachineDetails MachineDetails { get; set; }
    }

    public class ErpActualSales
    {
        public List<ErpActualSaleService> Services { get; set; }
    }
}
