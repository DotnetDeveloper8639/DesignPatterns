﻿using EventBus.Abstractions;
using System.Collections.Generic;

namespace Offer.API.IntegrationEvents.Events
{
    public class ErpPlannedCostResponseEvent
    {
        public RequestTechnicalHeader TechnicalHeader { get; set; }
        public ErpPlannedCost PlannedCost { get; set; }
    }

    public class ErpPlannedCost
    {
        public List<ErpServiceCost> Services { get; set; }
    }
}
