﻿using System.Collections.Generic;

namespace Offer.API.IntegrationEvents.Events
{

    public class ErpSubCost
    {
        public string Quantity { get; set; }
        public string Unit { get; set; }
        public string Cost { get; set; }
        public string Description { get; set; }
    }

    public class ErpCalculatedMachine
    {
        public string MachineID { get; set; }
        public string WBSID { get; set; }
        public string CalculatedHours { get; set; }
        public string Currency { get; set; }
        public string ItemCost { get; set; }
        public List<ErpSubCost> SubCost { get; set; }
    }

    public class ErpCalculatedMachinesDetails
    {
        public List<ErpCalculatedMachine> Machines { get; set; }
    }

    public class ErpCalculatedService
    {
        public string ServiceID { get; set; }
        public string WBSID { get; set; }
        public string TotalSumInHours { get; set; }
        public string TotalCalculatedCost { get; set; }
        public string CalculatedHours { get; set; }
        public ErpCalculatedMachinesDetails MachineDetails { get; set; }
        public string ItemID { get; set; }
    }

    public class ErpCalculatedOffer
    {
        public string OfferID { get; set; }
        public string WBSID { get; set; }
        public string ProjectID { get; set; }
        public string ERPProjectID { get; set; }
        public List<ErpCalculatedService> Services { get; set; }
    }
}
