﻿using EventBus.Abstractions;
using System.Collections.Generic;

namespace Offer.API.IntegrationEvents.Events
{
    public class ErpPlannedSalesResponseEvent
    {
        public RequestTechnicalHeader TechnicalHeader { get; set; }
        public ErpPlannedSales PlannedSale { get; set; }
    }

    public class ErpPlannedSaleMachine
    {
        public string MachineID { get; set; }
        public string WBSID { get; set; }
        public string CostType { get; set; }
        public string Currency { get; set; }
        public string PlannedSaleValue { get; set; }
    }

    public class ErpPlannedSalesMachineDetails
    {
        public List<ErpPlannedSaleMachine> Machines { get; set; }
    }

    public class ErpPlannedSalesService
    {
        public string ServiceID { get; set; }
        public string WBSID { get; set; }
        public string CostType { get; set; }
        public string Currency { get; set; }
        public string PlannedSaleValue { get; set; }
        public ErpPlannedSalesMachineDetails MachineDetails { get; set; }
    }

    public class ErpPlannedSales
    {
        public List<ErpPlannedSalesService> Services { get; set; }
    }
}
