﻿using EventBus.Abstractions;
using EventBus.Events;
using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Offer.API.IntegrationEvents.Events
{
    public class WbsUpdateRequestEvent : IntegrationEvent
    {
        [JsonPropertyName("TechnicalHeader")]
        public RequestTechnicalHeader TechnicalHeader { get; set; }
        [JsonPropertyName("Offer")]
        public WbsUpdateRequestOffer Offer { get; set; }
    }

    public class WbsUpdateMachine
    {
        public string MachineName { get; set; }
        public string MachineID { get; set; }
        public string Type { get; set; }
        public string SerialNumber { get; set; }
        public string AssetNumber { get; set; }
        public string Manufacturer { get; set; }
        public string Description { get; set; }
        public string Action { get; set; }
        public decimal EstimatedHours { get; set; }
        public string WBSID { get; set; }
    }

    public class WbsUpdateRequestMachineDetails
    {
        public List<WbsUpdateMachine> Machines { get; set; }
    }

    public class WbsUpdateRequestOffer
    {
        public string OfferID { get; set; }
        public string WBSID { get; set; }
        public string ERPProjectID { get; set; }
        public string ProjectID { get; set; }
        public string CustomerName { get; set; }
        public string ContactPerson { get; set; }
        public string ContactNumber { get; set; }
        public string ContactEmail { get; set; }
        public string Status { get; set; }
        public string QuoteType { get; set; }
        public string ValidityDate { get; set; }
        public List<WbsUpdateRequestService> Services { get; set; }
    }

    public class WbsUpdateRequestService
    {
        public string ServiceID { get; set; }
        public string ServiceProductID { get; set; }
        public string Type { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string Location { get; set; }
        public string Region { get; set; }
        public string ContactPerson { get; set; }
        public string ContactNumber { get; set; }
        public string ContactEmail { get; set; }
        public string Action { get; set; }
        public string Description { get; set; }
        public decimal TotalSumInHours { get; set; }
        public WbsUpdateRequestMachineDetails MachineDetails { get; set; }
    }
}
