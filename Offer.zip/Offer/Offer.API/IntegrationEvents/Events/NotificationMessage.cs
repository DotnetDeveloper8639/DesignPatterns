﻿//using AzureMessageBus;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;

//namespace Offer.API.IntegrationEvents.Events
//{
//    public class NotificationMessage : BaseMessage
//    {
//        public string Message { get; set; }
//    }
//}
