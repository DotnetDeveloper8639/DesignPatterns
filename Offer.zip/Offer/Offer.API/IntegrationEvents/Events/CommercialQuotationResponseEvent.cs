﻿using EventBus.Abstractions;
using Newtonsoft.Json;
using System;

namespace Offer.API.IntegrationEvents.Events
{
    public class CommercialQuotationResponseEvent
    {
        public RequestTechnicalHeader TechnicalHeader { get; set; }
        public CommercialQuotation CommercialQuotation { get; set; }
    }

    public class CommercialQuotation
    {
        public string Id { get; set; }
        public string ProjectID { get; set; }
        public string ERPProjectID { get; set; }
        public string OfferID { get; set; }
        public string ERPOfferID { get; set; }
        public string QuotationNumber { get; set; }

        //[JsonProperty("Content-Type")]
        public string ContentType { get; set; }
        public string EncodingFormat { get; set; }
        public string Data { get; set; }
        public string verion { get; set; }
        public string LayoutQuotationDetails { get; set; }
    }

    public class CommercialQuotationResponseEventV1
    {
        public RequestTechnicalHeader TechnicalHeader { get; set; }
        public CommercialQuotationChunk CommercialQuotation { get; set; }
    }

    public class CommercialQuotationChunk
    {
        public string Id { get; set; }
        public string ProjectID { get; set; }
        public string ERPProjectID { get; set; }
        public string OfferID { get; set; }
        public string QuotationNumber { get; set; }
        public string ContentType { get; set; }
        public string EncodingFormat { get; set; }
        public string Data { get; set; }
        public string CurrentChunkNumber { get; set; }
        public string NextChunkNumber { get; set; }
        public string TotalChunk { get; set; }

        public string ERPOfferID { get; set; }
        public string verion { get; set; }
        public string LayoutQuotationDetails { get; set; }
    }
}
