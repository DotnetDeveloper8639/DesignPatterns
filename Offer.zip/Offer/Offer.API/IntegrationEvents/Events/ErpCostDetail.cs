﻿using System.Collections.Generic;

namespace Offer.API.IntegrationEvents.Events
{
    public class ErpMachineCost
    {
        public string MachineID { get; set; }
        public string WBSID { get; set; }
        public string CostType { get; set; }
        public string Currency { get; set; }
        public string CurrentValue { get; set; }
    }

    public class ErpMachineCostDetails
    {
        public List<ErpMachineCost> Machines { get; set; }
    }

    public class ErpServiceCost
    {
        public string ServiceID { get; set; }
        public string WBSID { get; set; }
        public string CostType { get; set; }
        public string Currency { get; set; }
        public string CurrentValue { get; set; }
        public ErpMachineCostDetails MachineDetails { get; set; }
    }
}
