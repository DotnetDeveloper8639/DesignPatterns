﻿using EventBus.Abstractions;
using System.Collections.Generic;

namespace Offer.API.IntegrationEvents.Events
{
    public class ErpActualCostResponseEvent
    {
        public RequestTechnicalHeader TechnicalHeader { get; set; }
        public ErpPlannedCost ActualCost { get; set; }
    }

    public class ErpActualCost
    {
        public List<ErpServiceCost> Services { get; set; }
    }
}
