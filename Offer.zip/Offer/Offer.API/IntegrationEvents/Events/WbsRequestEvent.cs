﻿using EventBus.Abstractions;
using EventBus.Events;
using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Offer.API.IntegrationEvents.Events
{
    public class WbsRequestEvent : IntegrationEvent
    {
        [JsonPropertyName("TechnicalHeader")]
        public RequestTechnicalHeader TechnicalHeader { get; set; }

        [JsonPropertyName("Offer")]
        public WbsOffer Offer { get; set; }
    }

    public class WbsMachine
    {
        public string MachineName { get; set; }
        public string MachineID { get; set; }
        public string Type { get; set; }
        public string SerialNumber { get; set; }
        public string AssetNumber { get; set; }
        public string Manufacturer { get; set; }
        public string Description { get; set; }
        public string Action { get; set; }
        public decimal EstimatedHours { get; set; }
    }

    public class WbsMachinesDetails
    {
        public List<WbsMachine> Machines { get; set; } = new List<WbsMachine>();
    }

    public class WbsService
    {
        public string ServiceID { get; set; }
        public string ServiceProductID { get; set; }
        public string Type { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string Location { get; set; }
        public string Region { get; set; }
        public string ContactPerson { get; set; }
        public string ContactNumber { get; set; }
        public string ContactEmail { get; set; }
        public string Action { get; set; }
        public string Description { get; set; }
        public decimal TotalSumInHours { get; set; }
        public WbsMachinesDetails MachineDetails { get; set; } = new WbsMachinesDetails();
    }

    public class WbsOffer
    {
        public string OfferID { get; set; }
        public string ProjectID { get; set; }
        public string ERPProjectID { get; set; }
        public string CustomerName { get; set; }
        public string ContactPerson { get; set; }
        public string ContactNumber { get; set; }
        public string ContactEmail { get; set; }
        public string Status { get; set; }
        public string QuoteType { get; set; }
        public string ValidityDate { get; set; }
        public List<WbsService> Services { get; set; } = new List<WbsService>();
    }
}
