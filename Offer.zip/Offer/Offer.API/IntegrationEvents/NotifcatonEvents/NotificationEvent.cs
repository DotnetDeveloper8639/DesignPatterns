﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Offer.API.IntegrationEvents.NotifcatonEvents
{
    public class NotificationEvent
    {
        public string Message { get; set; }
    }
}
