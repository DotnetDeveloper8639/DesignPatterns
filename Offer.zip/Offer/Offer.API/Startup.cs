using EventBus;
using EventBus.Abstractions;
using EventBus.Extensions;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Identity.Web;
using Microsoft.IdentityModel.Tokens;
using Offer.API.DbContextClass;
using Offer.API.Extensions;
using Offer.API.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Tenant.Service;

namespace Offer.API
{
    public class Startup
    {
        readonly string corsPolicy = "CORSPolicy";
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            // services.AddControllers();
            services.AddControllers(options =>
                {
                    var jsonInputFormatter = options.InputFormatters
                        .OfType<Microsoft.AspNetCore.Mvc.Formatters.SystemTextJsonInputFormatter>()
                        .Single();
                    jsonInputFormatter.SupportedMediaTypes.Add("application/csp-report");
                }
            );
            services.AddTransient<OfferApiRatelimitMiddleware>();

            //var daprJsonSerializer = new System.Text.Json.JsonSerializerOptions()
            //{
            //    PropertyNamingPolicy = null,
            //});

            //daprJsonSerializer.Converters.Clear();
            //daprJsonSerializer.Converters.Add(new BlueprintJsonConverter<T>() { IgnoreBaseProperty = true });

            services.AddDaprClient(config =>
            config.UseJsonSerializationOptions(new System.Text.Json.JsonSerializerOptions()
            {
                PropertyNamingPolicy = null,
            }));

            services.AddTransient<IOfferStatusService, OfferStatusService>();
            services.AddTransient<IMasterMachineService, MasterMachineService>();
            services.AddTransient<IRoadMapService, RoadMapService>();
            services.AddTransient<IAzureSearchService, AzureSearchService>();
            services.AddTransient<IService, Service>();
            services.AddTransient<IOpportunityService, OpportunityService>();
            services.AddSingleton<IEventBus, DaprEventBus>();
           
            services.AddDataProtection();

            services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme).AddJwtBearer(options =>
            {
                options.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidateLifetime = true,
                    ValidateIssuerSigningKey = true,
                    ValidIssuer = Environment.GetEnvironmentVariable("TOKEN_SERVER"),
                    ValidAudience = "blueprint-api",
                    IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(Environment.GetEnvironmentVariable("JWT_KEY")))
                };
            });

            // adds an authorization policy to make sure the token is for scope 'api1'
           services.AddAuthorization(options =>
           {
               options.AddPolicy("ApiScope", policy =>
               {
                   policy.RequireAuthenticatedUser();
                   policy.RequireClaim(ClaimTypes.Role);
                   policy.RequireClaim(ClaimConstants.TenantId);
               });
           });

           services.AddSwaggerGen(options =>
            {
                options.SwaggerDoc("v2", new Microsoft.OpenApi.Models.OpenApiInfo
                {
                    Title = "Offer Service API",
                });
            });

            services.AddCors(options =>
            {
                options.AddPolicy(name: corsPolicy,
                                  builder =>
                                  {
                                      builder.AllowAnyOrigin()
                                      .AllowAnyMethod()
                                      .AllowAnyHeader();
                                  });
            });
            //services.AddDbContext<Sch_Context>(options =>
            // options.UseSqlServer(Configuration.GetConnectionString("AzureConnection")));

            services.AddDbContext<Sch_Context>(ServiceLifetime.Scoped);

            services.AddAutoMapper(typeof(Startup));

            services.AddHttpContextAccessor();
            services.RegisterTenantService(Configuration);
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseCors(corsPolicy);
            app.UseRouting();

            app.UseSwagger(options =>
            {
                options.RouteTemplate = "offer/swagger/{documentName}/swagger.json";
            });

            app.UseSwaggerUI(options =>
            {
                options.SwaggerEndpoint("/offer/swagger/v2/swagger.json", "Offer Service API");
                options.RoutePrefix = "offer/swagger";
            });

            app.UseAuthentication();
            app.UseAuthorization();
            //Api Rate limit
            app.UseMiddleware<OfferApiRatelimitMiddleware>(100, TimeSpan.FromMinutes(1));

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
