﻿namespace Offer.API.Helper
{
    public class ResponseVM
    {
        public bool flag { get; set; }
        public string message { get; set; }
        public int statusCode { get; set; }
        public dynamic response { get; set; }
        public ResponseVM(bool Flag, string Message, int StatusCode, dynamic Response)
        {
            flag = Flag;
            message = Message;
            statusCode = StatusCode;
            response = Response;
        }
    }
}
