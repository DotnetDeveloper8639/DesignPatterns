﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Offer.API.Helper
{
    public static class OfferDataRange
    {
        public const string WEEK = "week";
        public const string MONTH = "month";
        public const string DAY = "day";
    }
}
