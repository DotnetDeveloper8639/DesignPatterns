﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Offer.API.Helper
{
    public static class MachineStatus
    {
        public static string NOT_CONFIGURED = "Roadmap NC";
        public static string NOT_STARTED = "Not Started";
        public static string IN_PROGRESS = "In Progress";
        public static string COMPLETED = "Completed";
    }
}
