﻿namespace Offer.API.Helper
{
    public static class MessageConstants
    {
        public static string ErrorMessage = "Error occured while fetching the data";
        public static string EditErrorMessage = "Error occured while editing the data";
        public static string FailedToSaveData = "Failed to save data";
        public static string SUCCESS = "Success";
        public static string UPDATED = "Data updated ";
        public static string ERROR = "Error";
        public static string LIST_CAN_NOT_BE_EMPTY = "List Can't be empty";
    }
    public static class QuotationConstants
    {
        public static int FileLength = 200000;
        public static string EditErrorMessage = "Error occured while editing the data";
        public static string FailedToSaveData = "Failed to save data";
    }
}
