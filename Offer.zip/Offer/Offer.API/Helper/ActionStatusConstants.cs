﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Offer.API.Helper
{
    public static class ActionStatusConstants
    {
        public const string ADD = "Add";
        public const string UPDATE = "Update";
        public const string DELETE = "Delete";
    }
}
