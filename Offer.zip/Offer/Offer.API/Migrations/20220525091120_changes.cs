﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Offer.API.Migrations
{
    public partial class changes : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_tblCounterMeasures_tblUser_user_id",
                table: "tblCounterMeasures");

            migrationBuilder.DropForeignKey(
                name: "FK_tblInitialHazardsMaster_tblUser_user_id",
                table: "tblInitialHazardsMaster");

            migrationBuilder.DropIndex(
                name: "IX_tblInitialHazardsMaster_user_id",
                table: "tblInitialHazardsMaster");

            migrationBuilder.DropIndex(
                name: "IX_tblCounterMeasures_user_id",
                table: "tblCounterMeasures");

            migrationBuilder.AddColumn<string>(
                name: "TblUserid",
                table: "tblInitialHazardsMaster",
                type: "nvarchar(50)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "TblUserid",
                table: "tblCounterMeasures",
                type: "nvarchar(50)",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_tblInitialHazardsMaster_TblUserid",
                table: "tblInitialHazardsMaster",
                column: "TblUserid");

            migrationBuilder.CreateIndex(
                name: "IX_tblCounterMeasures_TblUserid",
                table: "tblCounterMeasures",
                column: "TblUserid");

            migrationBuilder.AddForeignKey(
                name: "FK_tblCounterMeasures_tblUsers_TblUserid",
                table: "tblCounterMeasures",
                column: "TblUserid",
                principalTable: "tblUsers",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_tblInitialHazardsMaster_tblUsers_TblUserid",
                table: "tblInitialHazardsMaster",
                column: "TblUserid",
                principalTable: "tblUsers",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_tblCounterMeasures_tblUsers_TblUserid",
                table: "tblCounterMeasures");

            migrationBuilder.DropForeignKey(
                name: "FK_tblInitialHazardsMaster_tblUsers_TblUserid",
                table: "tblInitialHazardsMaster");

            migrationBuilder.DropIndex(
                name: "IX_tblInitialHazardsMaster_TblUserid",
                table: "tblInitialHazardsMaster");

            migrationBuilder.DropIndex(
                name: "IX_tblCounterMeasures_TblUserid",
                table: "tblCounterMeasures");

            migrationBuilder.DropColumn(
                name: "TblUserid",
                table: "tblInitialHazardsMaster");

            migrationBuilder.DropColumn(
                name: "TblUserid",
                table: "tblCounterMeasures");

            migrationBuilder.CreateIndex(
                name: "IX_tblInitialHazardsMaster_user_id",
                table: "tblInitialHazardsMaster",
                column: "user_id");

            migrationBuilder.CreateIndex(
                name: "IX_tblCounterMeasures_user_id",
                table: "tblCounterMeasures",
                column: "user_id");

            migrationBuilder.AddForeignKey(
                name: "FK_tblCounterMeasures_tblUser_user_id",
                table: "tblCounterMeasures",
                column: "user_id",
                principalTable: "tblUser",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_tblInitialHazardsMaster_tblUser_user_id",
                table: "tblInitialHazardsMaster",
                column: "user_id",
                principalTable: "tblUser",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
