﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Offer.API.Migrations
{
    public partial class tblsadded : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "tblActualHours",
                columns: table => new
                {
                    id = table.Column<string>(type: "nvarchar(50)", nullable: false),
                    service_machine_id = table.Column<string>(type: "varchar(50)", nullable: true),
                    actualhours = table.Column<int>(type: "int", nullable: false),
                    user_id = table.Column<string>(type: "varchar(50)", nullable: true),
                    comments = table.Column<string>(type: "varchar(1000)", nullable: true),
                    created_at = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: false),
                    created_by = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    modified_at = table.Column<DateTimeOffset>(type: "datetimeoffset(7)", nullable: false),
                    modified_by = table.Column<string>(type: "nvarchar(50)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblActualHours", x => x.id);
                });

            migrationBuilder.CreateTable(
                name: "tblMachineKPI",
                columns: table => new
                {
                    id = table.Column<string>(type: "nvarchar(50)", nullable: false),
                    service_machine_id = table.Column<string>(type: "varchar(50)", nullable: true),
                    plannedcost = table.Column<int>(type: "int", nullable: false),
                    actualcost = table.Column<int>(type: "int", nullable: false),
                    plannedsales = table.Column<string>(type: "varchar(50)", nullable: true),
                    actualsales = table.Column<string>(type: "varchar(50)", nullable: true),
                    calculatedhours = table.Column<int>(type: "int", nullable: false),
                    actualaggregatedhours = table.Column<int>(type: "int", nullable: false),
                    created_at = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: false),
                    created_by = table.Column<string>(type: "nvarchar(50)", nullable: true),
                    modified_at = table.Column<DateTimeOffset>(type: "datetimeoffset(7)", nullable: false),
                    modified_by = table.Column<string>(type: "nvarchar(50)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_tblMachineKPI", x => x.id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "tblActualHours");

            migrationBuilder.DropTable(
                name: "tblMachineKPI");
        }
    }
}
