﻿using AutoMapper;
using Offer.API.EntityModels;
using Offer.API.IntegrationEvents.Events;
using Offer.API.Models.OfferDTO;
using System;

namespace Offer.API
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<CreateOfferDTO, WbsOffer>()
                .ForMember(dest => dest.OfferID, source => source.MapFrom(prop => prop.Offer.offer_id))
                .ForMember(dest => dest.QuoteType, source => source.MapFrom(prop => prop.Offer.quote_type))
                .ForMember(dest => dest.ProjectID, source => source.MapFrom(prop => string.Empty))
                .ForMember(dest => dest.Status, source => source.MapFrom(prop => prop.Offer.status))
                .ForMember(dest => dest.ValidityDate, source => source.MapFrom(prop => string.Empty))
                .ForMember(dest => dest.ContactEmail, source => source.MapFrom(prop => prop.Contact.email_address))
                .ForMember(dest => dest.ContactNumber, source => source.MapFrom(prop => prop.Contact.phone_number))
                .ForMember(dest => dest.ContactPerson, source => source.MapFrom(prop => prop.Contact.display_name))
                .ForMember(dest => dest.CustomerName, source => source.MapFrom(prop => prop.Customer.customer_name));
                //.ReverseMap();

            CreateMap<ServiceDTO, WbsService>()
                .ForMember(dest => dest.ServiceID, source => source.MapFrom(prop => prop.id))
                .ForMember(dest => dest.ServiceProductID, source => source.MapFrom(prop => string.Empty))
                .ForMember(dest => dest.TotalSumInHours, source => source.MapFrom(prop => prop.actual_hours))
                .ForMember(dest => dest.StartDate, source => source.MapFrom(prop => prop.start_date))
                .ForMember(dest => dest.EndDate, source => source.MapFrom(prop => prop.end_date))
                .ForMember(dest => dest.Region, source => source.MapFrom(prop => prop.service_region))
                //.ForMember(dest => dest.ContactEmail, source => source.MapFrom(prop => prop.Item2.contactModel.email_address))
                //.ForMember(dest => dest.ContactNumber, source => source.MapFrom(prop => prop.Item2.contactModel.phone_number))
                //.ForMember(dest => dest.ContactPerson, source => source.MapFrom(prop => prop.Item2.contactModel.display_name))
                .ForMember(dest => dest.Description, source => source.MapFrom(prop => prop.service_description))
                .ForMember(dest => dest.Location, source => source.MapFrom(prop => prop.service_location))
                .ForMember(dest => dest.Type, source => source.MapFrom(prop => string.Empty))
                .ForMember(dest => dest.Action, source => source.MapFrom(prop => "ADD"));

            CreateMap<MachineDTO, WbsMachine>()
                .ForMember(dest => dest.MachineID, source => source.MapFrom(prop => prop.id))
                .ForMember(dest => dest.MachineName, source => source.MapFrom(prop => prop.machine_name))
                .ForMember(dest => dest.EstimatedHours, source => source.MapFrom(prop => prop.estimated_hours))
                .ForMember(dest => dest.Description, source => source.MapFrom(prop => prop.machine_description))
                .ForMember(dest => dest.Type, source => source.MapFrom(prop => prop.machine_type))
                .ForMember(dest => dest.Action, source => source.MapFrom(prop => "ADD"))
                .ForMember(dest => dest.SerialNumber, source => source.MapFrom(prop => prop.serial_number))
                .ForMember(dest => dest.AssetNumber, source => source.MapFrom(prop => prop.asset_id))
                .ForMember(dest => dest.Manufacturer, source => source.MapFrom(prop => string.Empty)); //TODO: Confirm and change
                                                                                                       //.ForSourceMember(source => source.id,dest => dest.)
                                                                                                       //.ReverseMap();

            CreateMap<CommercialQuotation, TblCommercialQuotation>()
                .ForMember(dest => dest.project_id, source => source.MapFrom(prop => prop.ProjectID))
                .ForMember(dest => dest.content_type, source => source.MapFrom(prop => prop.ContentType))
                .ForMember(dest => dest.encoding_format, source => source.MapFrom(prop => prop.EncodingFormat))
                .ForMember(dest => dest.data, source => source.MapFrom(prop => prop.Data))
                .ForMember(dest => dest.erp_project_id, source => source.MapFrom(prop => prop.ERPProjectID))
                .ForMember(dest => dest.offer_id, source => source.MapFrom(prop => prop.OfferID))
                .ReverseMap();

        }
    }
}
