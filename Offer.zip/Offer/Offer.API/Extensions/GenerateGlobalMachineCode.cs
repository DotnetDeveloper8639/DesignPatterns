﻿using Microsoft.EntityFrameworkCore;
using Offer.API.DbContextClass;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Offer.API.Extensions
{
    public class GenerateGlobalMachineCode
    {
        private readonly Sch_Context _context;
        public GenerateGlobalMachineCode(Sch_Context context)
        {
            _context = context;
        }
        public GenerateGlobalMachineCode()
        {

        }
        public async Task<string> GetRecentMachineCode()
        {
            var isDuplicateGMId = await _context.TblMachines
                .OrderByDescending(o => o.global_id != null)
                .ThenByDescending(o => o.created_at)
                .FirstOrDefaultAsync();
            return isDuplicateGMId?.global_id;
        }
    }
}
