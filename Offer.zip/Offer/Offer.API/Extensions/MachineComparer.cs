﻿using Offer.API.Models.OfferDTO;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;

namespace Offer.API.Extensions
{
    public class MachineComparer : IEqualityComparer<GetMachineDto>
    {
        public bool Equals(GetMachineDto listA, GetMachineDto listB)
        {
            return listA.Id == listB.Id;
        }

        public int GetHashCode([DisallowNull] GetMachineDto obj)
        {
            return obj.Id.GetHashCode();
        }
    }
}
